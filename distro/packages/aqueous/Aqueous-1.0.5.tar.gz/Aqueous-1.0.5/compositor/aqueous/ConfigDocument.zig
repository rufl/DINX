const std = @import("std");
const instance = @import("Instance.zig");

const max_config_bytes = 1024 * 1024;

pub const Document = struct {
    allocator: std.mem.Allocator,
    source: []u8,

    pub const Table = struct {
        index: usize,
        name: []const u8,
        repeated: bool,
    };

    pub const Entry = struct {
        index: usize,
        table_index: usize,
        key: []const u8,
        value: []const u8,
    };

    pub const ResolvedRaw = struct {
        section: []const u8,
        value: []const u8,
    };

    pub fn init(allocator: std.mem.Allocator, source: []const u8) !Document {
        return .{
            .allocator = allocator,
            .source = try allocator.dupe(u8, source),
        };
    }

    pub fn read(allocator: std.mem.Allocator, path: []const u8) !Document {
        const io = std.Io.Threaded.global_single_threaded.io();
        const source = std.Io.Dir.readFileAlloc(
            std.Io.Dir.cwd(),
            io,
            path,
            allocator,
            .limited(max_config_bytes),
        ) catch |err| switch (err) {
            error.FileNotFound => return init(allocator, ""),
            else => return err,
        };
        return .{ .allocator = allocator, .source = source };
    }

    pub fn deinit(self: *Document) void {
        self.allocator.free(self.source);
        self.* = undefined;
    }

    pub fn tables(self: *const Document, allocator: std.mem.Allocator) ![]Table {
        var result = std.ArrayList(Table).empty;
        errdefer result.deinit(allocator);
        try result.append(allocator, .{
            .index = 0,
            .name = "",
            .repeated = false,
        });

        var offset: usize = 0;
        while (offset < self.source.len) {
            const end = lineEnd(self.source, offset);
            if (parseHeader(cleanLine(self.source[offset..end]))) |header| {
                try result.append(allocator, .{
                    .index = result.items.len,
                    .name = header.name,
                    .repeated = header.repeated,
                });
            }
            offset = nextLine(self.source, end);
        }
        return result.toOwnedSlice(allocator);
    }

    pub fn entries(self: *const Document, allocator: std.mem.Allocator) ![]Entry {
        var result = std.ArrayList(Entry).empty;
        errdefer result.deinit(allocator);
        var table_index: usize = 0;
        var entry_index: usize = 0;
        var offset: usize = 0;

        while (offset < self.source.len) {
            const end = lineEnd(self.source, offset);
            const line = cleanLine(self.source[offset..end]);
            if (parseHeader(line) != null) {
                table_index += 1;
            } else if (assignment(line)) |item| {
                try result.append(allocator, .{
                    .index = entry_index,
                    .table_index = table_index,
                    .key = item.key,
                    .value = item.value,
                });
                entry_index += 1;
            }
            offset = nextLine(self.source, end);
        }
        return result.toOwnedSlice(allocator);
    }

    pub fn getRaw(self: *const Document, section: []const u8, key: []const u8) ?[]const u8 {
        var current_section: []const u8 = "";
        var result: ?[]const u8 = null;
        var offset: usize = 0;
        while (offset < self.source.len) {
            const end = lineEnd(self.source, offset);
            const line = cleanLine(self.source[offset..end]);
            if (parseHeader(line)) |header| {
                current_section = header.name;
            } else if (std.mem.eql(u8, current_section, section)) {
                if (assignment(line)) |item| {
                    if (std.mem.eql(u8, item.key, key)) result = item.value;
                }
            }
            offset = nextLine(self.source, end);
        }
        return result;
    }

    /// Resolve a key using compositor parse order across a canonical section
    /// and its accepted aliases. The last assignment wins.
    pub fn getRawAliases(self: *const Document, section: []const u8, aliases: []const []const u8, key: []const u8) ?ResolvedRaw {
        var current_section: []const u8 = "";
        var current_matches = false;
        var result: ?ResolvedRaw = null;
        var offset: usize = 0;
        while (offset < self.source.len) {
            const end = lineEnd(self.source, offset);
            const line = cleanLine(self.source[offset..end]);
            if (parseHeader(line)) |header| {
                current_section = header.name;
                current_matches = sectionMatches(header.name, section, aliases);
            } else if (current_matches) {
                if (assignment(line)) |item| {
                    if (std.mem.eql(u8, item.key, key)) result = .{ .section = current_section, .value = item.value };
                }
            }
            offset = nextLine(self.source, end);
        }
        return result;
    }

    pub fn countSections(self: *const Document, section: []const u8, aliases: []const []const u8) usize {
        var count: usize = 0;
        var offset: usize = 0;
        while (offset < self.source.len) {
            const end = lineEnd(self.source, offset);
            if (parseHeader(cleanLine(self.source[offset..end]))) |header| {
                if (!header.repeated and sectionMatches(header.name, section, aliases)) count += 1;
            }
            offset = nextLine(self.source, end);
        }
        return count;
    }

    pub fn setEntryRaw(self: *Document, wanted: usize, encoded_value: []const u8) !void {
        var entry_index: usize = 0;
        var offset: usize = 0;
        while (offset < self.source.len) {
            const end = lineEnd(self.source, offset);
            const raw_line = self.source[offset..end];
            const without_comment = withoutComment(raw_line);
            const trimmed = std.mem.trim(u8, without_comment, " \t\r");
            if (parseHeader(trimmed) == null and assignment(trimmed) != null) {
                if (entry_index == wanted) {
                    const equal = indexUnquoted(without_comment, '=').?;
                    var value_start = equal + 1;
                    while (value_start < without_comment.len and
                        (without_comment[value_start] == ' ' or without_comment[value_start] == '\t'))
                    {
                        value_start += 1;
                    }
                    const value = std.mem.trimEnd(
                        u8,
                        without_comment[value_start..],
                        " \t\r",
                    );
                    try self.replace(
                        offset + value_start,
                        offset + value_start + value.len,
                        encoded_value,
                    );
                    return;
                }
                entry_index += 1;
            }
            offset = nextLine(self.source, end);
        }
        return error.EntryNotFound;
    }

    pub fn deleteEntry(self: *Document, wanted: usize) !void {
        var entry_index: usize = 0;
        var offset: usize = 0;
        while (offset < self.source.len) {
            const end = lineEnd(self.source, offset);
            const line = cleanLine(self.source[offset..end]);
            if (parseHeader(line) == null and assignment(line) != null) {
                if (entry_index == wanted) {
                    try self.replace(offset, nextLine(self.source, end), "");
                    return;
                }
                entry_index += 1;
            }
            offset = nextLine(self.source, end);
        }
        return error.EntryNotFound;
    }

    pub fn deleteTableEntry(self: *Document, table_index: usize, key: []const u8) !bool {
        const all_entries = try self.entries(self.allocator);
        defer self.allocator.free(all_entries);
        var wanted: ?usize = null;
        for (all_entries) |entry| {
            if (entry.table_index == table_index and std.mem.eql(u8, entry.key, key)) wanted = entry.index;
        }
        if (wanted) |entry_index| {
            try self.deleteEntry(entry_index);
            return true;
        }
        return false;
    }

    pub fn deleteTable(self: *Document, wanted: usize) !void {
        if (wanted == 0) return error.CannotDeleteRootTable;
        var table_index: usize = 0;
        var start: ?usize = null;
        var offset: usize = 0;
        while (offset < self.source.len) {
            const end = lineEnd(self.source, offset);
            if (parseHeader(cleanLine(self.source[offset..end])) != null) {
                table_index += 1;
                if (table_index == wanted) start = offset else if (start != null) {
                    try self.replace(start.?, offset, "");
                    return;
                }
            }
            offset = nextLine(self.source, end);
        }
        if (start) |table_start| {
            try self.replace(table_start, self.source.len, "");
            return;
        }
        return error.TableNotFound;
    }

    /// Move one complete table block before or after another table while
    /// preserving every byte inside both blocks.
    pub fn moveTable(self: *Document, wanted: usize, target: usize, after: bool) !void {
        if (wanted == 0 or target == 0 or wanted == target) return error.InvalidTableMove;
        const wanted_bounds = self.tableBounds(wanted) orelse return error.TableNotFound;
        const target_bounds = self.tableBounds(target) orelse return error.TableNotFound;
        const wanted_block = self.source[wanted_bounds[0]..wanted_bounds[1]];

        var updated = std.ArrayList(u8).empty;
        errdefer updated.deinit(self.allocator);
        try updated.ensureTotalCapacity(self.allocator, self.source.len);
        if (wanted_bounds[0] < target_bounds[0]) {
            if (!after) return error.InvalidTableMove;
            try updated.appendSlice(self.allocator, self.source[0..wanted_bounds[0]]);
            try updated.appendSlice(self.allocator, self.source[wanted_bounds[1]..target_bounds[1]]);
            try updated.appendSlice(self.allocator, wanted_block);
            try updated.appendSlice(self.allocator, self.source[target_bounds[1]..]);
        } else {
            if (after) return error.InvalidTableMove;
            try updated.appendSlice(self.allocator, self.source[0..target_bounds[0]]);
            try updated.appendSlice(self.allocator, wanted_block);
            try updated.appendSlice(self.allocator, self.source[target_bounds[0]..wanted_bounds[0]]);
            try updated.appendSlice(self.allocator, self.source[wanted_bounds[1]..]);
        }
        const owned = try updated.toOwnedSlice(self.allocator);
        self.allocator.free(self.source);
        self.source = owned;
    }

    /// Exact block bytes, including comments, for helper-owned batch editing.
    pub fn tableSource(self: *const Document, wanted: usize) ?[]const u8 {
        if (wanted == 0) {
            const first = self.tableBounds(1) orelse return self.source;
            return self.source[0..first[0]];
        }
        const bounds = self.tableBounds(wanted) orelse return null;
        return self.source[bounds[0]..bounds[1]];
    }

    fn tableBounds(self: *const Document, wanted: usize) ?[2]usize {
        var table_index: usize = 0;
        var start: ?usize = null;
        var offset: usize = 0;
        while (offset < self.source.len) {
            const end = lineEnd(self.source, offset);
            if (parseHeader(cleanLine(self.source[offset..end])) != null) {
                table_index += 1;
                if (table_index == wanted) start = offset else if (start != null) return .{ start.?, offset };
            }
            offset = nextLine(self.source, end);
        }
        if (start) |table_start| return .{ table_start, self.source.len };
        return null;
    }

    pub fn addToTable(
        self: *Document,
        wanted: usize,
        key: []const u8,
        encoded_value: []const u8,
    ) !void {
        var table_index: usize = 0;
        var found = wanted == 0;
        var insertion = self.source.len;
        var offset: usize = 0;
        while (offset < self.source.len) {
            const end = lineEnd(self.source, offset);
            if (parseHeader(cleanLine(self.source[offset..end])) != null) {
                table_index += 1;
                if (found) {
                    insertion = offset;
                    break;
                }
                if (table_index == wanted) found = true;
            }
            offset = nextLine(self.source, end);
        }
        if (!found) return error.TableNotFound;

        const prefix = if (insertion > 0 and self.source[insertion - 1] != '\n') "\n" else "";
        const line = try std.fmt.allocPrint(
            self.allocator,
            "{s}{s} = {s}\n",
            .{ prefix, key, encoded_value },
        );
        defer self.allocator.free(line);
        try self.replace(insertion, insertion, line);
    }

    pub fn setRaw(
        self: *Document,
        section: []const u8,
        key: []const u8,
        encoded_value: []const u8,
    ) !void {
        const all_tables = try self.tables(self.allocator);
        defer self.allocator.free(all_tables);
        const all_entries = try self.entries(self.allocator);
        defer self.allocator.free(all_entries);

        var table_index: ?usize = null;
        for (all_tables) |table| {
            if (!table.repeated and std.mem.eql(u8, table.name, section)) {
                table_index = table.index;
            }
        }
        if (table_index) |index| {
            var found_entry: ?usize = null;
            for (all_entries) |entry| {
                if (entry.table_index == index and std.mem.eql(u8, entry.key, key)) {
                    found_entry = entry.index;
                }
            }
            if (found_entry) |index_to_set| {
                try self.setEntryRaw(index_to_set, encoded_value);
            } else try self.addToTable(index, key, encoded_value);
            return;
        }

        const header = try std.fmt.allocPrint(self.allocator, "[{s}]", .{section});
        defer self.allocator.free(header);
        try self.appendTable(header, key, encoded_value);
    }

    /// Update the section that currently supplies this key. If the key is not
    /// configured, use the last existing alias section; create the canonical
    /// section only when no equivalent section exists.
    pub fn setRawAliases(
        self: *Document,
        section: []const u8,
        aliases: []const []const u8,
        key: []const u8,
        encoded_value: []const u8,
    ) !void {
        if (self.getRawAliases(section, aliases, key)) |resolved| {
            return self.setRaw(resolved.section, key, encoded_value);
        }
        const all_tables = try self.tables(self.allocator);
        defer self.allocator.free(all_tables);
        var target: ?[]const u8 = null;
        for (all_tables) |table| {
            if (!table.repeated and sectionMatches(table.name, section, aliases)) target = table.name;
        }
        return self.setRaw(target orelse section, key, encoded_value);
    }

    pub fn appendTable(
        self: *Document,
        header: []const u8,
        key: []const u8,
        encoded_value: []const u8,
    ) !void {
        if (parseHeader(header) == null) return error.InvalidTableHeader;
        const first_newline = if (self.source.len > 0 and self.source[self.source.len - 1] != '\n') "\n" else "";
        const blank_line = if (self.source.len > 0) "\n" else "";
        const block = try std.fmt.allocPrint(
            self.allocator,
            "{s}{s}{s}\n{s} = {s}\n",
            .{ first_newline, blank_line, header, key, encoded_value },
        );
        defer self.allocator.free(block);
        try self.replace(self.source.len, self.source.len, block);
    }

    pub fn write(self: *const Document, path: []const u8) !void {
        const io = std.Io.Threaded.global_single_threaded.io();
        var atomic_file = try std.Io.Dir.cwd().createFileAtomic(io, path, .{
            .make_path = true,
            .replace = true,
        });
        defer atomic_file.deinit(io);
        try atomic_file.file.writeStreamingAll(io, self.source);
        try atomic_file.file.sync(io);
        try atomic_file.replace(io);
    }

    fn replace(self: *Document, start: usize, end: usize, replacement: []const u8) !void {
        var updated = std.ArrayList(u8).empty;
        errdefer updated.deinit(self.allocator);
        try updated.ensureTotalCapacity(
            self.allocator,
            self.source.len - (end - start) + replacement.len,
        );
        try updated.appendSlice(self.allocator, self.source[0..start]);
        try updated.appendSlice(self.allocator, replacement);
        try updated.appendSlice(self.allocator, self.source[end..]);
        const owned = try updated.toOwnedSlice(self.allocator);
        self.allocator.free(self.source);
        self.source = owned;
    }
};

pub const ConfigFiles = struct {
    pub const File = struct {
        name: []const u8,
        path: []u8,
        document: Document,
        dirty: bool = false,

        fn open(allocator: std.mem.Allocator, name: []const u8, path: []u8) !File {
            errdefer allocator.free(path);
            return .{
                .name = name,
                .path = path,
                .document = try Document.read(allocator, path),
            };
        }

        fn deinit(self: *File, allocator: std.mem.Allocator) void {
            self.document.deinit();
            allocator.free(self.path);
        }
    };

    allocator: std.mem.Allocator,
    items: [6]File,

    pub fn init(allocator: std.mem.Allocator) !ConfigFiles {
        const wm_path = try resolveWmPath(allocator);
        var wm = try File.open(allocator, "wm.toml", wm_path);
        errdefer wm.deinit(allocator);

        const layout_path = try resolveLayoutPath(
            allocator,
            wm.document.getRaw("layout", "path"),
            wm.path,
        );
        var layout = try File.open(allocator, "layout.toml", layout_path);
        errdefer layout.deinit(allocator);

        const input_path = try resolveInputPath(
            allocator,
            wm.document.getRaw("input", "path"),
        );
        var input = try File.open(allocator, "input.toml", input_path);
        errdefer input.deinit(allocator);

        const outputs_path = try resolveOutputsPath(allocator);
        var outputs = try File.open(allocator, "outputs.toml", outputs_path);
        errdefer outputs.deinit(allocator);

        const rules_path = try resolveRulesPath(
            allocator,
            wm.document.getRaw("rules", "path"),
        );
        var rules = try File.open(allocator, "rules.toml", rules_path);
        errdefer rules.deinit(allocator);

        const appearance_path = try resolveAppearancePath(allocator);
        var appearance = try File.open(allocator, "appearance.toml", appearance_path);
        errdefer appearance.deinit(allocator);

        return .{
            .allocator = allocator,
            .items = .{ wm, layout, input, outputs, rules, appearance },
        };
    }

    pub fn deinit(self: *ConfigFiles) void {
        for (&self.items) |*file| file.deinit(self.allocator);
        self.* = undefined;
    }

    pub fn save(self: *ConfigFiles) !void {
        for (&self.items) |*file| {
            if (!file.dirty) continue;
            try file.document.write(file.path);
            file.dirty = false;
        }
    }

    pub fn reload(self: *ConfigFiles) !void {
        for (&self.items) |*file| {
            const replacement = try Document.read(self.allocator, file.path);
            file.document.deinit();
            file.document = replacement;
            file.dirty = false;
        }
    }
};

const Header = struct { name: []const u8, repeated: bool };
const Assignment = struct { key: []const u8, value: []const u8 };

fn parseHeader(line: []const u8) ?Header {
    if (line.len >= 5 and std.mem.startsWith(u8, line, "[[") and std.mem.endsWith(u8, line, "]]")) {
        const name = std.mem.trim(u8, line[2 .. line.len - 2], " \t");
        return if (name.len == 0) null else .{ .name = name, .repeated = true };
    }
    if (line.len >= 3 and line[0] == '[' and line[line.len - 1] == ']') {
        const name = std.mem.trim(u8, line[1 .. line.len - 1], " \t");
        return if (name.len == 0) null else .{ .name = name, .repeated = false };
    }
    return null;
}

fn sectionMatches(value: []const u8, canonical: []const u8, aliases: []const []const u8) bool {
    if (std.mem.eql(u8, value, canonical)) return true;
    for (aliases) |alias| if (std.mem.eql(u8, value, alias)) return true;
    return false;
}

fn assignment(line: []const u8) ?Assignment {
    const equal = indexUnquoted(line, '=') orelse return null;
    const key = unquote(std.mem.trim(u8, line[0..equal], " \t"));
    if (key.len == 0) return null;
    return .{
        .key = key,
        .value = std.mem.trim(u8, line[equal + 1 ..], " \t\r"),
    };
}

fn lineEnd(source: []const u8, start: usize) usize {
    return std.mem.indexOfScalarPos(u8, source, start, '\n') orelse source.len;
}

fn nextLine(source: []const u8, end: usize) usize {
    return if (end < source.len) end + 1 else source.len;
}

fn cleanLine(line: []const u8) []const u8 {
    return std.mem.trim(u8, withoutComment(line), " \t\r");
}

fn withoutComment(line: []const u8) []const u8 {
    return line[0 .. indexUnquoted(line, '#') orelse line.len];
}

fn indexUnquoted(text: []const u8, needle: u8) ?usize {
    var quote: ?u8 = null;
    var escaped = false;
    for (text, 0..) |byte, index| {
        if (escaped) {
            escaped = false;
            continue;
        }
        if (quote != null and byte == '\\' and quote.? == '"') {
            escaped = true;
            continue;
        }
        if (byte == '"' or byte == '\'') {
            if (quote == byte) quote = null else if (quote == null) quote = byte;
            continue;
        }
        if (quote == null and byte == needle) return index;
    }
    return null;
}

fn unquote(value: []const u8) []const u8 {
    if (value.len >= 2 and ((value[0] == '"' and value[value.len - 1] == '"') or
        (value[0] == '\'' and value[value.len - 1] == '\'')))
    {
        return value[1 .. value.len - 1];
    }
    return value;
}

fn resolveWmPath(allocator: std.mem.Allocator) ![]u8 {
    const home = getenv("HOME");
    if (getenv("AQUEOUS_CONFIG")) |path| return expandHome(allocator, path, home);
    if (try existingUserPath(allocator, "wm.toml")) |path| return path;
    if (exists("/etc/xdg/" ++ instance.name ++ "/wm.toml")) return allocator.dupe(u8, "/etc/xdg/" ++ instance.name ++ "/wm.toml");
    return userPath(allocator, "wm.toml");
}

fn resolveLayoutPath(
    allocator: std.mem.Allocator,
    configured_raw: ?[]const u8,
    wm_path: []const u8,
) ![]u8 {
    const home = getenv("HOME");
    if (home) |base| {
        const path = try std.fmt.allocPrint(allocator, "{s}/.config/" ++ instance.name ++ "/layout.toml", .{base});
        if (exists(path)) return path;
        allocator.free(path);
    }
    if (getenv("AQUEOUS_LAYOUT")) |path| return expandHome(allocator, path, home);
    if (configured_raw) |raw| {
        const configured = unquote(raw);
        if (configured.len > 0) {
            if (configured[0] == '~' or std.fs.path.isAbsolute(configured)) {
                return expandHome(allocator, configured, home);
            }
            return std.fs.path.join(allocator, &.{ std.fs.path.dirname(wm_path) orelse ".", configured });
        }
    }
    if (getenv("XDG_CONFIG_HOME")) |xdg| {
        const path = try std.fmt.allocPrint(allocator, "{s}/" ++ instance.name ++ "/layout.toml", .{xdg});
        if (exists(path)) return path;
        allocator.free(path);
    }
    if (exists("/etc/xdg/" ++ instance.name ++ "/layout.toml")) return allocator.dupe(u8, "/etc/xdg/" ++ instance.name ++ "/layout.toml");
    return userPath(allocator, "layout.toml");
}

fn resolveInputPath(allocator: std.mem.Allocator, configured_raw: ?[]const u8) ![]u8 {
    const home = getenv("HOME");
    if (getenv("AQUEOUS_INPUT")) |path| return expandHome(allocator, path, home);
    if (configured_raw) |raw| {
        const configured = unquote(raw);
        if (configured.len > 0) return expandHome(allocator, configured, home);
    }
    if (try existingUserPath(allocator, "input.toml")) |path| return path;
    if (exists("/etc/xdg/" ++ instance.name ++ "/input.toml")) return allocator.dupe(u8, "/etc/xdg/" ++ instance.name ++ "/input.toml");
    return userPath(allocator, "input.toml");
}

fn resolveOutputsPath(allocator: std.mem.Allocator) ![]u8 {
    const home = getenv("HOME");
    if (getenv("AQUEOUS_OUTPUTS")) |path| return expandHome(allocator, path, home);
    // Match the helper's historical outputs.toml location when no override is
    // supplied. The session launcher seeds the packaged template there.
    return userPath(allocator, "outputs.toml");
}

fn resolveRulesPath(allocator: std.mem.Allocator, configured_raw: ?[]const u8) ![]u8 {
    const home = getenv("HOME");
    if (getenv("AQUEOUS_RULES")) |path| return expandHome(allocator, path, home);
    if (configured_raw) |raw| {
        const configured = unquote(raw);
        if (configured.len > 0) return expandHome(allocator, configured, home);
    }
    if (try existingUserPath(allocator, "rules.toml")) |path| return path;
    return userPath(allocator, "rules.toml");
}

fn resolveAppearancePath(allocator: std.mem.Allocator) ![]u8 {
    const home = getenv("HOME");
    if (getenv("AQUEOUS_APPEARANCE")) |path| return expandHome(allocator, path, home);
    return userPath(allocator, "appearance.toml");
}

fn existingUserPath(allocator: std.mem.Allocator, filename: []const u8) !?[]u8 {
    if (getenv("XDG_CONFIG_HOME")) |xdg| {
        const path = try std.fmt.allocPrint(allocator, "{s}/" ++ instance.name ++ "/{s}", .{ xdg, filename });
        if (exists(path)) return path;
        allocator.free(path);
    }
    if (getenv("HOME")) |home| {
        const path = try std.fmt.allocPrint(allocator, "{s}/.config/" ++ instance.name ++ "/{s}", .{ home, filename });
        if (exists(path)) return path;
        allocator.free(path);
    }
    return null;
}

pub fn userPath(allocator: std.mem.Allocator, filename: []const u8) ![]u8 {
    if (getenv("XDG_CONFIG_HOME")) |xdg| {
        return std.fmt.allocPrint(allocator, "{s}/" ++ instance.name ++ "/{s}", .{ xdg, filename });
    }
    if (getenv("HOME")) |home| {
        return std.fmt.allocPrint(allocator, "{s}/.config/" ++ instance.name ++ "/{s}", .{ home, filename });
    }
    return error.ConfigPathUnavailable;
}

fn expandHome(allocator: std.mem.Allocator, path: []const u8, home: ?[]const u8) ![]u8 {
    if (path.len > 0 and path[0] == '~') {
        const base = home orelse return error.HomeUnavailable;
        return std.fmt.allocPrint(allocator, "{s}{s}", .{ base, path[1..] });
    }
    return allocator.dupe(u8, path);
}

fn getenv(name: [*:0]const u8) ?[]const u8 {
    const value = std.c.getenv(name) orelse return null;
    const result = std.mem.span(value);
    return if (result.len == 0) null else result;
}

fn exists(path: []const u8) bool {
    const io = std.Io.Threaded.global_single_threaded.io();
    std.Io.Dir.cwd().access(io, path, .{}) catch return false;
    return true;
}

test "document enumerates ordinary and repeated tables" {
    var document = try Document.init(std.testing.allocator,
        \\root = 1
        \\[blur]
        \\enabled = true
        \\[[window]]
        \\app_id = "one"
        \\[[window]]
        \\app_id = "two"
    );
    defer document.deinit();
    const tables = try document.tables(std.testing.allocator);
    defer std.testing.allocator.free(tables);
    const entries = try document.entries(std.testing.allocator);
    defer std.testing.allocator.free(entries);

    try std.testing.expectEqual(@as(usize, 4), tables.len);
    try std.testing.expect(tables[2].repeated);
    try std.testing.expectEqualStrings("window", tables[3].name);
    try std.testing.expectEqual(@as(usize, 4), entries.len);
    try std.testing.expectEqual(@as(usize, 3), entries[3].table_index);
}

test "document edits entries and repeated tables without losing comments" {
    var document = try Document.init(std.testing.allocator,
        \\# keep
        \\[blur]
        \\enabled = true # comment
        \\[[window]]
        \\app_id = "game"
    );
    defer document.deinit();

    try document.setEntryRaw(0, "false");
    try document.addToTable(2, "fullscreen", "true");
    try document.appendTable("[[window]]", "title", "\"Dialog\"");
    try std.testing.expect(std.mem.indexOf(u8, document.source, "enabled = false # comment") != null);
    try std.testing.expect(std.mem.indexOf(u8, document.source, "fullscreen = true") != null);
    try std.testing.expect(std.mem.indexOf(u8, document.source, "title = \"Dialog\"") != null);
    try std.testing.expect(std.mem.startsWith(u8, document.source, "# keep"));
}

test "document deletes one entry and one repeated table" {
    var document = try Document.init(std.testing.allocator,
        \\[one]
        \\a = 1
        \\b = 2
        \\[[item]]
        \\name = "first"
        \\[[item]]
        \\name = "second"
    );
    defer document.deinit();

    try document.deleteEntry(1);
    try document.deleteTable(2);
    try std.testing.expect(std.mem.indexOf(u8, document.source, "b = 2") == null);
    try std.testing.expect(std.mem.indexOf(u8, document.source, "first") == null);
    try std.testing.expect(std.mem.indexOf(u8, document.source, "second") != null);
}

test "document resolves and updates aliased sections in parse order" {
    var document = try Document.init(std.testing.allocator,
        \\[layout.options.float]
        \\placement = "cascade"
        \\[layout.options.stacking]
        \\placement = "center"
    );
    defer document.deinit();

    const aliases = &.{ "layout.options.float", "layout.options.floating", "layout.options.stack" };
    const resolved = document.getRawAliases("layout.options.stacking", aliases, "placement").?;
    try std.testing.expectEqualStrings("layout.options.stacking", resolved.section);
    try std.testing.expectEqualStrings("\"center\"", resolved.value);
    try std.testing.expectEqual(@as(usize, 2), document.countSections("layout.options.stacking", aliases));

    try document.setRawAliases("layout.options.stacking", aliases, "placement", "\"minimal-overlap\"");
    try std.testing.expectEqualStrings("\"minimal-overlap\"", document.getRaw("layout.options.stacking", "placement").?);
    try std.testing.expectEqualStrings("\"cascade\"", document.getRaw("layout.options.float", "placement").?);
}

test "document moves complete repeated table blocks" {
    var document = try Document.init(std.testing.allocator,
        \\# keep
        \\[[window]]
        \\app_id = "one"
        \\# second
        \\[[window]]
        \\app_id = "two"
    );
    defer document.deinit();
    try document.moveTable(2, 1, false);
    const two = std.mem.indexOf(u8, document.source, "app_id = \"two\"").?;
    const one = std.mem.indexOf(u8, document.source, "app_id = \"one\"").?;
    try std.testing.expect(two < one);
    try std.testing.expect(std.mem.indexOf(u8, document.source, "# second") != null);
}

pub fn generation(files: *const ConfigFiles) [16]u8 {
    var state = std.hash.Wyhash.init(0x415155454f5553);
    for (files.items) |file| {
        state.update(file.path);
        state.update(&.{0});
        state.update(file.document.source);
        state.update(&.{0xff});
    }
    var buffer: [16]u8 = undefined;
    _ = std.fmt.bufPrint(&buffer, "{x:0>16}", .{state.final()}) catch unreachable;
    return buffer;
}

fn hashPart(hash: *std.crypto.hash.sha2.Sha256, bytes: []const u8) void {
    var size: [8]u8 = undefined;
    std.mem.writeInt(u64, &size, bytes.len, .big);
    hash.update(&size);
    hash.update(bytes);
}
pub fn candidateDigest(files: *const ConfigFiles) [64]u8 {
    var hash = std.crypto.hash.sha2.Sha256.init(.{});
    hashPart(&hash, "aqueous-candidate-v1");
    for (files.items) |file| {
        hashPart(&hash, file.name);
        hashPart(&hash, file.path);
        hashPart(&hash, file.document.source);
    }
    return std.fmt.bytesToHex(hash.finalResult(), .lower);
}

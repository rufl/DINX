// SPDX-FileCopyrightText: © 2026 Seafoam Labs
// SPDX-License-Identifier: GPL-3.0-only

const Output = @This();

var next_shell_id: u64 = 1;

const std = @import("std");
const build_options = @import("build_options");
const assert = std.debug.assert;
const math = std.math;
const mem = std.mem;
const posix = std.posix;
const fmt = std.fmt;
const pixman = @import("pixman");
const wlr = @import("wlroots");
const c = @import("c");
const wayland = @import("wayland");
const wl = wayland.server.wl;
const zwlr = wayland.server.zwlr;
const aqueous = wayland.server.aqueous;

const server = &@import("main.zig").server;
const util = @import("util.zig");
const scaling = @import("scaling");
const render_metrics = @import("render_metrics.zig");
const overlay_planes = @import("overlay_planes.zig");
const output_retry = @import("output_retry.zig");
const panel_orientation = @import("panel_orientation.zig");
const visual_state = @import("visual_state.zig");
pub const hdr = @import("output_hdr.zig");
const auto_hdr = @import("auto_hdr.zig");
const Scene = @import("Scene.zig");

const fx = @import("fx.zig");
const BlurPipeline = @import("render/BlurPipeline.zig");
const EffectMetadata = @import("render/EffectMetadata.zig");
const LayerSurface = @import("LayerSurface.zig");
const LayerShellOutput = @import("LayerShellOutput.zig");
const LockSurface = @import("LockSurface.zig");
const SceneNodeData = @import("SceneNodeData.zig");
const Window = @import("Window.zig");
const Workspace = @import("Workspace.zig");
const XdgPopup = @import("XdgPopup.zig");

const log = std.log.scoped(.output);
const Mirror = @import("OutputMirror.zig");

comptime {
    if (@sizeOf(wlr.Output.State) != @sizeOf(c.struct_wlr_output_state) or
        @alignOf(wlr.Output.State) != @alignOf(c.struct_wlr_output_state) or
        @offsetOf(wlr.Output.State, "buffer") != @offsetOf(c.struct_wlr_output_state, "buffer") or
        @offsetOf(wlr.Output.State, "image_description") != @offsetOf(c.struct_wlr_output_state, "image_description"))
    {
        @compileError("wlroots output-state ABI does not match the pinned Zig bindings");
    }
}

pub const State = struct {
    pub const PositionSource = enum {
        automatic,
        configuration,
        output_management,
    };

    state: enum {
        /// Powered on and exposed to the window manager
        enabled,
        /// Powered off and exposed to the window manager
        disabled_soft,
        /// Powered off and hidden from the window manager
        disabled_hard,
        /// Corresponding hardware no longer present
        destroying,
    },
    mirror_of: @import("wm/output/config.zig").Text = .{},
    /// Logical coordinate space
    x: i32,
    /// Logical coordinate space
    y: i32,
    /// The width/height of modes is in physical pixels, not in the
    /// compositors logical coordinate space.
    mode: union(enum) {
        standard: *wlr.Output.Mode,
        custom: struct {
            width: i32,
            height: i32,
            refresh: i32,
        },
        /// Used before the initial modeset and after the wlr_output is destroyed.
        none,
    },
    scale: f32,
    transform: wl.Output.Transform,
    /// Configured master preference; hardware state can differ under fullscreen policy.
    adaptive_sync: bool,
    fullscreen_only_adaptive_sync: bool = false,
    /// Enable the BT.2020/PQ HDR10 output profile.
    hdr_enabled: bool,
    /// Target peak luminance preset for the HDR10 mastering metadata.
    hdr_level: hdr.HdrLevel,
    /// SDR diffuse white luminance on the HDR output, in cd/m².
    sdr_white_level: f64,
    /// Expand SDR highlights toward the HDR peak (Auto HDR). Takes effect
    /// only while HDR is active and the effects build can draw the buffer.
    auto_hdr: bool,
    /// Auto HDR expansion strength, 0..1.
    auto_hdr_boost: f64,
    position_source: PositionSource,

    pub fn fromHeadState(state: *const wlr.OutputHeadV1.State) State {
        assert(state.enabled);
        const requested_scale: f32 = @floatCast(state.scale);
        const normalized_scale = scaling.normalizeScale(requested_scale);
        if (normalized_scale != requested_scale) {
            std.log.scoped(.output).info(
                "output {s}: scale {d} adjusted to {d}",
                .{ state.output.name, requested_scale, normalized_scale },
            );
        }
        return .{
            .state = .enabled,
            .mode = blk: {
                if (state.mode) |mode| {
                    break :blk .{ .standard = mode };
                } else {
                    break :blk .{ .custom = .{
                        .width = state.custom_mode.width,
                        .height = state.custom_mode.height,
                        .refresh = state.custom_mode.refresh,
                    } };
                }
            },
            .x = state.x,
            .y = state.y,
            .scale = normalized_scale,
            .transform = state.transform,
            .adaptive_sync = state.adaptive_sync_enabled,
            // wlr-output-management-v1 has no HDR field. Callers replacing
            // existing state through that protocol preserve this separately.
            .hdr_enabled = false,
            .hdr_level = .l1000,
            .sdr_white_level = hdr.default_sdr_white_level,
            .auto_hdr = false,
            .auto_hdr_boost = auto_hdr.default_boost,
            .position_source = .output_management,
        };
    }

    /// Width/height in the logical coordinate space
    pub fn dimensions(state: *const State) struct { u31, u31 } {
        var w: i32, var h: i32 = switch (state.mode) {
            .standard => |mode| .{ mode.width, mode.height },
            .custom => |mode| .{ mode.width, mode.height },
            .none => .{ 0, 0 },
        };
        if (@mod(@intFromEnum(state.transform), 2) != 0) {
            mem.swap(i32, &w, &h);
        }
        return .{
            scaling.logicalDimension(w, state.scale),
            scaling.logicalDimension(h, state.scale),
        };
    }

    /// Physical mode dimensions after applying the output transform.
    pub fn physicalDimensions(state: *const State) struct { i32, i32 } {
        var width: i32, var height: i32 = switch (state.mode) {
            .standard => |mode| .{ mode.width, mode.height },
            .custom => |mode| .{ mode.width, mode.height },
            .none => .{ 0, 0 },
        };
        if (@mod(@intFromEnum(state.transform), 2) != 0) mem.swap(i32, &width, &height);
        return .{ width, height };
    }

    pub fn box(state: *const State) wlr.Box {
        const w, const h = state.dimensions();
        return .{ .x = state.x, .y = state.y, .width = w, .height = h };
    }

    pub fn applyNoModeset(state: *const State, wlr_state: *wlr.Output.State) void {
        wlr_state.setScale(state.scale);
        wlr_state.setTransform(state.transform);
    }

    pub fn applyModeset(state: *const State, wlr_output: *wlr.Output, wlr_state: *wlr.Output.State, adaptive_sync: bool) bool {
        const enabled = state.state == .enabled;
        wlr_state.setEnabled(enabled);
        if (!enabled) return true;
        state.applyNoModeset(wlr_state);
        switch (state.mode) {
            .standard => |mode| wlr_state.setMode(mode),
            .custom => |mode| wlr_state.setCustomMode(mode.width, mode.height, mode.refresh),
            .none => {},
        }
        wlr_state.setAdaptiveSyncEnabled(adaptive_sync);
        return hdr.apply(wlr_output, state.hdr_enabled, state.hdr_level, state.sdr_white_level, wlr_state);
    }
};

const RenderingState = struct {
    tearing: bool,
    const init: RenderingState = .{
        .tearing = false,
    };
};

pub const RetryFault = struct {
    stage: output_retry.Stage = .scene_build,
    remaining: i32 = 0,
    disable_retry: bool = false,
    simulate_overlay: bool = false,
    simulate_color_pipeline: bool = false,
};

/// Requested policy is kept in State; these fields describe one runtime target.
adaptive_sync_policy: @import("adaptive_sync_policy.zig").State = .{},
adaptive_sync_commit_target: bool = false,
adaptive_sync_before: bool = false,
/// Diagnostic-only virtual backend, never enabled in a production build.
adaptive_sync_test: if (build_options.output_retry_testing) struct {
    enabled: bool = false,
    actual: bool = false,
    fail_next: bool = false,
    inactive: bool = false,
} else void = if (build_options.output_retry_testing) .{} else {},

/// Session-scoped identity, never reused after disconnect.
display_instance: u64 = 0,

/// Set to null when the wlr_output is destroyed.
shell_id: u64 = 0,
wlr_output: ?*wlr.Output,
scene_output: ?*wlr.SceneOutput,
mirror: Mirror = .{},
mirror_source_locked: bool = false,
mirror_scene: ?*wlr.Scene = null,
retry: output_retry.State = .{},
retry_timer: ?*wl.EventSource = null,
retry_timer_armed: bool = false,
render_commit_active: bool = false,
early_present: ?wlr.Output.event.Present = null,
retry_test: if (build_options.output_retry_testing) RetryFault else void = if (build_options.output_retry_testing) .{} else {},

/// One backend output layer and one caller-owned scene promotion state per
/// output. wlroots destroys the layer as part of wlr_output teardown.
overlay_layer: ?*c.struct_wlr_output_layer = null,
overlay_candidate: c.struct_wlr_scene_output_layer_candidate = std.mem.zeroes(c.struct_wlr_scene_output_layer_candidate),
overlay_state: overlay_planes.State = .{},

object: ?*aqueous.OutputV1 = null,
layer_shell: LayerShellOutput = .{},

/// Tracks the currently presented frame on the output as it pertains to ext-session-lock.
/// The output is initially considered blanked:
/// If using the DRM backend it will be blanked with the initial modeset.
/// If using the Wayland or X11 backend nothing will be visible until the first frame is rendered.
lock_render_state: enum {
    /// Submitted an unlocked buffer but the buffer has not yet been presented.
    pending_unlock,
    /// Normal, "unlocked" content may be visible.
    unlocked,
    /// Submitted a blank buffer but the buffer has not yet been presented.
    /// Normal, "unlocked" content may be visible.
    pending_blank,
    /// A blank buffer has been presented.
    blanked,
    /// Submitted the lock surface buffer but the buffer has not yet been presented.
    /// Normal, "unlocked" content may be visible.
    pending_lock_surface,
    /// The lock surface buffer has been presented.
    lock_surface,
} = .blanked,

/// Root.outputs
link: wl.list.Link,

/// Ordered list of workspaces belonging to this output.
workspaces: wl.list.Head(Workspace, .link),
/// The single workspace currently visible on this output.
active_workspace: ?*Workspace = null,

/// Workspace currently sliding out during a switch (null when not
/// transitioning). A non-null value is the single source of truth that a
/// workspace-swap slide animation is in flight on this output.
prev_workspace: ?*Workspace = null,
/// Sign of the slide direction during a transition: +1 means the incoming
/// workspace enters from the right (outgoing exits left), -1 the reverse.
transition_dir: i32 = 0,
/// True once `renderFinish` has actually armed the current workspace-swap
/// slide. Guards `finalizeTransition` against running before the (async)
/// windowing transaction has seeded/armed the participating windows, which
/// would otherwise cancel the transition before it visibly begins.
transition_armed: bool = false,

/// State to be sent to the wm in the next manage sequence.
scheduled: State,
/// State sent to the wm in the latest manage sequence.
sent: State,
link_sent: wl.list.Link,
sent_wl_output: bool = false,
/// The wl_output global for which `aqueous_output_v1.wl_output` was last sent.
/// Tracked so the event is re-sent if wlroots destroys and recreates the
/// global (e.g. on hotplug/modeset), which would otherwise leave the wm
/// client referencing a stale global name.
sent_wl_output_global: ?*wl.Global = null,
/// Rendering state requested by the window manager.
rendering_requested: RenderingState = .init,
/// State applied to the wlr_output and rendered.
current: State,
rendering_current: RenderingState = .init,

/// Monotonic timestamp (nanoseconds) of the previous frame, used to compute the
/// frame-rate-independent delta time for window position animations. 0 means no
/// previous frame has been recorded yet.
anim_last_ns: i64 = 0,

/// Backend-specific backdrop blur cache for this output. `blur_box` records
/// the geometry used to produce the cached texture so moves and modesets can
/// invalidate it without forcing regeneration on every frame.
blur_node: ?fx.OutputBlurCache = null,
blur_box: ?wlr.Box = null,
render_metric_sample: ?render_metrics.SceneSample = null,
effects_swapchain_path: bool = false,
blur_last_key: ?u64 = null,
blur_cache: if (build_options.vulkan_effects) BlurPipeline.OutputCache else void =
    if (build_options.vulkan_effects) .{} else {},

destroy: wl.Listener(*wlr.Output) = .init(handleDestroy),
request_state: wl.Listener(*wlr.Output.event.RequestState) = .init(handleRequestState),
frame: wl.Listener(*wlr.Output) = .init(handleFrame),
present: wl.Listener(*wlr.Output.event.Present) = .init(handlePresent),
commit: wl.Listener(*wlr.Output.event.Commit) = .init(handleCommit),
bind: wl.Listener(*wlr.Output.event.Bind) = .init(handleBind),

/// Stable identity used by the in-process policy. This is deliberately derived from the
/// output object's address only for the lifetime of the output; policy state is discarded
/// when the output no longer appears in a manage-cycle snapshot.
pub fn policyId(output: *const Output) u64 {
    return @intFromPtr(output);
}

fn boxesEqual(a: wlr.Box, b: wlr.Box) bool {
    return a.x == b.x and a.y == b.y and
        a.width == b.width and a.height == b.height;
}

/// Synchronize the output-local optimized blur node with the current output
/// state. Scene graph coordinates are logical, matching State.box().
pub fn syncBlur(output: *Output, force_dirty: bool) void {
    if (comptime !fx.blur_available) return;

    const active = server.wm.blur.enabled and
        server.wm.blur.radius > 0 and
        server.wm.blur.passes > 0 and
        output.current.state == .enabled and
        output.current.mode != .none;
    if (!active) {
        if (output.blur_node) |node| fx.setOptimizedBlurEnabled(node, false);
        if (comptime build_options.vulkan_effects) {
            output.blur_cache.clear(&server.vulkan_context.blur_pipeline);
        }
        // Re-enabling must regenerate the cached backdrop even if the output
        // returns with identical geometry.
        output.blur_box = null;
        return;
    }

    const box = output.current.box();
    if (box.width == 0 or box.height == 0) return;

    var created = false;
    if (output.blur_node == null) {
        output.blur_node = fx.createOptimizedBlur(
            server.scene.layers.wm,
            box.width,
            box.height,
        );
        created = output.blur_node != null;
    }

    const node = output.blur_node orelse return;
    const geometry_changed = if (output.blur_box) |old| !boxesEqual(old, box) else true;
    fx.configureOptimizedBlur(node, box, true, force_dirty or created or geometry_changed);
    output.blur_box = box;

    if (created or geometry_changed) {
        const name = if (output.wlr_output) |wlr_output| std.mem.span(wlr_output.name) else "unknown";
        log.debug("blur node for {s}: {d}x{d} at {d},{d}", .{
            name,
            box.width,
            box.height,
            box.x,
            box.y,
        });
    }
}

/// Propagate a background/bottom layer change to the active effects backend.
pub fn markBlurDirty(output: *Output) void {
    if (comptime !fx.blur_available) return;
    if (!server.wm.blur.enabled or output.current.state != .enabled) return;
    if (comptime build_options.vulkan_effects) {
        const wlr_output = output.wlr_output orelse return;
        wlr_output.scheduleFrame();
        return;
    }
    if (output.blur_node) |node| fx.markOptimizedBlurDirty(node);
}

/// Repaint appearance-only blur changes while retaining the cached blur source.
pub fn damageBlurAppearance(output: *Output) void {
    if (comptime !fx.blur_available) return;
    const scene_output = output.scene_output orelse return;
    scene_output.damage_ring.addWhole();
}

fn destroyBlur(output: *Output) void {
    if (comptime build_options.vulkan_effects) {
        output.blur_cache.deinit(&server.vulkan_context.blur_pipeline);
    }
    if (comptime !fx.blur_available) return;
    if (output.blur_node) |node| fx.destroyOptimizedBlur(node);
    output.blur_node = null;
    output.blur_box = null;
}

pub fn releaseVulkanBlurCache(output: *Output) void {
    if (comptime build_options.vulkan_effects) {
        output.blur_cache.clear(&server.vulkan_context.blur_pipeline);
    }
}

/// Scene-order changes alter which previously rendered windows are present at
/// each blur checkpoint even when every blur box is unchanged. Advance the
/// shared source generation so a focus-driven restack cannot reuse a cache
/// image captured under the old ordering.
pub fn invalidateBlurSources(output: *Output) void {
    if (comptime !fx.blur_available) return;
    if (!server.wm.blur.enabled or output.current.state != .enabled) return;
    const node = output.blur_node orelse return;

    // A generation mismatch rebuilds each complete cache domain. Damage those
    // same domains so the offscreen source is reconstructed under the new
    // scene order instead of sampling untouched pixels from the prior frame.
    var windows = server.wm.windows.iterator();
    while (windows.next()) |window| {
        output.damageBlurOwnerDomain(.{ .window = window });
    }
    var layers = server.layer_shell.surfaces.iterator();
    while (layers.next()) |surface| {
        output.damageBlurOwnerDomain(.{ .layer_surface = surface });
    }
    var popups = server.layer_shell.popups.iterator();
    while (popups.next()) |popup| {
        output.damageBlurOwnerDomain(.{ .popup = popup });
    }

    fx.markOptimizedBlurDirty(node);
}

fn damageBlurOwnerDomain(output: *Output, owner: BlurOwner) void {
    const blur = blurOwnerData(owner) orelse return;
    const effect = blurOwnerEffect(
        owner,
        blur,
        output.effectRenderState(),
    ) orelse return;
    var box: wlr.Box = .{
        .x = effect.box.x,
        .y = effect.box.y,
        .width = effect.box.width,
        .height = effect.box.height,
    };
    output.scene_output.?.damage_ring.addBox(&box);
}

fn finishRenderMetric(output: *Output) void {
    const wlr_output = output.wlr_output orelse return;
    if (output.render_metric_sample) |*sample| {
        sample.finish(std.mem.span(wlr_output.name));
        output.render_metric_sample = null;
    }
}

fn discardRenderMetric(output: *Output) void {
    if (output.render_metric_sample) |*sample| {
        sample.discard();
        output.render_metric_sample = null;
    }
}

/// Full output geometry exposed to the in-process policy.
pub fn policyFullBox(output: *const Output) wlr.Box {
    return output.scheduled.box();
}

/// Hard-disabled and destroyed outputs are absent from integrated-policy
/// snapshots. Soft-disabled outputs intentionally remain exposed to preserve
/// their workspace model while powered off.
pub fn policyExposed(output: *const Output) bool {
    return output.scheduled.mirror_of.empty() and (output.scheduled.state == .enabled or output.scheduled.state == .disabled_soft);
}

/// A pointer drag may only enter a visible, powered output.
pub fn policyTransferTarget(output: *const Output) bool {
    return output.policyExposed() and output.scheduled.state == .enabled and output.active_workspace != null;
}

/// Output geometry remaining after layer-shell exclusive zones are reserved.
pub fn policyUsableBox(output: *const Output) wlr.Box {
    const usable = output.layer_shell.scheduled.non_exclusive_area;
    if (usable.width > 0 and usable.height > 0) return usable;
    return output.policyFullBox();
}

pub fn policyName(output: *const Output) []const u8 {
    return if (output.wlr_output) |wlr_output| std.mem.span(wlr_output.name) else "";
}

pub const PolicyIdentity = struct {
    name: []const u8,
    make: ?[]const u8,
    model: ?[]const u8,
    serial: ?[]const u8,
};

pub fn policyIdentity(output: *const Output) PolicyIdentity {
    const wlr_output = output.wlr_output orelse return .{ .name = "", .make = null, .model = null, .serial = null };
    return .{
        .name = std.mem.span(wlr_output.name),
        .make = if (wlr_output.make) |value| std.mem.span(value) else null,
        .model = if (wlr_output.model) |value| std.mem.span(value) else null,
        .serial = if (wlr_output.serial) |value| std.mem.span(value) else null,
    };
}

pub fn policyActiveWorkspaceNumber(output: *Output) u32 {
    const active = output.active_workspace orelse return 0;
    var number: u32 = 1;
    var it = output.workspaces.iterator(.forward);
    while (it.next()) |workspace| : (number += 1) if (workspace == active) return number;
    return 0;
}

pub fn policyWorkspaceAt(output: *Output, requested: u32) ?*Workspace {
    if (requested == 0) return null;
    var number: u32 = 1;
    var it = output.workspaces.iterator(.forward);
    while (it.next()) |workspace| : (number += 1) if (number == requested) return workspace;
    return null;
}

pub fn policyWorkspaceActive(output: *const Output, workspace: ?*const Workspace) bool {
    return workspace == null or workspace == output.active_workspace;
}

pub fn policyTrace(output: *const Output, hasher: *std.hash.Wyhash) void {
    const name = if (output.wlr_output) |wlr_output| std.mem.span(wlr_output.name) else "";
    hasher.update(name);
    const workspace_id: u32 = if (output.active_workspace) |workspace| workspace.policyId() else 0;
    hasher.update(std.mem.asBytes(&workspace_id));
}

pub fn create(wlr_output: *wlr.Output) !void {
    const output = try util.gpa.create(Output);
    errdefer util.gpa.destroy(output);
    const retry_timer = try server.wl_server.getEventLoop().addTimer(*Output, handleRetryTimer, output);
    errdefer retry_timer.remove();

    {
        const title = try fmt.allocPrintSentinel(util.gpa, "river - {s}", .{wlr_output.name}, 0);
        defer util.gpa.free(title);
        if (wlr_output.isWl()) {
            wlr_output.wlSetAppId("river");
            wlr_output.wlSetTitle(title);
        } else if (wlr.config.has_x11_backend and wlr_output.isX11()) {
            wlr_output.x11SetTitle(title);
        }
    }

    if (!wlr_output.initRender(server.allocator, server.renderer)) return error.InitRenderFailed;
    try @import("render/Presentation.zig").configure(wlr_output);

    const scene_output = try server.scene.wlr_scene.createSceneOutput(wlr_output);
    errdefer comptime unreachable;

    const initial: State = .{
        .state = .disabled_hard,
        .x = 0,
        .y = 0,
        .mode = .none,
        .scale = 1,
        .transform = .normal,
        .adaptive_sync = wlr_output.adaptive_sync_status == .enabled,
        .hdr_enabled = false,
        .hdr_level = .l1000,
        .sdr_white_level = hdr.default_sdr_white_level,
        .auto_hdr = false,
        .auto_hdr_boost = auto_hdr.default_boost,
        .position_source = .automatic,
    };
    output.* = .{
        .shell_id = next_shell_id,
        .wlr_output = wlr_output,
        .scene_output = scene_output,
        .retry_timer = retry_timer,
        .scheduled = initial,
        .sent = initial,
        .current = initial,
        .link = undefined,
        .link_sent = undefined,
        .workspaces = undefined,
    };
    next_shell_id = std.math.add(u64, next_shell_id, 1) catch @panic("shell identity exhausted");

    if (server.overlay_planes_enabled and wlr_output.isDrm()) {
        output.overlay_layer = c.wlr_output_layer_create(@ptrCast(wlr_output));
        if (output.overlay_layer == null) {
            log.err("output {s}: failed to allocate DRM overlay layer", .{wlr_output.name});
        } else {
            log.info("output {s}: DRM overlay-plane promotion enabled", .{wlr_output.name});
        }
    } else if (server.overlay_planes_enabled) {
        log.warn(
            "output {s}: overlay-plane promotion unavailable on non-DRM backend",
            .{wlr_output.name},
        );
    }
    output.overlay_state.configure(server.overlay_planes_enabled, output.overlay_layer != null);
    output.overlay_state.trace_budget = overlayTraceBudget();
    wlr_output.data = output;
    output.installSceneHooks();

    server.om.outputs.append(output);
    output.link_sent.init();
    output.workspaces.init();
    output.ensureWorkspaces();

    server.om.next_display_instance += 1;
    output.display_instance = server.om.next_display_instance;
    server.om.display_revision += 1;
    server.om.warming.add(wlr_output, output.display_instance) catch {
        // No contract object means no native acquisition or legacy gamma grant.
        log.err("warming output registration failed for {s}", .{wlr_output.name});
    };
    wlr_output.events.destroy.add(&output.destroy);
    wlr_output.events.request_state.add(&output.request_state);
    wlr_output.events.frame.add(&output.frame);
    wlr_output.events.present.add(&output.present);
    wlr_output.events.commit.add(&output.commit);
    wlr_output.events.bind.add(&output.bind);

    output.scheduled.state = .enabled;
    if (wlr_output.preferredMode()) |preferred_mode| {
        output.scheduled.mode = .{ .standard = preferred_mode };
    } else {
        // The output does not support modes (i.e. we are not using the DRM backend)
        // Currently, wlroots does not make it possible for us know the dimensions
        // requested by the host compositor in the first configure event. Therefore,
        // we can't do anything but guess until the second configure is sent and
        // wlroots emits the wlr_output request_state event.
        // TODO(wlroots): fix this API limitation, for context see
        // https://gitlab.freedesktop.org/wlroots/wlroots/-/merge_requests/4963
        output.scheduled.mode = .{ .custom = .{ .width = 1280, .height = 720, .refresh = 0 } };
    }
    output.scheduled.transform = defaultTransform(wlr_output);

    server.wm.dirtyWindowing();
}

/// Rotate built-in panels that are mounted sideways in the chassis. Explicit
/// output configuration still overrides this.
fn defaultTransform(wlr_output: *wlr.Output) wl.Output.Transform {
    if (!wlr_output.isDrm()) return .normal;
    const kernel: wl.Output.Transform =
        @enumFromInt(c.wlr_drm_connector_get_panel_orientation(@ptrCast(wlr_output)));
    if (kernel != .normal) {
        log.info("output {s}: using kernel panel orientation {s}", .{ wlr_output.name, @tagName(kernel) });
        return kernel;
    }
    if (!panel_orientation.isInternalConnector(mem.span(wlr_output.name))) return .normal;
    const quirk = panel_orientation.dmiTransform() orelse return .normal;
    log.info("output {s}: using DMI panel orientation quirk {s}", .{ wlr_output.name, @tagName(quirk) });
    return quirk;
}

fn roundedBufferHook(
    c_scene_buffer: ?*c.struct_wlr_scene_buffer,
    options: ?*const c.struct_wlr_render_texture_options,
    attributes: ?*const c.struct_wlr_vk_render_texture_attribs,
    data: ?*anyopaque,
) callconv(.c) bool {
    if (comptime !build_options.vulkan_effects) return false;
    const output: *Output = @ptrCast(@alignCast(data orelse return false));
    const scene_buffer: *wlr.SceneBuffer =
        @ptrCast(@alignCast(c_scene_buffer orelse return false));
    const effect = server.effect_metadata.bufferData(scene_buffer);
    const itm = output.autoHdrExpansion(scene_buffer);
    if (effect == null and itm == null) return false;
    const clip = if (effect) |entry| entry.clip else null;
    const physical_clip = if (clip) |mask|
        output.bufferEffectClip(scene_buffer, mask)
    else
        null;
    return server.vulkan_context.rounded_pipeline.drawTexture(
        attributes orelse return false,
        options orelse return false,
        physical_clip,
        output.effects_swapchain_path,
        itm,
    ) catch |err| {
        log.err("Vulkan rounded texture draw failed: {s}", .{@errorName(err)});
        return false;
    };
}

/// Resolve the Auto HDR expansion for one buffer draw, or null when the
/// buffer keeps the stock SDR path. Expansion applies to relative-luminance
/// (SDR) content owned by policy-eligible windows on an HDR output;
/// absolute-luminance PQ content and non-window surfaces are untouched.
fn autoHdrExpansion(output: *Output, scene_buffer: *wlr.SceneBuffer) ?auto_hdr.ItmParams {
    const wlr_output = output.wlr_output orelse return null;
    if (!hdr.active(wlr_output)) return null;
    const state = output.effectRenderState();
    if (!state.auto_hdr) return null;
    const policy = Scene.bufferHdrPolicy(scene_buffer);
    if (!auto_hdr.shouldExpandForPolicy(
        scene_buffer.transfer_function == .st2084_pq,
        policy.native_windows_hdr,
        policy.eligible,
    )) return null;
    const peak_nits: f64 = @floatFromInt(state.hdr_level.nits());
    return .{
        .peak = @floatCast(peak_nits / 203.0),
        .boost = @floatCast(std.math.clamp(state.auto_hdr_boost, 0.0, 1.0)),
    };
}

fn roundedBufferNeedsComposition(
    c_scene_buffer: ?*c.struct_wlr_scene_buffer,
    _: ?*anyopaque,
) callconv(.c) bool {
    if (comptime !build_options.vulkan_effects) return false;
    const scene_buffer: *wlr.SceneBuffer =
        @ptrCast(@alignCast(c_scene_buffer orelse return false));
    const rounded = if (server.effect_metadata.bufferData(scene_buffer)) |effect|
        effect.clip != null
    else
        false;
    return visual_state.effectsRequireComposition(
        rounded,
        bufferNeedsBackdropBlur(scene_buffer),
    );
}

fn bufferNeedsBackdropBlur(scene_buffer: *wlr.SceneBuffer) bool {
    return blurOwnerForNode(&scene_buffer.node) != null;
}

fn roundedRectHook(
    render_pass: ?*c.struct_wlr_render_pass,
    c_scene_rect: ?*c.struct_wlr_scene_rect,
    options: ?*const c.struct_wlr_render_rect_options,
    data: ?*anyopaque,
) callconv(.c) bool {
    if (comptime !build_options.vulkan_effects) return false;
    const output: *Output = @ptrCast(@alignCast(data orelse return false));
    const scene_rect: *wlr.SceneRect =
        @ptrCast(@alignCast(c_scene_rect orelse return false));
    if (isBlurMarker(scene_rect)) return true;
    const effect = server.effect_metadata.rectData(scene_rect) orelse
        return false;
    const rect_options = options orelse return false;
    const geometry = output.rectEffect(scene_rect, rect_options, effect) orelse
        return false;
    return server.vulkan_context.rounded_pipeline.drawRect(
        render_pass orelse return false,
        rect_options,
        geometry,
        output.effects_swapchain_path,
    ) catch |err| {
        log.err("Vulkan rounded rect draw failed: {s}", .{@errorName(err)});
        return false;
    };
}

fn isBlurMarker(scene_rect: *wlr.SceneRect) bool {
    const owner = blurOwnerForNode(&scene_rect.node) orelse return false;
    return scene_rect == blurOwnerMarker(owner);
}

fn effectRenderState(output: *const Output) *const State {
    return if (output.effects_swapchain_path) &output.sent else &output.current;
}

/// Convert a destination-local mask to framebuffer pixels. Using framebuffer
/// coordinates keeps the mask independent of the client's texture transform.
fn bufferEffectClip(output: *const Output, buffer: *wlr.SceneBuffer, clip: fx.BufferClip) ?fx.BufferClip {
    const state = output.effectRenderState();
    const box = nodeEffectBox(&buffer.node, clip, state) orelse return null;
    return .{
        .x = @floatFromInt(box.x),
        .y = @floatFromInt(box.y),
        .width = @floatFromInt(box.width),
        .height = @floatFromInt(box.height),
        .radius = @min(clip.radius * state.scale, @as(f64, @floatFromInt(@max(0, @min(box.width, box.height)))) / 2),
    };
}

fn nodeEffectBox(node: *wlr.SceneNode, area: fx.BufferClip, state: *const State) ?wlr.Box {
    var x: f64 = 0;
    var y: f64 = 0;
    if (!c.wlr_scene_node_coords_f64(@ptrCast(node), &x, &y)) return null;
    x += area.x - @as(f64, @floatFromInt(state.x));
    y += area.y - @as(f64, @floatFromInt(state.y));
    const left: i32 = @intFromFloat(@round(x * state.scale));
    const top: i32 = @intFromFloat(@round(y * state.scale));
    var box: wlr.Box = .{
        .x = left,
        .y = top,
        .width = @as(i32, @intFromFloat(@round((x + area.width) * state.scale))) - left,
        .height = @as(i32, @intFromFloat(@round((y + area.height) * state.scale))) - top,
    };
    const width, const height = state.physicalDimensions();
    box.transform(&box, invertTransform(state.transform), width, height);
    return box;
}

/// Mask metadata can change without a client commit or a geometry setter.
/// Feed that damage through the same blur provenance hook as scene changes.
pub fn damageBufferEffects(output: *Output, buffer: *wlr.SceneBuffer) void {
    if (comptime !build_options.vulkan_effects) return;
    const scene_output = output.scene_output orelse return;
    var width = buffer.dst_width;
    var height = buffer.dst_height;
    if (width <= 0 or height <= 0) {
        width = buffer.private.buffer_width;
        height = buffer.private.buffer_height;
        if (@mod(@intFromEnum(buffer.transform), 2) != 0) mem.swap(c_int, &width, &height);
    }
    var box = nodeEffectBox(&buffer.node, .{
        .x = 0,
        .y = 0,
        .width = @floatFromInt(width),
        .height = @floatFromInt(height),
        .radius = 0,
    }, output.effectRenderState()) orelse return;
    const render_width, const render_height = physicalDimensions(output.effectRenderState());
    if (!box.intersection(&box, &.{ .x = 0, .y = 0, .width = render_width, .height = render_height })) return;
    var region: pixman.Region32 = undefined;
    region.initRect(box.x, box.y, @intCast(box.width), @intCast(box.height));
    defer region.deinit();
    scene_output.damage_ring.addBox(&box);
    // Match wlroots' scene-content damage bookkeeping: presentation damage
    // alone would omit blur-filter expansion and backend commit damage.
    const c_output: *c.struct_wlr_scene_output = @ptrCast(scene_output);
    const pending = &c_output.WLR_PRIVATE;
    _ = c.pixman_region32_union(&pending.pending_commit_damage, &pending.pending_commit_damage, @ptrCast(&region));
    _ = c.pixman_region32_union(&pending.pending_effect_damage, &pending.pending_effect_damage, @ptrCast(&region));
    effectsDamage(@ptrCast(&buffer.node), @ptrCast(&region), output);
    if (output.wlr_output) |wlr_output| wlr_output.scheduleFrame();
}

fn effectsRenderBegin(
    _: ?*c.struct_wlr_render_pass,
    content_damage: ?*const c.pixman_region32_t,
    data: ?*anyopaque,
) callconv(.c) u32 {
    if (comptime !build_options.vulkan_effects) return 0;
    const output: *Output = @ptrCast(@alignCast(data orelse return 0));
    output.blur_last_key = null;
    if (uncachedBlurRequested()) return 0;
    output.blur_cache.beginFrame();
    const config = server.effect_metadata.blurConfig();
    const kernel = BlurPipeline.resolveKernel(
        config.radius,
        config.passes,
        output.effectRenderState().scale,
    ) orelse return 0;
    var preserved: u32 = 0;
    var affected = false;
    var windows = server.wm.windows.iterator();
    while (windows.next()) |window| {
        prepareBlurOwner(
            output,
            .{ .window = window },
            content_damage,
            kernel,
            &preserved,
            &affected,
        );
    }
    var layer_surfaces = server.layer_shell.surfaces.iterator();
    while (layer_surfaces.next()) |layer_surface| {
        prepareBlurOwner(
            output,
            .{ .layer_surface = layer_surface },
            content_damage,
            kernel,
            &preserved,
            &affected,
        );
    }
    var popups = server.layer_shell.popups.iterator();
    while (popups.next()) |popup| {
        prepareBlurOwner(
            output,
            .{ .popup = popup },
            content_damage,
            kernel,
            &preserved,
            &affected,
        );
    }
    for (server.background_effect_manager.attachments.items) |attachment| {
        if (attachment.tree == null) continue;
        prepareBlurOwner(output, .{ .native = attachment }, content_damage, kernel, &preserved, &affected);
    }
    output.blur_cache.removeInvisible(
        &server.vulkan_context.blur_pipeline,
    );
    server.vulkan_context.blur_pipeline.recordCacheHits(
        &output.blur_cache,
        preserved,
    );
    return if (affected)
        EffectMetadata.cachedBlurRenderReach(kernel)
    else
        0;
}

fn prepareBlurOwner(
    output: *Output,
    owner: BlurOwner,
    content_damage: ?*const c.pixman_region32_t,
    kernel: BlurPipeline.Kernel,
    preserved: *u32,
    affected: *bool,
) void {
    const handle = blurOwnerHandle(owner) orelse return;
    const blur = blurOwnerData(owner) orelse return;
    const effect = blurOwnerEffect(
        owner,
        blur,
        output.effectRenderState(),
    ) orelse return;
    const key: u64 = @bitCast(handle.key);
    const ready = output.blur_cache.markVisible(key);
    if (output.blur_cache.ownerDamage(key) != null) {
        affected.* = true;
    } else if (!ready and expandedRenderRegionIntersects(
        content_damage,
        effect.box,
        kernel.reach,
    )) {
        // A cache entry doesn't exist until its first draw, so use aggregate
        // damage conservatively for that initial population.
        affected.* = true;
    } else if (ready) {
        preserved.* += 1;
    }
}

fn effectsDamage(
    c_source: ?*c.struct_wlr_scene_node,
    damage: ?*const c.pixman_region32_t,
    data: ?*anyopaque,
) callconv(.c) void {
    if (comptime !build_options.vulkan_effects) return;
    const output: *Output = @ptrCast(@alignCast(data orelse return));
    const region = damage orelse return;
    const source: ?*wlr.SceneNode = if (c_source) |node|
        @ptrCast(@alignCast(node))
    else
        null;
    const config = server.effect_metadata.blurConfig();
    const kernel = BlurPipeline.resolveKernel(
        config.radius,
        config.passes,
        output.effectRenderState().scale,
    ) orelse return;

    var windows = server.wm.windows.iterator();
    while (windows.next()) |window| {
        damageBlurOwner(output, .{ .window = window }, source, region, kernel);
    }
    var layer_surfaces = server.layer_shell.surfaces.iterator();
    while (layer_surfaces.next()) |layer_surface| {
        damageBlurOwner(
            output,
            .{ .layer_surface = layer_surface },
            source,
            region,
            kernel,
        );
    }
    var popups = server.layer_shell.popups.iterator();
    while (popups.next()) |popup| {
        damageBlurOwner(output, .{ .popup = popup }, source, region, kernel);
    }
    for (server.background_effect_manager.attachments.items) |attachment| {
        if (attachment.tree == null) continue;
        damageBlurOwner(output, .{ .native = attachment }, source, region, kernel);
    }
}

fn damageBlurOwner(
    output: *Output,
    owner: BlurOwner,
    source: ?*wlr.SceneNode,
    damage: *const c.pixman_region32_t,
    kernel: BlurPipeline.Kernel,
) void {
    const handle = blurOwnerHandle(owner) orelse return;
    const blur = blurOwnerData(owner) orelse return;
    const effect = blurOwnerEffect(
        owner,
        blur,
        output.effectRenderState(),
    ) orelse return;
    if (!expandedRenderRegionIntersects(damage, effect.box, kernel.reach)) return;

    if (source) |node| {
        const marker = &blurOwnerMarker(owner).node;
        const order = c.wlr_scene_node_render_order(
            @ptrCast(node),
            @ptrCast(marker),
        );
        // A source rendered above the marker cannot alter its backdrop. An
        // ancestor in the owner's own tree is likewise not backdrop content;
        // its geometry/config generations cover effect-domain changes.
        if (order > 0 or nodeInTree(node, blurOwnerTree(owner))) return;
    }
    output.blur_cache.damageOwner(@bitCast(handle.key), damage);
}

fn effectsNodeRender(
    render_pass: ?*c.struct_wlr_render_pass,
    c_node: ?*c.struct_wlr_scene_node,
    render_region: ?*const c.pixman_region32_t,
    data: ?*anyopaque,
) callconv(.c) void {
    if (comptime !build_options.vulkan_effects) return;
    const output: *Output = @ptrCast(@alignCast(data orelse return));
    const node: *wlr.SceneNode =
        @ptrCast(@alignCast(c_node orelse return));
    const owner = blurOwnerForNode(node) orelse return;
    if (node != &blurOwnerMarker(owner).node) return;
    const handle = blurOwnerHandle(owner) orelse return;
    const key: u64 = @bitCast(handle.key);
    if (output.blur_last_key == key) return;
    output.blur_last_key = key;

    const blur = blurOwnerData(owner) orelse return;
    const state = output.effectRenderState();
    const effect = blurOwnerEffect(owner, blur, state) orelse return;
    const config = server.effect_metadata.blurConfig();
    const pass = render_pass orelse return;
    const frame_clip = render_region orelse return;
    var native_clip: c.pixman_region32_t = undefined;
    c.pixman_region32_init(&native_clip);
    defer c.pixman_region32_fini(&native_clip);
    const clip = if (owner == .native) blk: {
        for (owner.native.region.rectangles()) |rect| {
            var part = blur;
            part.box = .{ .x = rect.x1, .y = rect.y1, .width = rect.x2 - rect.x1, .height = rect.y2 - rect.y1 };
            const projected = blurOwnerEffect(owner, part, state) orelse continue;
            const box = projected.box;
            if (c.pixman_region32_union_rect(&native_clip, &native_clip, box.x, box.y, @intCast(box.width), @intCast(box.height)) == 0) return;
        }
        if (c.pixman_region32_intersect(&native_clip, &native_clip, frame_clip) == 0) return;
        break :blk &native_clip;
    } else frame_clip;
    const rendered = if (uncachedBlurRequested())
        server.vulkan_context.blur_pipeline.render(
            pass,
            effect,
            clip,
            config.radius,
            config.passes,
            state.scale,
            config.appearance,
        )
    else blk: {
        const output_cache = if (output.blur_node) |cache_node|
            fx.outputBlurCacheData(cache_node)
        else
            null;
        break :blk server.vulkan_context.blur_pipeline.renderCached(
            &output.blur_cache,
            pass,
            key,
            effect,
            clip,
            blur.generation,
            config.generation,
            if (output_cache) |cache| cache.invalidation_generation else 0,
            config.radius,
            config.passes,
            state.scale,
            config.appearance,
        );
    };
    _ = rendered catch |err| {
        log.err("Vulkan backdrop blur failed: {s}", .{@errorName(err)});
        return;
    };
}

const BlurOwner = union(enum) {
    native: *@import("BackgroundEffectManager.zig").Attachment,
    window: *Window,
    layer_surface: *LayerSurface,
    popup: *XdgPopup,
};

fn blurOwnerHandle(owner: BlurOwner) ?EffectMetadata.WindowBlurHandle {
    return switch (owner) {
        .native => |attachment| attachment.blur,
        .window => |window| window.backdrop_blur,
        .layer_surface => |surface| surface.backdrop_blur,
        .popup => |popup| popup.backdrop_blur,
    };
}

fn blurOwnerTree(owner: BlurOwner) *wlr.SceneTree {
    return switch (owner) {
        .native => |attachment| attachment.tree.?,
        .window => |window| if (window.anim_snapshot)
            window.anim_tree
        else
            window.tree,
        .layer_surface => |surface| surface.scene_layer_surface.tree,
        .popup => |popup| popup.tree,
    };
}

fn blurOwnerMarker(owner: BlurOwner) *wlr.SceneRect {
    return switch (owner) {
        .native => |attachment| attachment.marker.?,
        .window => |window| if (window.anim_snapshot)
            window.anim_blur_marker
        else
            window.blur_marker,
        .layer_surface => |surface| surface.blur_marker,
        .popup => |popup| popup.blur_marker,
    };
}

/// Animation snapshots are deliberately input-inert and therefore carry no
/// SceneNodeData. Fall back to the window registry only for those snapshots.
fn blurOwnerForNode(node: *wlr.SceneNode) ?BlurOwner {
    if (server.background_effect_manager.forNode(node)) |attachment| {
        const owner: BlurOwner = .{ .native = attachment };
        if (blurOwnerData(owner) != null) return owner;
    }
    if (SceneNodeData.fromNode(node)) |owner| {
        switch (owner.data) {
            .window => |window| if (nodeInTree(node, windowBlurTree(window)) and
                windowBlurData(window) != null)
                return .{ .window = window },
            .layer_surface => |surface| if (nodeInTree(
                node,
                surface.scene_layer_surface.tree,
            ) and blurOwnerData(.{ .layer_surface = surface }) != null)
                return .{ .layer_surface = surface },
            else => {},
        }
    }
    var popup_match: ?BlurOwner = null;
    var popup_distance: usize = math.maxInt(usize);
    var popups = server.layer_shell.popups.iterator();
    while (popups.next()) |popup| {
        const popup_owner: BlurOwner = .{ .popup = popup };
        if (blurOwnerData(popup_owner) == null) continue;
        const distance = nodeDistanceInTree(node, popup.tree) orelse continue;
        if (distance >= popup_distance) continue;
        popup_match = popup_owner;
        popup_distance = distance;
    }
    if (popup_match) |owner| return owner;
    var windows = server.wm.windows.iterator();
    while (windows.next()) |window| {
        if (windowBlurData(window) != null and
            nodeInTree(node, windowBlurTree(window)))
        {
            return .{ .window = window };
        }
    }
    return null;
}

fn windowBlurTree(window: *Window) *wlr.SceneTree {
    return blurOwnerTree(.{ .window = window });
}

fn windowBlurData(window: *Window) ?EffectMetadata.WindowBlurData {
    return blurOwnerData(.{ .window = window });
}

fn blurOwnerData(owner: BlurOwner) ?EffectMetadata.WindowBlurData {
    const handle = blurOwnerHandle(owner) orelse return null;
    const data = server.effect_metadata.windowBlurData(handle) orelse
        return null;
    const config = server.effect_metadata.blurConfig();
    if (!data.enabled or data.box.width <= 0 or data.box.height <= 0 or
        config.radius <= 0 or config.passes <= 0)
    {
        return null;
    }
    return data;
}

fn uncachedBlurRequested() bool {
    if (comptime !build_options.vulkan_effects) return false;
    const raw = std.c.getenv("AQUEOUS_VULKAN_BLUR_UNCACHED") orelse return false;
    const value = mem.span(raw);
    return mem.eql(u8, value, "1") or
        std.ascii.eqlIgnoreCase(value, "true");
}

fn nodeInTree(node: *wlr.SceneNode, tree: *wlr.SceneTree) bool {
    return nodeDistanceInTree(node, tree) != null;
}

fn nodeDistanceInTree(
    node: *wlr.SceneNode,
    tree: *wlr.SceneTree,
) ?usize {
    var current = node;
    var distance: usize = 0;
    while (true) {
        if (current == &tree.node) return distance;
        const parent = current.parent orelse return null;
        current = &parent.node;
        distance += 1;
    }
}

fn blurOwnerEffect(
    owner: BlurOwner,
    blur: EffectMetadata.WindowBlurData,
    state: *const State,
) ?BlurPipeline.Effect {
    var global_x: i32 = 0;
    var global_y: i32 = 0;
    if (!blurOwnerTree(owner).node.coords(&global_x, &global_y)) return null;

    const logical_x = global_x + blur.box.x - state.x;
    const logical_y = global_y + blur.box.y - state.y;
    const left = scaleBoundary(logical_x, state.scale);
    const top = scaleBoundary(logical_y, state.scale);
    const right = scaleBoundary(
        logical_x + blur.box.width,
        state.scale,
    );
    const bottom = scaleBoundary(
        logical_y + blur.box.height,
        state.scale,
    );
    var box: wlr.Box = .{
        .x = left,
        .y = top,
        .width = right - left,
        .height = bottom - top,
    };
    if (box.width <= 0 or box.height <= 0) return null;

    var radii = EffectMetadata.clampedPhysicalRadii(
        .uniform(blur.radius),
        box.width,
        box.height,
        state.scale,
    );
    const transform = invertTransform(state.transform);
    radii = transformRadii(radii, transform);
    var transformed_width, var transformed_height =
        physicalDimensions(state);
    if (@mod(@intFromEnum(state.transform), 2) != 0) {
        mem.swap(i32, &transformed_width, &transformed_height);
    }
    box.transform(
        &box,
        transform,
        transformed_width,
        transformed_height,
    );
    const render_width, const render_height = physicalDimensions(state);
    if (!renderBoxesIntersect(
        .{ .x = 0, .y = 0, .width = render_width, .height = render_height },
        .{ .x = box.x, .y = box.y, .width = box.width, .height = box.height },
    )) return null;
    return .{
        .box = .{
            .x = box.x,
            .y = box.y,
            .width = box.width,
            .height = box.height,
        },
        .radii = radii,
    };
}

fn physicalDimensions(state: *const State) struct { i32, i32 } {
    return switch (state.mode) {
        .standard => |mode| .{ mode.width, mode.height },
        .custom => |mode| .{ mode.width, mode.height },
        .none => .{ 0, 0 },
    };
}

fn expandedRenderBox(
    box: c.struct_wlr_box,
    reach: u32,
) c.struct_wlr_box {
    const amount: i32 = @intCast(@min(reach, math.maxInt(i32)));
    return .{
        .x = box.x -| amount,
        .y = box.y -| amount,
        .width = box.width +| amount *| 2,
        .height = box.height +| amount *| 2,
    };
}

fn expandedRenderRegionIntersects(
    region: ?*const c.pixman_region32_t,
    box: c.struct_wlr_box,
    reach: u32,
) bool {
    const damage = region orelse return false;
    var count: c_int = 0;
    const rectangles = c.pixman_region32_rectangles(damage, &count);
    var index: usize = 0;
    while (index < @as(usize, @intCast(@max(0, count)))) : (index += 1) {
        const rectangle = rectangles[index];
        if (renderBoxesIntersect(
            expandedRenderBox(.{
                .x = rectangle.x1,
                .y = rectangle.y1,
                .width = rectangle.x2 - rectangle.x1,
                .height = rectangle.y2 - rectangle.y1,
            }, reach),
            box,
        )) return true;
    }
    return false;
}

fn renderBoxesIntersect(
    a: c.struct_wlr_box,
    b: c.struct_wlr_box,
) bool {
    return @max(a.x, b.x) < @min(a.x + a.width, b.x + b.width) and
        @max(a.y, b.y) < @min(a.y + a.height, b.y + b.height);
}

fn hasVisibleBlur(output: *const Output) bool {
    if (comptime !build_options.vulkan_effects) return false;
    var it = server.wm.windows.iterator();
    while (it.next()) |window| {
        const blur = windowBlurData(window) orelse continue;
        if (blurOwnerEffect(
            .{ .window = window },
            blur,
            output.effectRenderState(),
        ) != null) {
            return true;
        }
    }
    var layers = server.layer_shell.surfaces.iterator();
    while (layers.next()) |surface| {
        const owner: BlurOwner = .{ .layer_surface = surface };
        const blur = blurOwnerData(owner) orelse continue;
        if (blurOwnerEffect(owner, blur, output.effectRenderState()) != null) {
            return true;
        }
    }
    var popups = server.layer_shell.popups.iterator();
    while (popups.next()) |popup| {
        const owner: BlurOwner = .{ .popup = popup };
        const blur = blurOwnerData(owner) orelse continue;
        if (blurOwnerEffect(owner, blur, output.effectRenderState()) != null) {
            return true;
        }
    }
    for (server.background_effect_manager.attachments.items) |attachment| {
        if (attachment.tree == null) continue;
        const owner: BlurOwner = .{ .native = attachment };
        const blur = blurOwnerData(owner) orelse continue;
        if (blurOwnerEffect(owner, blur, output.effectRenderState()) != null) return true;
    }
    return false;
}

/// Animation moves both the blur source and decorations drawn above it. Repaint
/// the complete output so the offscreen blur pass cannot sample decoration
/// pixels retained at a window's previous position. Static cached blur keeps
/// using normal partial damage.
pub fn prepareFullBlurDamage(
    output: *Output,
    animation_changed_scene: bool,
) bool {
    if ((!uncachedBlurRequested() and !animation_changed_scene) or
        !output.hasVisibleBlur())
    {
        return false;
    }
    if (animation_changed_scene) {
        log.debug("forcing full output damage for blurred animation", .{});
    }
    output.scene_output.?.damage_ring.addWhole();
    return true;
}

pub fn setFullBlurDamage(
    output: *const Output,
    state: *wlr.Output.State,
) void {
    var width, var height = physicalDimensions(output.effectRenderState());
    if (@mod(
        @intFromEnum(output.effectRenderState().transform),
        2,
    ) != 0) {
        mem.swap(i32, &width, &height);
    }
    if (width <= 0 or height <= 0) return;

    var region: pixman.Region32 = undefined;
    region.initRect(0, 0, @intCast(width), @intCast(height));
    defer region.deinit();
    state.setDamage(&region);
}

pub fn recordVulkanEffectsMetric(output: *const Output) void {
    if (comptime !build_options.vulkan_effects) return;
    if (!render_metrics.enabled() or uncachedBlurRequested()) return;
    const stats = output.blur_cache.stats;
    if (stats.hits == 0 and stats.partial_rebuilds == 0 and
        stats.full_rebuilds == 0)
    {
        return;
    }
    const wlr_output = output.wlr_output orelse return;
    (render_metrics.VulkanEffectsSample{
        .gpu_duration_ns = -1,
        .cache_hits = stats.hits,
        .cache_partial_rebuilds = stats.partial_rebuilds,
        .cache_full_rebuilds = stats.full_rebuilds,
        .pixels_processed = stats.pixels_processed,
    }).record(std.mem.span(wlr_output.name));
}

fn rectEffect(
    output: *const Output,
    rect: *wlr.SceneRect,
    options: *const c.struct_wlr_render_rect_options,
    effect: EffectMetadata.RectData,
) ?EffectMetadata.RectRenderData {
    const state = output.effectRenderState();
    const scale = state.scale;
    const box = options.box;
    var outer_radii = EffectMetadata.clampedPhysicalRadii(
        effect.radii,
        box.width,
        box.height,
        scale,
    );
    const transform = invertTransform(state.transform);
    outer_radii = transformRadii(outer_radii, transform);

    var geometry: EffectMetadata.RectRenderData = .{
        .outer_radii = outer_radii,
    };
    if (effect.clipped_region) |clipped| {
        const inner_box = transformedInnerBox(rect, clipped.area, state) orelse
            return null;
        if (inner_box.width <= 0 or inner_box.height <= 0) return null;
        var inner_radii = EffectMetadata.clampedPhysicalRadii(
            clipped.radii,
            inner_box.width,
            inner_box.height,
            scale,
        );
        inner_radii = transformRadii(inner_radii, transform);
        geometry.inner_rect = .{
            @floatFromInt(inner_box.x),
            @floatFromInt(inner_box.y),
            @floatFromInt(inner_box.width),
            @floatFromInt(inner_box.height),
        };
        geometry.inner_radii = inner_radii;
        geometry.has_inner = true;
    }
    if (!geometry.has_inner and !hasPhysicalRadius(geometry.outer_radii)) {
        return null;
    }
    return geometry;
}

fn transformedInnerBox(
    rect: *wlr.SceneRect,
    area: wlr.Box,
    state: *const State,
) ?wlr.Box {
    var global_x: i32 = 0;
    var global_y: i32 = 0;
    if (!rect.node.coords(&global_x, &global_y)) return null;

    const logical_x = global_x - state.x;
    const logical_y = global_y - state.y;
    const outer_left = scaleBoundary(logical_x, state.scale);
    const outer_top = scaleBoundary(logical_y, state.scale);
    const outer_right = scaleBoundary(logical_x + rect.width, state.scale);
    const outer_bottom = scaleBoundary(logical_y + rect.height, state.scale);
    const outer_width = outer_right - outer_left;
    const outer_height = outer_bottom - outer_top;
    if (outer_width <= 0 or outer_height <= 0) return null;

    var inner: wlr.Box = .{
        .x = scaleBoundary(logical_x + area.x, state.scale) - outer_left,
        .y = scaleBoundary(logical_y + area.y, state.scale) - outer_top,
        .width = scaleBoundary(logical_x + area.x + area.width, state.scale) -
            scaleBoundary(logical_x + area.x, state.scale),
        .height = scaleBoundary(logical_y + area.y + area.height, state.scale) -
            scaleBoundary(logical_y + area.y, state.scale),
    };
    inner.transform(
        &inner,
        invertTransform(state.transform),
        outer_width,
        outer_height,
    );
    return inner;
}

fn scaleBoundary(value: i32, scale: f32) i32 {
    return @intFromFloat(@round(@as(f32, @floatFromInt(value)) * scale));
}

fn invertTransform(transform: wl.Output.Transform) wl.Output.Transform {
    return switch (transform) {
        .@"90" => .@"270",
        .@"270" => .@"90",
        else => transform,
    };
}

fn transformRadii(
    radii: [4]f32,
    transform: wl.Output.Transform,
) [4]f32 {
    return switch (transform) {
        .normal => radii,
        .@"90" => .{ radii[3], radii[0], radii[1], radii[2] },
        .@"180" => .{ radii[2], radii[3], radii[0], radii[1] },
        .@"270" => .{ radii[1], radii[2], radii[3], radii[0] },
        .flipped => .{ radii[1], radii[0], radii[3], radii[2] },
        .flipped_90 => .{ radii[0], radii[3], radii[2], radii[1] },
        .flipped_180 => .{ radii[3], radii[2], radii[1], radii[0] },
        .flipped_270 => .{ radii[2], radii[1], radii[0], radii[3] },
        else => radii,
    };
}

fn hasPhysicalRadius(radii: [4]f32) bool {
    for (radii) |radius| {
        if (radius > 0) return true;
    }
    return false;
}

/// Ensure the output has at least one workspace and an active workspace.
pub fn ensureWorkspaces(output: *Output) void {
    if (output.workspaces.first() == null) {
        var i: u32 = 1;
        while (i <= 9) : (i += 1) {
            var buf: [16]u8 = undefined;
            const name = fmt.bufPrint(&buf, "{d}", .{i}) catch "workspace";
            const ws = Workspace.create(output, name) catch {
                log.err("out of memory creating static workspace", .{});
                break;
            };
            ws.pinned = true;
        }
    }
    if (output.active_workspace == null) {
        output.active_workspace = output.workspaces.first();
    }
}

/// Make the given workspace the single active workspace on this output.
pub fn activateWorkspace(output: *Output, workspace: *Workspace) void {
    assert(workspace.output == output);
    const prev = output.active_workspace;
    if (prev == workspace) return;
    server.aqueous.forgetOutput(output.policyId());

    if (comptime fx.anim_enabled) {
        if (server.wm.workspace_transition.enabled) {
            if (prev) |p| {
                // Begin a workspace-swap slide. `renderFinish` keeps both the
                // outgoing (`prev_workspace`) and incoming (`active_workspace`)
                // workspaces rendered and offset; the transition is finalized in
                // `stepAnimations` once every participating window has settled.
                // If a transition is already in flight, retarget it: the workspace
                // sliding out is whichever one we are leaving now.
                output.prev_workspace = p;
                output.transition_dir = output.slideDirection(p, workspace);
                output.transition_armed = false;
                // The incoming windows must seed their clones off-screen on the
                // first transition frame; clear any stale seed flags so they do.
                var it = p.windows.iterator(.forward);
                while (it.next()) |w| w.slide_seeded = false;
                var it2 = workspace.windows.iterator(.forward);
                while (it2.next()) |w| w.slide_seeded = false;
            }
        }
    }

    output.active_workspace = workspace;
    // Reaping is intentionally not performed here: it is deferred to the end of
    // the workspace transaction so an in-flight batch cannot free a workspace
    // it still references. Other call sites (window unmap/move) reap directly.
    server.wm.dirtyWindowing();
    server.workspace_manager.dirty();
    if (output.wlr_output) |o| o.scheduleFrame();
}

/// Return the slide direction sign for a transition from `prev` to `next`:
/// +1 when `next` is ordered after `prev` in `output.workspaces` (new content
/// enters from the right), -1 otherwise.
fn slideDirection(output: *Output, prev: *Workspace, next: *Workspace) i32 {
    var it = output.workspaces.iterator(.forward);
    while (it.next()) |w| {
        if (w == prev) return 1;
        if (w == next) return -1;
    }
    return 1;
}

/// Abort any in-flight workspace-swap slide, tearing down the participating
/// windows' clones so they cannot outlive their workspace (e.g. when an output
/// is disconnected, migrated, or cleared mid-transition).
pub fn cancelTransition(output: *Output) void {
    if (comptime !fx.anim_enabled) return;
    if (output.prev_workspace) |prev| {
        var it = prev.windows.iterator(.forward);
        while (it.next()) |w| w.cancelSlide();
    }
    if (output.active_workspace) |active| {
        var it = active.windows.iterator(.forward);
        while (it.next()) |w| w.cancelSlide();
    }
    output.prev_workspace = null;
    output.transition_dir = 0;
    output.transition_armed = false;
}

/// Settle cosmetic window/workspace animation overlays before the overview
/// clones live content. Authoritative geometry, layout, and focus are untouched.
pub fn prepareOverview(output: *Output) void {
    output.cancelTransition();
    var windows = server.wm.windows.iterator();
    while (windows.next()) |window| {
        const workspace = window.workspace orelse continue;
        if (workspace.output != output) continue;
        window.cancelSlide();
    }
}

/// If a workspace-swap slide is in flight and every participating window has
/// settled, commit the end state: clear the transition so the outgoing
/// workspace's windows hit the non-visible gate (disabling their live trees) on
/// the next `renderFinish`, then reap the now-hidden empty workspace.
fn finalizeTransition(output: *Output) void {
    if (comptime !fx.anim_enabled) return;
    const prev = output.prev_workspace orelse return;
    // Do not finalize before `renderFinish` has armed the slide: an early frame
    // (scheduled by `activateWorkspace`) can beat the async windowing
    // transaction, at which point no window is animating yet and finalizing
    // here would cancel the transition before it visibly begins.
    if (!output.transition_armed) return;
    if (output.hasActiveAnimations()) return;
    output.prev_workspace = null;
    output.transition_dir = 0;
    output.transition_armed = false;
    server.wm.dirtyWindowing();
    if (!prev.pinned and prev.empty()) output.reapEmpty();
}

/// Made a noop as static exists but this is safer than removing the functionality entirely
pub fn ensureTrailingEmpty(output: *Output) void {
    if (output.workspaces.first() != null) return;
    _ = output.createWorkspace();
}

/// Destroy empty workspaces that are neither active nor the trailing one.
pub fn reapEmpty(output: *Output) void {
    const last = output.workspaces.last();
    var it = output.workspaces.iterator(.forward);
    while (it.next()) |workspace| {
        if (workspace.pinned) continue;
        if (workspace == output.active_workspace) continue;
        // Never reap a workspace that is still sliding out: its windows' clones
        // are mid-transition and `Workspace.destroy` asserts the workspace is
        // inactive and empty. The finalize block clears `prev_workspace` and
        // calls `reapEmpty` again once the slide completes.
        if (workspace == output.prev_workspace) continue;
        if (workspace == last) continue;
        if (workspace.empty()) workspace.destroy();
    }
}

/// Return another enabled output to which this output's workspaces may be
/// migrated, or null if this is the last remaining output.
fn fallbackOutput(output: *Output) ?*Output {
    var it = server.om.outputs.iterator(.forward);
    while (it.next()) |other| {
        if (other == output) continue;
        if (!other.policyExposed()) continue;
        if (other.wlr_output == null) continue;
        return other;
    }
    return null;
}

fn migrateWorkspacesTo(output: *Output, dest: *Output) void {
    output.cancelTransition();
    output.active_workspace = null;
    var it = output.workspaces.safeIterator(.forward);
    while (it.next()) |workspace| {
        var fullscreen_windows = workspace.windows.iterator(.forward);
        while (fullscreen_windows.next()) |window| {
            if (window.wm_requested.fullscreen != null) window.wm_requested.fullscreen = dest;
        }
        if (workspace.pinned) {
            if (dest.pinnedByName(workspace.name)) |target| {
                var win_it = workspace.windows.safeIterator(.forward);
                while (win_it.next()) |window| window.setWorkspace(target);
            } else {
                workspace.link.remove();
                workspace.output = dest;
                dest.workspaces.append(workspace);
                continue;
            }
            workspace.destroy();
            continue;
        }

        workspace.link.remove();
        workspace.output = dest;
        dest.workspaces.append(workspace);
    }
    dest.ensureTrailingEmpty();
    dest.reapEmpty();
    server.wm.dirtyWindowing();
    server.workspace_manager.dirty();
}

/// Destroy all workspaces, detaching any remaining windows first. Detaching is
/// done without triggering reaping so it is safe to call while iterating the
/// workspace list.
fn clearWorkspaces(output: *Output) void {
    output.cancelTransition();
    output.active_workspace = null;
    var it = output.workspaces.iterator(.forward);
    while (it.next()) |workspace| {
        var window_it = workspace.windows.iterator(.forward);
        while (window_it.next()) |window| window.detachWorkspace();
        workspace.destroy();
    }
}

fn createWorkspace(output: *Output) ?*Workspace {
    var buf: [16]u8 = undefined;
    const index = output.workspaces.length() + 1;
    const name = fmt.bufPrint(&buf, "{d}", .{index}) catch "workspace";
    return Workspace.create(output, name) catch {
        log.err("out of memory creating workspace", .{});
        return null;
    };
}

fn handleCommit(
    listener: *wl.Listener(*wlr.Output.event.Commit),
    event: *wlr.Output.event.Commit,
) void {
    const output: *Output = @fieldParentPtr("commit", listener);
    Mirror.capture(output, event.state);
    const committed = event.state.committed;
    if (!(committed.scale or committed.mode or committed.transform or committed.enabled or
        committed.adaptive_sync_enabled)) return;
    output.overlay_state.invalidateCapabilities();
    // VRR-only commits do not change layout or require another WM transaction.
    if (!(committed.scale or committed.mode or committed.transform or committed.enabled)) return;
    if (!server.om.committing_outputs) output.adaptive_sync_policy.reset();
    server.aqueous.forgetOutput(output.policyId());
    const wlr_output = output.wlr_output orelse return;
    log.debug("output {s}: commit affects layout (scale={} mode={} transform={} enabled={})", .{
        wlr_output.name,
        committed.scale,
        committed.mode,
        committed.transform,
        committed.enabled,
    });
    server.wm.dirtyWindowing();

    if (committed.scale or committed.enabled) {
        var seat_it = server.input_manager.seats.iterator(.forward);
        while (seat_it.next()) |seat| {
            seat.cursor.reloadScales();
        }
    }
}

/// Attempts to send the aqueous_output_v1.wl_output event if it has not yet been
/// sent and the underlying wl_output global now exists. Wlroots creates the
/// wl_output global lazily (notably on the DRM backend the global is only
/// created once the output is added to the layout and a mode is committed), so
/// this must be retried from every site that learns the global may now exist
/// (manageStart, post-modeset, and client bind) until it succeeds.
pub fn trySendWlOutput(output: *Output) void {
    const wlr_output = output.wlr_output orelse return;
    const global = wlr_output.global orelse return;
    const output_v1 = output.object orelse return;
    // Re-send if we have not sent yet or the global was recreated.
    if (output.sent_wl_output and output.sent_wl_output_global == global) return;
    output_v1.sendWlOutput(global.getName(output_v1.getClient()));
    output.sent_wl_output = true;
    output.sent_wl_output_global = global;
}

/// Handles a client binding to an output
fn handleBind(listener: *wl.Listener(*wlr.Output.event.Bind), _: *wlr.Output.event.Bind) void {
    const output: *Output = @fieldParentPtr("bind", listener);
    // The wl_output.bind event only fires after the wl_output global exists, so
    // this is a reliable point to (re)send aqueous_output_v1.wl_output when the
    // global was still null at manageStart/modeset time (e.g. DRM backend).
    output.trySendWlOutput();
    server.workspace_manager.dirty();
}

fn handleDestroy(listener: *wl.Listener(*wlr.Output), wlr_output: *wlr.Output) void {
    const output: *Output = @fieldParentPtr("destroy", listener);
    server.om.warming.remove(wlr_output);
    output.discardOverlayCandidate();
    server.om.display_revision += 1;
    @import("DisplayPreview.zig").removed(output.display_instance);
    server.system_bell.outputRemoved(output.policyId());
    output.mirror.reset();
    if (output.mirror_source_locked) {
        wlr_output.lockAttachRender(false);
        wlr_output.lockSoftwareCursors(false);
        output.mirror_source_locked = false;
    }
    output.cancelRetry();
    if (output.retry_timer) |timer| timer.remove();
    output.retry_timer = null;

    log.debug("wlr_output '{s}' destroyed", .{wlr_output.name});
    server.aqueous.forgetOutput(output.policyId());

    var seats = server.input_manager.seats.iterator(.forward);
    while (seats.next()) |seat| seat.policyForgetOutput(output);

    {
        var it = server.layer_shell.surfaces.iterator();
        while (it.next()) |surface| {
            if (surface.wlr_layer_surface.output == wlr_output) {
                surface.wlr_layer_surface.destroy();
            }
        }
    }
    {
        var it = server.input_manager.devices.iterator(.forward);
        while (it.next()) |device| {
            if (device.config.map_to_output == wlr_output) {
                device.config.map_to_output = null;
                device.seat.cursor.wlr_cursor.mapInputToOutput(device.wlr_device, null);
            }
        }
    }

    @import("TabletMapping.zig").forgetOutput(output.policyId());
    output.destroy.link.remove();
    output.request_state.link.remove();
    output.frame.link.remove();
    output.present.link.remove();
    output.commit.link.remove();
    output.bind.link.remove();

    output.finishRenderMetric();
    output.destroyBlur();

    wlr_output.data = null;

    output.wlr_output = null;
    output.scene_output = null;
    if (output.mirror_scene) |scene| scene.tree.node.destroy();
    output.mirror_scene = null;
    output.scheduled.mode = .none;
    output.sent.mode = .none;
    output.current.mode = .none;
    output.scheduled.state = .destroying;

    server.aqueous.output_service.outputsChanged(true);

    server.wm.dirtyWindowing();
}

/// A mirror must not participate in wlroots surface enter/leave, preferred scale,
/// or primary-output selection. Give its physical output a separate empty scene.
pub fn selectScene(output: *Output, mirrored: bool) bool {
    if (mirrored == (output.mirror_scene != null)) return true;
    const scene = if (mirrored) wlr.Scene.create() catch return false else server.scene.wlr_scene;
    const replacement = scene.createSceneOutput(output.wlr_output.?) catch {
        if (mirrored) scene.tree.node.destroy();
        return false;
    };
    output.scene_output.?.destroy();
    if (output.mirror_scene) |old| old.tree.node.destroy();
    output.mirror_scene = if (mirrored) scene else null;
    output.scene_output = replacement;
    if (!mirrored) output.installSceneHooks();
    return true;
}

fn installSceneHooks(output: *Output) void {
    const scene_output = output.scene_output.?;
    if (comptime build_options.vulkan_effects) {
        c.wlr_scene_output_set_buffer_render_hook(
            @ptrCast(scene_output),
            roundedBufferHook,
            output,
        );
        c.wlr_scene_output_set_buffer_needs_composition(
            @ptrCast(scene_output),
            roundedBufferNeedsComposition,
        );
        c.wlr_scene_output_set_rect_render_hook(
            @ptrCast(scene_output),
            roundedRectHook,
        );
        c.wlr_scene_output_set_render_hooks(
            @ptrCast(scene_output),
            effectsRenderBegin,
            effectsNodeRender,
        );
        c.wlr_scene_output_set_damage_hook(
            @ptrCast(scene_output),
            effectsDamage,
            output,
        );
    }
}

pub fn manageStart(output: *Output) void {
    if (!output.scheduled.mirror_of.empty() and output.scheduled.state != .destroying) {
        if (output.active_workspace != null) {
            var layers = server.layer_shell.surfaces.iterator();
            while (layers.next()) |layer| {
                if (layer.wlr_layer_surface.output == output.wlr_output) layer.wlr_layer_surface.destroy();
            }
            var seats = server.input_manager.seats.iterator(.forward);
            while (seats.next()) |seat| seat.policyForgetOutput(output);
            var devices = server.input_manager.devices.iterator(.forward);
            while (devices.next()) |device| {
                if (device.config.map_to_output == output.wlr_output) {
                    device.config.map_to_output = null;
                    device.seat.cursor.wlr_cursor.mapInputToOutput(device.wlr_device, null);
                }
            }
            const dest = output.fallbackOutput();
            if (dest) |to| output.migrateWorkspacesTo(to) else output.clearWorkspaces();
            server.workspace_manager.handleOutputRemoved(output, dest);
        }
        output.makeInert();
        output.sent = output.scheduled;
        output.link_sent.remove();
        server.wm.sent.outputs.append(output);
        return;
    }
    if (output.policyExposed() and output.active_workspace == null) output.ensureWorkspaces();
    // Snap an in-flight workspace swap before its output coordinate system
    // changes or stops receiving frames. Its captured buffers and fullscreen
    // backing use the old grid, and a powered-off output cannot finish easing.
    if (output.prev_workspace != null and
        (output.scheduled.state != .enabled or
            !std.meta.eql(output.sent.box(), output.scheduled.box()) or
            output.sent.scale != output.scheduled.scale or
            output.sent.transform != output.scheduled.transform))
    {
        output.cancelTransition();
    }
    switch (output.scheduled.state) {
        .enabled, .disabled_soft => {
            // We cannot send 0 width/height to the window manager client.
            assert(output.scheduled.mode != .none);

            output.layer_shell.manageStart();
            server.aqueous.reconfigureOutput(output);

            if (server.wm.object) |wm_v1| {
                const new = output.object == null;
                const output_v1 = output.object orelse blk: {
                    const output_v1 = aqueous.OutputV1.create(wm_v1.getClient(), wm_v1.getVersion(), 0) catch {
                        log.err("out of memory", .{});
                        return; // try again next update
                    };
                    output.object = output_v1;

                    output_v1.setHandler(*Output, handleRequest, handleObjectDestroy, output);
                    wm_v1.sendOutput(output_v1);

                    break :blk output_v1;
                };
                errdefer comptime unreachable;

                // wl_output globals are created/destroyed by the wlroots output layout.
                // Retry until it succeeds; handleBind and the post-modeset pass also retry.
                output.trySendWlOutput();

                const scheduled = &output.scheduled;
                const sent = &output.sent;

                const scheduled_width, const scheduled_height = scheduled.dimensions();
                const sent_width, const sent_height = sent.dimensions();

                if (new or scheduled_width != sent_width or scheduled_height != sent_height) {
                    output_v1.sendDimensions(scheduled_width, scheduled_height);
                }
                if (new or scheduled.x != sent.x or scheduled.y != sent.y) {
                    output_v1.sendPosition(scheduled.x, scheduled.y);
                }
            }

            output.sent = output.scheduled;

            output.link_sent.remove();
            server.wm.sent.outputs.append(output);
        },
        .disabled_hard, .destroying => {
            output.makeInert();

            output.sent = output.scheduled;

            if (output.scheduled.state == .destroying) {
                assert(output.wlr_output == null);
                {
                    var it = server.wm.windows.iterator();
                    while (it.next()) |window| {
                        switch (window.wm_scheduled.fullscreen_requested) {
                            .fullscreen => |output_hint| {
                                if (output_hint == output) {
                                    window.wm_scheduled.fullscreen_requested = .{ .fullscreen = null };
                                }
                            },
                            .no_request, .exit => {},
                        }
                        if (window.wm_requested.fullscreen == output) {
                            window.wm_requested.fullscreen = null;
                        }
                    }
                }
                const dest = output.fallbackOutput();
                if (dest) |to| {
                    output.migrateWorkspacesTo(to);
                } else {
                    output.clearWorkspaces();
                }
                server.workspace_manager.handleOutputRemoved(output, dest);

                output.link.remove();
                output.link_sent.remove();

                util.gpa.destroy(output);
            }
        },
    }
}

pub fn makeInert(output: *Output) void {
    if (output.object) |output_v1| {
        output_v1.sendRemoved();
        output_v1.setHandler(?*anyopaque, handleRequestInert, null, null);
        output.layer_shell.makeInert();
        handleObjectDestroy(output_v1, output);
    }
}

fn handleRequestInert(
    output_v1: *aqueous.OutputV1,
    request: aqueous.OutputV1.Request,
    _: ?*anyopaque,
) void {
    if (request == .destroy) output_v1.destroy();
}

fn handleObjectDestroy(_: *aqueous.OutputV1, output: *Output) void {
    output.object = null;
    output.sent_wl_output = false;
    output.sent_wl_output_global = null;
}

fn handleRequest(
    output_v1: *aqueous.OutputV1,
    request: aqueous.OutputV1.Request,
    output: *Output,
) void {
    assert(output.object == output_v1);
    switch (request) {
        .destroy => output_v1.destroy(),
        .set_presentation_mode => |args| {
            if (!server.wm.ensureRendering()) return;
            output.rendering_requested.tearing = switch (args.mode) {
                .vsync => false,
                .async => true,
                _ => {
                    output_v1.postError(.invalid_presentation_mode, "invalid presentation mode enum value");
                    return;
                },
            };
        },
    }
}

fn handleRequestState(listener: *wl.Listener(*wlr.Output.event.RequestState), event: *wlr.Output.event.RequestState) void {
    const output: *Output = @fieldParentPtr("request_state", listener);

    // The only state currently requested by a wlroots backend is a
    // custom mode as the Wayland/X11 backend window is resized.
    const committed: u32 = @bitCast(event.state.committed);
    const supported: u32 = @bitCast(wlr.Output.State.Fields{ .mode = true });

    if (committed != supported) {
        log.err("backend requested unsupported state {}", .{committed});
        return;
    }

    log.debug("backend requested new mode", .{});

    if (event.state.mode) |mode| {
        output.scheduled.mode = .{ .standard = mode };
    } else {
        output.scheduled.mode = .{ .custom = .{
            .width = event.state.custom_mode.width,
            .height = event.state.custom_mode.height,
            .refresh = event.state.custom_mode.refresh,
        } };
    }

    server.wm.dirtyWindowing();
}

pub fn retryNowMs() u64 {
    const now = util.timestamp();
    return @as(u64, @intCast(now.sec)) * 1000 + @as(u64, @intCast(now.nsec)) / std.time.ns_per_ms;
}

fn retryEnabled(output: *const Output) bool {
    const wlr_output = output.wlr_output orelse return false;
    return output.scene_output != null and wlr_output.enabled and output.current.state == .enabled;
}

fn retryDisabledForTest(output: *const Output) bool {
    if (comptime build_options.output_retry_testing) return output.retry_test.disable_retry;
    return false;
}

fn injectRetryFailure(output: *Output, stage: output_retry.Stage) bool {
    if (comptime build_options.output_retry_testing) {
        const fault = &output.retry_test;
        if (fault.stage == stage and fault.remaining != 0) {
            if (fault.remaining > 0) fault.remaining -= 1;
            return true;
        }
    }
    return false;
}

fn commitFrameState(output: *Output, state: *wlr.Output.State, stage: output_retry.Stage) bool {
    if (output.injectRetryFailure(stage)) return false;
    if (comptime build_options.output_retry_testing) {
        // Exercise fallback control flow on a backend with no DRM planes.
        if (stage == .output_commit and
            (output.retry_test.simulate_overlay or output.retry_test.simulate_color_pipeline) and
            !output.retry.pending and output.retry_test.remaining != 0) return false;
    }
    output.render_commit_active = true;
    defer output.render_commit_active = false;
    return output.wlr_output.?.commitState(state);
}

fn disarmRetryTimer(output: *Output) void {
    if (output.retry_timer_armed) {
        if (output.retry_timer) |timer| timer.timerUpdate(0) catch log.err("unable to disarm output retry timer", .{});
    }
    output.retry_timer_armed = false;
}

pub fn cancelRetry(output: *Output) void {
    output.disarmRetryTimer();
    output.retry.cancel();
    output.early_present = null;
}

fn armRetryTimer(output: *Output) void {
    if (output.retry_timer_armed or !output.retryEnabled() or !output.retry.pending) return;
    const timer = output.retry_timer orelse return;
    const delay = std.math.clamp(output.retry.deadline_ms -| retryNowMs(), 1, 1000);
    timer.timerUpdate(@intCast(delay)) catch {
        // Leave damage/recovery pending for a future backend frame. Do not
        // replace a failed timer with a self-scheduling idle-frame loop.
        log.err("output {s}: cannot arm recovery timer; awaiting a backend frame", .{output.policyName()});
        return;
    };
    output.retry_timer_armed = true;
}

fn handleRetryTimer(output: *Output) c_int {
    output.retry_timer_armed = false;
    if (!output.retryEnabled()) {
        output.cancelRetry();
        return 0;
    }
    if (!output.retry.pending or output.retryDisabledForTest()) return 0;
    if (!output.retry.ready(retryNowMs())) {
        output.armRetryTimer();
        return 0;
    }
    const wlr_output = output.wlr_output.?;
    if (!output.retry.frame_requested) {
        output.retry.frame_requested = true;
        wlr_output.scheduleFrame();
    }
    // scheduleFrame respects a backend-owned pending frame. Do not forge its
    // completion; keep a slow check alive until that backend frame arrives.
    if (wlr_output.frame_pending) {
        output.retry_timer.?.timerUpdate(1000) catch return 0;
        output.retry_timer_armed = true;
    }
    return 0;
}

fn handleFrame(listener: *wl.Listener(*wlr.Output), wlr_output: *wlr.Output) void {
    const output: *Output = @fieldParentPtr("frame", listener);
    if (!output.retryEnabled()) {
        output.cancelRetry();
        return;
    }
    const recovering = output.retry.pending and !output.retryDisabledForTest();
    if (recovering and !output.retry.ready(retryNowMs())) return;
    output.disarmRetryTimer();
    if (output.retry.ready(retryNowMs())) output.retry.attempted(retryNowMs());

    const animation_changed_scene = if (output.current.mirror_of.empty()) output.stepAnimations() else false;

    // Commit the end of a workspace-swap slide once all windows have settled.
    output.finalizeTransition();

    const outcome = output.renderAndCommit(animation_changed_scene or recovering, recovering);
    if (output.current.mirror_of.empty()) server.fifo.finish(wlr_output, outcome == .committed);
    switch (outcome) {
        .skipped => {},
        .committed => {
            const failures = output.retry.failures;
            const elapsed = retryNowMs() -| output.retry.started_ms;
            if (output.retry.committed(wlr_output.commit_seq)) {
                log.info("output {s}: commit recovered after {} failures in {}ms, sequence={} (awaiting presentation)", .{
                    wlr_output.name, failures, elapsed, wlr_output.commit_seq,
                });
            }
            // Some backends present synchronously inside commitState(). Replay
            // only after commit and session-lock submission bookkeeping finish.
            if (output.early_present) |*event| output.processPresent(event);
        },
        .failed => |stage| {
            output.discardRenderMetric();
            const now_ms = retryNowMs();
            if (output.retry.failed(stage, now_ms, wlr_output.refresh)) {
                log.err("output {s}: {s} failed, sequence={} frame_pending={} failures={} retry_in={}ms", .{
                    wlr_output.name,       @tagName(stage),                    wlr_output.commit_seq, wlr_output.frame_pending,
                    output.retry.failures, output.retry.deadline_ms -| now_ms,
                });
            }
            if (!output.retryDisabledForTest()) {
                output.scene_output.?.damage_ring.addWhole();
                output.armRetryTimer();
            }
        },
    }
    output.early_present = null;

    var now = util.timestamp();
    if (!output.current.mirror_of.empty()) {
        output.mirror.notifyStatus(output);
        // Mirrors consume compositor buffers, never client frame callbacks.
        wlr_output.scheduleFrame();
        return;
    }
    output.scene_output.?.sendFrameDone(&now);
    // Clones carry textures rather than scene-surface frame callbacks. Keep only
    // the three presented clients live, without an idle thumbnail polling loop.
    if (server.overview.deck and server.overview.activeOn(output.policyId())) {
        for (server.overview.entries.items) |entry| {
            const ref: Window.Ref = @bitCast(entry.handle);
            if (ref.get()) |window| if (window.state == .mapped) window.sendFrameDone();
        }
    }

    // renderAndCommit early-returns when the scene reports no pending changes, so
    // re-arm the frame loop ourselves while any window on this output is still
    // moving; otherwise the animation would stall after the first eased frame.
    if (outcome != .failed and output.hasActiveAnimations()) {
        wlr_output.scheduleFrame();
    } else {
        // The animation loop is going idle. Clear the delta accumulator so the
        // next slide's first frame starts fresh (dt == 0) instead of inheriting
        // the multi-second gap since this slide ended — which would otherwise
        // produce a single huge first step (clamped to 0.1s) and make every
        // switch after the first appear to snap most of the way instantly.
        output.anim_last_ns = 0;
    }
}

/// Advance the position animation of every window currently displayed on this
/// output by the time elapsed since the previous frame. Returns true when any
/// animation changed scene state. Compiles out (always returns false) when animations
/// are disabled.
fn stepAnimations(output: *Output) bool {
    if (comptime !fx.anim_enabled) return false;

    const now = util.timestamp();
    const now_ns: i64 = @as(i64, @intCast(now.sec)) * std.time.ns_per_s + @as(i64, @intCast(now.nsec));

    var dt_s: f64 = 0;
    if (output.anim_last_ns != 0) {
        const delta_ns = now_ns - output.anim_last_ns;
        dt_s = @as(f64, @floatFromInt(delta_ns)) / @as(f64, std.time.ns_per_s);
        // Clamp so a stall (e.g. after the output was idle) does not teleport the
        // window in a single huge step.
        if (dt_s < 0) dt_s = 0;
        if (dt_s > 0.1) dt_s = 0.1;
    }
    output.anim_last_ns = now_ns;

    if (dt_s <= 0) return false;

    var changed = false;
    var it = server.wm.windows.iterator();
    while (it.next()) |window| {
        const ws = window.workspace orelse continue;
        if (ws.output != output) continue;
        if (window.stepAnimation(dt_s)) changed = true;
    }
    if (server.overview.step(output, dt_s)) changed = true;
    return changed;
}

fn hasActiveAnimations(output: *Output) bool {
    if (comptime !fx.anim_enabled) return false;

    var it = server.wm.windows.iterator();
    while (it.next()) |window| {
        const ws = window.workspace orelse continue;
        if (ws.output != output) continue;
        if (window.anim_active) return true;
    }
    return server.overview.animatingOn(output.policyId());
}

fn renderAndCommit(output: *Output, force: bool, recovering: bool) output_retry.Outcome {
    output.syncWindowVisualState();
    const fifo_pending = output.current.mirror_of.empty() and server.fifo.pending(output.wlr_output.?);
    if (output.current.mirror_of.empty() and !force and !fifo_pending and !output.scene_output.?.needsFrame()) return .skipped;

    const wlr_output = output.wlr_output.?;
    if (output.current.mirror_of.empty()) server.fifo.prepare(wlr_output);
    if (recovering) {
        output.scene_output.?.damage_ring.addWhole();
        wlr_output.lockAttachRender(true);
    }
    defer if (recovering) wlr_output.lockAttachRender(false);

    var state = wlr.Output.State.init();
    defer state.finish();

    output.current.applyNoModeset(&state);

    const was_copy = @import("render/Presentation.zig").usesCopy(wlr_output);
    const collect_metrics = render_metrics.enabled() and output.render_metric_sample == null;
    if (output.injectRetryFailure(.scene_build)) return .{ .failed = .scene_build };
    if (!output.buildSceneStateInternal(
        &state,
        null,
        collect_metrics,
        force,
        !recovering,
    )) {
        if (!@import("render/Presentation.zig").tryCopy(wlr_output) and
            !(!was_copy and @import("render/Presentation.zig").usesCopy(wlr_output)))
            return .{ .failed = .scene_build };
        output.discardRenderMetric();
        output.discardOverlayCandidate();
        state.finish();
        state = wlr.Output.State.init();
        output.current.applyNoModeset(&state);
        output.scene_output.?.damage_ring.addWhole();
        if (!output.buildSceneStateInternal(&state, null, collect_metrics, true, false))
            return .{ .failed = .scene_build };
    }

    // FIFO barriers use a non-tearing latch. The client's tearing preference
    // remains a hint and resumes once its FIFO-constrained update has latched.
    if (!recovering and !fifo_pending and output.current.mirror_of.empty() and output.rendering_current.tearing) {
        state.tearing_page_flip = true;
        // TODO don't try this every frame if it consistently fails. Stop trying if it fails
        // for 10 frames in a row or something.
        if (!wlr_output.testState(&state)) {
            log.info("tearing page flip test failed for {s}, retrying without tearing", .{wlr_output.name});
            state.tearing_page_flip = false;
        }
    }

    if (!output.commitFrameState(&state, .output_commit)) {
        output.discardRenderMetric();
        const promoted_attempt = output.overlay_candidate.promoted or
            (if (comptime build_options.output_retry_testing) output.retry_test.simulate_overlay and !recovering else false);
        const buffer_has_color_pipeline = if (state.buffer) |buffer|
            c.wlr_buffer_has_color_pipeline(@ptrCast(buffer))
        else
            false;
        const color_pipeline_attempt = buffer_has_color_pipeline or
            (if (comptime build_options.output_retry_testing) output.retry_test.simulate_color_pipeline and !recovering else false);
        output.commitOverlayState(false);
        const copied_attempt = @import("render/Presentation.zig").tryCopy(wlr_output);
        if (!promoted_attempt and !color_pipeline_attempt and !copied_attempt) return .{ .failed = .output_commit };

        // The failed state may omit an overlay or contain a primary buffer
        // awaiting hardware color conversion. Rebuild the complete renderer
        // frame, explicitly disable the layer, and retry once.
        // Never recurse: failure of this ordinary composed commit is final for
        // the frame and follows the normal output error path.
        output.scene_output.?.damage_ring.addWhole();
        // A rejected hardware color recipe must be rendered into the fallback
        // buffer. Disable both direct scanout and final-conversion offload.
        wlr_output.lockAttachRender(true);
        defer wlr_output.lockAttachRender(false);
        var fallback = wlr.Output.State.init();
        defer fallback.finish();
        output.current.applyNoModeset(&fallback);
        if (output.injectRetryFailure(.fallback_build) or !output.buildSceneStateInternal(
            &fallback,
            null,
            collect_metrics,
            true,
            false,
        )) return .{ .failed = .fallback_build };
        if (!output.commitFrameState(&fallback, .fallback_commit)) {
            output.discardRenderMetric();
            output.commitOverlayState(false);
            return .{ .failed = .fallback_commit };
        }
        output.commitOverlayState(true);
    } else {
        output.commitOverlayState(true);
    }
    if (comptime build_options.vulkan_effects) {
        output.blur_cache.clearPendingDamage();
    }

    if (!output.current.mirror_of.empty()) {
        output.lock_render_state = if (server.lock_manager.state == .unlocked) .pending_unlock else .pending_blank;
        return .committed;
    }
    switch (server.lock_manager.state) {
        .unlocked => {
            if (output.lock_render_state != .unlocked) {
                output.lock_render_state = .pending_unlock;
            }
        },
        .locked => {
            assert(!server.scene.normal_tree.node.enabled);
            switch (output.lock_render_state) {
                .pending_unlock, .unlocked, .pending_blank, .pending_lock_surface => unreachable,
                .blanked, .lock_surface => {},
            }
        },
        .waiting_for_blank => {
            assert(!server.scene.normal_tree.node.enabled);
            if (output.lock_render_state != .blanked) {
                output.lock_render_state = .pending_blank;
            }
        },
        .waiting_for_lock_surfaces => {
            const lock_surface_mapped = blk: {
                if (server.lock_manager.lockSurfaceFromOutput(output)) |lock_surface| {
                    break :blk lock_surface.wlr_lock_surface.surface.mapped;
                } else {
                    break :blk false;
                }
            };
            if (lock_surface_mapped) {
                if (output.lock_render_state != .lock_surface) {
                    output.lock_render_state = .pending_lock_surface;
                }
            } else {
                if (output.lock_render_state != .unlocked) {
                    output.lock_render_state = .pending_unlock;
                }
            }
        },
    }
    return .committed;
}

pub fn buildSceneState(
    output: *Output,
    state: *wlr.Output.State,
    swapchain: ?*wlr.Swapchain,
    collect_metrics: bool,
    animation_changed_scene: bool,
) bool {
    return output.buildSceneStateInternal(
        state,
        swapchain,
        collect_metrics,
        animation_changed_scene,
        true,
    );
}

fn buildSceneStateInternal(
    output: *Output,
    state: *wlr.Output.State,
    swapchain: ?*wlr.Swapchain,
    collect_metrics: bool,
    animation_changed_scene: bool,
    allow_overlay: bool,
) bool {
    if (output.wlr_output) |w| {
        if (@import("render/Presentation.zig").usesCopy(w) and
            !hdr.apply(w, false, .l1000, hdr.default_sdr_white_level, state)) return false;
    }
    if (!output.sent.mirror_of.empty()) {
        // A newly mirrored output may still owe baseline restoration. Mirror
        // sources are revoked before the transaction is built; its copied SDR
        // buffer must pass the same prepared-buffer commit guard.
        var options: c.struct_wlr_scene_output_state_options = std.mem.zeroes(c.struct_wlr_scene_output_state_options);
        if (!server.om.warming.prepare(output.wlr_output.?, output.scene_output.?, state, &options)) return false;
        const built = output.mirror.build(output, state, swapchain);
        server.om.warming.built(output.wlr_output.?, state, built);
        return built;
    }
    output.syncWindowVisualState();
    output.effects_swapchain_path = swapchain != null;
    defer output.effects_swapchain_path = false;

    const full_blur_damage =
        output.prepareFullBlurDamage(animation_changed_scene);
    var scene_options: c.struct_wlr_scene_output_state_options = std.mem.zeroes(c.struct_wlr_scene_output_state_options);
    scene_options.swapchain = @ptrCast(swapchain);
    output.prepareOverlayCandidate(&scene_options, allow_overlay and !output.mirror_source_locked);
    if (collect_metrics) {
        output.render_metric_sample = .{};
        scene_options.timer = @ptrCast(&output.render_metric_sample.?.timer);
    }

    if (!server.om.warming.prepare(output.wlr_output.?, output.scene_output.?, state, &scene_options)) {
        if (collect_metrics) output.discardRenderMetric();
        return false;
    }
    const warming_built = c.wlr_scene_output_build_state(
        @ptrCast(output.scene_output.?),
        @ptrCast(state),
        &scene_options,
    );
    server.om.warming.built(output.wlr_output.?, state, warming_built);
    if (!warming_built) {
        if (collect_metrics) output.discardRenderMetric();
        return false;
    }
    output.finishOverlayBuild();
    output.recordVulkanEffectsMetric();
    if (full_blur_damage) output.setFullBlurDamage(state);
    return true;
}

fn prepareOverlayCandidate(
    output: *Output,
    options: *c.struct_wlr_scene_output_state_options,
    allow_overlay: bool,
) void {
    const layer = output.overlay_layer orelse return;

    output.discardOverlayCandidate();
    output.overlay_candidate = std.mem.zeroes(c.struct_wlr_scene_output_layer_candidate);
    output.overlay_candidate.layer = layer;
    output.overlay_candidate.previously_promoted = output.overlay_state.committed;
    options.layer_candidate = &output.overlay_candidate;

    if (!allow_overlay) return;
    if (server.lock_manager.state != .unlocked) {
        output.overlay_state.setIneligible(.session_locked);
        return;
    }
    if (server.session) |session| if (!session.active) {
        output.overlay_state.setIneligible(.session_inactive);
        return;
    };
    const wlr_output = output.wlr_output orelse {
        output.overlay_state.setIneligible(.backend_unavailable);
        return;
    };
    if (!wlr_output.isDirectScanoutAllowed()) {
        output.overlay_state.setIneligible(.capture_active);
        return;
    }
    if (wlr_output.software_cursor_locks > 0) {
        output.overlay_state.setIneligible(.software_cursor);
        return;
    }
    if (output.current.scale != 1) {
        output.overlay_state.setIneligible(.scaled);
        return;
    }
    if (output.current.transform != .normal) {
        output.overlay_state.setIneligible(.transformed);
        return;
    }

    const window = output.selectOverlayWindow() orelse {
        output.overlay_state.setIneligible(.no_candidate);
        return;
    };
    const buffer = window.overlaySceneBuffer() orelse {
        output.overlay_state.setCandidateIneligible(
            @bitCast(window.ref),
            overlayDestination(output, window),
            .candidate_destroyed,
        );
        return;
    };
    var source = buffer.buffer orelse {
        output.overlay_state.setCandidateIneligible(
            @bitCast(window.ref),
            overlayDestination(output, window),
            .candidate_destroyed,
        );
        return;
    };
    if (wlr.ClientBuffer.get(source)) |client_buffer| {
        if (client_buffer.source) |client_source| {
            if (client_source.n_locks > 0) source = client_source;
        }
    }
    var dmabuf: wlr.DmabufAttributes = undefined;
    if (!source.getDmabuf(&dmabuf)) {
        output.overlay_state.setCandidateIneligible(
            @bitCast(window.ref),
            overlayDestination(output, window),
            .no_dmabuf,
        );
        return;
    }

    const assignment: overlay_planes.AssignmentKey = .{
        .candidate_id = @bitCast(window.ref),
        .output_generation = output.overlay_state.capability_generation,
        .format = dmabuf.format,
        .modifier = dmabuf.modifier,
        .buffer_width = dmabuf.width,
        .buffer_height = dmabuf.height,
        .destination = overlayDestination(output, window),
        .output_scale_bits = @bitCast(output.current.scale),
        .output_transform = @intCast(@intFromEnum(output.current.transform)),
        .output_width = output.current.dimensions()[0],
        .output_height = output.current.dimensions()[1],
        .adaptive_sync = output.actualAdaptiveSync(),
        .blocker_generation = output.overlay_state.blocker_generation,
    };
    if (!output.overlay_state.shouldAttempt(assignment, overlayNowMs())) {
        output.traceOverlayState("test skipped");
        return;
    }

    output.overlay_candidate.buffer = @ptrCast(buffer);
}

fn selectOverlayWindow(output: *Output) ?*Window {
    var selected: ?*Window = null;
    var selected_score: overlay_planes.CandidateScore = undefined;
    var windows = server.wm.windows.iterator();
    while (windows.next()) |window| {
        if (window.state != .mapped or window.overlayPreference() != .prefer or
            window.anim_active) continue;
        const workspace = window.workspace orelse continue;
        if (workspace.output != output or output.active_workspace != workspace) continue;
        if (window.overlaySceneBuffer() == null) continue;

        const snapshot = window.infoSnapshot();
        const stable_id: u64 = @bitCast(window.ref);
        const area: u64 = @as(u64, @intCast(@max(window.box.width, 0))) *
            @as(u64, @intCast(@max(window.box.height, 0)));
        const score: overlay_planes.CandidateScore = .{
            .currently_promoted = output.overlay_state.committed_candidate_id == stable_id,
            .focused_fullscreen = snapshot.focused and snapshot.fullscreen,
            .focused = snapshot.focused,
            .fullscreen = snapshot.fullscreen,
            .visible_area = area,
            .stable_id = stable_id,
        };
        if (selected == null or score.betterThan(selected_score)) {
            selected = window;
            selected_score = score;
        }
    }
    return selected;
}

fn overlayDestination(output: *const Output, window: *const Window) overlay_planes.Rect {
    return .{
        .x = window.box.x - output.current.x,
        .y = window.box.y - output.current.y,
        .width = window.box.width,
        .height = window.box.height,
    };
}

fn overlayNowMs() u64 {
    const now = util.timestamp();
    return @as(u64, @intCast(now.sec)) * std.time.ms_per_s +
        @as(u64, @intCast(@divTrunc(now.nsec, std.time.ns_per_ms)));
}

fn overlayTraceBudget() u32 {
    const raw = std.c.getenv("AQUEOUS_OVERLAY_TRACE_BUDGET") orelse return 0;
    return @min(std.fmt.parseInt(u32, std.mem.span(raw), 10) catch 0, 10_000);
}

fn traceOverlayState(output: *Output, action: []const u8) void {
    if (output.overlay_state.trace_budget == 0) return;
    output.overlay_state.trace_budget -= 1;
    const snapshot = output.overlay_state.snapshot(overlayNowMs());
    const wlr_output = output.wlr_output orelse return;
    log.debug(
        "output {s}: overlay {s} candidate=0x{x} phase={s} reason={s} backoff={}ms attempts={}",
        .{
            wlr_output.name,
            action,
            snapshot.candidate_id,
            @tagName(snapshot.phase),
            @tagName(snapshot.reason),
            snapshot.backoff_remaining_ms,
            snapshot.counters.attempts,
        },
    );
}

fn overlayRejectionReason(reason: c_uint) overlay_planes.RejectionReason {
    return switch (reason) {
        c.WLR_SCENE_OUTPUT_LAYER_REJECTION_WRONG_NODE,
        c.WLR_SCENE_OUTPUT_LAYER_REJECTION_NO_BUFFER,
        => .candidate_destroyed,
        c.WLR_SCENE_OUTPUT_LAYER_REJECTION_OUTPUT_STATE => .backend_test_rejected,
        c.WLR_SCENE_OUTPUT_LAYER_REJECTION_CAPTURE_ACTIVE => .capture_active,
        c.WLR_SCENE_OUTPUT_LAYER_REJECTION_SOFTWARE_CURSOR => .software_cursor,
        c.WLR_SCENE_OUTPUT_LAYER_REJECTION_NOT_OPAQUE => .not_opaque,
        c.WLR_SCENE_OUTPUT_LAYER_REJECTION_TRANSFORMED => .transformed,
        c.WLR_SCENE_OUTPUT_LAYER_REJECTION_CLIPPED,
        c.WLR_SCENE_OUTPUT_LAYER_REJECTION_OUTSIDE_OUTPUT,
        => .clipped,
        c.WLR_SCENE_OUTPUT_LAYER_REJECTION_EFFECTS,
        c.WLR_SCENE_OUTPUT_LAYER_REJECTION_COLOR,
        => .effects_active,
        c.WLR_SCENE_OUTPUT_LAYER_REJECTION_SCALED => .scaled,
        c.WLR_SCENE_OUTPUT_LAYER_REJECTION_INTERSECTED => .intersected,
        c.WLR_SCENE_OUTPUT_LAYER_REJECTION_BACKEND_TEST => .backend_test_rejected,
        else => .backend_test_rejected,
    };
}

fn finishOverlayBuild(output: *Output) void {
    if (output.overlay_candidate.buffer == null or output.overlay_state.pending_key == null) return;
    if (!output.overlay_candidate.tested) {
        output.overlay_state.recordEligibilityRejected(
            overlayRejectionReason(@intCast(output.overlay_candidate.rejection_reason)),
            overlayNowMs(),
        );
    } else if (output.overlay_candidate.promoted and output.overlay_candidate.state.accepted) {
        output.overlay_state.recordTestAccepted();
    } else {
        output.overlay_state.recordTestRejected(
            overlayRejectionReason(@intCast(output.overlay_candidate.rejection_reason)),
            overlayNowMs(),
        );
    }
    output.traceOverlayState("test completed");
}

pub fn discardOverlayCandidate(output: *Output) void {
    c.wlr_scene_output_layer_candidate_finish(&output.overlay_candidate, false);
}

pub fn commitOverlayState(output: *Output, commit_succeeded: bool) void {
    if (output.overlay_layer == null) return;
    const promoted = output.overlay_candidate.promoted and
        output.overlay_candidate.state.accepted;
    c.wlr_scene_output_layer_candidate_finish(
        &output.overlay_candidate,
        commit_succeeded and promoted,
    );
    const was_promoted = output.overlay_state.committed;
    if (!commit_succeeded and output.overlay_candidate.promoted) {
        output.overlay_state.recordPromotedCommitFailure(overlayNowMs());
    } else if (commit_succeeded) {
        output.overlay_state.recordCommitSuccess(promoted);
    }
    if (commit_succeeded and promoted != was_promoted) {
        const wlr_output = output.wlr_output orelse return;
        const counters = output.overlay_state.counters;
        log.info(
            "output {s}: DRM overlay-plane promotion {s} (attempts={}, accepted={}, rejected={}, fallback={})",
            .{
                wlr_output.name,
                if (promoted) "active" else "inactive",
                counters.attempts,
                counters.accepted_tests,
                counters.backend_rejections,
                counters.fallback_retries,
            },
        );
    }
}

pub fn overlaySnapshot(output: *const Output) overlay_planes.Snapshot {
    return output.overlay_state.snapshot(overlayNowMs());
}

pub fn invalidateOverlayCapabilities(output: *Output) void {
    output.overlay_state.invalidateCapabilities();
}

fn syncWindowVisualState(output: *Output) void {
    _ = output;
    var windows = server.wm.windows.iterator();
    while (windows.next()) |window| window.applyOpacity();
    server.background_effect_manager.sync();
}

fn handlePresent(
    listener: *wl.Listener(*wlr.Output.event.Present),
    event: *wlr.Output.event.Present,
) void {
    const output: *Output = @fieldParentPtr("present", listener);
    if (output.render_commit_active) {
        output.early_present = event.*;
        return;
    }
    output.processPresent(event);
}

fn processPresent(output: *Output, event: *const wlr.Output.event.Present) void {
    @import("DisplayPreview.zig").presented(output.display_instance, event.commit_seq, event.presented);
    if (!output.current.mirror_of.empty() and event.commit_seq != output.mirror.commit_seq) return;
    if (output.current.mirror_of.empty() and server.fifo.present(output.wlr_output.?, event) and
        output.retryEnabled() and !output.retryDisabledForTest())
    {
        // Rejected presentation is not a FIFO latch. Preserve the barrier and
        // retry with the same backoff used for failed scene/output submissions.
        _ = output.retry.failed(.output_commit, retryNowMs(), output.wlr_output.?.refresh);
        output.scene_output.?.damage_ring.addWhole();
        output.armRetryTimer();
    }
    output.finishRenderMetric();
    if (output.retry.presented(event.commit_seq, event.presented)) {
        log.info("output {s}: recovery presented, sequence={}", .{ output.policyName(), event.commit_seq });
    }
    if (!event.presented) {
        return;
    }
    switch (output.lock_render_state) {
        .pending_unlock => {
            assert(server.lock_manager.state != .locked);
            output.lock_render_state = .unlocked;
        },
        .unlocked => assert(server.lock_manager.state != .locked),
        .pending_blank => {
            output.lock_render_state = .blanked;
            if (server.lock_manager.state != .locked) {
                server.lock_manager.maybeLock();
            }
        },
        .pending_lock_surface => {
            output.lock_render_state = .lock_surface;
            if (server.lock_manager.state != .locked) {
                server.lock_manager.maybeLock();
            }
        },
        .blanked, .lock_surface => {},
    }
}

fn pinnedByName(output: *Output, name: [:0]const u8) ?*Workspace {
    var it = output.workspaces.iterator(.forward);
    while (it.next()) |workspace| {
        if (workspace.pinned and std.mem.eql(u8, workspace.name, name)) {
            return workspace;
        }
    }
    return null;
}

pub fn actualAdaptiveSync(output: *const Output) bool {
    if (comptime build_options.output_retry_testing) if (output.adaptive_sync_test.enabled) return output.adaptive_sync_test.actual;
    const w = output.wlr_output orelse return false;
    return w.adaptive_sync_status == .enabled;
}

pub fn adaptiveSyncTarget(output: *const Output, state: State) bool {
    var fullscreen = false;
    if (output.active_workspace) |workspace| {
        var windows = workspace.windows.iterator(.forward);
        while (windows.next()) |window| {
            if (window.state == .mapped and window.wm_requested.fullscreen == output and
                window.policy_state.isVisible() and !window.rendering_requested.hidden and
                !window.overview_hidden)
            {
                fullscreen = true;
                break;
            }
        }
    }
    var active = if (server.session) |session| session.active else true;
    if (comptime build_options.output_retry_testing) if (output.adaptive_sync_test.inactive) {
        active = false;
    };
    return @import("adaptive_sync_policy.zig").target(state.adaptive_sync, state.fullscreen_only_adaptive_sync, .{
        .enabled = output.wlr_output != null and state.state == .enabled,
        .mirror = !state.mirror_of.empty(),
        .session_active = active,
        .unlocked = server.lock_manager.state == .unlocked,
        .overview = server.aqueous.overview != null,
        .fullscreen = fullscreen,
    });
}

pub fn adaptiveSyncError(output: *const Output) ?[]const u8 {
    return if (output.adaptive_sync_policy.failure) |failure| @tagName(failure) else null;
}

/// Capture once for the transaction, after live window visibility is finalized.
pub fn prepareAdaptiveSync(output: *Output) void {
    if (!std.meta.eql(output.sent, output.current)) output.adaptive_sync_policy.reset();
    output.adaptive_sync_policy.update(output.adaptiveSyncTarget(output.sent));
    output.adaptive_sync_before = output.actualAdaptiveSync();
    const w = output.wlr_output orelse return;
    var supported = w.adaptive_sync_supported;
    if (comptime build_options.output_retry_testing) supported = supported or output.adaptive_sync_test.enabled;
    if (output.adaptive_sync_policy.target and !supported) output.adaptive_sync_policy.failure = .unsupported;
    output.adaptive_sync_commit_target = if (output.adaptive_sync_policy.failure == null)
        output.adaptive_sync_policy.target
    else
        output.adaptive_sync_before;
}

/// Change VRR without replacing swapchains, color state or window layout.
pub fn commitAdaptiveSync(output: *Output) bool {
    const w = output.wlr_output orelse return true;
    if (output.sent.state != .enabled or !output.adaptive_sync_policy.shouldCommit(output.actualAdaptiveSync())) return true;
    if (server.session) |session| if (!session.active) return true;
    output.adaptive_sync_policy.attempts += 1;
    const success = blk: {
        if (comptime build_options.output_retry_testing) if (output.adaptive_sync_test.enabled) {
            const accepted = !output.adaptive_sync_test.fail_next;
            output.adaptive_sync_test.fail_next = false;
            if (accepted) output.adaptive_sync_test.actual = output.adaptive_sync_policy.target;
            break :blk accepted;
        };
        var state = wlr.Output.State.init();
        defer state.finish();
        state.setAdaptiveSyncEnabled(output.adaptive_sync_commit_target);
        break :blk w.commitState(&state);
    };
    if (!success) {
        output.adaptive_sync_policy.failure = .commit_failed;
        log.warn("output {s}: adaptive sync toggle rejected; retaining hardware state", .{w.name});
    } else {
        output.adaptive_sync_policy.reset();
        output.overlay_state.invalidateCapabilities();
        server.om.display_revision += 1;
    }
    return success;
}

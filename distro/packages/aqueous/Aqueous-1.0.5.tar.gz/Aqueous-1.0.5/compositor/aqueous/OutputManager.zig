// SPDX-FileCopyrightText: © 2026 Seafoam Labs
// SPDX-License-Identifier: GPL-3.0-only

const OutputManager = @This();

const build_options = @import("build_options");
const std = @import("std");
const assert = std.debug.assert;
const math = std.math;
const mem = std.mem;
const wlr = @import("wlroots");
const wl = @import("wayland").server.wl;
const zwlr = @import("wayland").server.zwlr;

const server = &@import("main.zig").server;
const util = @import("util.zig");

const DragIcon = @import("DragIcon.zig");
const LockSurface = @import("LockSurface.zig");
const Output = @import("Output.zig");
const SceneNodeData = @import("SceneNodeData.zig");
const Window = @import("Window.zig");
const XwaylandOverrideRedirect = @import("XwaylandOverrideRedirect.zig");
const OutputConfig = @import("wm/output/config.zig");
const autolayout = @import("wm/output/autolayout.zig");
const mode_match = @import("wm/output/mode_match.zig");
const xwayland_projection = @import("xwayland_projection.zig");

const log = std.log.scoped(.output);

/// The very first modeset is different in that if it fails we exit river.
first_modeset: bool = true,
committing_outputs: bool = false,
display_revision: u64 = 1,
next_display_instance: u64 = 0,

new_output: wl.Listener(*wlr.Output) = .init(handleNewOutput),
session: ?*wlr.Session = null,
session_active: wl.Listener(void) = .init(handleSessionActive),
session_destroy: wl.Listener(*wlr.Session) = .init(handleSessionDestroy),

output_layout: *wlr.OutputLayout,

presentation: *wlr.Presentation,
xdg_output_manager: *wlr.XdgOutputManagerV1,

wlr_output_manager: *wlr.OutputManagerV1,
manager_apply: wl.Listener(*wlr.OutputConfigurationV1) = .init(handleManagerApply),
manager_test: wl.Listener(*wlr.OutputConfigurationV1) = .init(handleManagerTest),

power_manager: *wlr.OutputPowerManagerV1,
power_manager_set_mode: wl.Listener(*wlr.OutputPowerManagerV1.event.SetMode) = .init(handlePowerManagerSetMode),

gamma_control_manager: *wlr.GammaControlManagerV1,
warming: *@import("OutputWarming.zig"),

/// All Outputs that have a corresponding wlr_output.
outputs: wl.list.Head(Output, .link),

pub fn init(om: *OutputManager) !void {
    const output_layout = try wlr.OutputLayout.create(server.wl_server);
    errdefer output_layout.destroy();

    const gamma_control_manager = try wlr.GammaControlManagerV1.create(server.wl_server);
    server.scene.wlr_scene.setGammaControlManagerV1(gamma_control_manager);

    om.* = .{
        .output_layout = output_layout,
        .outputs = undefined,

        .presentation = try wlr.Presentation.create(server.wl_server, server.backend, 2),
        .xdg_output_manager = try wlr.XdgOutputManagerV1.create(server.wl_server, output_layout),
        .wlr_output_manager = try wlr.OutputManagerV1.create(server.wl_server),
        .power_manager = try wlr.OutputPowerManagerV1.create(server.wl_server),
        .gamma_control_manager = gamma_control_manager,
        .warming = try @import("OutputWarming.zig").init(util.gpa, server.wl_server, gamma_control_manager),
    };

    om.outputs.init();
    om.session = server.session;
    om.warming.active(if (om.session) |session| session.active else true);
    if (om.session) |session| {
        session.events.active.add(&om.session_active);
        session.events.destroy.add(&om.session_destroy);
    }

    server.backend.events.new_output.add(&om.new_output);
    om.wlr_output_manager.events.apply.add(&om.manager_apply);
    om.wlr_output_manager.events.@"test".add(&om.manager_test);
    om.power_manager.events.set_mode.add(&om.power_manager_set_mode);
}

pub fn deinit(om: *OutputManager) void {
    om.warming.deinit();
    if (om.session != null) {
        om.session_active.link.remove();
        om.session_destroy.link.remove();
    }
    om.manager_apply.link.remove();
    om.manager_test.link.remove();
    om.power_manager_set_mode.link.remove();

    om.output_layout.destroy();
}

fn handleSessionActive(listener: *wl.Listener(void)) void {
    const om: *OutputManager = @fieldParentPtr("session_active", listener);
    om.warming.active(if (om.session) |session| session.active else false);
    var outputs = om.outputs.iterator(.forward);
    while (outputs.next()) |output| output.adaptive_sync_policy.reset();
    server.wm.dirtyWindowing();
}

fn handleSessionDestroy(listener: *wl.Listener(*wlr.Session), _: *wlr.Session) void {
    const om: *OutputManager = @fieldParentPtr("session_destroy", listener);
    om.session_active.link.remove();
    om.session_destroy.link.remove();
    om.warming.active(false);
    om.session = null;
}

fn handleNewOutput(_: *wl.Listener(*wlr.Output), wlr_output: *wlr.Output) void {
    log.debug("new output {s}", .{wlr_output.name});

    if (server.drm_lease.reserve(wlr_output)) return;

    Output.create(wlr_output) catch |err| {
        switch (@as(anyerror, err)) {
            error.OutOfMemory => log.err("out of memory", .{}),
            error.InitRenderFailed => log.err("failed to initialize renderer for output {s}", .{wlr_output.name}),
            error.AddTimerFailed => log.err("failed to create recovery timer for output {s}", .{wlr_output.name}),
            else => log.err("output {s}: presentation initialization failed: {s}", .{ wlr_output.name, @errorName(err) }),
        }
        if (server.om.first_modeset) {
            server.fatal_error = error.PresentationUnavailable;
            server.wl_server.terminate();
        }
        wlr_output.destroy();
        return;
    };
    server.aqueous.output_service.outputsChanged(true);
}

/// Returns null if there are no outputs in the output layout
pub fn outputAt(om: *OutputManager, lx: f64, ly: f64) ?*wlr.Output {
    var output_lx: f64 = undefined;
    var output_ly: f64 = undefined;
    om.output_layout.closestPoint(null, lx, ly, &output_lx, &output_ly);
    return om.output_layout.outputAt(output_lx, output_ly);
}

pub const ApplyError = error{
    DisplayPreviewBusy,
    MissingMatcher,
    UnknownOutput,
    WildcardPosition,
    ModeNotAdvertised,
    HdrUnsupported,
    InvalidCoordinates,
    TooManyOutputs,
    InvalidMirror,
};

pub const RejectionReason = enum {
    missing_matcher,
    unknown_output,
    wildcard_position,
    mode_not_advertised,
    hdr_unsupported,
    invalid_coordinates,
};

pub const Rejection = struct {
    spec_index: usize,
    matcher_kind: enum { name, edid },
    matcher: OutputConfig.Text,
    output_name: ?[]const u8,
    reason: RejectionReason,
};

pub const max_rejections = OutputConfig.max_outputs * 2;

pub const ApplyReport = struct {
    applied: usize = 0,
    rejections: [max_rejections]Rejection = undefined,
    rejection_count: usize = 0,
    total_rejections: usize = 0,

    fn reject(
        report: *ApplyReport,
        spec_index: usize,
        matcher_kind: @FieldType(Rejection, "matcher_kind"),
        matcher: OutputConfig.Text,
        output_name: ?[]const u8,
        reason: RejectionReason,
    ) void {
        if (report.rejection_count < report.rejections.len) {
            report.rejections[report.rejection_count] = .{
                .spec_index = spec_index,
                .matcher_kind = matcher_kind,
                .matcher = matcher,
                .output_name = output_name,
                .reason = reason,
            };
            report.rejection_count += 1;
        }
        report.total_rejections += 1;
    }
};

pub fn rejectionMessage(reason: RejectionReason) []const u8 {
    return switch (reason) {
        .missing_matcher => "missing 'name' or 'edid'",
        .unknown_output => "no connected output matches the spec",
        .wildcard_position => "position is not allowed with a wildcard name",
        .mode_not_advertised => "mode is not advertised by the output",
        .hdr_unsupported => "HDR10 is not supported by the output, renderer, or 10-bit scanout path",
        .invalid_coordinates => "coordinates are incompatible with Xwayland",
    };
}

/// Validate and stage a native output transaction. Later specs override fields
/// from earlier specs, which preserves outputd's wildcard-then-specific behavior.
/// A rejected spec/output pair is reported and skipped without preventing valid
/// settings for other outputs from being staged. The existing WindowManager
/// transaction performs the atomic backend commit and restores `current` if
/// wlroots rejects the modeset.
pub const Pending = struct { output: *Output, state: Output.State };
pub const Plan = struct { items: [OutputConfig.max_outputs]Pending = undefined, len: usize = 0, report: ApplyReport = .{} };
pub fn applySpecs(om: *OutputManager, specs: []const OutputConfig.Spec) ApplyError!ApplyReport {
    if (@import("DisplayPreview.zig").active()) return error.DisplayPreviewBusy;
    const plan = try om.prepareSpecs(specs);
    for (plan.items[0..plan.len]) |entry| {
        entry.output.scheduled = entry.state;
        entry.output.adaptive_sync_policy.reset();
    }
    if (plan.len != 0) {
        om.display_revision += 1;
        server.wm.dirtyWindowing();
    }
    return plan.report;
}
pub fn prepareSpecs(om: *OutputManager, specs: []const OutputConfig.Spec) ApplyError!Plan {
    var pending: [OutputConfig.max_outputs]Pending = undefined;
    var pending_count: usize = 0;
    var report: ApplyReport = .{};

    for (specs, 0..) |*spec, spec_index| {
        const matcher_kind: @FieldType(Rejection, "matcher_kind") = if (!spec.edid.empty()) .edid else .name;
        const matcher = if (matcher_kind == .edid) spec.edid else spec.name;
        if (spec.name.empty() and spec.edid.empty()) {
            report.reject(spec_index, matcher_kind, matcher, null, .missing_matcher);
            continue;
        }
        const wildcard = spec.edid.empty() and hasGlob(spec.name.slice());
        if (wildcard and spec.x != null) {
            report.reject(spec_index, matcher_kind, matcher, null, .wildcard_position);
            continue;
        }
        var matched: usize = 0;
        var it = om.outputs.iterator(.forward);
        while (it.next()) |output| {
            const wlr_output = output.wlr_output orelse continue;
            if (!matchesSpec(spec, wlr_output)) continue;
            matched += 1;
            var index: ?usize = null;
            var created = false;
            for (pending[0..pending_count], 0..) |entry, i| if (entry.output == output) {
                index = i;
                break;
            };
            if (index == null) {
                if (pending_count == pending.len) return error.TooManyOutputs;
                pending[pending_count] = .{ .output = output, .state = output.scheduled };
                index = pending_count;
                pending_count += 1;
                created = true;
            }
            var proposed = pending[index.?].state;
            applySpecToState(spec, wlr_output, &proposed) catch |err| {
                if (created) pending_count -= 1;
                report.reject(spec_index, matcher_kind, matcher, std.mem.span(wlr_output.name), switch (err) {
                    error.ModeNotAdvertised => .mode_not_advertised,
                    error.HdrUnsupported => .hdr_unsupported,
                    else => unreachable,
                });
                continue;
            };
            const previous = pending[index.?].state;
            pending[index.?].state = proposed;
            if (!om.coordinatesValid(pending[0..pending_count])) {
                pending[index.?].state = previous;
                if (created) pending_count -= 1;
                report.reject(spec_index, matcher_kind, matcher, std.mem.span(wlr_output.name), .invalid_coordinates);
                continue;
            }
        }
        if (matched == 0) report.reject(spec_index, matcher_kind, matcher, null, .unknown_output);
    }

    // Validate the complete proposed graph before publishing any state.
    var mirrors: usize = 0;
    var all = om.outputs.iterator(.forward);
    while (all.next()) |output| {
        var state = output.scheduled;
        for (pending[0..pending_count]) |entry| if (entry.output == output) {
            state = entry.state;
        };
        if (state.mirror_of.empty() or state.state == .destroying) continue;
        mirrors += 1;
        if (mirrors > 1 or !@import("OutputMirror.zig").supported() or state.hdr_enabled or state.transform != .normal or state.adaptive_sync or
            std.mem.eql(u8, state.mirror_of.slice(), output.policyName())) return error.InvalidMirror;
        var sources = om.outputs.iterator(.forward);
        while (sources.next()) |source| {
            if (!std.mem.eql(u8, source.policyName(), state.mirror_of.slice())) continue;
            var source_state = source.scheduled;
            for (pending[0..pending_count]) |entry| if (entry.output == source) {
                source_state = entry.state;
            };
            if (!source_state.mirror_of.empty() or source_state.hdr_enabled or source_state.transform != .normal or
                source.wlr_output.?.backend != output.wlr_output.?.backend) return error.InvalidMirror;
        }
    }
    report.applied = pending_count;
    return .{ .items = pending, .len = pending_count, .report = report };
}

fn coordinatesValid(om: *OutputManager, pending: []const Pending) bool {
    var specs: [OutputConfig.max_outputs]xwayland_projection.Output = undefined;
    var count: usize = 0;
    var it = om.outputs.iterator(.forward);
    while (it.next()) |output| {
        var state = output.scheduled;
        for (pending) |entry| if (entry.output == output) {
            state = entry.state;
            break;
        };
        if (!state.mirror_of.empty() or (state.state != .enabled and state.state != .disabled_soft)) continue;
        const width, const height = state.dimensions();
        // Scene boxes use i32 even when Xwayland is disabled.
        if (@as(i64, state.x) + width > math.maxInt(i32) or
            @as(i64, state.y) + height > math.maxInt(i32)) return false;
        if (count == specs.len) return false;
        specs[count] = projectionSpec(&state);
        count += 1;
    }
    return !server.xwayland_enabled or
        xwayland_projection.layoutValid(specs[0..count], server.xwayland_scaling);
}

fn applySpecToState(spec: *const OutputConfig.Spec, wlr_output: *wlr.Output, state: *Output.State) ApplyError!void {
    if (spec.mirror_of) |name| state.mirror_of = name;
    if (spec.enabled) |enabled| state.state = if (enabled) .enabled else .disabled_hard;
    if (spec.mode) |requested| {
        var selected: ?*wlr.Output.Mode = null;
        var modes = wlr_output.modes.iterator(.forward);
        while (modes.next()) |mode| {
            if (mode.width != requested.width or mode.height != requested.height) continue;
            const candidate: mode_match.Candidate = .{
                .refresh_mhz = mode.refresh,
                .preferred = mode.preferred,
            };
            const best: ?mode_match.Candidate = if (selected) |current| .{
                .refresh_mhz = current.refresh,
                .preferred = current.preferred,
            } else null;
            if (mode_match.prefer(requested.refresh_mhz, best, candidate)) {
                selected = mode;
            }
        }
        if (selected) |mode| {
            state.mode = .{ .standard = mode };
            if (requested.refresh_mhz) |refresh| log.info(
                "output {s}: requested {d}x{d}@{d} mHz, selected {d} mHz",
                .{ wlr_output.name, requested.width, requested.height, refresh, mode.refresh },
            );
        } else if (wlr_output.modes.first() == null) {
            state.mode = .{ .custom = .{ .width = requested.width, .height = requested.height, .refresh = requested.refresh_mhz orelse 0 } };
        } else return error.ModeNotAdvertised;
    }
    if (spec.scale) |scale| state.scale = scale;
    if (spec.transform) |transform| state.transform = transformToWl(transform);
    if (spec.x) |x| {
        state.x = x;
        state.y = spec.y.?;
        state.position_source = .configuration;
    }
    if (spec.adaptive_sync) |adaptive_sync| state.adaptive_sync = adaptive_sync;
    if (spec.fullscreen_only_adaptive_sync) |value| state.fullscreen_only_adaptive_sync = value;
    if (spec.hdr) |enabled| {
        if (enabled and !Output.hdr.capable(wlr_output)) return error.HdrUnsupported;
        state.hdr_enabled = enabled;
    }
    if (spec.hdr_level) |choice| state.hdr_level = switch (choice) {
        .auto => Output.hdr.autoLevel(wlr_output) orelse .l1000,
        .l100 => .l100,
        .l400 => .l400,
        .l1000 => .l1000,
    };
    if (spec.sdr_white_level) |white| state.sdr_white_level = white;
    if (spec.auto_hdr) |enabled| state.auto_hdr = enabled;
    if (spec.auto_hdr_boost) |boost| state.auto_hdr_boost = boost;
}

/// Shared with the in-process output service when resolving the configured
/// primary output. Keeping this matcher in one place ensures name globs and
/// EDID identities have identical semantics for modesetting and selection.
pub fn matchesSpec(spec: *const OutputConfig.Spec, output: *wlr.Output) bool {
    if (!spec.edid.empty()) {
        var buffer: [7 + 64]u8 = undefined;
        const hash = outputIdentityHash(output, &buffer) orelse return false;
        return std.ascii.eqlIgnoreCase(spec.edid.slice(), hash);
    }
    return globMatch(spec.name.slice(), std.mem.span(output.name));
}

pub fn outputIdentityHash(output: *wlr.Output, buffer: *[71]u8) ?[]const u8 {
    if (output.make == null and output.model == null and output.serial == null) return null;
    var identity: [768]u8 = undefined;
    const source = std.fmt.bufPrint(&identity, "{s}|{s}|{s}", .{
        if (output.make) |value| std.mem.span(value) else "",
        if (output.model) |value| std.mem.span(value) else "",
        if (output.serial) |value| std.mem.span(value) else "",
    }) catch return null;
    var digest: [32]u8 = undefined;
    std.crypto.hash.sha2.Sha256.hash(source, &digest, .{});
    const hex = std.fmt.bytesToHex(digest, .lower);
    return std.fmt.bufPrint(buffer, "sha256:{s}", .{hex}) catch null;
}

fn hasGlob(pattern: []const u8) bool {
    return std.mem.indexOfAny(u8, pattern, "*?") != null;
}

fn globMatch(pattern: []const u8, value: []const u8) bool {
    var p: usize = 0;
    var v: usize = 0;
    var star: ?usize = null;
    var retry: usize = 0;
    while (v < value.len) {
        if (p < pattern.len and (pattern[p] == '?' or pattern[p] == value[v])) {
            p += 1;
            v += 1;
        } else if (p < pattern.len and pattern[p] == '*') {
            star = p;
            p += 1;
            retry = v;
        } else if (star) |index| {
            p = index + 1;
            retry += 1;
            v = retry;
        } else return false;
    }
    while (p < pattern.len and pattern[p] == '*') p += 1;
    return p == pattern.len;
}

fn transformToWl(transform: OutputConfig.Transform) wl.Output.Transform {
    return switch (transform) {
        .normal => .normal,
        .rotate_90 => .@"90",
        .rotate_180 => .@"180",
        .rotate_270 => .@"270",
        .flipped => .flipped,
        .flipped_90 => .flipped_90,
        .flipped_180 => .flipped_180,
        .flipped_270 => .flipped_270,
    };
}

pub fn transformName(transform: wl.Output.Transform) []const u8 {
    return switch (transform) {
        .normal => "normal",
        .@"90" => "90",
        .@"180" => "180",
        .@"270" => "270",
        .flipped => "flipped",
        .flipped_90 => "flipped-90",
        .flipped_180 => "flipped-180",
        .flipped_270 => "flipped-270",
        else => "normal",
    };
}

fn handleManagerTest(_: *wl.Listener(*wlr.OutputConfigurationV1), config: *wlr.OutputConfigurationV1) void {
    defer config.destroy();

    if (!validateConfigCoordinates(config)) {
        config.sendFailed();
        return;
    }

    const states = config.buildState() catch {
        log.err("out of memory", .{});
        config.sendFailed();
        return;
    };
    defer std.c.free(states.ptr);
    for (states) |*entry| {
        const output: *Output = @ptrCast(@alignCast(entry.output.data));
        var policy = output.scheduled;
        policy.state = if (entry.base.enabled) .enabled else .disabled_soft;
        policy.adaptive_sync = entry.base.adaptive_sync_enabled;
        entry.base.setAdaptiveSyncEnabled(output.adaptiveSyncTarget(policy));
    }

    var swapchain_manager: wlr.OutputSwapchainManager = undefined;
    swapchain_manager.init(server.backend);
    defer swapchain_manager.finish();

    if (swapchain_manager.prepare(states)) {
        config.sendSucceeded();
    } else {
        config.sendFailed();
    }
}

fn handleManagerApply(_: *wl.Listener(*wlr.OutputConfigurationV1), config: *wlr.OutputConfigurationV1) void {
    if (@import("DisplayPreview.zig").active()) {
        config.sendFailed();
        config.destroy();
        return;
    }
    server.om.display_revision += 1;
    log.info("applying output configuration", .{});

    if (!validateConfigCoordinates(config)) {
        config.sendFailed();
        return;
    }

    const repair_initial_overlap = shouldRepairInitialOverlap(&server.om, config);
    if (repair_initial_overlap) {
        log.warn("initial output-management transaction overlaps unconfigured outputs; retaining automatic positions", .{});
    }

    var it = config.heads.iterator(.forward);
    while (it.next()) |head| {
        const output: *Output = @ptrCast(@alignCast(head.state.output.data));
        if (head.state.enabled) {
            log.debug("head {s}: enabled scale={d} transform={d} adaptive_sync={}", .{
                head.state.output.name,
                head.state.scale,
                @intFromEnum(head.state.transform),
                head.state.adaptive_sync_enabled,
            });
            const previous = output.scheduled.state;
            var proposed: Output.State = .fromHeadState(&head.state);
            proposed.mirror_of = output.scheduled.mirror_of;
            proposed.fullscreen_only_adaptive_sync = output.scheduled.fullscreen_only_adaptive_sync;
            output.adaptive_sync_policy.reset();
            proposed.hdr_enabled = output.scheduled.hdr_enabled;
            proposed.hdr_level = output.scheduled.hdr_level;
            proposed.sdr_white_level = output.scheduled.sdr_white_level;
            proposed.auto_hdr = output.scheduled.auto_hdr;
            proposed.auto_hdr_boost = output.scheduled.auto_hdr_boost;
            if (repair_initial_overlap) proposed.position_source = .automatic;
            output.scheduled = proposed;
            // Maintain power management state set with wlr-output-power-management-v1
            if (previous == .disabled_soft) {
                output.scheduled.state = .disabled_soft;
            } else {
                assert(output.scheduled.state == .enabled);
            }
        } else {
            // Avoid overwriting and losing all other output state on disable.
            output.scheduled.state = .disabled_hard;
        }
    }

    if (server.wm.scheduled.output_config) |old| {
        old.sendFailed();
        old.destroy();
    }
    server.wm.scheduled.output_config = config;

    server.wm.dirtyWindowing();
}

/// Repair the uninitialized transaction emitted by output-management clients
/// which advertise every new head at (0, 0). Once any enabled output has an
/// explicitly owned position, overlap is treated as an intentional layout.
fn shouldRepairInitialOverlap(om: *OutputManager, config: *wlr.OutputConfigurationV1) bool {
    var outputs = om.outputs.iterator(.forward);
    while (outputs.next()) |output| {
        if (output.scheduled.state == .enabled and output.scheduled.position_source != .automatic) return false;
    }

    var boxes: [OutputConfig.max_outputs]autolayout.Rect = undefined;
    var count: usize = 0;
    var heads = config.heads.iterator(.forward);
    while (heads.next()) |head| {
        if (!head.state.enabled) continue;
        if (count == boxes.len) return false;
        const proposed: Output.State = .fromHeadState(&head.state);
        const width, const height = proposed.dimensions();
        boxes[count] = .{
            .x = proposed.x,
            .y = proposed.y,
            .width = @intCast(width),
            .height = @intCast(height),
        };
        count += 1;
    }
    return autolayout.hasOverlap(boxes[0..count]);
}

fn validateConfigCoordinates(config: *wlr.OutputConfigurationV1) bool {
    var mirror_heads = config.heads.iterator(.forward);
    while (mirror_heads.next()) |head| {
        const output: *Output = @ptrCast(@alignCast(head.state.output.data));
        var is_source = false;
        var destinations = server.om.outputs.iterator(.forward);
        while (destinations.next()) |dest| {
            if (!dest.scheduled.mirror_of.empty() and std.mem.eql(u8, dest.scheduled.mirror_of.slice(), output.policyName())) is_source = true;
        }
        if ((!output.scheduled.mirror_of.empty() or is_source) and head.state.enabled and
            (head.state.transform != .normal or (!output.scheduled.mirror_of.empty() and head.state.adaptive_sync_enabled))) return false;
    }
    var pending: [OutputConfig.max_outputs]Pending = undefined;
    var count: usize = 0;
    var it = config.heads.iterator(.forward);
    while (it.next()) |head| {
        if (count == pending.len) return false;
        const output: *Output = @ptrCast(@alignCast(head.state.output.data));
        // Disabled heads do not carry valid mode/scale fields. Preserve their
        // last state just as handleManagerApply does, while excluding them
        // from the proposed visible layout.
        var proposed: Output.State = if (head.state.enabled) .fromHeadState(&head.state) else output.scheduled;
        if (!head.state.enabled) proposed.state = .disabled_hard;
        proposed.mirror_of = output.scheduled.mirror_of;
        pending[count] = .{ .output = output, .state = proposed };
        count += 1;
    }
    if (server.om.coordinatesValid(pending[0..count])) return true;
    log.err("output layout exceeds scene or translated Xwayland coordinate limits", .{});
    return false;
}

fn handlePowerManagerSetMode(
    _: *wl.Listener(*wlr.OutputPowerManagerV1.event.SetMode),
    event: *wlr.OutputPowerManagerV1.event.SetMode,
) void {
    @import("DisplayPreview.zig").competingChange();
    // The output may have been destroyed, in which case there is nothing to do
    const output = @as(?*Output, @ptrCast(@alignCast(event.output.data))) orelse return;

    log.debug("client requested dpms {s} for output {s}", .{
        @tagName(event.mode),
        event.output.name,
    });

    switch (output.scheduled.state) {
        .enabled => {
            if (event.mode == .off) output.scheduled.state = .disabled_soft else return;
        },
        .disabled_soft => {
            if (event.mode == .on) output.scheduled.state = .enabled else return;
        },
        .disabled_hard, .destroying => unreachable,
    }

    server.wm.dirtyWindowing();
}

pub fn layoutPlan(pending: []Pending) void {
    var rightmost_edge: i32 = 0;
    var row_y: i32 = 0;
    for (pending) |entry| {
        const state = entry.state;
        if (!state.mirror_of.empty() or state.state != .enabled or state.position_source == .automatic) continue;
        const x = state.x + state.dimensions()[0];
        if (x > rightmost_edge) {
            rightmost_edge = x;
            row_y = state.y;
        }
    }
    for (pending) |*entry| {
        if (!entry.state.mirror_of.empty() or entry.state.state != .enabled or entry.state.position_source != .automatic) continue;
        entry.state.x = rightmost_edge;
        entry.state.y = row_y;
        rightmost_edge += entry.state.dimensions()[0];
    }
}
pub fn autoLayout(om: *OutputManager) void {
    var entries: std.ArrayList(Pending) = .empty;
    defer entries.deinit(util.gpa);
    var it = om.outputs.iterator(.forward);
    while (it.next()) |o| entries.append(util.gpa, .{ .output = o, .state = o.scheduled }) catch return;
    layoutPlan(entries.items);
    for (entries.items) |entry| entry.output.scheduled = entry.state;
}

/// Group commits do not identify which output failed. Retain already copied
/// outputs, and try the remaining enabled members once before rejecting the GPU.
fn retryPresentation(states: []wlr.Backend.OutputState) bool {
    const presentation = @import("render/Presentation.zig");
    var changed = false;
    for (states) |*state| {
        if (!state.base.enabled) continue;
        const output: *Output = @ptrCast(@alignCast(state.output.data));
        const selected = presentation.tryCopy(state.output);
        if (!presentation.usesCopy(state.output)) continue;
        const format = if (state.base.committed.render_format) state.base.render_format else state.output.render_format;
        const description = if (state.base.committed.image_description) state.base.image_description else state.output.image_description;
        const hdr_pending = format != Output.hdr.sdr_render_format or description != null;
        if (!selected and !hdr_pending) continue;
        if (!Output.hdr.apply(state.output, false, .l1000, Output.hdr.default_sdr_white_level, &state.base)) return false;
        output.discardOverlayCandidate();
        output.scene_output.?.damage_ring.addWhole();
        changed = true;
    }
    return changed;
}

pub fn commitOutputState(om: *OutputManager) void {
    // A suspended startup session cannot prove scanout. Keep the candidate and
    // let the session-active listener schedule this transaction on resume.
    if (server.selection_pending) {
        if (server.session) |session| if (!session.active) return;
    }
    // Revoke before constructing any conflicting modeset/preview/mirror state.
    var warming_outputs = om.outputs.iterator(.forward);
    while (warming_outputs.next()) |output| {
        if (output.wlr_output) |w| {
            var mirror_source = output.mirror_source_locked;
            var destinations = om.outputs.iterator(.forward);
            while (destinations.next()) |destination| {
                if (destination.sent.state == .enabled and !destination.sent.mirror_of.empty() and
                    std.mem.eql(u8, destination.sent.mirror_of.slice(), output.policyName())) mirror_source = true;
            }
            om.warming.path(w, !output.sent.mirror_of.empty() or mirror_source);
            if (!std.meta.eql(output.sent, output.current)) om.warming.invalidate(w);
        }
    }
    om.committing_outputs = true;
    defer om.committing_outputs = false;
    defer server.system_bell.validateTargets();
    const wm = &server.wm;
    {
        var it = wm.sent.outputs.iterator(.forward);
        while (it.next()) |output| output.prepareAdaptiveSync();
    }
    {
        var it = wm.sent.outputs.iterator(.forward);
        while (it.next()) |output| {
            assert(output.sent.state != .destroying);
            if (!std.meta.eql(output.sent, output.current)) {
                server.aqueous.forgetOutput(output.policyId());
            }
            output.rendering_current = output.rendering_requested;
            // This may be null even when the state is not .destroying if the
            // output is destroyed between manage start and render finish.
            const wlr_output = output.wlr_output orelse continue;
            if (!output.selectScene(!output.sent.mirror_of.empty())) {
                om.modesetFailed();
                return;
            }
            switch (output.sent.state) {
                .enabled, .disabled_soft => {
                    if (!output.sent.mirror_of.empty()) {
                        om.output_layout.remove(wlr_output);
                        continue;
                    }
                    output.scene_output.?.setPosition(output.sent.x, output.sent.y);
                    _ = om.output_layout.add(wlr_output, output.sent.x, output.sent.y) catch {
                        log.err("out of memory", .{});
                        continue; // Try again next time
                    };
                    if (server.lock_manager.lockSurfaceFromOutput(output)) |lock_surface| {
                        lock_surface.tree.node.setPosition(output.sent.x, output.sent.y);
                    }
                },
                .disabled_hard => {
                    om.output_layout.remove(wlr_output);
                },
                .destroying => unreachable,
            }
        }
    }

    const need_modeset = blk: {
        var it = wm.sent.outputs.iterator(.forward);
        while (it.next()) |output| {
            const wlr_output = output.wlr_output orelse continue;
            if (!std.meta.eql(output.sent.mirror_of, output.current.mirror_of)) break :blk true;
            switch (output.sent.state) {
                .enabled => if (!wlr_output.enabled) break :blk true,
                .disabled_soft, .disabled_hard => if (wlr_output.enabled) break :blk true,
                .destroying => unreachable,
            }
            switch (output.sent.mode) {
                .standard => |mode| {
                    if (mode != wlr_output.current_mode) break :blk true;
                },
                .custom => |mode| {
                    if (mode.width != wlr_output.width) break :blk true;
                    if (mode.height != wlr_output.height) break :blk true;
                    if (mode.refresh != wlr_output.refresh) break :blk true;
                },
                // This branch is reachable if we fail to enable an output.
                .none => assert(output.sent.state == .disabled_hard),
            }
            // If an output newly exposed to river is already enabled, we
            // must modeset since the mode is otherwise undefined.
            if (output.current.mode == .none and output.sent.state == .enabled) {
                break :blk true;
            }
            if (output.sent.state == .enabled) {
                if (output.sent.scale != wlr_output.scale) break :blk true;
                if (output.sent.transform != wlr_output.transform) break :blk true;
                if (!Output.hdr.stateMatches(wlr_output, output.sent.hdr_enabled, output.sent.hdr_level, output.sent.sdr_white_level)) break :blk true;
            }
        }
        break :blk false;
    };

    @import("DisplayPreview.zig").submitting();
    if (need_modeset) {
        log.debug("committing output state requires modeset", .{});

        if (comptime build_options.vulkan_effects) {
            _ = server.vulkan_context.invalidateBlurRenderTargets() catch {
                om.modesetFailed();
                return;
            };
        }

        var states: std.ArrayList(wlr.Backend.OutputState) = .empty;
        defer states.deinit(util.gpa);
        defer for (states.items) |*s| s.base.finish();
        // Pending overlay buffers may own a hardware color recipe even when
        // another output fails before the group is committed.
        defer for (states.items) |*s| {
            const output: *Output = @ptrCast(@alignCast(s.output.data));
            output.discardOverlayCandidate();
        };

        {
            var it = wm.sent.outputs.iterator(.forward);
            while (it.next()) |output| {
                const wlr_output = output.wlr_output orelse continue;
                const state = states.addOne(util.gpa) catch {
                    log.err("out of memory", .{});
                    return;
                };

                state.output = wlr_output;
                state.base = wlr.Output.State.init();

                if (!output.sent.applyModeset(wlr_output, &state.base, if (build_options.output_retry_testing and output.adaptive_sync_test.enabled) false else output.adaptive_sync_commit_target)) {
                    log.err("failed to prepare HDR/color state for output {s}", .{wlr_output.name});
                    om.modesetFailed();
                    return;
                }
            }
        }

        var swapchain_manager: wlr.OutputSwapchainManager = undefined;
        swapchain_manager.init(server.backend);
        defer swapchain_manager.finish();

        // Each output can switch to copy once. Include real backend commits in
        // this loop: TEST_ONLY success alone does not prove presentation works.
        var attempts: usize = 0;
        build_group: while (true) : (attempts += 1) {
            for (states.items) |state| {
                const output: *Output = @ptrCast(@alignCast(state.output.data));
                output.discardOverlayCandidate();
            }
            if (!swapchain_manager.prepare(states.items) and
                !(retainAdaptiveSync(states.items) and swapchain_manager.prepare(states.items)))
            {
                if (attempts <= states.items.len and retryPresentation(states.items)) continue;
                log.err("failed to prepare new output configuration", .{});
                om.modesetFailed();
                return;
            }
            for (states.items) |*state| {
                const output: *Output = @ptrCast(@alignCast(state.output.data));
                if (!output.buildSceneState(&state.base, swapchain_manager.getSwapchain(state.output), false, false)) {
                    if (attempts <= states.items.len and retryPresentation(@as(*[1]wlr.Backend.OutputState, @ptrCast(state))))
                        continue :build_group;
                    log.err("failed to render scene for {s}", .{state.output.name});
                    om.modesetFailed();
                    return;
                }
            }

            const injected_failure = if (comptime build_options.output_retry_testing) blk: {
                const preview = @import("DisplayPreview.zig");
                var fail = preview.test_fail_commit and preview.active();
                if (preview.test_partial_commit and preview.active() and states.items.len > 1) {
                    // Exercise a backend which applied one member before failure.
                    _ = server.backend.commit(states.items[0..1]);
                    fail = true;
                }
                preview.test_partial_commit = false;
                preview.test_fail_commit = false;
                const selection = @import("render/RendererSelection.zig");
                fail = fail or (om.first_modeset and selection.testFails(server.selection_attempt, "commit"));
                // Reject direct only, proving copy is tried before another GPU.
                for (states.items) |state| {
                    if (om.first_modeset and !@import("render/Presentation.zig").usesCopy(state.output) and
                        selection.testFails(server.selection_attempt, "direct")) fail = true;
                }
                break :blk fail;
            } else false;
            if (injected_failure or (!server.backend.commit(states.items) and
                !(retainAdaptiveSync(states.items) and server.backend.commit(states.items))))
            {
                // Preview fault injection verifies transaction rollback, not
                // renderer selection, and must retain its existing semantics.
                if (!@import("DisplayPreview.zig").active() and attempts <= states.items.len and
                    retryPresentation(states.items)) continue;
                log.err("failed to commit new output configuration", .{});
                om.modesetFailed();
                return;
            }
            break;
        }
        for (states.items) |*state| {
            const output: *Output = @ptrCast(@alignCast(state.output.data));
            output.commitOverlayState(true);
        }
        om.first_modeset = false;

        swapchain_manager.apply();
    }

    {
        var it = wm.sent.outputs.iterator(.forward);
        while (it.next()) |output| {
            // This path also updates the virtual backend used by diagnostic tests.
            if (!output.commitAdaptiveSync() and @import("DisplayPreview.zig").active()) {
                om.modesetFailed();
                return;
            }
        }
    }

    if (wm.sent.output_config) |config| {
        config.sendSucceeded();
        config.destroy();
        wm.sent.output_config = null;
    }

    {
        var it = wm.sent.outputs.safeIterator(.forward);
        while (it.next()) |output| {
            const wlr_output = output.wlr_output orelse continue;

            // The wl_output global is created by wlroots when the output is
            // added to the wlr_output_layout and a mode is committed.
            // Wlroots does not directly notify us when the wl_output global is created.
            // However, we want send the aqueous_output_v1.wl_output event as soon as
            // possible and therefore need to check after committing a mode.
            // This is idempotent and retried until it succeeds (also from
            // Output.handleBind and Output.manageStart) so the DRM backend's
            // lazily-created global is eventually announced to the wm client.
            output.trySendWlOutput();
            // Auto HDR changes alter pixel processing without changing any
            // output color state, so they need full damage rather than a
            // modeset to become visible.
            if (output.current.auto_hdr != output.sent.auto_hdr or
                output.current.auto_hdr_boost != output.sent.auto_hdr_boost)
            {
                if (output.scene_output) |scene_output| scene_output.damage_ring.addWhole();
            }
            if (!std.meta.eql(output.current, output.sent)) om.display_revision += 1;
            output.current = output.sent;
            // A successful modeset supersedes the old buffer-retry episode.
            // Ordinary window-management cycles must not reset its backoff.
            if (need_modeset) output.cancelRetry();
            output.syncBlur(false);
            switch (output.sent.state) {
                .enabled => {
                    assert(wlr_output.enabled);
                    wlr_output.scheduleFrame();
                },
                .disabled_soft, .disabled_hard => {
                    assert(!wlr_output.enabled);
                    output.lock_render_state = .blanked;
                    if (output.sent.state == .disabled_hard) {
                        output.link_sent.remove();
                        output.link_sent.init();
                    }
                },
                .destroying => unreachable,
            }
        }
    }

    if (build_options.xwayland and server.xwayland != null) {
        // Refresh after current state is committed: another head may change the
        // shared X11 origin. wlroots compares each projected resource's last
        // advertised geometry and leaves ordinary Wayland clients untouched.
        wlr_xdg_output_manager_v1_update(om.xdg_output_manager);
        // Window.renderFinish ran before current output state was committed.
        // Reconfigure against the new desktop origin even when window size and
        // logical position did not change (another head may have moved).
        var windows = wm.windows.iterator();
        while (windows.next()) |window| {
            if (window.impl == .xwayland and window.impl.xwayland.surface_tree != null) {
                _ = window.impl.xwayland.configure();
            }
        }
        var popups = server.scene.layers.override_redirect.children.iterator(.forward);
        while (popups.next()) |node| {
            const data = SceneNodeData.fromNode(node) orelse continue;
            if (data.data == .override_redirect) data.data.override_redirect.applyProjection();
        }
    }

    @import("OutputMirror.zig").reconcile();
    @import("TabletMapping.zig").refresh();
    om.sendConfig() catch {
        log.err("out of memory", .{});
    };
    @import("DisplayPreview.zig").applied();
    server.xwayland_dpi.refresh();
    server.aqueous.output_service.outputsChanged(false);
}

extern fn wlr_xdg_output_manager_v1_update(manager: *wlr.XdgOutputManagerV1) void;

const ProjectionSet = struct {
    specs: [OutputConfig.max_outputs]xwayland_projection.Output = undefined,
    outputs: [OutputConfig.max_outputs]*Output = undefined,
    len: usize = 0,

    fn projection(set: *const ProjectionSet, index: usize) xwayland_projection.Projection {
        return xwayland_projection.project(set.specs[0..set.len], index, server.xwayland_scaling);
    }
};

fn projectionSpec(state: *const Output.State) xwayland_projection.Output {
    const logical = state.box();
    const physical_width, const physical_height = state.physicalDimensions();
    return .{
        .logical = .{ .x = logical.x, .y = logical.y, .width = logical.width, .height = logical.height },
        .physical_width = physical_width,
        .physical_height = physical_height,
        .scale = state.scale,
    };
}

fn xwaylandProjectionSet(om: *OutputManager) ProjectionSet {
    var set: ProjectionSet = .{};
    var it = om.outputs.iterator(.forward);
    while (it.next()) |output| {
        if (set.len == set.specs.len) break;
        if (output.wlr_output == null or !output.current.mirror_of.empty()) continue;
        switch (output.current.state) {
            .enabled, .disabled_soft => {},
            .disabled_hard, .destroying => continue,
        }
        const logical = output.current.box();
        if (logical.empty()) continue;
        const physical_width, const physical_height = output.current.physicalDimensions();
        if (physical_width <= 0 or physical_height <= 0) continue;
        set.specs[set.len] = projectionSpec(&output.current);
        set.outputs[set.len] = output;
        set.len += 1;
    }
    return set;
}

pub fn xwaylandProjectionForOutput(
    om: *OutputManager,
    wlr_output: *wlr.Output,
) ?xwayland_projection.Projection {
    const set = om.xwaylandProjectionSet();
    for (set.outputs[0..set.len], 0..) |output, index| {
        if (output.wlr_output == wlr_output) return set.projection(index);
    }
    return null;
}

pub fn xwaylandProjectionForLogicalBox(
    om: *OutputManager,
    box: wlr.Box,
) ?xwayland_projection.Projection {
    const set = om.xwaylandProjectionSet();
    var best_index: ?usize = null;
    var best_area: i64 = -1;
    for (set.specs[0..set.len], 0..) |spec, index| {
        const left = @max(box.x, spec.logical.x);
        const top = @max(box.y, spec.logical.y);
        const right = @min(box.x + box.width, spec.logical.x + spec.logical.width);
        const bottom = @min(box.y + box.height, spec.logical.y + spec.logical.height);
        const area: i64 = @as(i64, @max(0, right - left)) * @as(i64, @max(0, bottom - top));
        if (area > best_area) {
            best_area = area;
            best_index = index;
        }
    }
    return if (best_index) |index| set.projection(index) else null;
}

pub fn xwaylandProjectionForX11Point(
    om: *OutputManager,
    x: f64,
    y: f64,
) ?xwayland_projection.Projection {
    const set = om.xwaylandProjectionSet();
    for (set.specs[0..set.len], 0..) |_, index| {
        const projection = set.projection(index);
        if (projection.x11.contains(x, y)) return projection;
    }
    return if (set.len > 0) set.projection(0) else null;
}

/// A mode/HDR transaction may also include a conditional VRR transition. Retry
/// once with the previous VRR state, without discarding the configured policy.
fn retainAdaptiveSync(states: []wlr.Backend.OutputState) bool {
    if (@import("DisplayPreview.zig").active()) return false;
    var changed = false;
    for (states) |*state| {
        if (!state.base.committed.adaptive_sync_enabled) continue;
        const output: *Output = @ptrCast(@alignCast(state.output.data));
        if (state.base.adaptive_sync_enabled == output.adaptive_sync_before) continue;
        output.adaptive_sync_policy.failure = .commit_failed;
        output.adaptive_sync_commit_target = output.adaptive_sync_before;
        state.base.setAdaptiveSyncEnabled(output.adaptive_sync_before);
        changed = true;
    }
    return changed;
}

fn modesetFailed(om: *OutputManager) void {
    const wm = &server.wm;

    // Initial failure rejects this startup candidate. main tears it down before
    // trying the next GPU; no clients have been started yet.
    if (om.first_modeset) {
        log.err("no usable presentation path: initial output commit failed", .{});
        server.fatal_error = error.PresentationUnavailable;
        server.wl_server.terminate();
        return;
    }

    if (wm.sent.output_config) |config| {
        config.sendFailed();
        config.destroy();
        wm.sent.output_config = null;
    }

    {
        // Revert to last working state on failure
        var it = wm.sent.outputs.iterator(.forward);
        while (it.next()) |output| {
            output.mirror.reset();
            output.scheduled = output.current;
            output.sent = output.current;
        }
        wm.dirtyWindowing();
    }
    // Ordinary cleanup must finish before the lease schedules restoration.
    @import("DisplayPreview.zig").failed();
}

/// Send the current output state to all wlr-output-manager clients.
fn sendConfig(om: *OutputManager) !void {
    const config = try wlr.OutputConfigurationV1.create();
    // this destroys all associated config heads as well
    errdefer config.destroy();

    var it = om.outputs.iterator(.forward);
    while (it.next()) |output| {
        const wlr_output = output.wlr_output orelse continue;
        const head = try wlr.OutputConfigurationV1.Head.create(config, wlr_output);

        // It's only necessary to overwrite the state that does not require a modeset.
        // All state that requires a modeset will have already been committed to the wlr_output.
        head.state.enabled = switch (output.current.state) {
            .enabled, .disabled_soft => true,
            .disabled_hard => false,
            .destroying => unreachable,
        };
        head.state.scale = output.current.scale;
        head.state.transform = output.current.transform;
        head.state.x = output.current.x;
        head.state.y = output.current.y;
    }

    // wlroots won't send events to clients unless something has changed
    // compared to the last config set.
    om.wlr_output_manager.setConfiguration(config);
}

// Returning a wlr.Output rather than Output is more convenient at the callsites.
pub fn maxOverlapOutput(om: *OutputManager, box: *const wlr.Box) ?*wlr.Output {
    var max_overlap_area: i32 = 0;
    var max_overlap_output: ?*wlr.Output = null;
    var it = om.outputs.iterator(.forward);
    while (it.next()) |output| {
        const wlr_output = output.wlr_output orelse continue;
        var overlap: wlr.Box = undefined;
        om.output_layout.getBox(wlr_output, &overlap);
        if (overlap.empty()) continue; // output not in layout
        _ = overlap.intersection(&overlap, box);
        const overlap_area = overlap.width * overlap.height;
        if (overlap_area > max_overlap_area) {
            max_overlap_area = overlap_area;
            max_overlap_output = wlr_output;
        }
    }
    return max_overlap_output;
}

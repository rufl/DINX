// SPDX-FileCopyrightText: © 2026 Seafoam Labs
// SPDX-License-Identifier: GPL-3.0-only

const Overview = @This();

const std = @import("std");
const wlr = @import("wlroots");
const wl = @import("wayland").server.wl;

const server = &@import("main.zig").server;
const util = @import("util.zig");
const fx = @import("fx.zig");
const LayerSurface = @import("LayerSurface.zig");
const Window = @import("Window.zig");
const Output = @import("Output.zig");
const model = @import("wm/overview/model.zig");
const layout = @import("wm/layout/types.zig");

const log = std.log.scoped(.overview);

pub const backdrop_opacity: f32 = 0.68;
pub const selection_border_width: i32 = 5;
pub const selection_color: [4]f32 = .{ 0.24, 0.72, 1.0, 1.0 };
pub const animation_rate: f64 = 11.0;

tree: *wlr.SceneTree,
output_id: ?u64 = null,
backdrop: ?*wlr.SceneRect = null,
entries: std.ArrayListUnmanaged(Entry) = .empty,
progress: f64 = 1,
deck: bool = false,
deck_workspace: ?u32 = null,
reduced_motion: bool = false,
hidden_windows: std.ArrayListUnmanaged(HiddenWindow) = .empty,
hidden_layer_surfaces: std.ArrayListUnmanaged(HiddenLayerSurface) = .empty,

const HiddenWindow = struct {
    ref: Window.Ref,
    tree_enabled: bool,
    popup_enabled: bool,
    animation_enabled: bool,
    overview_hidden: bool,
};

const HiddenLayerSurface = struct {
    ref: LayerSurface.Ref,
    tree_enabled: bool,
    popup_enabled: bool,
};

const Borders = struct {
    left: *wlr.SceneRect,
    right: *wlr.SceneRect,
    top: *wlr.SceneRect,
    bottom: *wlr.SceneRect,

    fn create(tree: *wlr.SceneTree) !Borders {
        return .{
            .left = try tree.createSceneRect(0, 0, &selection_color),
            .right = try tree.createSceneRect(0, 0, &selection_color),
            .top = try tree.createSceneRect(0, 0, &selection_color),
            .bottom = try tree.createSceneRect(0, 0, &selection_color),
        };
    }

    fn raiseToTop(borders: Borders) void {
        inline for (.{ "left", "right", "top", "bottom" }) |name| {
            @field(borders, name).node.raiseToTop();
        }
    }

    fn update(borders: Borders, rect: layout.Rect, clip: layout.Rect, selected: bool) void {
        const width: i32 = selection_border_width;
        const horizontal_width = @max(1, rect.width + 2 * width);
        const vertical_height = @max(1, rect.height);
        updateBorderPart(borders.left, .{
            .x = rect.x - width,
            .y = rect.y,
            .width = width,
            .height = vertical_height,
        }, clip, selected);
        updateBorderPart(borders.right, .{
            .x = rect.right(),
            .y = rect.y,
            .width = width,
            .height = vertical_height,
        }, clip, selected);
        updateBorderPart(borders.top, .{
            .x = rect.x - width,
            .y = rect.y - width,
            .width = horizontal_width,
            .height = width,
        }, clip, selected);
        updateBorderPart(borders.bottom, .{
            .x = rect.x - width,
            .y = rect.bottom(),
            .width = horizontal_width,
            .height = width,
        }, clip, selected);
    }

    fn updateBorderPart(node: *wlr.SceneRect, rect: layout.Rect, clip: layout.Rect, selected: bool) void {
        node.node.setEnabled(false);
        if (!selected) return;
        const visible = intersection(rect, clip) orelse return;
        node.node.setPosition(visible.x, visible.y);
        node.setSize(visible.width, visible.height);
        node.node.setEnabled(true);
    }
};

const Entry = struct {
    handle: layout.Handle,
    tree: *wlr.SceneTree,
    buffers: std.ArrayListUnmanaged(Window.OverviewBuffer) = .empty,
    content: *wlr.SceneTree,
    source_rect: layout.Rect,
    borders: Borders,
    icon: ?*wlr.SceneBuffer = null,
    icon_placeholder: ?*wlr.SceneRect = null,
    icon_scale: f64 = 1,
    start_rect: layout.Rect,
    target_rect: layout.Rect,
    current_rect: layout.Rect,
    clip_rect: layout.Rect,
    selected: bool = false,

    fn deinit(entry: *Entry) void {
        entry.tree.node.destroy();
        entry.buffers.deinit(util.gpa);
        entry.* = undefined;
    }

    fn update(entry: *Entry, progress: f64) void {
        entry.current_rect = interpolateRect(entry.start_rect, entry.target_rect, progress);
        entry.updateBorders();
        entry.updateBuffers();
        entry.updateIconPosition();
    }

    fn refreshIcon(entry: *Entry, window: *Window) void {
        const source = if (window.impl == .toplevel) blk: {
            const icon = window.impl.toplevel.icon.current orelse break :blk null;
            break :blk @import("ToplevelIcon.zig").select(icon, 32, entry.icon_scale);
        } else null;
        if (entry.icon == null) entry.icon = entry.tree.createSceneBuffer(null) catch return;
        entry.icon.?.setBuffer(source);
        if (entry.icon_placeholder == null) {
            entry.icon_placeholder = entry.tree.createSceneRect(32, 32, &.{ 0.24, 0.28, 0.34, 1 }) catch return;
        }
        entry.icon.?.node.raiseToTop();
        entry.updateIconPosition();
    }

    fn updateIconPosition(entry: *Entry) void {
        const icon = entry.icon orelse return;
        const rect = entry.current_rect;
        const size = @min(32, @min(rect.width, rect.height));
        const target: layout.Rect = .{ .x = rect.x, .y = rect.y, .width = size, .height = size };
        icon.node.setEnabled(false);
        if (entry.icon_placeholder) |placeholder| placeholder.node.setEnabled(false);
        const visible = intersection(target, entry.clip_rect) orelse return;
        if (icon.buffer) |buffer| {
            icon.node.setPosition(visible.x, visible.y);
            icon.setDestSize(visible.width, visible.height);
            const ratio = @as(f64, @floatFromInt(buffer.width)) / @as(f64, @floatFromInt(size));
            icon.setSourceBox(&.{
                .x = @as(f64, @floatFromInt(visible.x - target.x)) * ratio,
                .y = @as(f64, @floatFromInt(visible.y - target.y)) * ratio,
                .width = @as(f64, @floatFromInt(visible.width)) * ratio,
                .height = @as(f64, @floatFromInt(visible.height)) * ratio,
            });
            icon.node.setEnabled(true);
        } else if (entry.icon_placeholder) |placeholder| {
            placeholder.node.setPosition(visible.x, visible.y);
            placeholder.setSize(visible.width, visible.height);
            placeholder.node.setEnabled(true);
        }
    }

    fn updateBorders(entry: *Entry) void {
        entry.borders.update(entry.current_rect, entry.clip_rect, entry.selected);
    }

    fn updateBuffers(entry: *Entry) void {
        const source = entry.source_rect;
        const current = entry.current_rect;
        if (source.width <= 0 or source.height <= 0 or current.width <= 0 or current.height <= 0) {
            for (entry.buffers.items) |record| record.buffer.node.setEnabled(false);
            return;
        }
        const card_clip = intersection(current, entry.clip_rect) orelse {
            for (entry.buffers.items) |record| record.buffer.node.setEnabled(false);
            return;
        };

        const scale_x = @as(f64, @floatFromInt(current.width)) / @as(f64, @floatFromInt(source.width));
        const scale_y = @as(f64, @floatFromInt(current.height)) / @as(f64, @floatFromInt(source.height));
        for (entry.buffers.items) |record| {
            const destination: layout.Rect = .{
                .x = current.x + @as(i32, @intFromFloat(@round(@as(f64, @floatFromInt(record.x)) * scale_x))),
                .y = current.y + @as(i32, @intFromFloat(@round(@as(f64, @floatFromInt(record.y)) * scale_y))),
                .width = @max(1, @as(i32, @intFromFloat(@round(@as(f64, @floatFromInt(record.dest_width)) * scale_x)))),
                .height = @max(1, @as(i32, @intFromFloat(@round(@as(f64, @floatFromInt(record.dest_height)) * scale_y)))),
            };
            const clipped = intersection(destination, card_clip) orelse {
                record.buffer.node.setEnabled(false);
                continue;
            };
            record.buffer.node.setEnabled(true);
            record.buffer.node.setPosition(clipped.x, clipped.y);
            record.buffer.setDestSize(clipped.width, clipped.height);

            const crop_x = clipped.x - destination.x;
            const crop_y = clipped.y - destination.y;
            // Scale the shared window coordinates before rounding each buffer's
            // destination. Otherwise differently sized subsurfaces can acquire
            // masks a pixel apart at fractional thumbnail scales.
            fx.setBufferClip(record.buffer, if (record.clip) |mask|
                mask.translated(@floatFromInt(record.x), @floatFromInt(record.y))
                    .scaled(scale_x, scale_y)
                    .translated(@floatFromInt(current.x - clipped.x), @floatFromInt(current.y - clipped.y))
            else
                null);
            const transformed_width = if (transformSwapsAxes(record.transform)) record.source.height else record.source.width;
            const transformed_height = if (transformSwapsAxes(record.transform)) record.source.width else record.source.height;
            const transformed_crop: wlr.FBox = .{
                .x = @as(f64, @floatFromInt(crop_x)) * transformed_width / @as(f64, @floatFromInt(destination.width)),
                .y = @as(f64, @floatFromInt(crop_y)) * transformed_height / @as(f64, @floatFromInt(destination.height)),
                .width = @as(f64, @floatFromInt(clipped.width)) * transformed_width / @as(f64, @floatFromInt(destination.width)),
                .height = @as(f64, @floatFromInt(clipped.height)) * transformed_height / @as(f64, @floatFromInt(destination.height)),
            };
            var source_crop: wlr.FBox = undefined;
            source_crop.transform(
                &transformed_crop,
                inverseTransform(record.transform),
                transformed_width,
                transformed_height,
            );
            source_crop.x += record.source.x;
            source_crop.y += record.source.y;
            record.buffer.setSourceBox(&source_crop);
        }
    }
};

pub fn init(overview: *Overview) !void {
    const tree = try server.scene.normal_tree.createSceneTree();
    tree.node.setEnabled(false);
    overview.* = .{ .tree = tree };
}

pub fn deinit(overview: *Overview) void {
    overview.hide();
    overview.tree.node.destroy();
    overview.entries.deinit(util.gpa);
    overview.hidden_windows.deinit(util.gpa);
    overview.hidden_layer_surfaces.deinit(util.gpa);
    overview.* = undefined;
}

/// Build a frozen overview transactionally. Successfully cloned cards are
/// compacted to the front of `cards`; `selected` is repaired if its card was
/// skipped. The returned length is the visual/logical membership to retain.
pub fn show(
    overview: *Overview,
    output: *Output,
    output_box: wlr.Box,
    cards: []model.Card,
    selected: *layout.Handle,
    deck: bool,
) !usize {
    overview.hide();
    overview.deck = deck;
    errdefer overview.hide();
    try overview.entries.ensureTotalCapacity(util.gpa, cards.len);

    const backdrop_color: [4]f32 = .{ 0, 0, 0, if (fx.anim_enabled) 0 else backdrop_opacity };
    const backdrop = try overview.tree.createSceneRect(
        output_box.width,
        output_box.height,
        &backdrop_color,
    );
    backdrop.node.setPosition(output_box.x, output_box.y);
    overview.backdrop = backdrop;
    const output_rect: layout.Rect = .{
        .x = output_box.x,
        .y = output_box.y,
        .width = output_box.width,
        .height = output_box.height,
    };

    var accepted: usize = 0;
    for (cards, 0..) |card, index| {
        if (card.source.width <= 0 or card.source.height <= 0 or
            card.target.width <= 0 or card.target.height <= 0)
        {
            continue;
        }
        const ref: Window.Ref = @bitCast(card.handle);
        const window = ref.get() orelse continue;
        const entry_tree = overview.tree.createSceneTree() catch return error.OutOfMemory;
        const content = entry_tree.createSceneTree() catch {
            entry_tree.node.destroy();
            return error.OutOfMemory;
        };
        var entry: Entry = .{
            .handle = card.handle,
            .tree = entry_tree,
            .borders = Borders.create(entry_tree) catch {
                entry_tree.node.destroy();
                return error.OutOfMemory;
            },
            .content = content,
            .source_rect = card.source,
            .start_rect = card.source,
            .target_rect = card.target,
            .current_rect = if (fx.anim_enabled) card.source else card.target,
            .clip_rect = output_rect,
            .icon_scale = output.current.scale,
        };
        window.cloneOverviewInto(util.gpa, entry.content, &entry.buffers) catch |err| {
            log.warn("skipping overview window {}: {}", .{ card.handle, err });
            if (!deck) {
                entry.deinit();
                continue;
            }
            // A missing texture must not remove a global cycling stop. The
            // card outline and application icon remain a usable placeholder.
        };
        entry.refreshIcon(window);
        entry.borders.raiseToTop();
        entry.update(if (fx.anim_enabled) 0 else 1);
        overview.entries.appendAssumeCapacity(entry);
        cards[accepted] = cards[index];
        accepted += 1;
    }
    if (accepted == 0) return error.NoUsableWindows;
    if (!containsEntry(overview.entries.items, selected.*)) selected.* = overview.entries.items[0].handle;

    overview.output_id = output.policyId();
    overview.progress = if (fx.anim_enabled) 0 else 1;
    overview.setSelected(selected.*);
    if (deck) overview.tree.node.placeBelow(&server.scene.layers.top.node) else overview.tree.node.raiseToTop();
    try overview.hideOutputScene(output);
    overview.tree.node.setEnabled(true);
    server.wm.dirtyWindowing();
    return accepted;
}

pub fn iconChanged(overview: *Overview, window: *Window) void {
    for (overview.entries.items) |*entry| {
        if (entry.handle == @as(layout.Handle, @bitCast(window.ref))) entry.refreshIcon(window);
    }
}

pub fn setSelected(overview: *Overview, handle: layout.Handle) void {
    for (overview.entries.items) |*entry| {
        entry.selected = entry.handle == handle;
        entry.updateBorders();
    }
}

pub fn remove(overview: *Overview, handle: layout.Handle) void {
    for (overview.entries.items, 0..) |entry, index| {
        if (entry.handle != handle) continue;
        var removed = overview.entries.orderedRemove(index);
        removed.deinit();
        if (overview.entries.items.len == 0) overview.hide();
        return;
    }
}

pub fn hide(overview: *Overview) void {
    overview.tree.node.setEnabled(false);
    overview.restoreOutputScene();
    for (overview.entries.items) |*entry| entry.deinit();
    overview.entries.clearRetainingCapacity();
    if (overview.backdrop) |backdrop| backdrop.node.destroy();
    overview.backdrop = null;
    overview.output_id = null;
    overview.progress = 1;
    overview.deck = false;
    overview.deck_workspace = null;
    overview.reduced_motion = false;
    server.wm.dirtyWindowing();
}

/// Hide only content owned by the overview output. Scene layer roots span all
/// outputs, so disabling those roots would incorrectly blank a second monitor.
/// Background layer surfaces remain visible; their popups do not.
fn hideOutputScene(overview: *Overview, output: *Output) !void {
    std.debug.assert(overview.hidden_windows.items.len == 0);
    std.debug.assert(overview.hidden_layer_surfaces.items.len == 0);

    if (output.active_workspace) |active_workspace| {
        var windows = active_workspace.windows.iterator(.forward);
        while (windows.next()) |window| {
            try overview.hidden_windows.append(util.gpa, .{
                .ref = window.ref,
                .tree_enabled = window.tree.node.enabled,
                .popup_enabled = window.popup_tree.node.enabled,
                .animation_enabled = window.anim_tree.node.enabled,
                .overview_hidden = window.overview_hidden,
            });
            window.overview_hidden = true;
            window.tree.node.setEnabled(false);
            window.popup_tree.node.setEnabled(false);
            window.anim_tree.node.setEnabled(false);
        }
    }

    if (overview.deck) {
        overview.deck_workspace = if (output.active_workspace) |ws| ws.id else null;
        return; // Keep bar and non-keyboard HUD usable.
    }
    const wlr_output = output.wlr_output orelse return error.OutputUnavailable;
    var layer_surfaces = server.layer_shell.surfaces.iterator();
    while (layer_surfaces.next()) |layer_surface| {
        if (layer_surface.wlr_layer_surface.output != wlr_output) continue;
        try overview.hidden_layer_surfaces.append(util.gpa, .{
            .ref = layer_surface.ref,
            .tree_enabled = layer_surface.scene_layer_surface.tree.node.enabled,
            .popup_enabled = layer_surface.popup_tree.node.enabled,
        });
        if (layer_surface.wlr_layer_surface.current.layer != .background) {
            layer_surface.scene_layer_surface.tree.node.setEnabled(false);
        }
        layer_surface.popup_tree.node.setEnabled(false);
    }
}

fn restoreOutputScene(overview: *Overview) void {
    for (overview.hidden_windows.items) |hidden| {
        const window = hidden.ref.get() orelse continue;
        window.overview_hidden = hidden.overview_hidden;
        const workspace_active = if (window.workspace) |ws| ws.isActive() else false;
        window.tree.node.setEnabled(hidden.tree_enabled and workspace_active);
        window.popup_tree.node.setEnabled(hidden.popup_enabled and workspace_active);
        window.anim_tree.node.setEnabled(hidden.animation_enabled and workspace_active);
    }
    overview.hidden_windows.clearRetainingCapacity();

    for (overview.hidden_layer_surfaces.items) |hidden| {
        const layer_surface = hidden.ref.get() orelse continue;
        layer_surface.scene_layer_surface.tree.node.setEnabled(hidden.tree_enabled);
        layer_surface.popup_tree.node.setEnabled(hidden.popup_enabled);
    }
    overview.hidden_layer_surfaces.clearRetainingCapacity();
}

pub fn step(overview: *Overview, output: *Output, dt_s: f64) bool {
    if (comptime !fx.anim_enabled) return false;
    if (!overview.animatingOn(output.policyId()) or dt_s <= 0) return false;
    const t = 1.0 - @exp(-animation_rate * dt_s);
    if (overview.deck) overview.progress = @min(1, overview.progress + dt_s / 0.240) else overview.progress += (1.0 - overview.progress) * t;
    if (1.0 - overview.progress < 0.002) overview.progress = 1;

    for (overview.entries.items) |*entry| entry.update(if (overview.deck) 1 - std.math.pow(f64, 1 - overview.progress, 3) else overview.progress);
    if (overview.backdrop) |backdrop| {
        const color: [4]f32 = .{ 0, 0, 0, if (overview.deck) 0.42 else @floatCast(backdrop_opacity * @as(f32, @floatCast(overview.progress))) };
        backdrop.setColor(&color);
    }
    return true;
}

pub fn activeOn(overview: *const Overview, output_id: u64) bool {
    return overview.output_id == output_id and overview.entries.items.len > 0;
}

pub fn animatingOn(overview: *const Overview, output_id: u64) bool {
    if (comptime !fx.anim_enabled) return false;
    return overview.activeOn(output_id) and overview.progress < 1 and !overview.reduced_motion;
}

pub fn active(overview: *const Overview) bool {
    return overview.output_id != null and overview.entries.items.len > 0;
}

pub fn nodeLabel(
    overview: *const Overview,
    node: *wlr.SceneNode,
    buffer: *[512]u8,
) ?[:0]const u8 {
    if (node == &overview.tree.node) return "workspace overview";
    if (overview.backdrop) |backdrop| {
        if (node == &backdrop.node) return "overview backdrop";
    }
    for (overview.entries.items) |entry| {
        if (node == &entry.tree.node) {
            return std.fmt.bufPrintZ(buffer, "overview card: {}", .{entry.handle}) catch
                "overview card";
        }
        for (entry.buffers.items) |record| {
            if (node == &record.buffer.node) return "overview thumbnail buffer";
        }
        inline for (.{ "left", "right", "top", "bottom" }) |name| {
            if (node == &@field(entry.borders, name).node) {
                return "overview selection border: " ++ name;
            }
        }
    }
    return null;
}

fn containsEntry(entries: []const Entry, handle: layout.Handle) bool {
    for (entries) |entry| if (entry.handle == handle) return true;
    return false;
}

fn interpolateRect(start: layout.Rect, target: layout.Rect, progress: f64) layout.Rect {
    return .{
        .x = interpolate(start.x, target.x, progress),
        .y = interpolate(start.y, target.y, progress),
        .width = @max(1, interpolate(start.width, target.width, progress)),
        .height = @max(1, interpolate(start.height, target.height, progress)),
    };
}

fn interpolate(start: i32, target: i32, progress: f64) i32 {
    return @intFromFloat(@round(@as(f64, @floatFromInt(start)) +
        @as(f64, @floatFromInt(target - start)) * progress));
}

fn intersection(a: layout.Rect, b: layout.Rect) ?layout.Rect {
    const x = @max(a.x, b.x);
    const y = @max(a.y, b.y);
    const right = @min(a.right(), b.right());
    const bottom = @min(a.bottom(), b.bottom());
    if (right <= x or bottom <= y) return null;
    return .{ .x = x, .y = y, .width = right - x, .height = bottom - y };
}

fn transformSwapsAxes(transform: wl.Output.Transform) bool {
    return switch (transform) {
        .@"90", .@"270", .flipped_90, .flipped_270 => true,
        else => false,
    };
}

fn inverseTransform(transform: wl.Output.Transform) wl.Output.Transform {
    return switch (transform) {
        .@"90" => .@"270",
        .@"270" => .@"90",
        else => transform,
    };
}

/// Selection can activate another workspace underneath a stationary deck.
pub fn syncDeckScene(self: *Overview, output: *Output) !void {
    if (!self.deck) return;
    const workspace = if (output.active_workspace) |ws| ws.id else null;
    if (self.deck_workspace == workspace) return;
    output.prepareOverview();
    self.restoreOutputScene();
    try self.hideOutputScene(output);
}
/// Rebuild only three live texture cards, preserving interpolated positions.
pub fn showDeck(self: *Overview, output: *Output, cards: []model.Card, selected: layout.Handle, reduced: bool, reverse: bool) !void {
    var old: [3]struct { handle: u64, rect: layout.Rect } = undefined;
    var count: usize = 0;
    if (self.deck and self.output_id == output.policyId()) for (self.entries.items) |entry| {
        if (count == old.len) break;
        old[count] = .{ .handle = entry.handle, .rect = entry.current_rect };
        count += 1;
    };
    output.prepareOverview();
    var chosen = selected;
    const accepted = try self.show(output, output.policyFullBox(), cards, &chosen, true);
    if (accepted == 0 or chosen != selected) {
        self.hide();
        return error.Unavailable;
    }
    self.reduced_motion = reduced or !fx.anim_enabled;
    self.progress = if (self.reduced_motion) 1 else 0;
    for (self.entries.items) |*entry| {
        entry.start_rect = entry.target_rect;
        // New front enters from the next slot on initial presentation.
        if (entry.handle == selected) entry.start_rect.x += @divTrunc(output.policyFullBox().width, 6) * (if (reverse) @as(i32, -1) else 1);
        for (old[0..count]) |prior| if (prior.handle == entry.handle) {
            entry.start_rect = prior.rect;
            break;
        };
        entry.update(self.progress);
    }
    // Back-to-front tree order; card zero is selected.
    var i = self.entries.items.len;
    while (i > 0) {
        i -= 1;
        self.entries.items[i].tree.node.raiseToTop();
    }
    for (self.entries.items) |entry| {
        inline for (.{ "left", "right", "top", "bottom" }) |name| @field(entry.borders, name).setColor(&.{ 0.82, 0.74, 1, 1 });
    }
    if (self.backdrop) |backdrop| backdrop.setColor(&.{ 0, 0, 0, 0.42 });
    if (output.wlr_output) |wlr_output| wlr_output.scheduleFrame();
}
pub fn refreshDeck(self: *Overview, window: *Window) void {
    if (!self.deck) return;
    for (self.entries.items) |*entry| {
        if (entry.handle != @as(u64, @bitCast(window.ref))) continue;
        const content = entry.tree.createSceneTree() catch return;
        var records: std.ArrayListUnmanaged(Window.OverviewBuffer) = .empty;
        window.cloneOverviewInto(util.gpa, content, &records) catch {
            content.node.destroy();
            records.deinit(util.gpa);
            return;
        };
        entry.content.node.destroy();
        entry.buffers.deinit(util.gpa);
        entry.content = content;
        entry.buffers = records;
        entry.source_rect = server.aqueous.api.windowGeometry(entry.handle) orelse entry.source_rect;
        entry.updateBuffers();
        entry.borders.raiseToTop();
        if (entry.icon) |icon| icon.node.raiseToTop();
    }
}

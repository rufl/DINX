// SPDX-FileCopyrightText: © 2026 Seafoam Labs
// SPDX-License-Identifier: GPL-3.0-only

const EffectMetadata = @This();

const std = @import("std");
const Allocator = std.mem.Allocator;
const AutoHashMapUnmanaged = std.AutoHashMapUnmanaged;
const SlotMap = @import("slotmap").SlotMap;
const wl = @import("wayland").server.wl;
const wlr = @import("wlroots");

pub const CornerRadii = struct {
    top_left: u31 = 0,
    top_right: u31 = 0,
    bottom_right: u31 = 0,
    bottom_left: u31 = 0,

    pub fn uniform(radius: u31) CornerRadii {
        return .{
            .top_left = radius,
            .top_right = radius,
            .bottom_right = radius,
            .bottom_left = radius,
        };
    }
};

pub fn clampedPhysicalRadii(
    radii: CornerRadii,
    width: i32,
    height: i32,
    scale: f32,
) [4]f32 {
    if (width <= 0 or height <= 0 or !(scale > 0)) {
        return .{ 0, 0, 0, 0 };
    }
    const maximum =
        @as(f32, @floatFromInt(@min(width, height))) * 0.5;
    return .{
        @min(@as(f32, @floatFromInt(radii.top_left)) * scale, maximum),
        @min(@as(f32, @floatFromInt(radii.top_right)) * scale, maximum),
        @min(@as(f32, @floatFromInt(radii.bottom_right)) * scale, maximum),
        @min(@as(f32, @floatFromInt(radii.bottom_left)) * scale, maximum),
    };
}

pub const RoundedClip = struct {
    area: wlr.Box,
    radii: CornerRadii,
};

pub const BufferData = struct {
    clip: ?BufferClip = null,
    /// Frozen render policy for input-inert snapshots; contains no live owners.
    snapshot_hdr: ?SnapshotHdrPolicy = null,
    generation: u64 = 1,
};

pub const BufferClip = @import("WindowClip.zig").RoundedClip;

pub const SnapshotHdrPolicy = struct {
    eligible: bool = false,
    native_windows_hdr: bool = false,
};

pub const RectData = struct {
    radii: CornerRadii = .{},
    clipped_region: ?RoundedClip = null,
    generation: u64 = 1,
};

pub const RectRenderData = struct {
    outer_radii: [4]f32,
    inner_rect: [4]f32 = .{ 0, 0, 0, 0 },
    inner_radii: [4]f32 = .{ 0, 0, 0, 0 },
    has_inner: bool = false,
};

pub const BlurConfig = struct {
    radius: c_int = 0,
    passes: c_int = 0,
    appearance: BlurAppearance = .{},
    generation: u64 = 1,
};

pub const BlurAppearance = struct {
    noise: f32 = 0,
    contrast: f32 = 1,
    brightness: f32 = 1,
    vibrancy: f32 = 0,
    vibrancy_darkness: f32 = 0,
};

pub const BlurUpdate = struct {
    kernel_changed: bool,
    appearance_changed: bool,
};

pub const BlurKernel = struct {
    passes: u32,
    sample_step: f32,
    tap_reach: u32,
    reach: u32,
};

pub fn resolveBlurKernel(
    radius: c_int,
    passes: c_int,
    scale: f32,
) ?BlurKernel {
    if (radius <= 0 or passes <= 0 or !(scale > 0)) return null;
    const pass_count: u32 = @intCast(std.math.clamp(passes, 1, 16));
    const physical_radius =
        @as(f32, @floatFromInt(radius)) * scale;
    const root_passes = @sqrt(@as(f32, @floatFromInt(pass_count)));
    const sample_step = @max(
        0.125,
        physical_radius / (12.9230769232 * root_passes),
    );
    // The separable shader samples through a linear sampler. Account for the
    // adjacent texel footprint at every pass, rather than accumulating only
    // the continuous offset: at high pass counts that difference is large
    // enough to leave stale pixels around damaged window edges.
    const tap_reach: u32 = @intFromFloat(@ceil(
        3.2307692308 * sample_step + 1.0,
    ));
    return .{
        .passes = pass_count,
        .sample_step = sample_step,
        .tap_reach = tap_reach,
        // Blur runs at half resolution, so each dependency texel spans two
        // output pixels. The final two pixels cover downsample/upsample
        // filtering at the ends of the chain.
        .reach = 2 * tap_reach * pass_count + 2,
    };
}

/// Cached blur first expands content damage to cover every changed output
/// pixel, then reconstructs those pixels from the scene prefix. That
/// reconstruction needs the same kernel reach again so its source never falls
/// back to retained, fully composited output pixels.
pub fn cachedBlurRenderReach(kernel: BlurKernel) u32 {
    return @min(
        kernel.reach *| 2,
        @as(u32, @intCast(std.math.maxInt(c_int))),
    );
}

pub const WindowBlurData = struct {
    box: wlr.Box = .{ .x = 0, .y = 0, .width = 0, .height = 0 },
    radius: u31 = 0,
    enabled: bool = false,
    generation: u64 = 1,
};

pub const OutputBlurCacheData = struct {
    box: wlr.Box,
    enabled: bool = true,
    invalidation_generation: u64 = 1,
    config_generation: u64,
};

const WindowBlurMap = SlotMap(*WindowBlurRecord);
const OutputBlurCacheMap = SlotMap(*OutputBlurCacheRecord);

pub const WindowBlurHandle = struct {
    key: WindowBlurMap.Key,
};

pub const OutputBlurCacheHandle = struct {
    key: OutputBlurCacheMap.Key,
};

pub const LiveCounts = struct {
    buffers: usize,
    rects: usize,
    window_blurs: usize,
    output_blur_caches: usize,

    pub fn total(counts: LiveCounts) usize {
        return counts.buffers +
            counts.rects +
            counts.window_blurs +
            counts.output_blur_caches;
    }
};

const BufferRecord = struct {
    owner: *EffectMetadata,
    object: *wlr.SceneBuffer,
    data: BufferData,
    destroy: wl.Listener(void) = .init(handleDestroy),

    fn handleDestroy(listener: *wl.Listener(void)) void {
        const record: *BufferRecord = @fieldParentPtr("destroy", listener);
        record.owner.removeBufferRecord(record);
    }
};

const RectRecord = struct {
    owner: *EffectMetadata,
    object: *wlr.SceneRect,
    data: RectData,
    destroy: wl.Listener(void) = .init(handleDestroy),

    fn handleDestroy(listener: *wl.Listener(void)) void {
        const record: *RectRecord = @fieldParentPtr("destroy", listener);
        record.owner.removeRectRecord(record);
    }
};

const WindowBlurRecord = struct {
    owner: *EffectMetadata,
    tree: *wlr.SceneTree,
    handle: WindowBlurHandle,
    data: WindowBlurData = .{},
    destroy: wl.Listener(void) = .init(handleDestroy),

    fn handleDestroy(listener: *wl.Listener(void)) void {
        const record: *WindowBlurRecord = @fieldParentPtr("destroy", listener);
        record.owner.destroyWindowBlur(record.handle);
    }
};

const OutputBlurCacheRecord = struct {
    owner: *EffectMetadata,
    tree: *wlr.SceneTree,
    handle: OutputBlurCacheHandle,
    data: OutputBlurCacheData,
    destroy: wl.Listener(void) = .init(handleDestroy),

    fn handleDestroy(listener: *wl.Listener(void)) void {
        const record: *OutputBlurCacheRecord = @fieldParentPtr("destroy", listener);
        record.owner.destroyOutputBlurCache(record.handle);
    }
};

allocator: Allocator,
buffers: AutoHashMapUnmanaged(*wlr.SceneBuffer, *BufferRecord) = .empty,
rects: AutoHashMapUnmanaged(*wlr.SceneRect, *RectRecord) = .empty,
window_blurs: WindowBlurMap = .empty,
output_blur_caches: OutputBlurCacheMap = .empty,
blur_config: BlurConfig = .{},

pub fn init(allocator: Allocator) EffectMetadata {
    return .{ .allocator = allocator };
}

pub fn deinit(metadata: *EffectMetadata) void {
    var buffer_it = metadata.buffers.valueIterator();
    while (buffer_it.next()) |record_ptr| {
        const record = record_ptr.*;
        record.destroy.link.remove();
        metadata.allocator.destroy(record);
    }
    metadata.buffers.deinit(metadata.allocator);

    var rect_it = metadata.rects.valueIterator();
    while (rect_it.next()) |record_ptr| {
        const record = record_ptr.*;
        record.destroy.link.remove();
        metadata.allocator.destroy(record);
    }
    metadata.rects.deinit(metadata.allocator);

    var window_it = metadata.window_blurs.iterator();
    while (window_it.next()) |record| {
        record.destroy.link.remove();
        metadata.allocator.destroy(record);
    }
    metadata.window_blurs.deinit(metadata.allocator);

    var cache_it = metadata.output_blur_caches.iterator();
    while (cache_it.next()) |record| {
        record.destroy.link.remove();
        metadata.allocator.destroy(record);
    }
    metadata.output_blur_caches.deinit(metadata.allocator);
}

pub fn liveCounts(metadata: *const EffectMetadata) LiveCounts {
    return .{
        .buffers = metadata.buffers.count(),
        .rects = metadata.rects.count(),
        .window_blurs = metadata.window_blurs.count,
        .output_blur_caches = metadata.output_blur_caches.count,
    };
}

pub fn bufferData(metadata: *EffectMetadata, buffer: *wlr.SceneBuffer) ?BufferData {
    const record = metadata.buffers.get(buffer) orelse return null;
    return record.data;
}

pub fn setBufferClip(
    metadata: *EffectMetadata,
    buffer: *wlr.SceneBuffer,
    clip: ?BufferClip,
) error{OutOfMemory}!bool {
    if (metadata.buffers.get(buffer)) |record| {
        if (std.meta.eql(record.data.clip, clip)) return false;
        record.data.clip = clip;
        record.data.generation = nextGeneration(record.data.generation);
        if (clip == null and record.data.snapshot_hdr == null) metadata.removeBufferRecord(record);
        return true;
    }
    if (clip == null) return false;

    const record = try metadata.allocator.create(BufferRecord);
    errdefer metadata.allocator.destroy(record);
    record.* = .{
        .owner = metadata,
        .object = buffer,
        .data = .{ .clip = clip },
    };
    try metadata.buffers.put(metadata.allocator, buffer, record);
    buffer.node.events.destroy.add(&record.destroy);
    return true;
}

pub fn copyBufferData(
    metadata: *EffectMetadata,
    dst: *wlr.SceneBuffer,
    src: *wlr.SceneBuffer,
) error{OutOfMemory}!void {
    if (dst == src) return;
    const src_data = metadata.bufferData(src);
    if (metadata.buffers.get(dst)) |record| metadata.removeBufferRecord(record);
    if (src_data) |data| {
        const record = try metadata.allocator.create(BufferRecord);
        errdefer metadata.allocator.destroy(record);
        record.* = .{
            .owner = metadata,
            .object = dst,
            .data = data,
        };
        try metadata.buffers.put(metadata.allocator, dst, record);
        dst.node.events.destroy.add(&record.destroy);
    }
}

pub fn setSnapshotHdrPolicy(
    metadata: *EffectMetadata,
    buffer: *wlr.SceneBuffer,
    policy: SnapshotHdrPolicy,
) error{OutOfMemory}!void {
    if (metadata.buffers.get(buffer)) |record| {
        if (std.meta.eql(record.data.snapshot_hdr, @as(?SnapshotHdrPolicy, policy))) return;
        record.data.snapshot_hdr = policy;
        record.data.generation = nextGeneration(record.data.generation);
        return;
    }
    const record = try metadata.allocator.create(BufferRecord);
    errdefer metadata.allocator.destroy(record);
    record.* = .{
        .owner = metadata,
        .object = buffer,
        .data = .{ .snapshot_hdr = policy },
    };
    try metadata.buffers.put(metadata.allocator, buffer, record);
    buffer.node.events.destroy.add(&record.destroy);
}

fn removeBufferRecord(metadata: *EffectMetadata, record: *BufferRecord) void {
    if (metadata.buffers.get(record.object) != record) return;
    _ = metadata.buffers.remove(record.object);
    record.destroy.link.remove();
    metadata.allocator.destroy(record);
}

pub fn rectData(metadata: *EffectMetadata, rect: *wlr.SceneRect) ?RectData {
    const record = metadata.rects.get(rect) orelse return null;
    return record.data;
}

pub fn setRectRadius(
    metadata: *EffectMetadata,
    rect: *wlr.SceneRect,
    radius: u31,
) error{OutOfMemory}!void {
    if (metadata.rects.get(rect) == null and radius == 0) return;
    const record = try metadata.getOrCreateRect(rect);
    const radii = CornerRadii.uniform(radius);
    if (std.meta.eql(record.data.radii, radii)) return;
    record.data.radii = radii;
    record.data.generation = nextGeneration(record.data.generation);
    if (radius == 0 and record.data.clipped_region == null) {
        metadata.removeRectRecord(record);
    }
}

pub fn setRectClippedRegion(
    metadata: *EffectMetadata,
    rect: *wlr.SceneRect,
    area: wlr.Box,
    radii: CornerRadii,
) error{OutOfMemory}!void {
    const record = try metadata.getOrCreateRect(rect);
    const clipped_region: RoundedClip = .{ .area = area, .radii = radii };
    if (record.data.clipped_region) |current| {
        if (std.meta.eql(current, clipped_region)) return;
    }
    record.data.clipped_region = clipped_region;
    record.data.generation = nextGeneration(record.data.generation);
}

fn getOrCreateRect(
    metadata: *EffectMetadata,
    rect: *wlr.SceneRect,
) error{OutOfMemory}!*RectRecord {
    if (metadata.rects.get(rect)) |record| return record;

    const record = try metadata.allocator.create(RectRecord);
    errdefer metadata.allocator.destroy(record);
    record.* = .{
        .owner = metadata,
        .object = rect,
        .data = .{},
    };
    try metadata.rects.put(metadata.allocator, rect, record);
    rect.node.events.destroy.add(&record.destroy);
    return record;
}

fn removeRectRecord(metadata: *EffectMetadata, record: *RectRecord) void {
    if (metadata.rects.get(record.object) != record) return;
    _ = metadata.rects.remove(record.object);
    record.destroy.link.remove();
    metadata.allocator.destroy(record);
}

/// Update scene-wide blur state. Kernel changes advance the cache generation;
/// appearance changes are reported separately because they only need a new
/// composite and deliberately do not invalidate cached blur sources.
pub fn setBlurConfig(metadata: *EffectMetadata, radius: c_int, passes: c_int, appearance: BlurAppearance) BlurUpdate {
    const kernel_changed =
        metadata.blur_config.radius != radius or
        metadata.blur_config.passes != passes;
    const appearance_changed =
        !std.meta.eql(metadata.blur_config.appearance, appearance);
    metadata.blur_config.radius = radius;
    metadata.blur_config.passes = passes;
    metadata.blur_config.appearance = appearance;
    if (kernel_changed) {
        metadata.blur_config.generation = nextGeneration(metadata.blur_config.generation);
    }
    return .{
        .kernel_changed = kernel_changed,
        .appearance_changed = appearance_changed,
    };
}

pub fn blurConfig(metadata: *const EffectMetadata) BlurConfig {
    return metadata.blur_config;
}

pub fn createWindowBlur(
    metadata: *EffectMetadata,
    tree: *wlr.SceneTree,
) error{OutOfMemory}!WindowBlurHandle {
    const record = try metadata.allocator.create(WindowBlurRecord);
    errdefer metadata.allocator.destroy(record);
    record.* = .{
        .owner = metadata,
        .tree = tree,
        .handle = undefined,
    };
    const key = try metadata.window_blurs.put(metadata.allocator, record);
    record.handle = .{ .key = key };
    tree.node.events.destroy.add(&record.destroy);
    return record.handle;
}

pub fn configureWindowBlur(
    metadata: *EffectMetadata,
    handle: WindowBlurHandle,
    box: wlr.Box,
    radius: u31,
    enabled: bool,
) bool {
    const record = metadata.window_blurs.get(handle.key) orelse return false;
    if (std.meta.eql(record.data.box, box) and
        record.data.radius == radius and
        record.data.enabled == enabled)
    {
        return true;
    }
    record.data.box = box;
    record.data.radius = radius;
    record.data.enabled = enabled;
    record.data.generation = nextGeneration(record.data.generation);
    return true;
}

pub fn invalidateWindowBlur(metadata: *EffectMetadata, handle: WindowBlurHandle) void {
    const record = metadata.window_blurs.get(handle.key) orelse return;
    record.data.generation = nextGeneration(record.data.generation);
}

pub fn windowBlurData(
    metadata: *EffectMetadata,
    handle: WindowBlurHandle,
) ?WindowBlurData {
    const record = metadata.window_blurs.get(handle.key) orelse return null;
    return record.data;
}

pub fn destroyWindowBlur(metadata: *EffectMetadata, handle: WindowBlurHandle) void {
    const record = metadata.window_blurs.get(handle.key) orelse return;
    metadata.window_blurs.remove(handle.key);
    record.destroy.link.remove();
    metadata.allocator.destroy(record);
}

pub fn createOutputBlurCache(
    metadata: *EffectMetadata,
    tree: *wlr.SceneTree,
    width: c_int,
    height: c_int,
) error{OutOfMemory}!OutputBlurCacheHandle {
    const record = try metadata.allocator.create(OutputBlurCacheRecord);
    errdefer metadata.allocator.destroy(record);
    record.* = .{
        .owner = metadata,
        .tree = tree,
        .handle = undefined,
        .data = .{
            .box = .{ .x = 0, .y = 0, .width = width, .height = height },
            .config_generation = metadata.blur_config.generation,
        },
    };
    const key = try metadata.output_blur_caches.put(metadata.allocator, record);
    record.handle = .{ .key = key };
    tree.node.events.destroy.add(&record.destroy);
    return record.handle;
}

pub fn configureOutputBlurCache(
    metadata: *EffectMetadata,
    handle: OutputBlurCacheHandle,
    box: wlr.Box,
    enabled: bool,
    dirty: bool,
) bool {
    const record = metadata.output_blur_caches.get(handle.key) orelse return false;
    const geometry_changed = !std.meta.eql(record.data.box, box);
    const config_changed =
        record.data.config_generation != metadata.blur_config.generation;
    record.data.box = box;
    record.data.enabled = enabled;
    record.data.config_generation = metadata.blur_config.generation;
    if (dirty or geometry_changed or config_changed) {
        record.data.invalidation_generation =
            nextGeneration(record.data.invalidation_generation);
    }
    return true;
}

pub fn markOutputBlurCacheDirty(
    metadata: *EffectMetadata,
    handle: OutputBlurCacheHandle,
) bool {
    const record = metadata.output_blur_caches.get(handle.key) orelse return false;
    record.data.invalidation_generation =
        nextGeneration(record.data.invalidation_generation);
    return true;
}

pub fn setOutputBlurCacheEnabled(
    metadata: *EffectMetadata,
    handle: OutputBlurCacheHandle,
    enabled: bool,
) bool {
    const record = metadata.output_blur_caches.get(handle.key) orelse return false;
    record.data.enabled = enabled;
    return true;
}

pub fn outputBlurCacheData(
    metadata: *EffectMetadata,
    handle: OutputBlurCacheHandle,
) ?OutputBlurCacheData {
    const record = metadata.output_blur_caches.get(handle.key) orelse return null;
    return record.data;
}

pub fn destroyOutputBlurCache(
    metadata: *EffectMetadata,
    handle: OutputBlurCacheHandle,
) void {
    const record = metadata.output_blur_caches.get(handle.key) orelse return;
    metadata.output_blur_caches.remove(handle.key);
    record.destroy.link.remove();
    metadata.allocator.destroy(record);
}

fn nextGeneration(current: u64) u64 {
    const next = current +% 1;
    return if (next == 0) 1 else next;
}

fn initNodeDestroySignal(node: *wlr.SceneNode) void {
    node.events.destroy.init();
}

test "scene metadata follows node lifetime and pointer reuse" {
    var metadata = EffectMetadata.init(std.testing.allocator);
    defer metadata.deinit();

    var buffer: wlr.SceneBuffer = undefined;
    initNodeDestroySignal(&buffer.node);
    _ = try metadata.setBufferClip(&buffer, BufferClip.init(.{ .x = 0, .y = 0, .width = 320, .height = 240 }, 14));
    try std.testing.expectEqual(@as(f64, 14), metadata.bufferData(&buffer).?.clip.?.radius);
    try std.testing.expectEqual(@as(usize, 1), metadata.liveCounts().buffers);

    buffer.node.events.destroy.emit();
    try std.testing.expectEqual(@as(?BufferData, null), metadata.bufferData(&buffer));
    try std.testing.expectEqual(@as(usize, 0), metadata.liveCounts().buffers);

    initNodeDestroySignal(&buffer.node);
    _ = try metadata.setBufferClip(&buffer, BufferClip.init(.{ .x = 0, .y = 0, .width = 320, .height = 240 }, 7));
    try std.testing.expectEqual(@as(f64, 7), metadata.bufferData(&buffer).?.clip.?.radius);
    buffer.node.events.destroy.emit();

    var rect: wlr.SceneRect = undefined;
    initNodeDestroySignal(&rect.node);
    try metadata.setRectRadius(&rect, 9);
    try metadata.setRectClippedRegion(
        &rect,
        .{ .x = 2, .y = 3, .width = 40, .height = 50 },
        .uniform(4),
    );
    try std.testing.expectEqual(@as(u31, 9), metadata.rectData(&rect).?.radii.top_right);
    rect.node.events.destroy.emit();
    try std.testing.expectEqual(@as(?RectData, null), metadata.rectData(&rect));
}

test "buffer metadata is copied into scene snapshots" {
    var metadata = EffectMetadata.init(std.testing.allocator);
    defer metadata.deinit();

    var src: wlr.SceneBuffer = undefined;
    var dst: wlr.SceneBuffer = undefined;
    initNodeDestroySignal(&src.node);
    initNodeDestroySignal(&dst.node);

    _ = try metadata.setBufferClip(&src, BufferClip.init(.{ .x = 0, .y = 0, .width = 320, .height = 240 }, 15));
    try metadata.copyBufferData(&dst, &src);
    try std.testing.expectEqualDeep(metadata.bufferData(&src), metadata.bufferData(&dst));

    src.node.events.destroy.emit();
    try std.testing.expect(metadata.bufferData(&dst) != null);
    dst.node.events.destroy.emit();
    try std.testing.expectEqual(@as(usize, 0), metadata.liveCounts().total());
}

test "mask-only updates advance generation and square masks remain active" {
    var metadata = EffectMetadata.init(std.testing.allocator);
    defer metadata.deinit();
    var buffer: wlr.SceneBuffer = undefined;
    initNodeDestroySignal(&buffer.node);
    const clip = BufferClip.init(.{ .x = 20, .y = 20, .width = 320, .height = 240 }, 15);
    try std.testing.expect(try metadata.setBufferClip(&buffer, clip));
    const generation = metadata.bufferData(&buffer).?.generation;
    try std.testing.expect(!try metadata.setBufferClip(&buffer, clip));
    try std.testing.expectEqual(generation, metadata.bufferData(&buffer).?.generation);
    try std.testing.expect(try metadata.setBufferClip(&buffer, clip.translated(-5, 0)));
    try std.testing.expect(metadata.bufferData(&buffer).?.generation != generation);
    var square = clip;
    square.radius = 0;
    try std.testing.expect(try metadata.setBufferClip(&buffer, square));
    try std.testing.expect(metadata.bufferData(&buffer).?.clip != null);
    try std.testing.expect(try metadata.setBufferClip(&buffer, null));
    try std.testing.expect(metadata.bufferData(&buffer) == null);
    try std.testing.expect(!try metadata.setBufferClip(&buffer, null));
    buffer.node.events.destroy.emit();
}

test "snapshot HDR policy survives mask resets, copying, and source destruction" {
    var metadata = EffectMetadata.init(std.testing.allocator);
    defer metadata.deinit();
    var src: wlr.SceneBuffer = undefined;
    var dst: wlr.SceneBuffer = undefined;
    initNodeDestroySignal(&src.node);
    initNodeDestroySignal(&dst.node);
    const policy: SnapshotHdrPolicy = .{ .eligible = true, .native_windows_hdr = true };
    try metadata.setSnapshotHdrPolicy(&src, policy);
    _ = try metadata.setBufferClip(&src, BufferClip.init(.{ .x = 0, .y = 0, .width = 320, .height = 240 }, 12));
    _ = try metadata.setBufferClip(&src, null);
    try std.testing.expectEqualDeep(policy, metadata.bufferData(&src).?.snapshot_hdr.?);
    try std.testing.expectEqual(@as(?BufferClip, null), metadata.bufferData(&src).?.clip);
    try metadata.copyBufferData(&dst, &src);
    try metadata.setSnapshotHdrPolicy(&src, .{});
    try std.testing.expectEqualDeep(policy, metadata.bufferData(&dst).?.snapshot_hdr.?);
    src.node.events.destroy.emit();
    try std.testing.expectEqualDeep(policy, metadata.bufferData(&dst).?.snapshot_hdr.?);
    dst.node.events.destroy.emit();
    try std.testing.expectEqual(@as(usize, 0), metadata.liveCounts().buffers);

    // Reusing an address must not inherit the previous clone's eligibility.
    initNodeDestroySignal(&dst.node);
    try metadata.setSnapshotHdrPolicy(&dst, .{});
    try std.testing.expectEqualDeep(SnapshotHdrPolicy{}, metadata.bufferData(&dst).?.snapshot_hdr.?);
    dst.node.events.destroy.emit();
}

test "blur handles reject stale generations and track invalidation" {
    var metadata = EffectMetadata.init(std.testing.allocator);
    defer metadata.deinit();

    var tree: wlr.SceneTree = undefined;
    initNodeDestroySignal(&tree.node);

    const old_window = try metadata.createWindowBlur(&tree);
    try std.testing.expect(metadata.configureWindowBlur(
        old_window,
        .{ .x = 1, .y = 2, .width = 300, .height = 200 },
        15,
        true,
    ));
    metadata.destroyWindowBlur(old_window);
    try std.testing.expect(!metadata.configureWindowBlur(
        old_window,
        .{ .x = 0, .y = 0, .width = 1, .height = 1 },
        1,
        true,
    ));

    const new_window = try metadata.createWindowBlur(&tree);
    try std.testing.expect(old_window.key.index == new_window.key.index);
    try std.testing.expect(old_window.key.generation != new_window.key.generation);

    const cache = try metadata.createOutputBlurCache(&tree, 1920, 1080);
    const first = metadata.outputBlurCacheData(cache).?;
    const unchanged = metadata.setBlurConfig(0, 0, .{});
    try std.testing.expect(!unchanged.kernel_changed);
    try std.testing.expect(!unchanged.appearance_changed);
    const initial_generation = metadata.blurConfig().generation;
    const appearance_update = metadata.setBlurConfig(0, 0, .{ .noise = 0.25 });
    try std.testing.expect(!appearance_update.kernel_changed);
    try std.testing.expect(appearance_update.appearance_changed);
    try std.testing.expectEqual(initial_generation, metadata.blurConfig().generation);
    try std.testing.expectEqual(@as(f32, 0.25), metadata.blurConfig().appearance.noise);
    const kernel_update = metadata.setBlurConfig(12, 2, .{ .noise = 0.25 });
    try std.testing.expect(kernel_update.kernel_changed);
    try std.testing.expect(!kernel_update.appearance_changed);
    try std.testing.expect(metadata.configureOutputBlurCache(
        cache,
        .{ .x = 0, .y = 0, .width = 1920, .height = 1080 },
        true,
        false,
    ));
    const configured = metadata.outputBlurCacheData(cache).?;
    try std.testing.expect(configured.invalidation_generation != first.invalidation_generation);
    try std.testing.expectEqual(metadata.blurConfig().generation, configured.config_generation);

    try std.testing.expect(metadata.markOutputBlurCacheDirty(cache));
    const dirtied = metadata.outputBlurCacheData(cache).?;
    try std.testing.expect(dirtied.invalidation_generation != configured.invalidation_generation);

    tree.node.events.destroy.emit();
    try std.testing.expectEqual(@as(usize, 0), metadata.liveCounts().total());
    try std.testing.expect(!metadata.markOutputBlurCacheDirty(cache));
}

test "deinit releases records whose owners are still alive" {
    var metadata = EffectMetadata.init(std.testing.allocator);

    var buffer: wlr.SceneBuffer = undefined;
    var rect: wlr.SceneRect = undefined;
    var tree: wlr.SceneTree = undefined;
    initNodeDestroySignal(&buffer.node);
    initNodeDestroySignal(&rect.node);
    initNodeDestroySignal(&tree.node);

    _ = try metadata.setBufferClip(&buffer, BufferClip.init(.{ .x = 0, .y = 0, .width = 320, .height = 240 }, 5));
    try metadata.setRectRadius(&rect, 6);
    _ = try metadata.createWindowBlur(&tree);
    _ = try metadata.createOutputBlurCache(&tree, 800, 600);
    try std.testing.expectEqual(@as(usize, 4), metadata.liveCounts().total());

    metadata.deinit();
    buffer.node.events.destroy.emit();
    rect.node.events.destroy.emit();
    tree.node.events.destroy.emit();
}

test "physical corner radii are scaled and clamped on the CPU" {
    try std.testing.expectEqualDeep(
        [4]f32{ 18.75, 18.75, 18.75, 18.75 },
        clampedPhysicalRadii(.uniform(15), 500, 300, 1.25),
    );
    try std.testing.expectEqualDeep(
        [4]f32{ 20, 20, 10, 4 },
        clampedPhysicalRadii(.{
            .top_left = 40,
            .top_right = 20,
            .bottom_right = 10,
            .bottom_left = 4,
        }, 40, 100, 1),
    );
    try std.testing.expectEqualDeep(
        [4]f32{ 0, 0, 0, 0 },
        clampedPhysicalRadii(.uniform(15), 0, 100, 2),
    );
}

test "blur kernel maps physical radius and bounds pass count" {
    const normal = resolveBlurKernel(10, 8, 1).?;
    try std.testing.expectEqual(@as(u32, 8), normal.passes);
    try std.testing.expect(normal.reach >= 10);
    try std.testing.expectEqual(
        2 * normal.tap_reach * normal.passes + 2,
        normal.reach,
    );

    const scaled = resolveBlurKernel(12, 100, 2).?;
    try std.testing.expectEqual(@as(u32, 16), scaled.passes);
    try std.testing.expect(scaled.reach >= 24);

    const high_pass = resolveBlurKernel(10, 16, 1).?;
    try std.testing.expectEqual(@as(u32, 2), high_pass.tap_reach);
    try std.testing.expectEqual(@as(u32, 66), high_pass.reach);
    try std.testing.expectEqual(
        @as(u32, 132),
        cachedBlurRenderReach(high_pass),
    );
    var saturated = high_pass;
    saturated.reach = std.math.maxInt(u32);
    try std.testing.expectEqual(
        @as(u32, @intCast(std.math.maxInt(c_int))),
        cachedBlurRenderReach(saturated),
    );

    try std.testing.expect(resolveBlurKernel(0, 8, 1) == null);
    try std.testing.expect(resolveBlurKernel(10, 0, 1) == null);
}

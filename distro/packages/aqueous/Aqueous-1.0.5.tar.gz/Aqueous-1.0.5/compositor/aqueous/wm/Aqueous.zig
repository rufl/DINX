// SPDX-FileCopyrightText: © 2026 Seafoam Labs
// SPDX-License-Identifier: GPL-3.0-only

const Aqueous = @This();

const build_options = @import("build_options");
const std = @import("std");
const wl = @import("wayland").server.wl;

const server = &@import("../main.zig").server;

const Seat = @import("../Seat.zig");
const CompositorApi = @import("CompositorApi.zig");
const Mode = @import("Mode.zig").Mode;
const Trace = @import("Trace.zig");
const layout_config = @import("config/layout.zig");
const config_loader = @import("config/loader.zig");
const action_config = @import("config/actions.zig");
const layout_engine = @import("layout/engine.zig");
const game_mode = @import("layout/game_mode.zig");
const floating_layout = @import("layout/floating.zig");
const stacking = @import("layout/stacking.zig");
const layout_types = @import("layout/types.zig");
const geometry = @import("geometry.zig");
const FocusHistory = @import("focus/history.zig");
const PendingFocus = @import("focus/pending.zig");
const HoverDelay = @import("focus/hover_delay.zig");
const pointer_drag = @import("input/drag.zig");
const gesture_input = @import("input/gestures.zig");
const output_transfer = @import("input/output_transfer.zig");
const wheel_input = @import("input/wheel.zig");
const StateStore = @import("state/store.zig");
const PolicyState = @import("state/PolicyState.zig");
const WorkspaceStack = @import("state/stack.zig");
const transient = @import("state/transient.zig");
const OutputService = @import("output/Service.zig");
const output_navigation = @import("output/navigation.zig");
const workspace_navigation = @import("workspaces/navigation.zig");
const overview_model = @import("overview/model.zig");
const rules_config = @import("rules/config.zig");
const Rules = @import("rules/engine.zig");
const util = @import("../util.zig");
const process = @import("../process.zig");
const posix = std.posix;

const log = std.log.scoped(.aqueous);

const LayoutStateKey = struct { output: u64, workspace: u32 };

mode: Mode,
api: CompositorApi = .{},
focus_cause: CompositorApi.FocusCause = .non_pointer,
trace: Trace = .{},
config: config_loader.Snapshot = .{},
rules: Rules,
layout_states: std.AutoHashMapUnmanaged(LayoutStateKey, layout_engine.State) = .empty,
workspace_stacks: std.AutoHashMapUnmanaged(LayoutStateKey, WorkspaceStack) = .empty,
layout_overrides: std.AutoHashMapUnmanaged(LayoutStateKey, layout_config.LayoutId) = .empty,
snap_layout_overrides: std.AutoHashMapUnmanaged(u64, layout_config.SnapId) = .empty,
previous_workspaces: std.AutoHashMapUnmanaged(u64, u32) = .empty,
fired_exec: std.AutoHashMapUnmanaged(u64, void) = .empty,
reload_timer: ?*wl.EventSource = null,
hover_focus_timer: ?*wl.EventSource = null,
raise_focus_timer: ?*wl.EventSource = null,
hover_focus: HoverDelay.State = .{},
pending_raise: ?layout_types.Handle = null,
globals_applied: bool = false,
focus_history: FocusHistory,
pending_focus: PendingFocus,
/// Most recently admitted toplevel waiting for the opt-in new-window focus
/// policy. A single handle is sufficient: coalesced admissions focus the
/// newest window, matching the compositor's creation-event order.
pending_new_focus: layout_types.Handle = 0,
window_states: StateStore,
output_service: OutputService,
started: bool = false,
drag: ?Drag = null,
/// Admission can complete after the initiating button has been released.
pending_tiled_transfer: ?TiledTransfer = null,
last_scrolling_click: ?ScrollingClick = null,
untrap_keysym: ?u32 = null,
requested_stack_focus: ?layout_types.Handle = null,
overview: ?overview_model.State = null,

pub const Drag = struct {
    handle: layout_types.Handle,
    start: layout_types.Rect,
    pointer_x: f64,
    pointer_y: f64,
    last_pointer_x: f64,
    last_pointer_y: f64,
    action: pointer_drag.Action,
    layout_key: LayoutStateKey = .{ .output = 0, .workspace = 0 },
    awaiting_layout: ?layout_types.Handle = null,
    click_eligible: bool = true,
    resize_edges: pointer_drag.ResizeEdges = .{ .bottom = true, .right = true },
    resize_axis: ?pointer_drag.ResizeAxis = null,
    constraints: geometry.Constraints = .{},
    client_seat: ?usize = null,
    dnd: bool = false,
    /// Geometry belongs to the workspace floating layout, not PolicyState.
    layout_floating: bool = false,
    snap_candidate: ?SnapCandidate = null,
};

const TiledTransfer = struct {
    handle: layout_types.Handle,
    key: LayoutStateKey,
    target: ?layout_types.Handle = null,
    zone: layout_types.DropZone = .column_after,
    layout: ?layout_config.LayoutId = null,
};

const SnapCandidate = struct {
    output_id: u64,
    geometry: layout_types.Rect,
    layout_id: layout_config.SnapId = .{},
    zone_id: layout_config.SnapId = .{},
    zone_index: u8,
};

const SnapTargets = struct {
    geometries: [layout_config.max_snap_zones]layout_types.Rect = undefined,
    hit_geometries: [layout_config.max_snap_zones]layout_types.Rect = undefined,
    zone_indices: [layout_config.max_snap_zones]u8 = undefined,
    count: u8 = 0,
    layout_id: layout_config.SnapId = .{},
    zone_ids: [layout_config.max_snap_zones]layout_config.SnapId = [_]layout_config.SnapId{.{}} ** layout_config.max_snap_zones,
};

const ScrollingClick = struct {
    handle: layout_types.Handle,
    time_msec: u32,
};

pub fn init(aqueous: *Aqueous, mode: Mode, startup_config: config_loader.Snapshot) void {
    aqueous.* = .{
        .mode = mode,
        .config = startup_config,
        .rules = Rules.init(util.gpa),
        .focus_history = FocusHistory.init(util.gpa),
        .pending_focus = PendingFocus.init(util.gpa),
        .window_states = StateStore.init(util.gpa, CompositorApi.policyState),
        .output_service = undefined,
    };
    aqueous.api.setLegacyServerDecorationForce(aqueous.config.wm.force_ssd);
    aqueous.api.configureBell(&aqueous.config.wm.bell);
    aqueous.output_service.init();
    rules_config.reloadDiscovered(util.gpa, &aqueous.rules, aqueous.config.wm.rules_path.slice());
    const event_loop = @import("../main.zig").server.wl_server.getEventLoop();
    aqueous.reload_timer = event_loop.addTimer(*Aqueous, handleReloadTimer, aqueous) catch |err| blk: {
        log.warn("unable to start configuration monitor: {}", .{err});
        break :blk null;
    };
    if (aqueous.reload_timer) |timer| timer.timerUpdate(1000) catch log.warn("unable to arm configuration monitor", .{});
    aqueous.hover_focus_timer = event_loop.addTimer(*Aqueous, handleHoverFocusTimer, aqueous) catch |err| blk: {
        log.warn("unable to start scrolling pointer-focus delay timer: {}", .{err});
        break :blk null;
    };
    aqueous.raise_focus_timer = event_loop.addTimer(*Aqueous, handleRaiseFocusTimer, aqueous) catch |err| blk: {
        log.warn("unable to start delayed focus-raise timer: {}", .{err});
        break :blk null;
    };
    log.info("policy mode={s} layout={s}", .{ @tagName(mode), @tagName(aqueous.config.layout.default) });
}

pub fn deinit(aqueous: *Aqueous) void {
    aqueous.started = false;
    aqueous.cancelOverview();
    aqueous.output_service.deinit();
    if (aqueous.reload_timer) |timer| timer.remove();
    if (aqueous.hover_focus_timer) |timer| timer.remove();
    if (aqueous.raise_focus_timer) |timer| timer.remove();
    var states = aqueous.layout_states.valueIterator();
    while (states.next()) |state| state.deinit(util.gpa);
    aqueous.layout_states.deinit(util.gpa);
    var stacks = aqueous.workspace_stacks.valueIterator();
    while (stacks.next()) |stack| stack.deinit(util.gpa);
    aqueous.workspace_stacks.deinit(util.gpa);
    aqueous.layout_overrides.deinit(util.gpa);
    aqueous.snap_layout_overrides.deinit(util.gpa);
    aqueous.previous_workspaces.deinit(util.gpa);
    aqueous.fired_exec.deinit(util.gpa);
    aqueous.focus_history.deinit();
    aqueous.pending_focus.deinit();
    aqueous.window_states.deinit();
    aqueous.rules.deinit();
    log.debug("policy stopped after {} trace event(s)", .{aqueous.trace.sequence});
}

/// Called once the compositor globals, input manager and configuration objects exist.
pub fn start(aqueous: *Aqueous) void {
    if (aqueous.started) return;
    aqueous.started = true;
    aqueous.output_service.start();
    if (!aqueous.mode.runsInternal()) return;
    aqueous.applyLayerRules();
    aqueous.applyInputConfig();
    aqueous.runExec(.startup);
}

pub fn allowsExternal(aqueous: *const Aqueous) bool {
    return build_options.external_policy and aqueous.mode.allowsExternal();
}

pub fn reloadConfig(aqueous: *Aqueous) !void {
    if (@import("../DisplayPreview.zig").active()) return error.ConfigWriterBusy;
    const tx = @import("../ConfigTransaction.zig");
    const io = std.Io.Threaded.global_single_threaded.io();
    const lock = try tx.Lock.acquire(util.gpa, io, false);
    var lock_held = true;
    defer if (lock_held) lock.release();
    _ = try tx.recover(util.gpa, io);
    aqueous.cancelOverview();
    aqueous.cancelSnapPreview();
    aqueous.cancelHoverFocus();
    aqueous.cancelPendingRaise();
    var replacement = try config_loader.load(util.gpa);
    if (replacement.wm.overlay_planes != aqueous.config.wm.overlay_planes) {
        log.warn("render.overlay_planes is startup-only; restart Aqueous to apply the change", .{});
        replacement.wm.overlay_planes = aqueous.config.wm.overlay_planes;
    }
    if (replacement.wm.color_pipeline != aqueous.config.wm.color_pipeline) {
        log.warn("render.color_pipeline is startup-only; restart Aqueous to apply the change", .{});
        replacement.wm.color_pipeline = aqueous.config.wm.color_pipeline;
    }
    preserveTabletPolicy(aqueous, &replacement);
    aqueous.config = replacement;
    if (aqueous.pending_tiled_transfer) |*pending| pending.target = null;
    {
        var seats = server.input_manager.seats.iterator(.forward);
        while (seats.next()) |seat| seat.wheel.reset();
    }
    if (!aqueous.config.wm.input.mouse_follows_focus) {
        var seats = server.input_manager.seats.iterator(.forward);
        while (seats.next()) |seat| seat.cancelFocusWarp();
    }
    aqueous.api.setLegacyServerDecorationForce(aqueous.config.wm.force_ssd);
    aqueous.api.configureBell(&aqueous.config.wm.bell);
    if (!aqueous.config.wm.input.focus_new_windows) aqueous.pending_new_focus = 0;
    rules_config.reloadDiscovered(util.gpa, &aqueous.rules, aqueous.config.wm.rules_path.slice());
    aqueous.applyLayerRules();
    aqueous.globals_applied = false;
    aqueous.api.requestManageCycle();
    aqueous.applyInputConfig();
    _ = aqueous.output_service.reload(true);
    lock.release();
    lock_held = false;
    aqueous.runExec(.reload);
    aqueous.notify("Aqueous configuration reloaded", null, false);
    log.info("configuration reloaded layout={s}", .{@tagName(aqueous.config.layout.default)});
}

pub fn traceCycle(aqueous: *Aqueous, phase: Trace.Phase, external_active: bool) void {
    const snapshot = aqueous.api.snapshot();
    if (aqueous.mode.runsInternal()) {
        aqueous.trace.emit(.internal, phase, snapshot);
    }
    if (external_active) {
        aqueous.trace.emit(.external, phase, snapshot);
    }
}

/// Called once as an output advances from sent to scheduled geometry, before
/// this transaction's policy layout. Window ownership, not coordinate overlap,
/// decides which rectangles move when outputs exchange places.
pub fn reconfigureOutput(aqueous: *Aqueous, output: *@import("../Output.zig")) void {
    if (!aqueous.mode.runsInternal() or output.sent.mode == .none or
        !output.sent.mirror_of.empty()) return;
    const old = output.sent.box();
    const new = output.scheduled.box();
    if (std.meta.eql(old, new)) return;
    const before: layout_types.Rect = .{ .x = old.x, .y = old.y, .width = old.width, .height = old.height };
    const after: layout_types.Rect = .{ .x = new.x, .y = new.y, .width = new.width, .height = new.height };
    const box = output.policyUsableBox();
    const usable = aqueous.effectiveUsableArea(after, .{ .x = box.x, .y = box.y, .width = box.width, .height = box.height });
    const id = output.policyId();
    if (aqueous.drag) |*drag| if (drag.layout_key.output == id) {
        // A snap target and pointer offsets refer to the old coordinate system.
        drag.snap_candidate = null;
        aqueous.finishInteractiveDrag();
    };
    var layouts = aqueous.layout_states.iterator();
    while (layouts.next()) |entry| {
        if (entry.key_ptr.output == id) layout_engine.reconfigureOutput(entry.value_ptr, before, after, usable);
    }
    var windows = server.wm.windows.iterator();
    while (windows.next()) |window| {
        const workspace = window.workspace orelse continue;
        if (workspace.output != output) continue;
        const state = &window.policy_state;
        state.floating_geometry = @import("layout/geometry.zig").reconfigureGeometry(state.floating_geometry, before, after, usable);
        state.snap_restore_geometry = @import("layout/geometry.zig").reconfigureGeometry(state.snap_restore_geometry, before, after, usable);
    }
}

pub fn applyManageCycle(aqueous: *Aqueous) !void {
    if (!aqueous.mode.runsInternal()) return;
    defer aqueous.requested_stack_focus = null;
    var drag_seats = server.input_manager.seats.iterator(.forward);
    while (drag_seats.next()) |seat| seat.toplevel_drag.validate();

    if (!aqueous.globals_applied) {
        aqueous.applyGlobalConfig();
        aqueous.globals_applied = true;
    }

    var snapshot = try aqueous.api.policySnapshot(util.gpa);
    defer snapshot.deinit(util.gpa);
    const client_requests = try aqueous.api.takeClientWindowRequests(util.gpa);
    defer util.gpa.free(client_requests);
    if (aqueous.applyClientWindowRequests(&snapshot, client_requests)) {
        // Activation may select another workspace/output. Continue this
        // transaction using the newly active workspace so visibility, layout,
        // and focus are all committed together.
        const refreshed = try aqueous.api.policySnapshot(util.gpa);
        snapshot.deinit(util.gpa);
        snapshot = refreshed;
    }
    if (aqueous.finishInvalidInteractiveDrag(&snapshot)) {
        const refreshed = try aqueous.api.policySnapshot(util.gpa);
        snapshot.deinit(util.gpa);
        snapshot = refreshed;
    }
    if (aqueous.reconcileTransientParents(&snapshot)) {
        const refreshed = try aqueous.api.policySnapshot(util.gpa);
        snapshot.deinit(util.gpa);
        snapshot = refreshed;
    }
    const placement_changed = blk: {
        var placement_snapshot = try aqueous.api.rulePlacementSnapshot(util.gpa);
        defer placement_snapshot.deinit(util.gpa);
        break :blk aqueous.reconcileRulePlacements(&placement_snapshot);
    };
    if (placement_changed) {
        // Output rules can transfer a window between the per-output slices in
        // this snapshot. Rebuild before layout so the source never arranges a
        // window which already belongs to the destination.
        const refreshed = try aqueous.api.policySnapshot(util.gpa);
        snapshot.deinit(util.gpa);
        snapshot = refreshed;
    }
    // Resolve the current matcher and its placement claim before interpreting
    // fullscreen output hints, including requests made before the first map.
    const fullscreen_requests = try aqueous.api.takeClientFullscreenRequests(util.gpa);
    defer util.gpa.free(fullscreen_requests);
    if (fullscreen_requests.len > 0) {
        aqueous.applyClientFullscreenRequests(&snapshot, fullscreen_requests);

        // A usable output hint can move a window between outputs. Rebuild the
        // policy view so this same cycle lays it out under its new owner rather
        // than using the stale output grouping captured above.
        const refreshed = try aqueous.api.policySnapshot(util.gpa);
        snapshot.deinit(util.gpa);
        snapshot = refreshed;
    }
    aqueous.validateOverviewSnapshot(&snapshot);
    @import("../main.zig").server.window_switcher.validate();
    const focused = aqueous.api.focusedWindow();
    const non_window_keyboard_focus = aqueous.api.hasNonWindowKeyboardFocus();
    // A direct focus request is committed by Seat.manageFinish() after policy
    // resolves this transaction. Use that newer target now so placement order
    // and focus-sensitive visuals do not render one management cycle behind.
    var cycle_focus = transactionFocus(aqueous.requested_stack_focus, focused);
    const new_window_anchor = cycle_focus;
    var cycle_selected_output_id = aqueous.api.selectedOutputId();
    // Direct pointer, keybinding, or client activation requests are newer and
    // more intentional than admission focus. Never overwrite one which was
    // coalesced into this management transaction.
    if (!aqueous.config.wm.input.focus_new_windows or aqueous.requested_stack_focus != null) {
        aqueous.pending_new_focus = 0;
    }
    const pending_new_focus = aqueous.pending_new_focus;
    var pending_new_focus_seen = false;
    var focused_is_focusable = focused == null;
    var replacement_focus_requested = false;
    if ((focused != null and focused == aqueous.pending_focus.window) or
        (non_window_keyboard_focus and aqueous.pending_focus.window != 0))
    {
        aqueous.pending_focus.clear();
    }

    for (snapshot.outputs) |output| {
        var output_layout = aqueous.config.layout;
        for (&output_layout.options) |*options| options.new_window_anchor = new_window_anchor;
        if (aqueous.api.pointerPosition()) |pointer| {
            const floating_options = &output_layout.options[@intFromEnum(layout_config.LayoutId.floating)];
            floating_options.pointer_x = pointer.x;
            floating_options.pointer_y = pointer.y;
        }
        if (aqueous.config.wm.resolveOutput(.{ .name = output.name, .make = output.make, .model = output.model, .serial = output.serial })) |configured| output_layout.default = configured;
        if (aqueous.config.wm.resolveWorkspace(output.name, output.workspace_number)) |configured| output_layout.default = configured;
        // Respect both dynamic layer-shell reservations (Noctalia, panels,
        // docks) and the user's static struts. Taking the intersection avoids
        // double-counting when both reserve the same edge.
        const usable_area = aqueous.effectiveUsableArea(output.area, output.usable_area);
        const workspace_key = workspaceKey(output.id, output.workspace_number);
        const layout_key: LayoutStateKey = .{ .output = output.id, .workspace = output.workspace_number };
        const stack_entry = try aqueous.workspace_stacks.getOrPut(util.gpa, layout_key);
        if (!stack_entry.found_existing) stack_entry.value_ptr.* = .{};
        const workspace_stack = stack_entry.value_ptr;
        if (aqueous.layout_overrides.get(layout_key)) |override| output_layout.default = override;
        var managed: std.ArrayListUnmanaged(layout_types.Window) = .empty;
        defer managed.deinit(util.gpa);
        var requested: std.ArrayListUnmanaged(layout_types.Placement) = .empty;
        defer requested.deinit(util.gpa);
        var focusable: std.ArrayListUnmanaged(layout_types.Window) = .empty;
        defer focusable.deinit(util.gpa);
        // First-time floating presentations admitted this cycle. The focus
        // raise below mints newer orders than their admission orders, so they
        // are re-minted afterwards to open at the top of the floating band.
        var new_floats: std.ArrayListUnmanaged(layout_types.Handle) = .empty;
        defer new_floats.deinit(util.gpa);
        try managed.ensureTotalCapacity(util.gpa, output.windows.len);
        try requested.ensureTotalCapacity(util.gpa, output.windows.len);
        try focusable.ensureTotalCapacity(util.gpa, output.windows.len);
        try new_floats.ensureTotalCapacity(util.gpa, output.windows.len);
        var game_anchor: ?struct { handle: layout_types.Handle, rule: Rules.Rule } = null;
        var fullscreen_owner: ?layout_types.Handle = null;
        for (output.windows) |window| {
            const state = aqueous.window_states.get(window.handle) orelse continue;
            const rule = aqueous.rules.resolve(.{
                .app_id = window.app_id,
                .class = window.app_id,
                .title = window.title,
                .tag = window.tag,
                .content_type = window.content_type,
            });
            aqueous.api.ensureWorkspace(window.handle, output.id);
            const effect = aqueous.reconcileWindowRule(
                window,
                output.windows,
                output.id,
                output.workspace_number,
                output.area,
                usable_area,
                output_layout.layoutOptions(.floating).border,
                rule,
            );
            var window_drag_seats = server.input_manager.seats.iterator(.forward);
            while (window_drag_seats.next()) |seat| seat.toplevel_drag.syncWindow(window.handle);
            if (pending_new_focus != 0 and window.handle == pending_new_focus) {
                pending_new_focus_seen = true;
                if (!admissionFocusEligible(window.accepts_focus and state.focus_allowed, state.kind(), effect.workspace_visible)) {
                    aqueous.pending_new_focus = 0;
                } else if (!non_window_keyboard_focus) {
                    if (cycle_focus != window.handle) aqueous.requestFocus(window.handle);
                    cycle_focus = window.handle;
                    cycle_selected_output_id = output.id;
                    aqueous.pending_new_focus = 0;
                }
            }
            if (effect.fullscreen) {
                if (fullscreen_owner) |prior| if (prior != window.handle) {
                    if (aqueous.window_states.get(prior)) |prior_state| prior_state.overrideFullscreen();
                    aqueous.api.clearFullscreen(prior);
                };
                fullscreen_owner = window.handle;
            }
            if (state.kind() == .minimized) {
                requested.appendAssumeCapacity(.{ .handle = window.handle, .geometry = .empty, .z_order = -1, .visible = false, .border = .none, .tiled = false });
                continue;
            }
            if (effect.fullscreen) {
                requested.appendAssumeCapacity(.{
                    .handle = window.handle,
                    .geometry = output.area,
                    .z_order = stacking.fullscreen_band,
                    .stack_order = 0,
                    .visible = true,
                    .border = .none,
                    .tiled = false,
                });
                if (effect.workspace_visible and window.accepts_focus and state.focus_allowed) focusable.appendAssumeCapacity(window);
                continue;
            }
            if (state.kind() == .maximized) {
                const max_area = if (aqueous.config.wm.maximize_full_output) output.area else usable_area;
                const max_z: i32 = if (aqueous.layoutIsFloating(layout_key)) stacking.floating_band else stacking.maximized_band;
                requested.appendAssumeCapacity(.{
                    .handle = window.handle,
                    .geometry = max_area,
                    .z_order = max_z,
                    .stack_order = 0,
                    .visible = true,
                    .border = output_layout.layoutOptions(.floating).border,
                    .tiled = false,
                    .maximized = true,
                });
                if (effect.workspace_visible and window.accepts_focus and state.focus_allowed) focusable.appendAssumeCapacity(window);
                continue;
            }
            if (state.kind() == .floating) {
                // Keep a newly parented XDG transient out of ordinary floating
                // placement while its initial 0x0 configure asks the client for
                // a natural size. Otherwise the generic floating fallback would
                // become the client's apparent natural size.
                if (transient.waitingForNaturalSize(state, window.parent) and
                    (window.preferred_width <= 0 or window.preferred_height <= 0))
                {
                    // Keep the window in the compositor's requested list even
                    // though it has no visible placement yet. manageFinish()
                    // only configures windows in this list, so omitting it
                    // would also omit the 0x0 natural-size configure and leave
                    // Qt dialogs waiting indefinitely.
                    requested.appendAssumeCapacity(.{
                        .handle = window.handle,
                        .geometry = .empty,
                        .z_order = stacking.floating_band,
                        .stack_order = 0,
                        .visible = false,
                        .border = .none,
                        .tiled = false,
                    });
                    continue;
                }
                var floating_rect = state.floating_geometry;
                if (floating_rect.width <= 0 or floating_rect.height <= 0) floating_rect = aqueous.initialFloatingGeometry(
                    output.windows,
                    window,
                    usable_area,
                    output_layout.layoutOptions(.floating),
                    workspace_stack.items.items.len,
                ) catch floatingPlacement(usable_area, window.handle, .{}, output_layout.layoutOptions(.floating).border).geometry;
                if (state.needs_output_recovery) {
                    floating_rect = output_transfer.recoverGeometry(floating_rect, usable_area);
                    state.floating_geometry = floating_rect;
                    state.needs_output_recovery = false;
                }
                if (!workspace_stack.contains(window.handle)) new_floats.appendAssumeCapacity(window.handle);
                requested.appendAssumeCapacity(.{
                    .handle = window.handle,
                    .geometry = floating_rect,
                    .z_order = stacking.floating_band,
                    .stack_order = 0,
                    .visible = true,
                    .border = output_layout.layoutOptions(.floating).border,
                    .tiled = false,
                });
                if (effect.workspace_visible and window.accepts_focus and state.focus_allowed) focusable.appendAssumeCapacity(window);
                continue;
            }
            if (rule) |matched| {
                if (matched.layout) |id| output_layout.default = ruleLayout(id);
                if (matched.layout == .game_mode and (game_anchor == null or cycle_focus == window.handle)) {
                    game_anchor = .{ .handle = window.handle, .rule = matched };
                }
            }
            var layout_window = window;
            // The snapshot predates rule reconciliation. Use the new preset
            // for this transaction's first arrangement too.
            layout_window.scrolling_full_width = state.scrolling_full_width;
            layout_window.scrolling_width = state.scrolling_width;
            managed.appendAssumeCapacity(layout_window);
            if (effect.workspace_visible and window.accepts_focus and state.focus_allowed) focusable.appendAssumeCapacity(window);
            if (rule != null and rule.?.layout == .game_mode and managed.items.len > 1) {
                std.mem.swap(layout_types.Window, &managed.items[0], &managed.items[managed.items.len - 1]);
            }
        }
        // Admission focus is resolved only after workspace/focusability rules,
        // so apply focus-sensitive visuals in a second pass using the focus
        // target which Seat.manageFinish() will commit this transaction.
        for (output.windows) |window| {
            const rule = aqueous.rules.resolve(.{
                .app_id = window.app_id,
                .class = window.app_id,
                .title = window.title,
                .tag = window.tag,
                .content_type = window.content_type,
            });
            const focus_opacity: ?f64 = if (aqueous.config.wm.opacity_enabled and aqueous.config.wm.opacity_focus_sensitive)
                (if (cycle_focus == window.handle) aqueous.config.wm.opacity_focused else aqueous.config.wm.opacity_unfocused)
            else
                null;
            aqueous.api.applyRuleVisual(
                window.handle,
                if (rule) |matched| matched.blur else null,
                if (rule) |matched| matched.opacity orelse focus_opacity else focus_opacity,
                if (rule) |matched| matched.hdr_expand else null,
                if (rule) |matched| matched.buffer_scale_policy orelse aqueous.config.wm.buffer_scale_policy else aqueous.config.wm.buffer_scale_policy,
                if (rule) |matched| matched.overlay_plane else .off,
                aqueous.config.wm.force_ssd,
            );
        }
        const entry = try aqueous.layout_states.getOrPut(util.gpa, layout_key);
        if (!entry.found_existing) entry.value_ptr.* = .{};
        const game_state = layout_engine.gameModeState(entry.value_ptr);
        if (game_anchor != null) game_state.rule_layout_owned = true;
        if (game_state.rule_layout_owned) output_layout.default = .game_mode;
        game_state.rule_anchor = if (game_anchor) |anchor| anchor.handle else null;
        if (game_anchor) |anchor| game_state.rule_options = gameOptions(anchor.rule, aqueous.rules.game_mode, output.area, &output_layout);
        if (cycle_focus) |handle| {
            if (containsWindow(focusable.items, handle)) {
                focused_is_focusable = true;
                try aqueous.focus_history.record(workspace_key, handle);
            }
        }
        const focus_valid = if (cycle_focus) |handle| containsWindow(focusable.items, handle) else false;
        if (!focus_valid and !non_window_keyboard_focus and cycle_selected_output_id == output.id) {
            var target = aqueous.focus_history.pick(workspace_key, focusable.items, focusCandidateValid);
            if (target == 0 and focusable.items.len > 0) target = focusable.items[0].handle;
            if (target != 0 and target != aqueous.pending_focus.window) {
                aqueous.pending_focus.setWindow(target, 1);
                // Restoring focus after a workspace switch (or replacing a
                // window which disappeared) is not a user stacking gesture.
                // Keep the workspace's established bottom-to-top order: in
                // particular, do not lift an older focused background above
                // newer floating windows when returning to the workspace.
                aqueous.requestFocusPreservingStack(target);
                cycle_focus = target;
                replacement_focus_requested = true;
            }
        }
        var placements = try layout_engine.arrange(
            util.gpa,
            entry.value_ptr,
            &output_layout,
            usable_area,
            managed.items,
            cycle_focus,
            gameConfigOptions(aqueous.rules.game_mode, &output_layout),
        );
        defer util.gpa.free(placements);
        if (aqueous.completeTiledTransfer(layout_key, entry.value_ptr, managed.items)) {
            const reordered = try layout_engine.arrange(
                util.gpa,
                entry.value_ptr,
                &output_layout,
                usable_area,
                managed.items,
                cycle_focus,
                gameConfigOptions(aqueous.rules.game_mode, &output_layout),
            );
            util.gpa.free(placements);
            placements = reordered;
        }
        if (aqueous.drag) |drag| {
            if (drag.action == .swap_tiled and std.meta.eql(drag.layout_key, layout_key) and
                layout_engine.usesFloatingLayout(entry.value_ptr, drag.handle))
            {
                aqueous.finishInteractiveDrag();
            }
        }
        for (placements) |*placement| {
            if (!placement.tiled) {
                placement.z_order = stacking.floating_band;
                if (!workspace_stack.contains(placement.handle)) new_floats.appendAssumeCapacity(placement.handle);
            }
        }
        try requested.appendSlice(util.gpa, placements);
        for (requested.items) |*placement| {
            if (placement.z_order == stacking.fullscreen_band) continue;
            const window = findLayoutWindow(output.windows, placement.handle) orelse continue;
            const state = aqueous.window_states.get(placement.handle) orelse continue;
            if (state.snap_state != .none) placement.tiled = true;
            placement.z_order = stacking.layeredZ(
                placement.z_order,
                aqueous.effectiveStackLayer(output.windows, window, state.stack_layer),
                stacking.transientDepth(output.windows, window),
            );
        }
        var visible_handles: std.ArrayListUnmanaged(layout_types.Handle) = .empty;
        defer visible_handles.deinit(util.gpa);
        try visible_handles.ensureTotalCapacity(util.gpa, requested.items.len);
        for (requested.items) |placement| {
            if (placement.visible) visible_handles.appendAssumeCapacity(placement.handle);
        }
        try workspace_stack.sync(util.gpa, visible_handles.items);
        raiseFocusedPlacement(workspace_stack, requested.items, aqueous.requested_stack_focus);
        // New freeform presentations open above existing peers even when the
        // same transaction also raises a previously focused window.
        for (new_floats.items) |handle| {
            _ = workspace_stack.raise(handle);
        }
        for (requested.items) |*placement| {
            placement.stack_order = workspace_stack.rank(placement.handle);
        }
        std.mem.sort(layout_types.Placement, requested.items, {}, stacking.lessThan);
        try stacking.orderDialogs(util.gpa, output.windows, requested.items);
        for (requested.items) |*placement| {
            placement.output_scale = output.scale;
            placement.output_origin_x = output.area.x;
            placement.output_origin_y = output.area.y;
            aqueous.api.applyPlacement(
                placement.*,
                cycle_focus == placement.handle,
            );
        }
    }

    // An inactive/removed destination never consumes deferred placement.
    aqueous.pending_tiled_transfer = null;

    // A newly admitted window which cannot appear on any active output (for
    // example, a transient owned by an inactive workspace) must not steal
    // focus when that workspace is visited much later.
    if (pending_new_focus != 0 and !pending_new_focus_seen and snapshot.outputs.len > 0 and
        aqueous.pending_new_focus == pending_new_focus)
    {
        aqueous.pending_new_focus = 0;
    }

    // A closing, minimized, or workspace-removed window may still be the
    // wl_seat focus target. If no active output considers it focusable,
    // explicitly send keyboard leave before it is destroyed.
    if (!focused_is_focusable and !replacement_focus_requested) aqueous.clearFocus();

    var stale: std.ArrayListUnmanaged(LayoutStateKey) = .empty;
    defer stale.deinit(util.gpa);
    var keys = aqueous.layout_states.keyIterator();
    while (keys.next()) |id| {
        var found = false;
        for (snapshot.outputs) |output| {
            if (output.id == id.output) {
                found = true;
                break;
            }
        }
        if (!found) try stale.append(util.gpa, id.*);
    }
    for (stale.items) |id| {
        if (aqueous.layout_states.fetchRemove(id)) |removed| {
            var state = removed.value;
            state.deinit(util.gpa);
        }
        if (aqueous.workspace_stacks.fetchRemove(id)) |removed| {
            var stack = removed.value;
            stack.deinit(util.gpa);
        }
    }
}

/// Apply client-originated fullscreen transitions before layout reconciliation
/// so this manage cycle configures and renders the requested state. Explicit
/// output objects are preferences under xdg-shell; honor usable hints and fall
/// back to the window's current output (then the first usable output).
fn applyClientFullscreenRequests(
    aqueous: *Aqueous,
    snapshot: *CompositorApi.PolicySnapshot,
    requests: []const CompositorApi.ClientFullscreenRequest,
) void {
    for (requests) |request| {
        const state = aqueous.window_states.get(request.handle) orelse continue;
        state.overrideFullscreen();

        switch (request.action) {
            .exit => {
                aqueous.api.clearFullscreen(request.handle);
            },
            .enter => |output_hint| {
                const current_output_id = if (aqueous.api.windowWorkspace(request.handle)) |workspace|
                    workspace.output_id
                else
                    request.current_output_id;
                // A rule owns the composite output/workspace placement. Honor
                // fullscreen itself without letting a client hint relocate it.
                const target = if (state.rule_workspace_owned)
                    findPolicyOutput(snapshot, current_output_id)
                else
                    findPolicyOutput(snapshot, output_hint) orelse
                        findPolicyOutput(snapshot, current_output_id) orelse
                        if (snapshot.outputs.len > 0) &snapshot.outputs[0] else null;
                const output = target orelse continue;

                if (!state.rule_workspace_owned and current_output_id != output.id) {
                    _ = aqueous.api.moveWindowToWorkspace(
                        request.handle,
                        output.id,
                        output.workspace_number,
                    );
                }

                aqueous.api.clearOtherFullscreen(output.id, request.handle);
                _ = aqueous.api.setFullscreen(request.handle, output.id);
            },
        }
    }
}

fn findPolicyOutput(snapshot: *const CompositorApi.PolicySnapshot, id: ?u64) ?*const CompositorApi.PolicyOutput {
    const wanted = id orelse return null;
    for (snapshot.outputs) |*output| if (output.id == wanted) return output;
    return null;
}

/// Client-side decorations and foreign-toplevel controllers feed the same
/// one-shot request stream. Direct move/resize/maximize/minimize requests
/// remain constrained to floating presentations, while activation can restore
/// and focus any managed window.
fn applyClientWindowRequests(
    aqueous: *Aqueous,
    snapshot: *const CompositorApi.PolicySnapshot,
    requests: []const CompositorApi.ClientWindowRequest,
) bool {
    var snapshot_dirty = false;
    for (requests) |request| switch (request.action) {
        .move => |pointer| aqueous.startClientPointerDrag(
            request.handle,
            pointer,
            .move_floating,
            .{},
        ),
        .resize => |resize| {
            const edges: pointer_drag.ResizeEdges = .{
                .top = resize.edges.top,
                .bottom = resize.edges.bottom,
                .left = resize.edges.left,
                .right = resize.edges.right,
            };
            if (edges.any()) aqueous.startClientPointerDrag(
                request.handle,
                resize.pointer,
                .resize_floating,
                edges,
            );
        },
        .maximize => {
            aqueous.finishInteractiveDragFor(request.handle);
            _ = aqueous.window_states.setClientMaximized(
                request.handle,
                true,
                aqueous.clientWindowUsesFloatingLayout(request.handle),
            );
        },
        .unmaximize => {
            aqueous.finishInteractiveDragFor(request.handle);
            _ = aqueous.window_states.setClientMaximized(
                request.handle,
                false,
                aqueous.clientWindowUsesFloatingLayout(request.handle),
            );
        },
        .minimize => {
            aqueous.finishInteractiveDragFor(request.handle);
            _ = aqueous.window_states.setClientMinimized(
                request.handle,
                true,
                aqueous.clientWindowUsesFloatingLayout(request.handle),
            ) catch {
                log.err("out of memory recording client minimize request", .{});
            };
        },
        .unminimize => {
            _ = aqueous.window_states.setClientMinimized(
                request.handle,
                false,
                aqueous.clientWindowUsesFloatingLayout(request.handle),
            ) catch unreachable;
        },
        .activate => {
            snapshot_dirty = aqueous.activateClientWindow(snapshot, request.handle, null) or snapshot_dirty;
        },
    };
    return snapshot_dirty;
}

/// A foreign-toplevel activation is the compositor-side equivalent of clicking
/// a dock/taskbar item: reveal its workspace, restore it if minimized, then
/// raise and focus it.
pub fn activateShellWindow(aqueous: *Aqueous, handle: layout_types.Handle, seat: []const u8) bool {
    var snapshot = aqueous.api.policySnapshot(util.gpa) catch return false;
    defer snapshot.deinit(util.gpa);
    return aqueous.activateClientWindow(&snapshot, handle, seat);
}

fn activateClientWindow(
    aqueous: *Aqueous,
    snapshot: *const CompositorApi.PolicySnapshot,
    handle: layout_types.Handle,
    seat: ?[]const u8,
) bool {
    _ = aqueous.window_states.get(handle) orelse return false;
    const workspace = aqueous.api.windowWorkspace(handle) orelse return false;

    aqueous.finishInteractiveDragFor(handle);
    _ = aqueous.window_states.restore(handle);

    if (findPolicyOutput(snapshot, workspace.output_id)) |output| {
        if (output.workspace_number != workspace.workspace_number) {
            aqueous.previous_workspaces.put(
                util.gpa,
                workspace.output_id,
                output.workspace_number,
            ) catch log.err("out of memory recording previous workspace for dock activation", .{});
        }
    }

    if (!aqueous.api.selectOutputOnSeat(workspace.output_id, seat)) return false;
    if (!aqueous.api.activateWorkspace(workspace.output_id, workspace.workspace_number)) return false;
    if (seat) |_| {
        aqueous.cancelHoverFocus();
        aqueous.api.requestFocusOnSeat(handle, seat);
        aqueous.requestFocusRaise(handle);
    } else aqueous.requestFocus(handle);
    return true;
}

pub fn clientResizeAllowed(aqueous: *Aqueous, handle: layout_types.Handle) bool {
    if (aqueous.api.windowIsFullscreen(handle)) return false;
    const state = aqueous.window_states.get(handle) orelse return true;
    return pointer_drag.clientResizeAllowed(state.kind(), state.fixed_position, aqueous.clientWindowUsesFloatingLayout(handle));
}

fn startClientPointerDrag(
    aqueous: *Aqueous,
    handle: layout_types.Handle,
    pointer: CompositorApi.ClientPointer,
    action: pointer_drag.Action,
    edges: pointer_drag.ResizeEdges,
) void {
    aqueous.drag = aqueous.createClientDrag(handle, pointer, action, edges, true) orelse return;
}

pub fn createClientDrag(
    aqueous: *Aqueous,
    handle: layout_types.Handle,
    pointer: CompositorApi.ClientPointer,
    action: pointer_drag.Action,
    edges: pointer_drag.ResizeEdges,
    owns_grab: bool,
) ?Drag {
    const previous_cause = aqueous.focus_cause;
    aqueous.focus_cause = .pointer;
    defer aqueous.focus_cause = previous_cause;
    if (!aqueous.mode.runsInternal() or aqueous.drag != null) return null;
    if (aqueous.api.windowIsFullscreen(handle)) return null;
    var seats = server.input_manager.seats.iterator(.forward);
    while (seats.next()) |seat| {
        if (seat.toplevel_drag.movement) |move| if (move.handle == handle) return null;
    }
    if (action == .resize_floating and !aqueous.clientResizeAllowed(handle)) return null;
    const state = aqueous.window_states.get(handle) orelse return null;
    if (state.fixed_position) return null;
    const window_rect = aqueous.api.windowGeometry(handle) orelse return null;
    const workspace = aqueous.api.windowWorkspace(handle) orelse return null;
    const layout_key: LayoutStateKey = .{
        .output = workspace.output_id,
        .workspace = workspace.workspace_number,
    };
    const uses_floating_layout = aqueous.windowUsesFloatingLayout(layout_key, handle);
    var layout_floating = state.kind() == .tiled and uses_floating_layout;
    var drag_start = window_rect;

    if (state.kind() == .maximized) {
        if (action != .move_floating) return null;
        const restored_kind = aqueous.window_states.maximizedMoveRestoreKind(
            handle,
            uses_floating_layout,
        ) orelse return null;
        layout_floating = restored_kind == .tiled;
        const normal = if (layout_floating) blk: {
            const layout_state = aqueous.layout_states.getPtr(layout_key) orelse return null;
            break :blk layout_engine.floatingGeometry(layout_state, handle) orelse return null;
        } else state.floating_geometry;
        if (normal.width <= 0 or normal.height <= 0) return null;
        drag_start = pointer_drag.restoredMoveStart(
            window_rect,
            normal,
            pointer.x,
            pointer.y,
        );
    } else if (state.kind() != .floating and !layout_floating) {
        log.debug("client pointer drag rejected handle={} kind={s} floating_layout={}", .{ handle, @tagName(state.kind()), uses_floating_layout });
        return null;
    }
    if (state.snap_state != .none and state.snap_restore_geometry.width > 0 and state.snap_restore_geometry.height > 0) {
        drag_start = if (action == .move_floating)
            pointer_drag.restoredMoveStart(window_rect, state.snap_restore_geometry, pointer.x, pointer.y)
        else
            state.snap_restore_geometry;
        state.snap_state = .none;
        state.custom_snap_zone = std.math.maxInt(u8);
        if (!aqueous.storeFreeformGeometry(layout_key, handle, state, layout_floating, drag_start)) return null;
    }
    if (owns_grab and !aqueous.api.beginClientPointerOperation(pointer.seat)) return null;

    if (state.kind() == .maximized) {
        if (layout_floating) {
            const layout_state = aqueous.layout_states.getPtr(layout_key) orelse {
                if (owns_grab) aqueous.api.endClientPointerOperation(pointer.seat);
                return null;
            };
            layout_engine.setFloatingGeometry(util.gpa, layout_state, handle, drag_start) catch {
                log.err("out of memory restoring floating-layout geometry for titlebar move", .{});
                if (owns_grab) aqueous.api.endClientPointerOperation(pointer.seat);
                return null;
            };
        } else {
            state.floating_geometry = drag_start;
        }
        _ = aqueous.window_states.restoreMaximizedForMove(
            handle,
            layout_floating,
        ) orelse {
            if (owns_grab) aqueous.api.endClientPointerOperation(pointer.seat);
            return null;
        };
    }

    const result: Drag = .{
        .handle = handle,
        .start = drag_start,
        .pointer_x = pointer.x,
        .pointer_y = pointer.y,
        .last_pointer_x = pointer.x,
        .last_pointer_y = pointer.y,
        .action = action,
        .layout_key = layout_key,
        .resize_edges = edges,
        .constraints = aqueous.api.windowConstraints(handle),
        .client_seat = if (owns_grab) pointer.seat else null,
        .dnd = !owns_grab,
        .layout_floating = layout_floating,
    };
    log.debug("client pointer drag started handle={} action={s} stacking_owned={}", .{ handle, @tagName(action), layout_floating });
    aqueous.api.beginInteractive(handle, action == .resize_floating);
    if (owns_grab) aqueous.requestFocus(handle);
    return result;
}

pub fn clientDragEligible(aqueous: *Aqueous, drag: Drag) bool {
    const state = aqueous.window_states.get(drag.handle) orelse return false;
    return !state.fixed_position and !aqueous.api.windowIsFullscreen(drag.handle) and
        (state.kind() == .floating or (drag.layout_floating and state.kind() == .tiled and
            aqueous.windowUsesFloatingLayout(drag.layout_key, drag.handle)));
}

fn finishInteractiveDragFor(aqueous: *Aqueous, handle: layout_types.Handle) void {
    var seats = server.input_manager.seats.iterator(.forward);
    while (seats.next()) |seat| seat.toplevel_drag.stopWindow(handle);
    if (aqueous.drag) |drag| if (drag.handle == handle) aqueous.finishInteractiveDrag();
}

fn finishInvalidInteractiveDrag(
    aqueous: *Aqueous,
    snapshot: *const CompositorApi.PolicySnapshot,
) bool {
    const drag = aqueous.drag orelse return false;
    if (findPolicyOutput(snapshot, drag.layout_key.output)) |source| {
        if (source.workspace_number == drag.layout_key.workspace) {
            for (source.windows) |window| {
                if (window.handle != drag.handle) continue;
                const state = aqueous.window_states.get(drag.handle) orelse break;
                const layout_floating = drag.layout_floating and
                    state.kind() == .tiled and
                    aqueous.windowUsesFloatingLayout(drag.layout_key, drag.handle);
                if ((drag.action == .swap_tiled and
                    pointer_drag.tiledMoveAllowed(state.kind(), state.fixed_position, window.fullscreen)) or
                    (drag.action == .resize_scrolling and
                        state.kind() == .tiled and
                        !window.fullscreen and
                        if (aqueous.layout_states.get(drag.layout_key)) |layout_state|
                            layout_engine.canResizeScrolling(&layout_state, drag.handle)
                        else
                            false) or
                    ((state.kind() == .floating or layout_floating) and !window.fullscreen))
                {
                    return false;
                }
                break;
            }
        }
        aqueous.finishInteractiveDrag();
        return false;
    }

    const recovered = if (drag.action == .move_floating or drag.action == .resize_floating)
        aqueous.recoverRemovedOutputDrag(drag)
    else
        false;
    aqueous.finishInteractiveDrag();
    return recovered;
}

fn recoverRemovedOutputDrag(aqueous: *Aqueous, drag: Drag) bool {
    const previous_cause = aqueous.focus_cause;
    aqueous.focus_cause = .pointer;
    defer aqueous.focus_cause = previous_cause;
    const state = aqueous.window_states.get(drag.handle) orelse return false;
    if (state.kind() != .floating) return false;
    const target = aqueous.api.outputTargetAt(drag.last_pointer_x, drag.last_pointer_y, true) orelse {
        state.needs_output_recovery = true;
        return false;
    };
    const usable_area = aqueous.effectiveUsableArea(target.area, target.usable_area);
    const recovered_rect = output_transfer.recoverGeometry(state.floating_geometry, usable_area);
    if (!aqueous.api.moveWindowToWorkspace(drag.handle, target.id, target.workspace_number)) {
        state.needs_output_recovery = true;
        return false;
    }

    state.overrideWorkspace();
    state.floating_geometry = recovered_rect;
    state.needs_output_recovery = false;
    _ = aqueous.api.selectOutput(target.id);
    aqueous.requestFocus(drag.handle);
    log.info("recovered floating drag on output {} workspace {}", .{ target.id, target.workspace_number });
    return true;
}

/// Apply the compositor's established parent-based popup heuristic on the
/// null -> parent edge. xdg_toplevel parents and X11 WM_TRANSIENT_FOR both
/// arrive through this field, covering native dialogs and Xwayland dialogs
/// without application-specific rules.
fn reconcileTransientParents(aqueous: *Aqueous, snapshot: *const CompositorApi.PolicySnapshot) bool {
    var changed = false;
    for (snapshot.outputs) |output| {
        const usable_area = aqueous.effectiveUsableArea(output.area, output.usable_area);
        for (output.windows) |window| {
            if (aqueous.reconcileTransientParent(window, usable_area)) changed = true;
        }
    }
    return changed;
}

fn reconcileTransientParent(aqueous: *Aqueous, window: layout_types.Window, usable_area: layout_types.Rect) bool {
    const state = aqueous.window_states.get(window.handle) orelse return false;
    if (!transient.placementPending(state, window.parent)) return false;
    const parent = window.parent.?;

    const before = aqueous.api.windowWorkspace(window.handle);
    aqueous.api.moveToParentWorkspace(window.handle);
    const parent_geometry = aqueous.api.windowGeometry(parent) orelse usable_area;
    const resolved = transient.geometry(
        usable_area,
        parent_geometry,
        window.preferred_width,
        window.preferred_height,
        geometry.Constraints.fromWindow(window),
    ) orelse {
        if (!transient.waitingForNaturalSize(state, window.parent)) {
            if (aqueous.window_states.setAutomaticFloating(window.handle, .empty) and
                aqueous.api.requestNaturalSize(window.handle))
            {
                transient.deferForNaturalSize(state, parent);
            } else {
                // Preserve edge-triggered behavior when an overlay or explicit
                // floating state has precedence over this heuristic.
                transient.finishPlacement(state, parent);
            }
        }
        const after = aqueous.api.windowWorkspace(window.handle);
        return !sameWorkspace(before, after);
    };
    if (transient.waitingForNaturalSize(state, window.parent)) {
        state.floating_geometry = resolved;
    } else {
        _ = aqueous.window_states.setAutomaticFloating(window.handle, resolved);
    }
    // The edge is complete even when a higher-priority overlay rejected the
    // automatic floating transition; do not reassert it every manage cycle.
    transient.finishPlacement(state, parent);
    const after = aqueous.api.windowWorkspace(window.handle);
    return !sameWorkspace(before, after);
}

/// Drop policy state before the compositor invalidates a stable window handle.
pub fn forgetWindow(aqueous: *Aqueous, handle: layout_types.Handle) void {
    if (aqueous.pending_tiled_transfer) |*pending| {
        if (pending.handle == handle) {
            aqueous.pending_tiled_transfer = null;
        } else if (pending.target == handle) {
            pending.target = null;
        }
    }
    if (!aqueous.started) return;
    var close_overview = false;
    if (aqueous.overview) |*overview| {
        if (overview_model.remove(overview, handle)) {
            aqueous.api.removeOverviewWindow(handle);
            if (overview.cards.items.len == 0) {
                close_overview = true;
            } else {
                serverShellDirty();
                aqueous.api.updateOverviewSelection(overview.selected);
            }
        }
    }
    if (close_overview) aqueous.cancelOverview();
    aqueous.finishInteractiveDragFor(handle);
    var layouts = aqueous.layout_states.valueIterator();
    while (layouts.next()) |state| layout_engine.forgetWindow(state, handle);
    var stacks = aqueous.workspace_stacks.valueIterator();
    while (stacks.next()) |stack| stack.remove(handle);
    aqueous.window_states.remove(handle);
    if (aqueous.last_scrolling_click) |click| {
        if (click.handle == handle) aqueous.last_scrolling_click = null;
    }
    if (aqueous.pending_focus.window == handle) aqueous.pending_focus.clear();
    if (aqueous.pending_new_focus == handle) aqueous.pending_new_focus = 0;
    if (aqueous.pending_raise == handle) aqueous.cancelPendingRaise();
}

/// Record a newly admitted normal toplevel for the integrated focus policy.
/// Native windows call this before their initial configure; XWayland calls it
/// once the associated surface and ICCCM focus hint are available.
pub fn noteWindowAdmission(aqueous: *Aqueous, handle: layout_types.Handle) void {
    aqueous.cancelOverview();
    if (!aqueous.mode.runsInternal() or !aqueous.config.wm.input.focus_new_windows) return;
    aqueous.pending_new_focus = handle;
}

/// Input events may be coalesced while an integrated-policy pointer operation
/// is active. Tiled swapping is intentionally excluded because every crossed
/// window is semantically meaningful there.
pub fn interactiveDragActive(aqueous: *const Aqueous) bool {
    const drag = aqueous.drag orelse return false;
    return drag.action != .swap_tiled;
}

pub fn cancelSnapPreview(aqueous: *Aqueous) void {
    if (aqueous.drag) |*drag| drag.snap_candidate = null;
    aqueous.api.hideSnapOverlay();
}

fn finishInteractiveDrag(aqueous: *Aqueous) void {
    const drag = aqueous.drag orelse return;
    aqueous.drag = null;
    aqueous.finishDrag(drag);
}

pub fn finishDrag(aqueous: *Aqueous, drag: Drag) void {
    if (!drag.dnd) aqueous.api.hideSnapOverlay();
    if (drag.snap_candidate) |candidate| {
        if (drag.layout_floating and aqueous.layoutIsFloating(drag.layout_key) and
            candidate.output_id == drag.layout_key.output)
        {
            if (aqueous.window_states.get(drag.handle) != null) {
                const committed = if (aqueous.layout_states.getPtr(drag.layout_key)) |layout_state| commit: {
                    layout_engine.setFloatingGeometry(util.gpa, layout_state, drag.handle, candidate.geometry) catch {
                        log.err("out of memory committing stacking snap zone", .{});
                        break :commit false;
                    };
                    break :commit true;
                } else false;
                if (committed) if (aqueous.window_states.get(drag.handle)) |state| {
                    if (state.snap_state == .none and drag.start.width > 0 and drag.start.height > 0) {
                        state.snap_restore_geometry = drag.start;
                    }
                    state.snap_state = .center;
                    state.custom_snap_zone = candidate.zone_index;
                    state.snap_layout_id = candidate.layout_id;
                    state.snap_zone_id = candidate.zone_id;
                };
                if (committed) {
                    aqueous.api.requestManageCycle();
                }
            }
        }
    }
    if (drag.action != .swap_tiled) aqueous.api.endInteractive(drag.handle);
    if (drag.client_seat) |seat| aqueous.api.endClientPointerOperation(seat);
}

fn keyBindingVerb(aqueous: *Aqueous, keysym: u32, modifiers: u32) ?[]const u8 {
    if (!aqueous.mode.runsInternal()) return null;
    const verb = aqueous.config.actions.find(keysym, modifiers & (1 | 4 | 8 | 64)) orelse return null;
    if (server.input_manager.defaultSeat().xwaylandKeyboardGrabActive() and
        !std.mem.eql(u8, verb, "builtin:untrap_pointer"))
    {
        return null;
    }
    return verb;
}

/// Report whether a press would be consumed by the direct compositor key path
/// without running its action. The keyboard group uses this to keep a bound
/// Caps Lock key from changing the XKB lock state before handleKey sees it.
pub fn hasKeyBinding(aqueous: *Aqueous, keysym: u32, modifiers: u32) bool {
    return aqueous.keyBindingVerb(keysym, modifiers) != null;
}

/// Direct compositor key path. Returning true eats the event before it reaches a client.
pub fn handleKey(aqueous: *Aqueous, keysym: u32, modifiers: u32, pressed: bool) bool {
    const switcher = &@import("../main.zig").server.window_switcher;
    if (switcher.output != null and pressed) {
        if (keysym == 0xff1b) {
            switcher.finish();
            return true;
        }
        const binding = aqueous.keyBindingVerb(keysym, modifiers) orelse "";
        // Modifier transitions alone do not end presentation.
        if (!(keysym >= 0xffe1 and keysym <= 0xffee) and !std.mem.startsWith(u8, binding, "builtin:window_switcher_")) switcher.finish();
    }
    if (aqueous.overview != null) return aqueous.handleOverviewKey(keysym, modifiers, pressed);
    if (!pressed and aqueous.untrap_keysym == keysym) {
        aqueous.untrap_keysym = null;
        aqueous.api.suppressPointerConstraints(false);
        return true;
    }
    const verb = aqueous.keyBindingVerb(keysym, modifiers) orelse return false;
    if (std.mem.eql(u8, verb, "builtin:untrap_pointer")) {
        aqueous.untrap_keysym = if (pressed) keysym else null;
        aqueous.api.suppressPointerConstraints(pressed);
        return true;
    }
    if (pressed) {
        log.debug("key binding keysym=0x{x} modifiers=0x{x} verb={s}", .{ keysym, modifiers & (1 | 4 | 8 | 64), verb });
        aqueous.runVerb(verb);
    }
    return true;
}

pub fn wantsGesture(aqueous: *const Aqueous, kind: action_config.GestureKind, fingers: u32) bool {
    if (!aqueous.mode.runsInternal() or fingers > std.math.maxInt(u8)) return false;
    return aqueous.config.actions.hasGesture(kind, @intCast(fingers));
}

pub fn handleGesture(aqueous: *Aqueous, gesture: gesture_input.Completed) void {
    if (!aqueous.mode.runsInternal()) return;
    const verb = aqueous.config.actions.findGesture(gesture.kind, gesture.direction, gesture.fingers) orelse return;
    aqueous.runVerb(verb);
}

pub fn wheelBindingVerb(aqueous: *Aqueous, seat: *Seat, direction: wheel_input.Direction, modifiers: u32) ?[]const u8 {
    if (!aqueous.mode.runsInternal() or
        server.lock_manager.state != .unlocked or
        aqueous.overview != null or aqueous.drag != null or
        seat.xwaylandKeyboardGrabActive() or server.shortcuts.active(seat.wlr_seat)) return null;
    const verb = aqueous.config.actions.findWheel(direction, modifiers & (1 | 4 | 8 | 64)) orelse return null;
    if (wheel_input.navigationForVerb(verb)) |navigation| {
        _ = aqueous.wheelNavigationAxis(navigation.axis) orelse return null;
    }
    return verb;
}

pub fn handleWheel(aqueous: *Aqueous, seat: *Seat, direction: wheel_input.Direction, modifiers: u32, count: u32) void {
    const previous_cause = aqueous.focus_cause;
    // Bound wheel actions navigate focus like keyboard bindings. Hover and
    // clicks still retain pointer-originated focus without an automatic warp.
    aqueous.focus_cause = .non_pointer;
    defer aqueous.focus_cause = previous_cause;
    const verb = aqueous.wheelBindingVerb(seat, direction, modifiers) orelse return;
    if (wheel_input.navigationForVerb(verb)) |navigation| {
        const axis = aqueous.wheelNavigationAxis(navigation.axis) orelse return;
        _ = aqueous.navigateWithWheel(axis, navigation.steps * @as(i32, @intCast(@min(count, std.math.maxInt(i32)))));
        return;
    }
    // An action can replace the configuration containing its own verb. Copy it
    // before dispatch, and stop this burst if it changes bindings or input mode.
    var action: action_config.Binding = .{};
    if (!action.verb.set(verb)) return;
    // Keep extreme continuous deltas from launching an unbounded action burst.
    for (0..@min(count, 32)) |_| {
        const current = aqueous.wheelBindingVerb(seat, direction, modifiers) orelse break;
        if (!std.mem.eql(u8, current, action.verb.slice())) break;
        aqueous.runVerb(action.verb.slice());
    }
}

fn wheelNavigationAxis(aqueous: *Aqueous, axis: wheel_input.NavigationAxis) ?wheel_input.NavigationAxis {
    const context = aqueous.api.focusedContext() orelse return null;
    if (context.window.policy_state.kind() != .tiled) return null;
    const state = aqueous.layout_states.getPtr(.{
        .output = context.output.policyId(),
        .workspace = context.workspace_number,
    }) orelse return null;
    const handle: layout_types.Handle = @bitCast(context.window.ref);
    if (!layout_engine.supportsViewportScroll(state, handle)) return null;
    return wheel_input.applyLayoutPreference(axis, layout_engine.prefersVerticalScroll(state, handle));
}

pub fn navigateWithWheel(aqueous: *Aqueous, axis: wheel_input.NavigationAxis, steps: i32) bool {
    if (steps == 0) return false;
    return switch (axis) {
        .horizontal => aqueous.scrollViewport(steps, 0),
        .vertical => aqueous.scrollViewport(0, steps),
    };
}

pub fn handlePointerButton(aqueous: *Aqueous, button: u32, modifiers: u32, pressed: bool, x: f64, y: f64, time_msec: u32) bool {
    const previous_cause = aqueous.focus_cause;
    aqueous.focus_cause = .pointer;
    defer aqueous.focus_cause = previous_cause;
    if (!aqueous.mode.runsInternal()) return false;
    if (aqueous.overview != null) {
        if (button == 0x110 and pressed) { // BTN_LEFT
            if (aqueous.updateOverviewHover(x, y)) aqueous.confirmOverview();
        }
        return true;
    }
    if (pressed and (button != 0x110 or
        modifiers & (1 | 4 | 8 | 64) != aqueous.config.actions.primary_modifier))
    {
        aqueous.last_scrolling_click = null;
    }
    if (!pressed and aqueous.drag != null) {
        const drag = aqueous.drag.?;
        const scrolling_click = button == 0x110 and
            drag.action == .swap_tiled and
            drag.click_eligible and
            pointer_drag.stayedClick(drag.pointer_x, drag.pointer_y, drag.last_pointer_x, drag.last_pointer_y);
        aqueous.finishInteractiveDrag();
        if (scrolling_click) {
            aqueous.handleScrollingClick(drag, time_msec);
        } else {
            aqueous.last_scrolling_click = null;
        }
        return true;
    }
    if (modifiers & (1 | 4 | 8 | 64) != aqueous.config.actions.primary_modifier) return false;
    if (button != 0x110 and button != 0x111) return false; // BTN_LEFT / BTN_RIGHT
    if (!pressed) {
        aqueous.drag = null;
        return true;
    }
    const target = aqueous.api.windowAt(x, y) orelse return false;
    var drag_seats = server.input_manager.seats.iterator(.forward);
    while (drag_seats.next()) |seat| {
        if (seat.toplevel_drag.movement) |movement| if (movement.handle == target.handle) return false;
    }
    const state = aqueous.window_states.get(target.handle) orelse return false;
    if (state.fixed_position) return false;
    const workspace = aqueous.api.windowWorkspace(target.handle) orelse return false;
    const layout_key: LayoutStateKey = .{ .output = workspace.output_id, .workspace = workspace.workspace_number };
    const layout_state = aqueous.layout_states.getPtr(layout_key);
    const active_layout = if (layout_state) |value| value.active_layout else aqueous.config.layout.default;
    if (button == 0x111 and state.kind() == .tiled and if (layout_state) |value|
        layout_engine.isGameAnchor(value, target.handle)
    else
        false)
    {
        aqueous.requestFocus(target.handle);
        return true;
    }
    const scrolling_resizable = state.kind() == .tiled and if (layout_state) |value|
        layout_engine.canResizeScrolling(value, target.handle)
    else
        false;
    const layout_floating = state.kind() == .tiled and if (layout_state) |value|
        layout_engine.usesFloatingLayout(value, target.handle)
    else
        active_layout == .floating;
    const drag_action = pointer_drag.action(button, state.kind(), layout_floating, scrolling_resizable);
    if (drag_action == .swap_tiled and
        !pointer_drag.tiledMoveAllowed(state.kind(), state.fixed_position, aqueous.api.windowIsFullscreen(target.handle))) return false;
    var drag_geometry = target.geometry;
    if ((drag_action == .move_floating or drag_action == .resize_floating) and
        state.snap_state != .none and
        state.snap_restore_geometry.width > 0 and state.snap_restore_geometry.height > 0)
    {
        drag_geometry = if (drag_action == .move_floating)
            pointer_drag.restoredMoveStart(target.geometry, state.snap_restore_geometry, x, y)
        else
            state.snap_restore_geometry;
        state.snap_state = .none;
        state.custom_snap_zone = std.math.maxInt(u8);
        if (!aqueous.storeFreeformGeometry(layout_key, target.handle, state, layout_floating, drag_geometry)) return false;
    }
    if (drag_action == .swap_tiled) {
        aqueous.drag = .{
            .handle = target.handle,
            .start = drag_geometry,
            .pointer_x = x,
            .pointer_y = y,
            .last_pointer_x = x,
            .last_pointer_y = y,
            .action = drag_action,
            .layout_key = layout_key,
            .layout_floating = false,
            .constraints = aqueous.api.windowConstraints(target.handle),
        };
    } else {
        aqueous.drag = .{
            .handle = target.handle,
            .start = drag_geometry,
            .pointer_x = x,
            .pointer_y = y,
            .last_pointer_x = x,
            .last_pointer_y = y,
            .action = drag_action,
            .layout_key = layout_key,
            .layout_floating = layout_floating,
            .constraints = aqueous.api.windowConstraints(target.handle),
        };
        if (!layout_floating and drag_action != .resize_scrolling) {
            _ = aqueous.window_states.setFloating(target.handle, drag_geometry);
        }
        aqueous.api.beginInteractive(
            target.handle,
            drag_action == .resize_floating or drag_action == .resize_scrolling,
        );
    }
    aqueous.requestFocus(target.handle);
    return true;
}

fn handleScrollingClick(aqueous: *Aqueous, drag: Drag, time_msec: u32) void {
    const layout_state = aqueous.layout_states.getPtr(drag.layout_key) orelse {
        aqueous.last_scrolling_click = null;
        return;
    };
    if (!layout_engine.canResizeScrolling(layout_state, drag.handle)) {
        aqueous.last_scrolling_click = null;
        return;
    }
    const previous = aqueous.last_scrolling_click;
    if (previous == null or
        previous.?.handle != drag.handle or
        !pointer_drag.withinDoubleClick(previous.?.time_msec, time_msec))
    {
        aqueous.last_scrolling_click = .{ .handle = drag.handle, .time_msec = time_msec };
        return;
    }

    var changed = false;
    if (layout_engine.scrollingColumnMembers(layout_state, drag.handle)) |members| {
        for (members) |handle| {
            const state = aqueous.window_states.get(handle) orelse continue;
            state.overrideScrollingFullWidth();
            changed = state.scrolling_width != null or changed;
            state.overrideScrollingWidth();
            if (!state.scrolling_full_width) continue;
            state.scrolling_full_width = false;
            changed = true;
        }
    }
    changed = layout_engine.resetScrollingSize(layout_state, drag.handle) or changed;
    aqueous.last_scrolling_click = null;
    if (changed) aqueous.api.requestManageCycle();
}

pub fn handleHover(aqueous: *Aqueous, handle: ?layout_types.Handle) void {
    if (@import("../main.zig").server.window_switcher.output != null) {
        aqueous.cancelHoverFocus();
        return;
    }
    const previous_cause = aqueous.focus_cause;
    aqueous.focus_cause = .pointer;
    defer aqueous.focus_cause = previous_cause;
    if (!aqueous.mode.runsInternal() or !aqueous.config.wm.input.focus_follows_mouse) {
        aqueous.cancelHoverFocus();
        return;
    }

    const delay_ms = aqueous.config.layout.scrolling_focus_follows_mouse_delay_ms;
    const delayed = if (handle) |target|
        aqueous.hover_focus_timer != null and aqueous.scrollingHoverDelayApplies(target)
    else
        false;
    const action = aqueous.hover_focus.hover(
        handle,
        aqueous.api.focusedWindow(),
        delayed,
        delay_ms,
        aqueous.api.clientDragActive(),
    );
    switch (action) {
        .none => {},
        .disarm => aqueous.disarmHoverFocusTimer(),
        .immediate => |target| aqueous.requestFocus(target),
        .arm => |milliseconds| {
            const timer = aqueous.hover_focus_timer orelse unreachable;
            timer.timerUpdate(milliseconds) catch {
                log.warn("unable to arm scrolling pointer-focus delay; focusing immediately", .{});
                const target = aqueous.hover_focus.pending orelse return;
                _ = aqueous.hover_focus.cancel();
                aqueous.requestFocus(target);
            };
        },
    }
}

/// Cancel any dwell request which predates a client-side drag. wlroots installs
/// a keyboard grab for the drag and ignores keyboard-enter requests until that
/// grab is destroyed.
pub fn handleClientDragStarted(aqueous: *Aqueous) void {
    aqueous.cancelHoverFocus();
}

/// Focus and, when configured, raise a window after an explicit, unmodified
/// pointer interaction. The compositor historically forwarded this only
/// through aqueous_seat_v1, so the
/// integrated policy silently discarded click-to-focus when focus-follows-mouse
/// was disabled. Xwayland games can then receive pointer input while keyboard
/// events continue going to the previously focused client.
pub fn handleWindowInteraction(aqueous: *Aqueous, handle: layout_types.Handle) void {
    const previous_cause = aqueous.focus_cause;
    aqueous.focus_cause = .pointer;
    defer aqueous.focus_cause = previous_cause;
    if (!aqueous.mode.runsInternal()) return;
    aqueous.cancelHoverFocus();
    const state = aqueous.window_states.get(handle) orelse return;
    if (state.kind() == .minimized) return;
    if (aqueous.api.focusedWindow() != handle) {
        aqueous.requestFocus(handle);
    } else {
        // A focused window can still be below a newer peer when admission
        // focus is disabled. An explicit click must remain a raise gesture
        // even though it does not need another keyboard-focus request.
        aqueous.requestFocusRaise(handle);
    }
}

pub fn handlePointerMotion(aqueous: *Aqueous, x: f64, y: f64) void {
    if (aqueous.overview != null) {
        _ = aqueous.updateOverviewHover(x, y);
        return;
    }
    if (aqueous.drag) |*drag| aqueous.updateInteractiveDrag(drag, x, y);
}

pub fn updateInteractiveDrag(aqueous: *Aqueous, drag: *Drag, x: f64, y: f64) void {
    drag.last_pointer_x = x;
    drag.last_pointer_y = y;
    if (drag.action == .swap_tiled) {
        const state = aqueous.window_states.get(drag.handle) orelse return;
        if (!pointer_drag.tiledMoveAllowed(state.kind(), state.fixed_position, aqueous.api.windowIsFullscreen(drag.handle))) return;
        if (!aqueous.api.windowOnWorkspace(drag.handle, drag.layout_key.output, drag.layout_key.workspace)) return;
        if (!pointer_drag.stayedClick(drag.pointer_x, drag.pointer_y, x, y)) {
            drag.click_eligible = false;
        }
        // Resolve output ownership even over empty space or while the previous
        // output's layout/scene is still catching up with a reorder.
        if (aqueous.transferTiledDrag(drag, x, y)) return;
        if (aqueous.pending_tiled_transfer != null) return;
        const target = aqueous.api.windowAt(x, y) orelse return;
        if (drag.awaiting_layout != null) {
            // Do not swap back while the scene still exposes the old geometry.
            // Re-arm once a manage cycle has moved the dragged window beneath
            // the pointer.
            if (target.handle == drag.handle) drag.awaiting_layout = null;
            return;
        }
        if (target.handle == drag.handle) return;
        const target_state = aqueous.window_states.get(target.handle) orelse return;
        if (target_state.kind() != .tiled) return;
        if (!aqueous.api.windowOnWorkspace(target.handle, drag.layout_key.output, drag.layout_key.workspace)) return;
        const layout_state = aqueous.layout_states.getPtr(drag.layout_key) orelse return;
        const zone = pointer_drag.dropZone(target.geometry, x, y);
        if (!(layout_engine.drop(util.gpa, layout_state, drag.handle, target.handle, zone) catch {
            log.err("out of memory updating pointer drop target", .{});
            return;
        })) return;
        drag.click_eligible = false;
        drag.awaiting_layout = target.handle;
        aqueous.api.requestManageCycle();
        return;
    }
    const dx: i32 = @intFromFloat(x - drag.pointer_x);
    const dy: i32 = @intFromFloat(y - drag.pointer_y);
    if (drag.action == .resize_scrolling) {
        drag.resize_axis = pointer_drag.selectResizeAxis(drag.resize_axis, dx, dy);
        const axis = drag.resize_axis orelse return;
        const layout_state = aqueous.layout_states.getPtr(drag.layout_key) orelse return;
        var cleared_expanded = false;
        if (axis == .horizontal) {
            // Every member can own a preset. Release them together when the
            // pointer actually changes the column width, so another matching
            // member cannot immediately expand the manually resized column.
            if (layout_engine.scrollingColumnMembers(layout_state, drag.handle)) |members| {
                for (members) |handle| {
                    const member_state = aqueous.window_states.get(handle) orelse continue;
                    member_state.overrideScrollingFullWidth();
                    cleared_expanded = member_state.scrolling_width != null or cleared_expanded;
                    member_state.overrideScrollingWidth();
                    cleared_expanded = member_state.scrolling_full_width or cleared_expanded;
                    member_state.scrolling_full_width = false;
                }
            }
        }
        const resize_edges = pointer_drag.edgesForAxis(drag.resize_edges, axis);
        const resized_rect = pointer_drag.resizeConstrained(drag.start, dx, dy, resize_edges, drag.constraints);
        const update: layout_types.ResizeUpdate = switch (axis) {
            .horizontal => .{ .width = resized_rect.width },
            .vertical => .{ .height = resized_rect.height },
        };
        const resized = layout_engine.resizeScrolling(
            util.gpa,
            layout_state,
            drag.handle,
            update,
        ) catch {
            log.err("out of memory resizing scrolling member", .{});
            return;
        };
        if (!resized and !cleared_expanded) return;
        aqueous.api.requestManageCycle();
        return;
    }
    var resolved_geometry: layout_types.Rect = if (drag.action == .resize_floating)
        pointer_drag.resizeConstrained(drag.start, dx, dy, drag.resize_edges, drag.constraints)
    else
        .{
            .x = drag.start.x + dx,
            .y = drag.start.y + dy,
            .width = drag.start.width,
            .height = drag.start.height,
        };
    if (drag.action == .move_floating) {
        aqueous.transferFloatingDrag(drag, resolved_geometry, x, y);
        const pointer_target = aqueous.api.outputTargetAt(x, y, false);
        if (pointer_target == null or pointer_target.?.id != drag.layout_key.output) {
            drag.snap_candidate = null;
            if (!drag.dnd) aqueous.api.hideSnapOverlay();
        }
        if (pointer_target) |target| if (target.id == drag.layout_key.output) {
            const area = aqueous.effectiveUsableArea(target.area, target.usable_area);
            const options = aqueous.config.layout.layoutOptions(.floating);
            resolved_geometry = geometry.attractToRect(resolved_geometry, area, options.floating_resistance);
            resolved_geometry = aqueous.api.attractToWindowEdges(drag.handle, resolved_geometry, options.floating_resistance);
            const pointer_x = clampI32(@intFromFloat(x));
            const pointer_y = clampI32(@intFromFloat(y));
            const zone_candidate = !drag.dnd and drag.layout_floating and aqueous.layoutIsFloating(drag.layout_key) and
                aqueous.updateStackingSnapPreview(drag, target.id, area, pointer_x, pointer_y, options.floating_snap_threshold);
            const edge_direction = if (!zone_candidate)
                geometry.snapDirectionAt(area, pointer_x, pointer_y, options.floating_snap_threshold, options.floating_top_edge_maximize)
            else
                null;
            if (edge_direction) |direction| {
                const target_geometry = geometry.snap(area, direction, options.floating_snap_gap);
                resolved_geometry = geometry.constrainSnap(target_geometry, direction, drag.constraints);
                if (aqueous.window_states.get(drag.handle)) |state| {
                    state.snap_restore_geometry = drag.start;
                    state.snap_state = snapState(direction);
                    state.custom_snap_zone = std.math.maxInt(u8);
                }
            } else if (aqueous.window_states.get(drag.handle)) |state| {
                state.snap_state = .none;
                state.custom_snap_zone = std.math.maxInt(u8);
            }
        };
        if (!drag.layout_floating or !aqueous.layoutIsFloating(drag.layout_key)) {
            drag.snap_candidate = null;
            if (!drag.dnd) aqueous.api.hideSnapOverlay();
        }
    }
    if (drag.layout_floating) {
        const layout_state = aqueous.layout_states.getPtr(drag.layout_key) orelse return;
        layout_engine.setFloatingGeometry(util.gpa, layout_state, drag.handle, resolved_geometry) catch {
            log.err("out of memory remembering floating-layout geometry", .{});
            return;
        };
    } else if (!aqueous.window_states.setFloating(drag.handle, resolved_geometry)) return;
    aqueous.api.requestManageCycle();
}

fn updateStackingSnapPreview(
    aqueous: *Aqueous,
    drag: *Drag,
    output_id: u64,
    area: layout_types.Rect,
    pointer_x: i32,
    pointer_y: i32,
    activation_distance: i32,
) bool {
    const distance = @max(0, activation_distance);
    const edge_active = pointer_x <= area.x + distance or pointer_x >= area.right() - distance or
        pointer_y <= area.y + distance or pointer_y >= area.bottom() - distance;
    if (!edge_active) {
        drag.snap_candidate = null;
        aqueous.api.hideSnapOverlay();
        return false;
    }
    const targets = aqueous.stackingSnapTargets(output_id, area);
    if (targets.count == 0) {
        drag.snap_candidate = null;
        aqueous.api.hideSnapOverlay();
        return false;
    }

    var selected: ?usize = null;
    for (targets.hit_geometries[0..targets.count], 0..) |target, index| {
        if (pointer_x >= target.x and pointer_x < target.right() and
            pointer_y >= target.y and pointer_y < target.bottom())
        {
            selected = index;
            break;
        }
    }
    aqueous.api.showSnapOverlay(output_id, targets.geometries[0..targets.count], selected);
    if (selected) |index| {
        drag.snap_candidate = .{
            .output_id = output_id,
            .geometry = geometry.constrainSnap(targets.geometries[index], .center, drag.constraints),
            .layout_id = targets.layout_id,
            .zone_id = targets.zone_ids[index],
            .zone_index = targets.zone_indices[index],
        };
        return true;
    }
    drag.snap_candidate = null;
    return false;
}

/// Ownership is committed immediately; destination ordering waits for arrange
/// to admit the window. Only the latest crossing can have a pending drop.
fn transferTiledDrag(aqueous: *Aqueous, drag: *Drag, x: f64, y: f64) bool {
    const target = aqueous.api.outputTargetAt(x, y, false) orelse return false;
    if (target.id == drag.layout_key.output) return false;
    const key: LayoutStateKey = .{ .output = target.id, .workspace = target.workspace_number };
    var pending: TiledTransfer = .{ .handle = drag.handle, .key = key };
    if (aqueous.layout_states.getPtr(key)) |layout_state| {
        pending.layout = layout_state.active_layout;
    }
    if (aqueous.api.windowAt(x, y)) |hit| {
        if (hit.handle != drag.handle and aqueous.api.windowOnWorkspace(hit.handle, key.output, key.workspace)) {
            pending.target = hit.handle;
            pending.zone = pointer_drag.dropZone(hit.geometry, x, y);
        }
    }
    if (!aqueous.api.moveWindowToWorkspace(drag.handle, key.output, key.workspace)) return false;
    if (aqueous.layout_states.getPtr(drag.layout_key)) |source| {
        // Orders/columns are reconciled by arrange; persistent composable
        // membership and cached freeform geometry must not follow a departure.
        layout_engine.forgetWindow(source, drag.handle);
    }
    if (aqueous.workspace_stacks.getPtr(drag.layout_key)) |stack| stack.remove(drag.handle);
    if (aqueous.window_states.get(drag.handle)) |state| {
        state.overrideWorkspace();
        state.needs_output_recovery = false;
    }
    drag.layout_key = key;
    drag.awaiting_layout = null;
    drag.click_eligible = false;
    aqueous.last_scrolling_click = null;
    aqueous.pending_tiled_transfer = pending;
    _ = aqueous.api.selectOutput(key.output);
    const previous_cause = aqueous.focus_cause;
    aqueous.focus_cause = .pointer;
    defer aqueous.focus_cause = previous_cause;
    aqueous.requestFocus(drag.handle);
    aqueous.api.requestManageCycle();
    log.debug("tiled drag entered output {} workspace {}", .{ key.output, key.workspace });
    return true;
}

/// Called after destination admission, including when release ended the drag.
/// Normal admission remains valid if the optional target vanished or changed
/// layout. Never wait for the pointer to hit the newly admitted window.
fn completeTiledTransfer(aqueous: *Aqueous, key: LayoutStateKey, layout_state: *layout_engine.State, windows: []const layout_types.Window) bool {
    const pending = aqueous.pending_tiled_transfer orelse return false;
    if (!std.meta.eql(key, pending.key)) return false;
    aqueous.pending_tiled_transfer = null;
    if (!containsWindow(windows, pending.handle) or
        !aqueous.api.windowOnWorkspace(pending.handle, key.output, key.workspace)) return false;
    const state = aqueous.window_states.get(pending.handle) orelse return false;
    if (!pointer_drag.tiledMoveAllowed(state.kind(), state.fixed_position, aqueous.api.windowIsFullscreen(pending.handle)) or
        layout_engine.usesFloatingLayout(layout_state, pending.handle)) return false;
    if (pending.layout != layout_state.active_layout) return false;
    const target = pending.target orelse return false;
    if (!containsWindow(windows, target) or
        !aqueous.api.windowOnWorkspace(target, key.output, key.workspace)) return false;
    return layout_engine.drop(util.gpa, layout_state, pending.handle, target, pending.zone) catch {
        log.err("out of memory placing transferred tiled window", .{});
        return false;
    };
}

fn transferFloatingDrag(aqueous: *Aqueous, drag: *Drag, rect: layout_types.Rect, x: f64, y: f64) void {
    const target = aqueous.api.outputTargetAt(x, y, false) orelse return;
    if (target.id == drag.layout_key.output) return;
    const target_key: LayoutStateKey = .{ .output = target.id, .workspace = target.workspace_number };
    const target_layout_state = aqueous.layout_states.getPtr(target_key);
    if (drag.layout_floating) {
        if (target_layout_state) |layout_state| {
            if (!(layout_engine.prepareFloatingTransfer(layout_state, util.gpa) catch {
                log.err("out of memory preparing floating-layout transfer", .{});
                return;
            })) return;
        } else if (!aqueous.layoutIsFloating(target_key)) return;
    }
    if (!aqueous.api.moveWindowToWorkspace(drag.handle, target.id, target.workspace_number)) return;

    if (drag.layout_floating) {
        if (target_layout_state) |target_state| {
            layout_engine.commitFloatingTransfer(target_state, drag.handle);
            layout_engine.setFloatingGeometry(util.gpa, target_state, drag.handle, rect) catch
                log.err("out of memory transferring floating-layout geometry", .{});
        }
    } else if (aqueous.window_states.get(drag.handle)) |state| {
        state.overrideWorkspace();
        state.needs_output_recovery = false;
    }
    drag.layout_key = target_key;
    _ = aqueous.api.selectOutput(target.id);
    log.debug("floating drag entered output {} workspace {}", .{ target.id, target.workspace_number });
}

fn runVerb(aqueous: *Aqueous, verb: []const u8) void {
    if (wheel_input.navigationForVerb(verb)) |navigation| {
        const axis = aqueous.wheelNavigationAxis(navigation.axis) orelse return;
        _ = aqueous.navigateWithWheel(axis, navigation.steps);
        return;
    }
    const colon = std.mem.indexOfScalar(u8, verb, ':') orelse {
        log.warn("unknown action '{s}'", .{verb});
        return;
    };
    const head = verb[0..colon];
    const argument = std.mem.trim(u8, verb[colon + 1 ..], " \t");
    if (std.mem.eql(u8, head, "spawn")) return aqueous.spawn(argument);
    if (std.mem.eql(u8, head, "launch")) return aqueous.launchApplication(argument);
    if (std.mem.eql(u8, head, "set_layout")) return aqueous.setLayout(argument);
    if (std.mem.eql(u8, head, "builtin")) return aqueous.runBuiltin(argument);
    log.warn("unknown action verb '{s}'", .{head});
}

fn runBuiltin(aqueous: *Aqueous, value: []const u8) void {
    const colon = std.mem.indexOfScalar(u8, value, ':');
    const action = if (colon) |index| value[0..index] else value;
    const argument = if (colon) |index| std.mem.trim(u8, value[index + 1 ..], " \t") else "";
    if (std.mem.eql(u8, action, "toggle_start_menu")) return aqueous.spawn(aqueous.config.actions.toggle_start_menu.slice());
    if (std.mem.eql(u8, action, "spawn_terminal")) return aqueous.spawn(aqueous.config.actions.spawn_terminal.slice());
    if (std.mem.eql(u8, action, "screenshot")) return aqueous.spawn(aqueous.config.actions.screenshot.slice());
    if (std.mem.eql(u8, action, "lock_screen")) return aqueous.spawn(aqueous.config.actions.lock_screen.slice());
    if (std.mem.eql(u8, action, "window_switcher_next")) return @import("../main.zig").server.window_switcher.builtin(false);
    if (std.mem.eql(u8, action, "window_switcher_previous")) return @import("../main.zig").server.window_switcher.builtin(true);
    if (std.mem.eql(u8, action, "window_switcher_dismiss")) return @import("../main.zig").server.window_switcher.finish();
    if (std.mem.eql(u8, action, "toggle_overview")) return aqueous.toggleOverview();
    if (std.mem.eql(u8, action, "close_focused")) {
        if (aqueous.api.focusedWindow()) |handle| aqueous.api.closeWindow(handle);
        return;
    }
    if (std.mem.eql(u8, action, "reload_config")) return aqueous.reloadConfig() catch |err| log.warn("configuration reload rejected: {}", .{err});
    if (std.mem.eql(u8, action, "reload_rules")) {
        const tx = @import("../ConfigTransaction.zig");
        const io = std.Io.Threaded.global_single_threaded.io();
        const lock = tx.Lock.acquire(util.gpa, io, false) catch return;
        defer lock.release();
        _ = tx.recover(util.gpa, io) catch return;
        rules_config.reloadDiscovered(util.gpa, &aqueous.rules, aqueous.config.wm.rules_path.slice());
        aqueous.applyLayerRules();
        aqueous.api.requestManageCycle();
        aqueous.notify("Aqueous rules reloaded", null, false);
        return;
    }
    if (std.mem.startsWith(u8, action, "set_layout_")) {
        const slot: usize = if (std.mem.eql(u8, action, "set_layout_primary")) 0 else if (std.mem.eql(u8, action, "set_layout_secondary")) 1 else if (std.mem.eql(u8, action, "set_layout_tertiary")) 2 else 3;
        return aqueous.setLayoutId(aqueous.config.layout.slots[slot]);
    }
    if (parseIndexed(action, "focus_workspace_")) |number| return aqueous.focusWorkspace(number);
    if (parseIndexed(action, "move_to_workspace_")) |number| return aqueous.moveToWorkspace(number);
    if (std.mem.eql(u8, action, "focus_workspace_up")) return aqueous.relativeWorkspace(-1, false);
    if (std.mem.eql(u8, action, "focus_workspace_down")) return aqueous.relativeWorkspace(1, false);
    if (std.mem.eql(u8, action, "move_to_workspace_up")) return aqueous.relativeWorkspace(-1, true);
    if (std.mem.eql(u8, action, "move_to_workspace_down")) return aqueous.relativeWorkspace(1, true);
    if (std.mem.eql(u8, action, "focus_previous_workspace")) return aqueous.focusPreviousWorkspace();
    if (std.mem.eql(u8, action, "focus_output_left")) return aqueous.focusOutput(-1, false);
    if (std.mem.eql(u8, action, "focus_output_right")) return aqueous.focusOutput(1, false);
    if (std.mem.eql(u8, action, "move_to_output_left")) return aqueous.focusOutput(-1, true);
    if (std.mem.eql(u8, action, "move_to_output_right")) return aqueous.focusOutput(1, true);
    if (std.mem.eql(u8, action, "rotate_output_clockwise")) return aqueous.rotatePointerOutputClockwise();
    if (std.mem.eql(u8, action, "focus_composable")) {
        if (parseComposableSlot(argument)) |slot| aqueous.focusComposableSlot(slot);
        return;
    }
    if (std.mem.eql(u8, action, "move_to_composable")) {
        if (parseComposableSlot(argument)) |slot| aqueous.moveToComposableSlot(slot);
        return;
    }
    if (std.mem.eql(u8, action, "cycle_focus")) return aqueous.cycleFocus(1);
    if (std.mem.eql(u8, action, "focus_left")) return aqueous.directionalFocus(-1, 0);
    if (std.mem.eql(u8, action, "focus_right")) return aqueous.directionalFocus(1, 0);
    if (std.mem.eql(u8, action, "focus_up")) return aqueous.directionalFocus(0, -1);
    if (std.mem.eql(u8, action, "focus_down")) return aqueous.directionalFocus(0, 1);
    if (std.mem.eql(u8, action, "move_window_left")) return aqueous.moveFocused(-1, 0);
    if (std.mem.eql(u8, action, "move_window_right")) return aqueous.moveFocused(1, 0);
    if (std.mem.eql(u8, action, "move_window_up")) return aqueous.moveFocused(0, -1);
    if (std.mem.eql(u8, action, "move_window_down")) return aqueous.moveFocused(0, 1);
    if (std.mem.eql(u8, action, "move_column_left")) return aqueous.moveFocusedColumn(-1);
    if (std.mem.eql(u8, action, "move_column_right")) return aqueous.moveFocusedColumn(1);
    if (std.mem.eql(u8, action, "consume_window_into_column")) return aqueous.consumeWindowIntoColumn();
    if (std.mem.eql(u8, action, "expel_window_from_column")) return aqueous.expelWindowFromColumn();
    if (std.mem.startsWith(u8, action, "scroll_viewport_left")) {
        _ = aqueous.scrollViewport(-1, 0);
        return;
    }
    if (std.mem.startsWith(u8, action, "scroll_viewport_right")) {
        _ = aqueous.scrollViewport(1, 0);
        return;
    }
    if (std.mem.eql(u8, action, "scroll_viewport_up")) {
        _ = aqueous.scrollViewport(0, -1);
        return;
    }
    if (std.mem.eql(u8, action, "scroll_viewport_down")) {
        _ = aqueous.scrollViewport(0, 1);
        return;
    }
    if (std.mem.eql(u8, action, "toggle_scrolling_full_width")) return aqueous.toggleScrollingFullWidth();
    if (std.mem.eql(u8, action, "toggle_fullscreen")) return aqueous.toggleFullscreen();
    if (std.mem.eql(u8, action, "toggle_maximize")) return aqueous.toggleMaximize();
    if (std.mem.eql(u8, action, "toggle_maximize_horizontal")) return aqueous.togglePartialMaximize(true);
    if (std.mem.eql(u8, action, "toggle_maximize_vertical")) return aqueous.togglePartialMaximize(false);
    if (std.mem.eql(u8, action, "toggle_floating")) return aqueous.toggleFloating();
    if (std.mem.eql(u8, action, "toggle_minimize")) return aqueous.toggleMinimize();
    if (std.mem.eql(u8, action, "raise_window")) return aqueous.restackFocused(true);
    if (std.mem.eql(u8, action, "lower_window")) return aqueous.restackFocused(false);
    if (std.mem.eql(u8, action, "toggle_always_above")) return aqueous.toggleStackLayer(.above);
    if (std.mem.eql(u8, action, "toggle_always_below")) return aqueous.toggleStackLayer(.below);
    if (std.mem.eql(u8, action, "nudge_floating_left")) return aqueous.nudgeFocused(-1, 0, false);
    if (std.mem.eql(u8, action, "nudge_floating_right")) return aqueous.nudgeFocused(1, 0, false);
    if (std.mem.eql(u8, action, "nudge_floating_up")) return aqueous.nudgeFocused(0, -1, false);
    if (std.mem.eql(u8, action, "nudge_floating_down")) return aqueous.nudgeFocused(0, 1, false);
    if (std.mem.eql(u8, action, "nudge_floating_coarse_left")) return aqueous.nudgeFocused(-1, 0, true);
    if (std.mem.eql(u8, action, "nudge_floating_coarse_right")) return aqueous.nudgeFocused(1, 0, true);
    if (std.mem.eql(u8, action, "nudge_floating_coarse_up")) return aqueous.nudgeFocused(0, -1, true);
    if (std.mem.eql(u8, action, "nudge_floating_coarse_down")) return aqueous.nudgeFocused(0, 1, true);
    if (std.mem.eql(u8, action, "resize_floating_left")) return aqueous.resizeFocused(.{ .left = true }, true);
    if (std.mem.eql(u8, action, "resize_floating_right")) return aqueous.resizeFocused(.{ .right = true }, true);
    if (std.mem.eql(u8, action, "resize_floating_up")) return aqueous.resizeFocused(.{ .top = true }, true);
    if (std.mem.eql(u8, action, "resize_floating_down")) return aqueous.resizeFocused(.{ .bottom = true }, true);
    if (std.mem.eql(u8, action, "shrink_floating_left")) return aqueous.resizeFocused(.{ .left = true }, false);
    if (std.mem.eql(u8, action, "shrink_floating_right")) return aqueous.resizeFocused(.{ .right = true }, false);
    if (std.mem.eql(u8, action, "shrink_floating_up")) return aqueous.resizeFocused(.{ .top = true }, false);
    if (std.mem.eql(u8, action, "shrink_floating_down")) return aqueous.resizeFocused(.{ .bottom = true }, false);
    if (std.mem.eql(u8, action, "snap_left")) return aqueous.snapFocused(.left);
    if (std.mem.eql(u8, action, "snap_right")) return aqueous.snapFocused(.right);
    if (std.mem.eql(u8, action, "snap_up")) return aqueous.snapFocused(.up);
    if (std.mem.eql(u8, action, "snap_down")) return aqueous.snapFocused(.down);
    if (std.mem.eql(u8, action, "snap_up_left")) return aqueous.snapFocused(.up_left);
    if (std.mem.eql(u8, action, "snap_up_right")) return aqueous.snapFocused(.up_right);
    if (std.mem.eql(u8, action, "snap_down_left")) return aqueous.snapFocused(.down_left);
    if (std.mem.eql(u8, action, "snap_down_right")) return aqueous.snapFocused(.down_right);
    if (std.mem.eql(u8, action, "snap_center")) return aqueous.snapFocused(.center);
    if (std.mem.eql(u8, action, "unsnap")) return aqueous.unsnapFocused();
    if (std.mem.eql(u8, action, "snap_zone")) {
        return aqueous.snapFocusedZoneArgument(argument);
    }
    if (std.mem.eql(u8, action, "cycle_snap_zone")) return aqueous.cycleFocusedSnapZone();
    if (std.mem.eql(u8, action, "set_snap_layout")) return aqueous.setSnapLayout(argument);
    if (std.mem.eql(u8, action, "cycle_snap_layout")) return aqueous.cycleSnapLayout(false);
    if (std.mem.eql(u8, action, "cycle_snap_layout_reverse")) return aqueous.cycleSnapLayout(true);
    if (std.mem.eql(u8, action, "fit_floating_to_output")) return aqueous.fitFocusedToOutput();
    if (std.mem.eql(u8, action, "move_floating_to_edge_left")) return aqueous.moveFocusedToEdge(.left);
    if (std.mem.eql(u8, action, "move_floating_to_edge_right")) return aqueous.moveFocusedToEdge(.right);
    if (std.mem.eql(u8, action, "move_floating_to_edge_up")) return aqueous.moveFocusedToEdge(.up);
    if (std.mem.eql(u8, action, "move_floating_to_edge_down")) return aqueous.moveFocusedToEdge(.down);
    if (std.mem.eql(u8, action, "grow_floating_to_edge_left")) return aqueous.growFocusedToEdge(.left);
    if (std.mem.eql(u8, action, "grow_floating_to_edge_right")) return aqueous.growFocusedToEdge(.right);
    if (std.mem.eql(u8, action, "grow_floating_to_edge_up")) return aqueous.growFocusedToEdge(.up);
    if (std.mem.eql(u8, action, "grow_floating_to_edge_down")) return aqueous.growFocusedToEdge(.down);
    if (std.mem.eql(u8, action, "unminimize_last")) {
        const handle = aqueous.window_states.restoreLastMinimized();
        if (handle != 0) aqueous.requestFocus(handle);
        aqueous.api.requestManageCycle();
        return;
    }
    log.warn("unknown builtin action '{s}'", .{action});
}

fn parseIndexed(action: []const u8, prefix: []const u8) ?u32 {
    if (!std.mem.startsWith(u8, action, prefix)) return null;
    const number = std.fmt.parseInt(u32, action[prefix.len..], 10) catch return null;
    return if (number >= 1 and number <= 9) number else null;
}

fn rotatePointerOutputClockwise(aqueous: *Aqueous) void {
    const output_id = aqueous.api.pointerOutputId() orelse {
        log.debug("rotate output ignored: pointer is not on an enabled output", .{});
        return;
    };
    if (!aqueous.output_service.rotateOutputClockwise(output_id)) {
        log.warn("unable to schedule clockwise output rotation", .{});
    }
}

fn parseComposableSlot(value: []const u8) ?u8 {
    if (value.len != 1) return null;
    if (value[0] >= 'a' and value[0] <= 'd') return value[0] - 'a';
    if (value[0] >= '1' and value[0] <= '4') return value[0] - '1';
    return null;
}

pub fn toggleOverview(aqueous: *Aqueous) void {
    if (aqueous.overview != null) {
        aqueous.cancelOverview();
    } else {
        aqueous.openOverview();
    }
}

fn openOverview(aqueous: *Aqueous) void {
    aqueous.openOverviewOnOutput(null);
}

pub fn openOverviewOnOutput(aqueous: *Aqueous, explicit_output: ?u64) void {
    @import("../main.zig").server.window_switcher.dismiss();
    defer serverShellDirty();
    if (!aqueous.mode.runsInternal() or !aqueous.api.sessionUnlocked()) return;
    if (aqueous.drag != null or aqueous.api.hasNonWindowKeyboardFocus()) return;

    var snapshot = aqueous.api.policySnapshot(util.gpa) catch |err| {
        log.err("unable to snapshot windows for overview: {}", .{err});
        return;
    };
    defer snapshot.deinit(util.gpa);

    const focused = aqueous.api.focusedWindow();
    var target: ?*const CompositorApi.PolicyOutput = null;
    if (explicit_output) |id| {
        for (snapshot.outputs) |*output| if (output.id == id) {
            target = output;
            break;
        };
        if (target == null) return;
    } else if (focused) |handle| {
        for (snapshot.outputs) |*output| {
            if (containsWindow(output.windows, handle)) {
                target = output;
                break;
            }
        }
    }
    if (target == null) {
        const selected_output = aqueous.api.selectedOutputId() orelse return;
        for (snapshot.outputs) |*output| {
            if (output.id == selected_output) {
                target = output;
                break;
            }
        }
    }
    const output = target orelse return;
    const usable_area = aqueous.effectiveUsableArea(output.area, output.usable_area);

    var state: overview_model.State = .{
        .output_id = output.id,
        .workspace_number = output.workspace_number,
        .original_focus = focused,
        .selected = 0,
    };
    errdefer state.cards.deinit(util.gpa);
    state.cards.ensureTotalCapacity(util.gpa, output.windows.len) catch {
        log.err("out of memory building overview", .{});
        return;
    };
    for (output.windows) |window| {
        if (!window.accepts_focus) continue;
        const window_state = aqueous.window_states.get(window.handle) orelse continue;
        if (window_state.kind() == .minimized or window_state.skip_switcher or !window_state.focus_allowed) continue;
        const source_rect = aqueous.api.windowGeometry(window.handle) orelse continue;
        if (source_rect.width <= 0 or source_rect.height <= 0) continue;
        state.cards.appendAssumeCapacity(.{
            .handle = window.handle,
            .source = source_rect,
        });
    }
    if (state.cards.items.len == 0) return;
    overview_model.arrange(state.cards.items, usable_area);
    state.selected = if (focused) |handle|
        if (overview_model.contains(state.cards.items, handle)) handle else state.cards.items[0].handle
    else
        state.cards.items[0].handle;

    const accepted = aqueous.api.showOverview(
        state.output_id,
        state.cards.items,
        &state.selected,
    ) catch |err| {
        log.warn("unable to show overview: {}", .{err});
        return;
    };
    state.cards.items.len = accepted;
    aqueous.overview = state;
    aqueous.api.suppressPointerConstraints(true);
    aqueous.api.refreshPointerFocus();
}

fn serverShellDirty() void {
    @import("../main.zig").server.shell_manager.dirty();
    @import("../main.zig").server.shortcuts.refresh();
}

pub fn cancelOverview(aqueous: *Aqueous) void {
    defer serverShellDirty();
    var state = aqueous.overview orelse return;
    aqueous.overview = null;
    aqueous.api.hideOverview();
    state.deinit(util.gpa);
    aqueous.api.suppressPointerConstraints(false);
    aqueous.api.refreshPointerFocus();
}

fn confirmOverview(aqueous: *Aqueous) void {
    const state = aqueous.overview orelse return;
    const selected = state.selected;
    const output_id = state.output_id;
    const workspace_number = state.workspace_number;
    aqueous.cancelOverview();
    if (!aqueous.api.windowOnWorkspace(selected, output_id, workspace_number)) return;
    const window_state = aqueous.window_states.get(selected) orelse return;
    if (window_state.kind() == .minimized) return;
    aqueous.requestFocus(selected);
}

fn moveOverviewSelection(aqueous: *Aqueous, direction: overview_model.Direction) void {
    const state = &(aqueous.overview orelse return);
    const selected = overview_model.neighbor(state.cards.items, state.selected, direction) orelse return;
    if (selected == state.selected) return;
    state.selected = selected;
    serverShellDirty();
    aqueous.api.updateOverviewSelection(selected);
}

fn cycleOverviewSelection(aqueous: *Aqueous, delta: i32) void {
    const state = &(aqueous.overview orelse return);
    const selected = overview_model.cycle(state.cards.items, state.selected, delta) orelse return;
    if (selected == state.selected) return;
    state.selected = selected;
    serverShellDirty();
    aqueous.api.updateOverviewSelection(selected);
}

fn updateOverviewHover(aqueous: *Aqueous, x: f64, y: f64) bool {
    const state = &(aqueous.overview orelse return false);
    const selected = overview_model.hitTest(state.cards.items, x, y) orelse return false;
    if (selected != state.selected) {
        state.selected = selected;
        serverShellDirty();
        aqueous.api.updateOverviewSelection(selected);
    }
    return true;
}

fn handleOverviewKey(aqueous: *Aqueous, keysym: u32, modifiers: u32, pressed: bool) bool {
    const modifier_mask = modifiers & (1 | 4 | 8 | 64);
    const toggle = if (aqueous.mode.runsInternal())
        aqueous.config.actions.find(keysym, modifier_mask)
    else
        null;
    if (toggle) |verb| {
        if (std.mem.eql(u8, verb, "builtin:toggle_overview")) {
            if (pressed) aqueous.cancelOverview();
            return true;
        }
    }
    if (!pressed) return !isModifierKeysym(keysym);
    switch (keysym) {
        0xff51, 'h', 'H' => aqueous.moveOverviewSelection(.left),
        0xff53, 'l', 'L' => aqueous.moveOverviewSelection(.right),
        0xff52, 'k', 'K' => aqueous.moveOverviewSelection(.up),
        0xff54, 'j', 'J' => aqueous.moveOverviewSelection(.down),
        0xff09 => aqueous.cycleOverviewSelection(if (modifier_mask & 1 != 0) -1 else 1),
        0xff0d, 0x20 => aqueous.confirmOverview(),
        0xff1b => aqueous.cancelOverview(),
        else => return !isModifierKeysym(keysym),
    }
    return true;
}

fn isModifierKeysym(keysym: u32) bool {
    return switch (keysym) {
        0xffe1...0xffee => true, // Shift, Control, Meta, Alt, Super, Hyper
        else => false,
    };
}

fn validateOverviewSnapshot(aqueous: *Aqueous, snapshot: *const CompositorApi.PolicySnapshot) void {
    const state = if (aqueous.overview) |*value| value else return;
    var owner: ?*const CompositorApi.PolicyOutput = null;
    for (snapshot.outputs) |*output| {
        if (output.id == state.output_id) {
            owner = output;
            break;
        }
    }
    const output = owner orelse {
        aqueous.cancelOverview();
        return;
    };
    if (output.workspace_number != state.workspace_number) {
        aqueous.cancelOverview();
        return;
    }
    var index: usize = 0;
    while (index < state.cards.items.len) {
        const card = state.cards.items[index];
        const window_state = aqueous.window_states.get(card.handle);
        if (window_state == null or window_state.?.kind() == .minimized) {
            aqueous.cancelOverview();
            return;
        }
        if (!containsWindow(output.windows, card.handle)) {
            if (!aqueous.api.overviewWindowDisappearing(card.handle)) {
                aqueous.cancelOverview();
                return;
            }
            _ = overview_model.remove(state, card.handle);
            aqueous.api.removeOverviewWindow(card.handle);
            if (state.cards.items.len == 0) {
                aqueous.cancelOverview();
                return;
            }
            serverShellDirty();
            aqueous.api.updateOverviewSelection(state.selected);
            continue;
        }
        if (!aqueous.api.windowOnWorkspace(card.handle, state.output_id, state.workspace_number)) {
            aqueous.cancelOverview();
            return;
        }
        index += 1;
    }
}

pub fn forgetOutput(aqueous: *Aqueous, output_id: u64) void {
    const switcher = &@import("../main.zig").server.window_switcher;
    if (switcher.handoff) |pending| if (pending.output_id == output_id) {
        switcher.handoff = null;
    };
    if (switcher.output) |output| if (output.policyId() == output_id and !(switcher.all and switcher.activating)) switcher.dismiss();
    const state = aqueous.overview orelse return;
    if (state.output_id == output_id) aqueous.cancelOverview();
}

fn focusWorkspace(aqueous: *Aqueous, number: u32) void {
    const context = aqueous.api.workspaceContext() orelse return;
    if (number == context.workspace_number) return;
    aqueous.previous_workspaces.put(util.gpa, context.output.policyId(), context.workspace_number) catch return;
    _ = aqueous.api.activateWorkspace(context.output.policyId(), number);
}

fn moveToWorkspace(aqueous: *Aqueous, number: u32) void {
    const context = aqueous.api.focusedContext() orelse return;
    context.window.policy_state.overrideWorkspace();
    _ = aqueous.api.moveWindowToWorkspace(@bitCast(context.window.ref), context.output.policyId(), number);
    aqueous.api.requestManageCycle();
}

fn relativeWorkspace(aqueous: *Aqueous, delta: i32, move: bool) void {
    const context: CompositorApi.WorkspaceContext = if (move) blk: {
        const focused = aqueous.api.focusedContext() orelse return;
        break :blk .{ .output = focused.output, .workspace_number = focused.workspace_number };
    } else aqueous.api.workspaceContext() orelse return;
    const target_i = @as(i32, @intCast(context.workspace_number)) + delta;
    if (target_i < 1 or target_i > 9) return;
    if (move) aqueous.moveToWorkspace(@intCast(target_i)) else aqueous.focusWorkspace(@intCast(target_i));
}

fn focusPreviousWorkspace(aqueous: *Aqueous) void {
    const context = aqueous.api.workspaceContext() orelse return;
    const previous = aqueous.previous_workspaces.get(context.output.policyId()) orelse return;
    aqueous.focusWorkspace(previous);
}

fn focusOutput(aqueous: *Aqueous, delta: i32, move: bool) void {
    const context = aqueous.api.workspaceContext() orelse return;
    const moving_window = if (move) aqueous.api.focusedContext() orelse return else null;
    var snapshot = aqueous.api.policySnapshot(util.gpa) catch return;
    defer snapshot.deinit(util.gpa);
    const direction: output_navigation.Direction = if (delta < 0) .left else .right;
    const target_index = output_navigation.neighbor(snapshot.outputs, context.output.policyId(), direction) orelse return;
    const target = snapshot.outputs[target_index];
    if (!aqueous.api.selectOutput(target.id)) return;
    if (move) {
        moving_window.?.window.policy_state.overrideWorkspace();
        const handle: layout_types.Handle = @bitCast(moving_window.?.window.ref);
        if (!aqueous.api.moveWindowToWorkspace(handle, target.id, target.workspace_number)) return;
        aqueous.requestFocus(handle);
    } else {
        const candidate_context: OutputFocusContext = .{
            .aqueous = aqueous,
            .windows = target.windows,
            .output_id = target.id,
            .workspace_number = target.workspace_number,
        };
        var target_handle = aqueous.focus_history.pick(
            workspaceKey(target.id, target.workspace_number),
            candidate_context,
            outputFocusCandidateValid,
        );
        if (target_handle == 0) {
            for (target.windows) |window| {
                if (outputFocusCandidateValid(candidate_context, window.handle)) {
                    target_handle = window.handle;
                    break;
                }
            }
        }
        if (target_handle != 0) {
            aqueous.requestFocus(target_handle);
        } else {
            // Surface focus and output selection are deliberately independent:
            // an empty output remains selected after keyboard focus is cleared.
            aqueous.clearFocus();
        }
    }
    aqueous.api.warpPointerToOutput(target.id);
    aqueous.api.requestManageCycle();
}

fn cycleFocus(aqueous: *Aqueous, delta: i32) void {
    var snapshot = aqueous.api.policySnapshot(util.gpa) catch return;
    defer snapshot.deinit(util.gpa);
    const focused = aqueous.api.focusedWindow();
    const selected_output = aqueous.api.selectedOutputId();
    for (snapshot.outputs) |output| {
        if (selected_output != null and output.id != selected_output.?) continue;
        var candidates: std.ArrayListUnmanaged(layout_types.Handle) = .empty;
        defer candidates.deinit(util.gpa);
        candidates.ensureTotalCapacity(util.gpa, output.windows.len) catch return;
        for (output.windows) |window| candidates.appendAssumeCapacity(window.handle);
        const context: OutputFocusContext = .{
            .aqueous = aqueous,
            .windows = output.windows,
            .output_id = output.id,
            .workspace_number = output.workspace_number,
        };
        const target = aqueous.focus_history.cycle(
            workspaceKey(output.id, output.workspace_number),
            focused,
            delta,
            candidates.items,
            context,
            outputFocusCandidateValid,
        ) catch return;
        if (target != 0) aqueous.requestFocus(target);
        return;
    }
}

fn directionalFocus(aqueous: *Aqueous, dx: i32, dy: i32) void {
    if (aqueous.api.focusedWindow()) |focused| {
        if (aqueous.api.directionalNeighbor(focused, dx, dy)) |target| return aqueous.requestFocus(target);
    }
    if (dx != 0 and aqueous.config.wm.input.focus_crosses_workspaces) aqueous.focusAdjacentWorkspace(dx);
}

/// Continue horizontal focus into the neighboring workspace, landing on the
/// window nearest the edge focus entered from.
fn focusAdjacentWorkspace(aqueous: *Aqueous, dx: i32) void {
    const context = aqueous.api.workspaceContext() orelse return;
    const output_id = context.output.policyId();
    const count = aqueous.api.workspaceCount(output_id);
    const target = workspace_navigation.adjacent(context.workspace_number, dx, count) orelse return;
    const candidates: EdgeFocusContext = .{ .aqueous = aqueous, .output_id = output_id, .workspace_number = target };
    // Focus recovery after the switch picks the most recent history entry.
    if (aqueous.api.edgeWindow(output_id, target, -dx, candidates, edgeFocusCandidateValid)) |handle| {
        aqueous.focus_history.record(workspaceKey(output_id, target), handle) catch {};
    }
    aqueous.focusWorkspace(target);
}

fn focusComposableSlot(aqueous: *Aqueous, slot: u8) void {
    const context = aqueous.api.workspaceContext() orelse return;
    const state = aqueous.layout_states.getPtr(.{
        .output = context.output.policyId(),
        .workspace = context.workspace_number,
    }) orelse return;
    const target = layout_engine.focusComposableSlot(state, slot) orelse return;
    aqueous.requestFocus(target);
}

fn moveToComposableSlot(aqueous: *Aqueous, slot: u8) void {
    const context = aqueous.api.focusedContext() orelse return;
    if (context.window.policy_state.kind() != .tiled) return;
    const state = aqueous.layout_states.getPtr(.{
        .output = context.output.policyId(),
        .workspace = context.workspace_number,
    }) orelse return;
    const handle: layout_types.Handle = @bitCast(context.window.ref);
    if (!layout_engine.moveToComposableSlot(state, handle, slot)) return;
    aqueous.api.requestManageCycle();
}

fn moveFocused(aqueous: *Aqueous, dx: i32, dy: i32) void {
    const context = aqueous.api.focusedContext() orelse return;
    if (context.window.policy_state.kind() != .tiled) return;
    const key: LayoutStateKey = .{ .output = context.output.policyId(), .workspace = context.workspace_number };
    const state = aqueous.layout_states.getPtr(key) orelse return;
    const handle: layout_types.Handle = @bitCast(context.window.ref);
    if (layout_engine.usesSpecialMove(state, handle)) {
        if (!(layout_engine.moveScrolling(util.gpa, state, handle, dx, dy) catch {
            log.err("out of memory moving layout member", .{});
            return;
        })) {
            log.debug("window move ignored layout={s} handle={} dx={} dy={}", .{ @tagName(state.active_layout), handle, dx, dy });
            return;
        }
        log.debug("window moved layout={s} handle={} dx={} dy={}", .{ @tagName(state.active_layout), handle, dx, dy });
        aqueous.api.requestManageCycle();
        return;
    }
    const target = aqueous.api.directionalNeighbor(handle, dx, dy) orelse return;
    const target_state = aqueous.window_states.get(target) orelse return;
    if (target_state.kind() != .tiled) return;
    if (layout_engine.swap(state, handle, target)) aqueous.api.requestManageCycle();
}

fn moveFocusedColumn(aqueous: *Aqueous, delta: i32) void {
    const context = aqueous.api.focusedContext() orelse return;
    if (context.window.policy_state.kind() != .tiled) return;
    const key: LayoutStateKey = .{ .output = context.output.policyId(), .workspace = context.workspace_number };
    const state = aqueous.layout_states.getPtr(key) orelse return;
    const handle: layout_types.Handle = @bitCast(context.window.ref);
    if (!(layout_engine.moveScrollingColumn(util.gpa, state, handle, delta) catch {
        log.err("out of memory moving scrolling column", .{});
        return;
    })) return;
    aqueous.api.requestManageCycle();
}

fn scrollViewport(aqueous: *Aqueous, dx: i32, dy: i32) bool {
    // The keybinding is an explicit focus/navigation intent even when the
    // viewport is already at its edge. It must invalidate an older hover.
    aqueous.cancelHoverFocus();
    const context = aqueous.api.focusedContext() orelse return false;
    const state = aqueous.layout_states.getPtr(.{ .output = context.output.policyId(), .workspace = context.workspace_number }) orelse return false;
    const target = layout_engine.scrollViewport(state, @bitCast(context.window.ref), dx, dy) orelse return false;
    aqueous.requestFocus(target);
    aqueous.api.requestManageCycle();
    return true;
}

fn consumeWindowIntoColumn(aqueous: *Aqueous) void {
    const context = aqueous.api.focusedContext() orelse return;
    if (context.window.policy_state.kind() != .tiled) return;
    const state = aqueous.layout_states.getPtr(.{ .output = context.output.policyId(), .workspace = context.workspace_number }) orelse return;
    if (!(layout_engine.consumeWindowIntoColumn(util.gpa, state, @bitCast(context.window.ref)) catch {
        log.err("out of memory consuming window into column", .{});
        return;
    })) return;
    aqueous.api.requestManageCycle();
}

fn expelWindowFromColumn(aqueous: *Aqueous) void {
    const context = aqueous.api.focusedContext() orelse return;
    if (context.window.policy_state.kind() != .tiled) return;
    const state = aqueous.layout_states.getPtr(.{ .output = context.output.policyId(), .workspace = context.workspace_number }) orelse return;
    if (!(layout_engine.expelWindowFromColumn(util.gpa, state, @bitCast(context.window.ref)) catch {
        log.err("out of memory expelling window from column", .{});
        return;
    })) return;
    aqueous.api.requestManageCycle();
}

fn toggleFullscreen(aqueous: *Aqueous) void {
    const context = aqueous.api.focusedContext() orelse return;
    const handle: layout_types.Handle = @bitCast(context.window.ref);
    context.window.policy_state.overrideFullscreen();
    if (context.window.policySnapshot().fullscreen) {
        aqueous.api.clearFullscreen(handle);
    } else {
        aqueous.api.clearOtherFullscreen(context.output.policyId(), handle);
        _ = aqueous.api.setFullscreen(handle, context.output.policyId());
    }
    aqueous.api.requestManageCycle();
}

fn toggleMaximize(aqueous: *Aqueous) void {
    const handle = aqueous.api.focusedWindow() orelse return;
    _ = aqueous.window_states.toggleMaximized(handle) orelse return;
    aqueous.api.requestManageCycle();
}

fn toggleScrollingFullWidth(aqueous: *Aqueous) void {
    const context = aqueous.api.focusedContext() orelse return;
    if (context.window.policy_state.kind() != .tiled) return;
    _ = context.window.policy_state.toggleScrollingFullWidth();
    aqueous.api.requestManageCycle();
}

fn toggleFloating(aqueous: *Aqueous) void {
    const context = aqueous.api.focusedContext() orelse return;
    const handle: layout_types.Handle = @bitCast(context.window.ref);
    const key: LayoutStateKey = .{ .output = context.output.policyId(), .workspace = context.workspace_number };
    const box = context.window.box;
    const current_rect: layout_types.Rect = .{ .x = box.x, .y = box.y, .width = box.width, .height = box.height };

    // In a standalone or composable-child floating layout, toggling on creates
    // a deliberate per-window overlay which remains floating after a later
    // layout switch. Toggling off returns the window to workspace ownership at
    // its latest rectangle.
    if (aqueous.windowUsesFloatingLayout(key, handle)) {
        const layout_state = aqueous.layout_states.getPtr(key) orelse return;
        layout_engine.setFloatingGeometry(util.gpa, layout_state, handle, current_rect) catch return;
    }
    _ = aqueous.window_states.toggleFloating(handle, current_rect) orelse return;
    aqueous.api.requestManageCycle();
}

fn toggleMinimize(aqueous: *Aqueous) void {
    const handle = aqueous.api.focusedWindow() orelse return;
    if (!aqueous.window_states.restore(handle)) {
        if (aqueous.window_states.get(handle)) |state| state.overrideFullscreen();
        aqueous.api.clearFullscreen(handle);
        _ = aqueous.window_states.minimize(handle) catch return;
    }
    aqueous.api.requestManageCycle();
}

fn restackFocused(aqueous: *Aqueous, raise: bool) void {
    const context = aqueous.api.focusedContext() orelse return;
    const key: LayoutStateKey = .{
        .output = context.output.policyId(),
        .workspace = context.workspace_number,
    };
    const stack = aqueous.workspace_stacks.getPtr(key) orelse return;
    const handle: layout_types.Handle = @bitCast(context.window.ref);
    const changed = if (raise) stack.raise(handle) else stack.lower(handle);
    if (changed) aqueous.api.requestManageCycle();
}

fn toggleStackLayer(aqueous: *Aqueous, target: layout_types.StackLayer) void {
    const context = aqueous.api.focusedContext() orelse return;
    const state = &context.window.policy_state;
    state.overrideStackLayer();
    state.stack_layer = if (state.stack_layer == target) .normal else target;
    const key: LayoutStateKey = .{
        .output = context.output.policyId(),
        .workspace = context.workspace_number,
    };
    if (aqueous.workspace_stacks.getPtr(key)) |stack| {
        const handle: layout_types.Handle = @bitCast(context.window.ref);
        if (state.stack_layer == .above) {
            _ = stack.raise(handle);
        } else if (state.stack_layer == .below) {
            _ = stack.lower(handle);
        }
    }
    aqueous.api.requestManageCycle();
}

fn nudgeFocused(aqueous: *Aqueous, direction_x: i32, direction_y: i32, coarse: bool) void {
    const context = aqueous.api.focusedContext() orelse return;
    const handle: layout_types.Handle = @bitCast(context.window.ref);
    const key: LayoutStateKey = .{ .output = context.output.policyId(), .workspace = context.workspace_number };
    const layout_floating = aqueous.windowUsesFloatingLayout(key, handle);
    const state = &context.window.policy_state;
    if (state.presentation != .floating and !layout_floating) return;
    if (state.fixed_position) return;
    var current = currentOrRestoreGeometry(context.window.box, state);
    const options = aqueous.config.layout.layoutOptions(.floating);
    const step = if (coarse) options.floating_move_step_coarse else options.floating_move_step;
    current.x = clampI32(@as(i64, current.x) + @as(i64, direction_x) * step);
    current.y = clampI32(@as(i64, current.y) + @as(i64, direction_y) * step);
    const area = aqueous.focusedUsableArea(context.output);
    current = geometry.keepReachable(current, area, 64, 32);
    state.snap_state = .none;
    state.custom_snap_zone = std.math.maxInt(u8);
    if (aqueous.storeFreeformGeometry(key, handle, state, layout_floating, current)) aqueous.api.requestManageCycle();
}

fn resizeFocused(aqueous: *Aqueous, edges: geometry.ResizeEdges, grow: bool) void {
    const context = aqueous.api.focusedContext() orelse return;
    const handle: layout_types.Handle = @bitCast(context.window.ref);
    const key: LayoutStateKey = .{ .output = context.output.policyId(), .workspace = context.workspace_number };
    const layout_floating = aqueous.windowUsesFloatingLayout(key, handle);
    const state = &context.window.policy_state;
    if (state.presentation != .floating and !layout_floating) return;
    if (state.fixed_position) return;
    const current = currentOrRestoreGeometry(context.window.box, state);
    const step = aqueous.config.layout.layoutOptions(.floating).floating_resize_step * (if (grow) @as(i32, 1) else -1);
    const dx = if (edges.left) -step else if (edges.right) step else 0;
    const dy = if (edges.top) -step else if (edges.bottom) step else 0;
    var resized = geometry.resize(current, dx, dy, edges, aqueous.api.windowConstraints(handle));
    resized = geometry.keepReachable(resized, aqueous.focusedUsableArea(context.output), 64, 32);
    state.snap_state = .none;
    state.custom_snap_zone = std.math.maxInt(u8);
    if (aqueous.storeFreeformGeometry(key, handle, state, layout_floating, resized)) aqueous.api.requestManageCycle();
}

fn snapFocused(aqueous: *Aqueous, direction: geometry.SnapDirection) void {
    const context = aqueous.api.focusedContext() orelse return;
    const handle: layout_types.Handle = @bitCast(context.window.ref);
    const key: LayoutStateKey = .{ .output = context.output.policyId(), .workspace = context.workspace_number };
    const layout_floating = aqueous.windowUsesFloatingLayout(key, handle);
    const state = &context.window.policy_state;
    if (state.presentation != .floating and !layout_floating) return;
    const current: layout_types.Rect = .{ .x = context.window.box.x, .y = context.window.box.y, .width = context.window.box.width, .height = context.window.box.height };
    if (state.snap_state == .none and current.width > 0 and current.height > 0) state.snap_restore_geometry = current;
    const area = aqueous.focusedUsableArea(context.output);
    const target = geometry.snap(area, direction, aqueous.config.layout.layoutOptions(.floating).floating_snap_gap);
    const snapped = geometry.constrainSnap(target, direction, aqueous.api.windowConstraints(handle));
    state.snap_state = snapState(direction);
    state.custom_snap_zone = std.math.maxInt(u8);
    if (aqueous.storeFreeformGeometry(key, handle, state, layout_floating, snapped)) aqueous.api.requestManageCycle();
}

fn unsnapFocused(aqueous: *Aqueous) void {
    const context = aqueous.api.focusedContext() orelse return;
    const state = &context.window.policy_state;
    if (state.fixed_position) return;
    if (state.snap_state == .none or state.snap_restore_geometry.width <= 0 or state.snap_restore_geometry.height <= 0) return;
    const handle: layout_types.Handle = @bitCast(context.window.ref);
    const key: LayoutStateKey = .{ .output = context.output.policyId(), .workspace = context.workspace_number };
    const layout_floating = aqueous.windowUsesFloatingLayout(key, handle);
    const restored = geometry.keepReachable(state.snap_restore_geometry, aqueous.focusedUsableArea(context.output), 64, 32);
    state.snap_state = .none;
    state.custom_snap_zone = std.math.maxInt(u8);
    if (aqueous.storeFreeformGeometry(key, handle, state, layout_floating, restored)) aqueous.api.requestManageCycle();
}

fn fitFocusedToOutput(aqueous: *Aqueous) void {
    const context = aqueous.api.focusedContext() orelse return;
    const handle: layout_types.Handle = @bitCast(context.window.ref);
    const key: LayoutStateKey = .{ .output = context.output.policyId(), .workspace = context.workspace_number };
    const layout_floating = aqueous.windowUsesFloatingLayout(key, handle);
    const state = &context.window.policy_state;
    if (state.presentation != .floating and !layout_floating) return;
    if (state.fixed_position) return;
    if (state.fixed_position) return;
    const area = aqueous.focusedUsableArea(context.output);
    const fitted = geometry.constrainSnap(area, .center, aqueous.api.windowConstraints(handle));
    state.snap_state = .none;
    state.custom_snap_zone = std.math.maxInt(u8);
    if (aqueous.storeFreeformGeometry(key, handle, state, layout_floating, fitted)) aqueous.api.requestManageCycle();
}

fn snapFocusedZoneArgument(aqueous: *Aqueous, argument: []const u8) void {
    const context = aqueous.api.focusedContext() orelse return;
    const handle: layout_types.Handle = @bitCast(context.window.ref);
    const key: LayoutStateKey = .{ .output = context.output.policyId(), .workspace = context.workspace_number };
    if (!aqueous.layoutIsFloating(key)) return;
    var zone_id = argument;
    if (std.mem.indexOfAny(u8, argument, "/:")) |separator| {
        const layout_id = std.mem.trim(u8, argument[0..separator], " \t");
        zone_id = std.mem.trim(u8, argument[separator + 1 ..], " \t");
        const snap_layout = aqueous.config.layout.snapLayoutById(layout_id) orelse return;
        if (snap_layout.zoneById(zone_id) == null) return;
        var active: layout_config.SnapId = .{};
        if (!active.set(layout_id)) return;
        aqueous.snap_layout_overrides.put(util.gpa, context.output.policyId(), active) catch return;
    }
    const area = aqueous.focusedUsableArea(context.output);
    const targets = aqueous.stackingSnapTargets(context.output.policyId(), area);
    if (targets.count == 0) return;
    var selected: ?usize = null;
    for (targets.zone_ids[0..targets.count], 0..) |id, index| {
        if (id.eql(zone_id)) {
            selected = index;
            break;
        }
    }
    if (selected == null) if (parseComposableSlot(zone_id)) |legacy_index| {
        if (legacy_index < targets.count) selected = legacy_index;
    };
    const index = selected orelse return;
    aqueous.snapFocusedTarget(key, handle, &context.window.policy_state, .{
        .x = context.window.box.x,
        .y = context.window.box.y,
        .width = context.window.box.width,
        .height = context.window.box.height,
    }, targets, index);
}

fn snapFocusedTarget(
    aqueous: *Aqueous,
    key: LayoutStateKey,
    handle: layout_types.Handle,
    state: *PolicyState,
    current: layout_types.Rect,
    targets: SnapTargets,
    index: usize,
) void {
    if (index >= targets.count or !aqueous.layoutIsFloating(key)) return;
    if (state.fixed_position or !aqueous.windowUsesFloatingLayout(key, handle)) return;
    if (state.snap_state == .none and current.width > 0 and current.height > 0) state.snap_restore_geometry = current;
    const snapped = geometry.constrainSnap(targets.geometries[index], .center, aqueous.api.windowConstraints(handle));
    state.snap_state = .center;
    state.custom_snap_zone = targets.zone_indices[index];
    state.snap_layout_id = targets.layout_id;
    state.snap_zone_id = targets.zone_ids[index];
    if (aqueous.storeFreeformGeometry(key, handle, state, true, snapped)) aqueous.api.requestManageCycle();
}

fn cycleFocusedSnapZone(aqueous: *Aqueous) void {
    const context = aqueous.api.focusedContext() orelse return;
    const handle: layout_types.Handle = @bitCast(context.window.ref);
    const key: LayoutStateKey = .{ .output = context.output.policyId(), .workspace = context.workspace_number };
    if (!aqueous.layoutIsFloating(key)) return;
    const state = &context.window.policy_state;
    const targets = aqueous.stackingSnapTargets(context.output.policyId(), aqueous.focusedUsableArea(context.output));
    if (targets.count == 0) return;
    var current: ?usize = null;
    for (targets.zone_ids[0..targets.count], 0..) |id, index| {
        if (state.custom_snap_zone < layout_config.max_snap_zones and
            id.eql(state.snap_zone_id.slice()) and targets.layout_id.eql(state.snap_layout_id.slice()))
        {
            current = index;
            break;
        }
    }
    const next = if (current) |index| (index + 1) % targets.count else 0;
    aqueous.snapFocusedTarget(key, handle, &context.window.policy_state, .{
        .x = context.window.box.x,
        .y = context.window.box.y,
        .width = context.window.box.width,
        .height = context.window.box.height,
    }, targets, next);
}

fn setSnapLayout(aqueous: *Aqueous, id: []const u8) void {
    const context = aqueous.api.focusedContext() orelse return;
    const key: LayoutStateKey = .{ .output = context.output.policyId(), .workspace = context.workspace_number };
    if (!aqueous.layoutIsFloating(key) or aqueous.config.layout.snapLayoutById(id) == null) return;
    var stored: layout_config.SnapId = .{};
    if (!stored.set(id)) return;
    aqueous.snap_layout_overrides.put(util.gpa, context.output.policyId(), stored) catch return;
}

fn cycleSnapLayout(aqueous: *Aqueous, reverse: bool) void {
    if (aqueous.config.layout.snap_layout_count == 0) return;
    const context = aqueous.api.focusedContext() orelse return;
    const key: LayoutStateKey = .{ .output = context.output.policyId(), .workspace = context.workspace_number };
    if (!aqueous.layoutIsFloating(key)) return;
    const output_id = context.output.policyId();
    const current = aqueous.activeSnapLayout(output_id) orelse return;
    var current_index: usize = 0;
    for (aqueous.config.layout.snap_layouts[0..aqueous.config.layout.snap_layout_count], 0..) |*snap_layout, index| {
        if (snap_layout.id.eql(current.id.slice())) current_index = index;
    }
    const count: usize = aqueous.config.layout.snap_layout_count;
    const next = if (reverse) (current_index + count - 1) % count else (current_index + 1) % count;
    aqueous.snap_layout_overrides.put(util.gpa, output_id, aqueous.config.layout.snap_layouts[next].id) catch return;
}

fn activeSnapLayout(aqueous: *const Aqueous, output_id: u64) ?*const layout_config.SnapLayout {
    const preferred = if (aqueous.snap_layout_overrides.get(output_id)) |id| id.slice() else "";
    return aqueous.config.layout.configuredSnapLayout(preferred);
}

fn stackingSnapTargets(aqueous: *const Aqueous, output_id: u64, area: layout_types.Rect) SnapTargets {
    var targets: SnapTargets = .{};
    if (aqueous.activeSnapLayout(output_id)) |snap_layout| {
        targets.layout_id = snap_layout.id;
        for (snap_layout.zones[0..snap_layout.zone_count], 0..) |zone, zone_index| {
            if (!zone.valid() or targets.count == layout_config.max_snap_zones) continue;
            const index = targets.count;
            targets.hit_geometries[index] = normalizedZone(area, zone, 0);
            targets.geometries[index] = normalizedZone(area, zone, snap_layout.padding);
            targets.zone_indices[index] = @intCast(zone_index);
            targets.zone_ids[index] = zone.id;
            targets.count += 1;
        }
        return targets;
    }
    for (aqueous.config.layout.snap_zones, 0..) |zone, zone_index| {
        if (!zone.valid()) continue;
        const index = targets.count;
        targets.geometries[index] = normalizedZone(area, zone, 0);
        targets.hit_geometries[index] = targets.geometries[index];
        targets.zone_indices[index] = @intCast(zone_index);
        var id: layout_config.SnapId = .{};
        var text: [1]u8 = .{@intCast('a' + zone_index)};
        _ = id.set(&text);
        targets.zone_ids[index] = id;
        targets.count += 1;
    }
    return targets;
}

fn normalizedZone(area: layout_types.Rect, zone: layout_config.SnapZone, padding: i32) layout_types.Rect {
    const x_offset: i64 = @intFromFloat(@floor(@as(f64, @floatFromInt(area.width)) * zone.x));
    const y_offset: i64 = @intFromFloat(@floor(@as(f64, @floatFromInt(area.height)) * zone.y));
    const width: i32 = @max(1, @as(i32, @intFromFloat(@floor(@as(f64, @floatFromInt(area.width)) * zone.width))));
    const height: i32 = @max(1, @as(i32, @intFromFloat(@floor(@as(f64, @floatFromInt(area.height)) * zone.height))));
    const raw: layout_types.Rect = .{ .x = clampI32(@as(i64, area.x) + x_offset), .y = clampI32(@as(i64, area.y) + y_offset), .width = width, .height = height };
    const inset = @min(padding, @min(@divTrunc(raw.width - 1, 2), @divTrunc(raw.height - 1, 2)));
    return .{ .x = raw.x + inset, .y = raw.y + inset, .width = raw.width - 2 * inset, .height = raw.height - 2 * inset };
}

fn togglePartialMaximize(aqueous: *Aqueous, horizontal: bool) void {
    const context = aqueous.api.focusedContext() orelse return;
    const handle: layout_types.Handle = @bitCast(context.window.ref);
    const key: LayoutStateKey = .{ .output = context.output.policyId(), .workspace = context.workspace_number };
    const layout_floating = aqueous.windowUsesFloatingLayout(key, handle);
    const state = &context.window.policy_state;
    if ((state.presentation != .floating and !layout_floating) or state.fixed_position) return;
    const target_state: PolicyState.SnapState = if (horizontal) .maximized_horizontal else .maximized_vertical;
    if (state.snap_state == target_state) return aqueous.unsnapFocused();
    const current: layout_types.Rect = .{ .x = context.window.box.x, .y = context.window.box.y, .width = context.window.box.width, .height = context.window.box.height };
    if (state.snap_state == .none and current.width > 0 and current.height > 0) state.snap_restore_geometry = current;
    const area = aqueous.focusedUsableArea(context.output);
    const raw: layout_types.Rect = if (horizontal)
        .{ .x = area.x, .y = current.y, .width = area.width, .height = current.height }
    else
        .{ .x = current.x, .y = area.y, .width = current.width, .height = area.height };
    const edges: geometry.ResizeEdges = if (horizontal) .{ .left = true, .right = true } else .{ .top = true, .bottom = true };
    const size = geometry.constrainSize(raw.width, raw.height, aqueous.api.windowConstraints(handle), edges);
    var resolved = raw;
    resolved.width = size.width;
    resolved.height = size.height;
    if (horizontal) resolved.x = area.x + @divTrunc(area.width - size.width, 2) else resolved.y = area.y + @divTrunc(area.height - size.height, 2);
    state.snap_state = target_state;
    state.custom_snap_zone = std.math.maxInt(u8);
    if (aqueous.storeFreeformGeometry(key, handle, state, layout_floating, geometry.keepReachable(resolved, area, 64, 32))) aqueous.api.requestManageCycle();
}

fn moveFocusedToEdge(aqueous: *Aqueous, direction: geometry.SnapDirection) void {
    const context = aqueous.api.focusedContext() orelse return;
    const handle: layout_types.Handle = @bitCast(context.window.ref);
    const key: LayoutStateKey = .{ .output = context.output.policyId(), .workspace = context.workspace_number };
    const layout_floating = aqueous.windowUsesFloatingLayout(key, handle);
    const state = &context.window.policy_state;
    if ((state.presentation != .floating and !layout_floating) or state.fixed_position) return;
    var rect = currentOrRestoreGeometry(context.window.box, state);
    const area = aqueous.focusedUsableArea(context.output);
    switch (direction) {
        .left => rect.x = area.x,
        .right => rect.x = clampI32(@as(i64, area.x) + area.width - rect.width),
        .up => rect.y = area.y,
        .down => rect.y = clampI32(@as(i64, area.y) + area.height - rect.height),
        else => return,
    }
    state.snap_state = .none;
    state.custom_snap_zone = std.math.maxInt(u8);
    if (aqueous.storeFreeformGeometry(key, handle, state, layout_floating, geometry.keepReachable(rect, area, 64, 32))) aqueous.api.requestManageCycle();
}

fn growFocusedToEdge(aqueous: *Aqueous, direction: geometry.SnapDirection) void {
    const context = aqueous.api.focusedContext() orelse return;
    const handle: layout_types.Handle = @bitCast(context.window.ref);
    const key: LayoutStateKey = .{ .output = context.output.policyId(), .workspace = context.workspace_number };
    const layout_floating = aqueous.windowUsesFloatingLayout(key, handle);
    const state = &context.window.policy_state;
    if ((state.presentation != .floating and !layout_floating) or state.fixed_position) return;
    const rect = currentOrRestoreGeometry(context.window.box, state);
    const area = aqueous.focusedUsableArea(context.output);
    const edges: geometry.ResizeEdges = switch (direction) {
        .left => .{ .left = true },
        .right => .{ .right = true },
        .up => .{ .top = true },
        .down => .{ .bottom = true },
        else => return,
    };
    const dx = switch (direction) {
        .left => area.x - rect.x,
        .right => clampI32(@as(i64, area.x) + area.width - (@as(i64, rect.x) + rect.width)),
        else => 0,
    };
    const dy = switch (direction) {
        .up => area.y - rect.y,
        .down => clampI32(@as(i64, area.y) + area.height - (@as(i64, rect.y) + rect.height)),
        else => 0,
    };
    const resized = geometry.resize(rect, dx, dy, edges, aqueous.api.windowConstraints(handle));
    state.snap_state = .none;
    state.custom_snap_zone = std.math.maxInt(u8);
    if (aqueous.storeFreeformGeometry(key, handle, state, layout_floating, geometry.keepReachable(resized, area, 64, 32))) aqueous.api.requestManageCycle();
}

fn storeFreeformGeometry(aqueous: *Aqueous, key: LayoutStateKey, handle: layout_types.Handle, state: *PolicyState, layout_floating: bool, rect: layout_types.Rect) bool {
    if (rect.width <= 0 or rect.height <= 0) return false;
    if (layout_floating) {
        const layout_state = aqueous.layout_states.getPtr(key) orelse return false;
        layout_engine.setFloatingGeometry(util.gpa, layout_state, handle, rect) catch {
            log.err("out of memory remembering keyboard freeform geometry", .{});
            return false;
        };
    } else {
        state.floating_geometry = rect;
    }
    return true;
}

fn focusedUsableArea(aqueous: *const Aqueous, output: anytype) layout_types.Rect {
    const full = output.policyFullBox();
    const usable = output.policyUsableBox();
    return aqueous.effectiveUsableArea(
        .{ .x = full.x, .y = full.y, .width = full.width, .height = full.height },
        .{ .x = usable.x, .y = usable.y, .width = usable.width, .height = usable.height },
    );
}

fn currentOrRestoreGeometry(box: anytype, state: *const PolicyState) layout_types.Rect {
    if (state.snap_state != .none and state.snap_restore_geometry.width > 0 and state.snap_restore_geometry.height > 0) return state.snap_restore_geometry;
    return .{ .x = box.x, .y = box.y, .width = box.width, .height = box.height };
}

fn snapState(direction: geometry.SnapDirection) PolicyState.SnapState {
    return switch (direction) {
        inline else => |value| @enumFromInt(@intFromEnum(value) + 1),
    };
}

fn clampI32(value: i64) i32 {
    return @intCast(std.math.clamp(value, std.math.minInt(i32), std.math.maxInt(i32)));
}

fn setLayout(aqueous: *Aqueous, name: []const u8) void {
    const id = parseLayoutName(name) orelse {
        if (std.mem.eql(u8, name, "primary")) return aqueous.setLayoutId(aqueous.config.layout.slots[0]);
        if (std.mem.eql(u8, name, "secondary")) return aqueous.setLayoutId(aqueous.config.layout.slots[1]);
        if (std.mem.eql(u8, name, "tertiary")) return aqueous.setLayoutId(aqueous.config.layout.slots[2]);
        if (std.mem.eql(u8, name, "quaternary")) return aqueous.setLayoutId(aqueous.config.layout.slots[3]);
        return;
    };
    aqueous.setLayoutId(id);
}

fn parseLayoutName(name: []const u8) ?layout_config.LayoutId {
    return std.meta.stringToEnum(
        layout_config.LayoutId,
        if (std.mem.eql(u8, name, "float") or std.mem.eql(u8, name, "stack") or std.mem.eql(u8, name, "stacking")) "floating" else if (std.mem.eql(u8, name, "game-mode")) "game_mode" else if (std.mem.eql(u8, name, "reverse-dwindle")) "reverse_dwindle" else name,
    );
}

pub fn layoutName(id: layout_config.LayoutId) [:0]const u8 {
    return switch (id) {
        .floating => "float",
        .game_mode => "game-mode",
        .reverse_dwindle => "reverse-dwindle",
        else => @tagName(id),
    };
}

pub const ActiveWorkspaceLayout = struct {
    workspace: u32,
    layout: layout_config.LayoutId,
};

fn outputByName(name: []const u8) ?*@import("../Output.zig") {
    var outputs = server.om.outputs.iterator(.forward);
    while (outputs.next()) |output| {
        if (std.mem.eql(u8, output.policyName(), name)) return output;
    }
    return null;
}

pub fn activeWorkspaceLayout(aqueous: *Aqueous, output_name: []const u8) ?ActiveWorkspaceLayout {
    if (!aqueous.mode.runsInternal()) return null;
    const output = outputByName(output_name) orelse return null;
    const workspace = output.policyActiveWorkspaceNumber();
    if (workspace == 0) return null;
    const key: LayoutStateKey = .{ .output = output.policyId(), .workspace = workspace };
    if (aqueous.layout_overrides.get(key)) |id| return .{ .workspace = workspace, .layout = id };
    if (aqueous.layout_states.get(key)) |state| return .{ .workspace = workspace, .layout = state.active_layout };

    var id = aqueous.config.layout.default;
    const identity = output.policyIdentity();
    if (aqueous.config.wm.resolveOutput(.{
        .name = identity.name,
        .make = identity.make,
        .model = identity.model,
        .serial = identity.serial,
    })) |configured| id = configured;
    if (aqueous.config.wm.resolveWorkspace(output_name, workspace)) |configured| id = configured;
    return .{ .workspace = workspace, .layout = id };
}

pub const SetActiveWorkspaceLayoutStatus = enum {
    success,
    output_not_found,
    invalid_layout,
    unavailable,
};

pub fn setActiveWorkspaceLayout(
    aqueous: *Aqueous,
    output_name: []const u8,
    layout_name: []const u8,
) SetActiveWorkspaceLayoutStatus {
    if (!aqueous.mode.runsInternal()) return .unavailable;
    const id = parseLayoutName(layout_name) orelse return .invalid_layout;
    const output = outputByName(output_name) orelse return .output_not_found;
    const workspace = output.policyActiveWorkspaceNumber();
    if (workspace == 0) return .unavailable;
    const key: LayoutStateKey = .{ .output = output.policyId(), .workspace = workspace };
    if (aqueous.layout_states.getPtr(key)) |state| layout_engine.gameModeState(state).rule_layout_owned = false;
    aqueous.layout_overrides.put(util.gpa, key, id) catch return .unavailable;
    aqueous.api.requestManageCycle();
    return .success;
}

fn setLayoutId(aqueous: *Aqueous, id: layout_config.LayoutId) void {
    const context = aqueous.api.focusedContext() orelse return;
    const key: LayoutStateKey = .{ .output = context.output.policyId(), .workspace = context.workspace_number };
    if (aqueous.layout_states.getPtr(key)) |state| layout_engine.gameModeState(state).rule_layout_owned = false;
    aqueous.layout_overrides.put(util.gpa, key, id) catch return;
    aqueous.api.requestManageCycle();
}

fn layoutIsFloating(aqueous: *const Aqueous, key: LayoutStateKey) bool {
    if (aqueous.layout_overrides.get(key)) |id| return id == .floating;
    if (aqueous.layout_states.get(key)) |state| return state.active_layout == .floating;
    return aqueous.config.layout.default == .floating;
}

fn windowUsesFloatingLayout(aqueous: *const Aqueous, key: LayoutStateKey, handle: layout_types.Handle) bool {
    if (aqueous.layout_states.get(key)) |state| return layout_engine.usesFloatingLayout(&state, handle);
    return aqueous.layoutIsFloating(key);
}

pub fn clientWindowUsesFloatingLayout(
    aqueous: *const Aqueous,
    handle: layout_types.Handle,
) bool {
    if (!aqueous.mode.runsInternal()) return false;
    const workspace = aqueous.api.windowWorkspace(handle) orelse return false;
    return aqueous.windowUsesFloatingLayout(.{
        .output = workspace.output_id,
        .workspace = workspace.workspace_number,
    }, handle);
}

/// Read the existing layout order; shell refresh already diffs changed entities.
pub fn clientWindowLayoutIndex(aqueous: *Aqueous, handle: layout_types.Handle) ?u32 {
    if (!aqueous.mode.runsInternal()) return null;
    const workspace = aqueous.api.windowWorkspace(handle) orelse return null;
    const state = aqueous.layout_states.getPtr(.{ .output = workspace.output_id, .workspace = workspace.workspace_number }) orelse return null;
    return layout_engine.orderIndex(state, handle);
}

pub fn clientMinimizeAllowed(
    aqueous: *Aqueous,
    handle: layout_types.Handle,
    minimized: bool,
) bool {
    return aqueous.window_states.clientMinimizeAllowed(
        handle,
        minimized,
        aqueous.clientWindowUsesFloatingLayout(handle),
    );
}

fn applyInputConfig(aqueous: *Aqueous) void {
    if (aqueous.started and aqueous.mode.runsInternal()) aqueous.api.applyInputConfig(&aqueous.config.wm.input);
}

fn runExec(aqueous: *Aqueous, when: action_config.ExecWhen) void {
    if (!aqueous.started) return;
    for (aqueous.config.actions.exec[0..aqueous.config.actions.exec_count]) |*entry| {
        if (!(entry.when == .always or entry.when == when)) continue;
        var hash = std.hash.Wyhash.init(0);
        hash.update(entry.name.slice());
        const key = hash.final();
        if (entry.once and aqueous.fired_exec.contains(key)) continue;
        if (entry.once) aqueous.fired_exec.put(util.gpa, key, {}) catch continue;
        aqueous.spawnExec(entry);
    }
}

fn spawnExec(aqueous: *Aqueous, entry: *const action_config.Exec) void {
    var buffer: [2048]u8 = undefined;
    var out: usize = 0;
    if (!entry.env.empty()) {
        const raw = std.mem.trim(u8, entry.env.slice(), " {}\t");
        var pairs = std.mem.splitScalar(u8, raw, ',');
        while (pairs.next()) |pair| {
            const equal = std.mem.indexOfScalar(u8, pair, '=') orelse continue;
            const key = std.mem.trim(u8, pair[0..equal], " \t");
            const value = wmUnquote(std.mem.trim(u8, pair[equal + 1 ..], " \t"));
            const rendered = std.fmt.bufPrint(buffer[out..], "export {s}='{s}'; ", .{ key, value }) catch return;
            out += rendered.len;
        }
    }
    if (entry.restart) {
        const rendered = std.fmt.bufPrint(buffer[out..], "delay=.25; while :; do {s}; code=$?; [ $code -eq 0 ] && break; sleep $delay; case $delay in .25) delay=.5;; .5) delay=1;; 1) delay=2;; 2) delay=4;; 4) delay=8;; *) delay=10;; esac; done", .{entry.command.slice()}) catch return;
        out += rendered.len;
    } else {
        const rendered = std.fmt.bufPrint(buffer[out..], "{s}", .{entry.command.slice()}) catch return;
        out += rendered.len;
    }
    if (!entry.log_path.empty()) {
        const rendered = std.fmt.bufPrint(buffer[out..], " >>'{s}' 2>&1", .{entry.log_path.slice()}) catch return;
        out += rendered.len;
    }
    aqueous.spawn(buffer[0..out]);
}

fn wmUnquote(value: []const u8) []const u8 {
    if (value.len >= 2 and ((value[0] == '"' and value[value.len - 1] == '"') or (value[0] == '\'' and value[value.len - 1] == '\''))) return value[1 .. value.len - 1];
    return value;
}

fn spawn(_: *Aqueous, command: []const u8) void {
    if (command.len == 0) return;
    const owned = util.gpa.dupeZ(u8, command) catch return;
    const argv = [_:null]?[*:0]const u8{ "/bin/sh", "-c", owned.ptr, null };
    const rc = server.child_processes.fork() catch |err| {
        util.gpa.free(owned);
        log.err("spawn failed for command '{s}': {s}", .{ command, @errorName(err) });
        return;
    };
    if (rc == 0) {
        process.cleanupChild();
        const envp: [*:null]const ?[*:0]const u8 = @ptrCast(std.c.environ);
        if (posix.errno(posix.system.execve("/bin/sh", &argv, envp)) != .SUCCESS) posix.system.exit(127);
    }
    util.gpa.free(owned);
}

fn launchApplication(aqueous: *Aqueous, name: []const u8) void {
    const application = aqueous.config.actions.findApplication(name) orelse {
        log.warn("unknown application launch profile '{s}'", .{name});
        return;
    };
    aqueous.execApplication(application) catch |err| {
        log.err("failed to launch application profile '{s}': {s}", .{ name, @errorName(err) });
    };
}

fn execApplication(_: *Aqueous, application: *const action_config.Application) !void {
    const command = try util.gpa.dupeZ(u8, application.command.slice());
    defer util.gpa.free(command);

    var owned_args: [action_config.max_application_args]?[:0]u8 =
        [_]?[:0]u8{null} ** action_config.max_application_args;
    defer for (&owned_args) |owned| if (owned) |value| util.gpa.free(value);

    var argv = [_]?[*:0]const u8{null} ** (action_config.max_application_args + 2);
    argv[0] = command.ptr;
    for (application.args[0..application.arg_count], 0..) |arg, index| {
        const owned = try util.gpa.dupeZ(u8, arg.slice());
        owned_args[index] = owned;
        argv[index + 1] = owned.ptr;
    }

    var owned_env: [action_config.max_application_env]?[:0]u8 =
        [_]?[:0]u8{null} ** action_config.max_application_env;
    defer for (&owned_env) |owned| if (owned) |value| util.gpa.free(value);

    var env_list: std.ArrayList(?[*:0]const u8) = .empty;
    defer env_list.deinit(util.gpa);
    const inherited: [*:null]const ?[*:0]const u8 = @ptrCast(std.c.environ);
    var inherited_index: usize = 0;
    while (inherited[inherited_index]) |entry| : (inherited_index += 1) {
        const inherited_name = std.mem.sliceTo(entry, '=');
        if (applicationOverridesEnvironment(application, inherited_name)) continue;
        try env_list.append(util.gpa, entry);
    }
    for (application.env[0..application.env_count], 0..) |variable, index| {
        const assignment = try std.fmt.allocPrintSentinel(
            util.gpa,
            "{s}={s}",
            .{ variable.name.slice(), variable.value.slice() },
            0,
        );
        owned_env[index] = assignment;
        try env_list.append(util.gpa, assignment.ptr);
    }
    try env_list.append(util.gpa, null);

    const rc = try server.child_processes.fork();
    if (rc == 0) {
        process.cleanupChild();
        const envp: [*:null]const ?[*:0]const u8 = @ptrCast(env_list.items.ptr);
        const child_argv: [*:null]const ?[*:0]const u8 = @ptrCast(&argv);
        if (posix.errno(posix.system.execve(command.ptr, child_argv, envp)) != .SUCCESS) posix.system.exit(127);
    }
}

fn applicationOverridesEnvironment(application: *const action_config.Application, name: []const u8) bool {
    for (application.env[0..application.env_count]) |variable| {
        if (std.mem.eql(u8, variable.name.slice(), name)) return true;
    }
    return false;
}

fn notify(aqueous: *Aqueous, summary: []const u8, body: ?[]const u8, is_error: bool) void {
    _ = body;
    var buffer: [512]u8 = undefined;
    const command = std.fmt.bufPrint(&buffer, "notify-send --app-name=Aqueous --expire-time=3000 --urgency={s} '{s}'", .{ if (is_error) "critical" else "normal", summary }) catch return;
    aqueous.spawn(command);
}

fn focusCandidateValid(windows: []const layout_types.Window, handle: layout_types.Handle) bool {
    return containsWindow(windows, handle);
}

fn admissionFocusEligible(accepts_focus: bool, kind: StateStore.Kind, workspace_visible: bool) bool {
    return accepts_focus and kind != .minimized and workspace_visible;
}

const OutputFocusContext = struct {
    aqueous: *Aqueous,
    windows: []const layout_types.Window,
    output_id: u64,
    workspace_number: u32,
};

fn outputFocusCandidateValid(context: OutputFocusContext, handle: layout_types.Handle) bool {
    if (!containsWindow(context.windows, handle)) return false;
    if (!context.aqueous.api.windowOnWorkspace(handle, context.output_id, context.workspace_number)) return false;
    const state = context.aqueous.window_states.get(handle) orelse return false;
    // Otherwise cycling from a dialog can repeatedly select its blocked
    // parent and resolve straight back to the same dialog.
    if (context.aqueous.api.resolveModalHandle(handle) != handle) return false;
    return state.kind() != .minimized and state.focus_allowed and !state.skip_switcher;
}

const EdgeFocusContext = struct {
    aqueous: *Aqueous,
    output_id: u64,
    workspace_number: u32,
};

fn edgeFocusCandidateValid(context: EdgeFocusContext, handle: layout_types.Handle) bool {
    if (!context.aqueous.api.windowOnWorkspace(handle, context.output_id, context.workspace_number)) return false;
    const state = context.aqueous.window_states.get(handle) orelse return false;
    if (context.aqueous.api.resolveModalHandle(handle) != handle) return false;
    return state.kind() != .minimized and state.focus_allowed and !state.skip_switcher;
}

fn workspaceKey(output_id: u64, workspace_number: u32) u64 {
    return output_id ^ (@as(u64, workspace_number) *% 0x9e3779b97f4a7c15);
}

fn containsWindow(windows: []const layout_types.Window, handle: layout_types.Handle) bool {
    for (windows) |window| if (window.handle == handle) return true;
    return false;
}

fn findLayoutWindow(windows: []const layout_types.Window, handle: layout_types.Handle) ?layout_types.Window {
    for (windows) |window| if (window.handle == handle) return window;
    return null;
}

/// A transient may request a higher layer than its parent, but never a lower
/// one: doing so would violate the requirement that it remain reachable above
/// the parent group. Bound traversal by the snapshot size to tolerate cycles.
fn effectiveStackLayer(
    aqueous: *Aqueous,
    windows: []const layout_types.Window,
    window: layout_types.Window,
    own: layout_types.StackLayer,
) layout_types.StackLayer {
    var result = own;
    var parent = window.parent;
    var remaining = windows.len;
    while (parent != null and remaining > 0) : (remaining -= 1) {
        const state = aqueous.window_states.get(parent.?) orelse break;
        if (@intFromEnum(state.stack_layer) > @intFromEnum(result)) result = state.stack_layer;
        const ancestor = findLayoutWindow(windows, parent.?) orelse break;
        parent = ancestor.parent;
    }
    return result;
}

const RuleEffect = struct {
    fullscreen: bool,
    workspace_visible: bool = true,
};

fn reconcileRulePlacements(aqueous: *Aqueous, snapshot: *const CompositorApi.PolicySnapshot) bool {
    var refresh = false;
    for (snapshot.outputs) |output| for (output.windows) |window| {
        const rule = aqueous.rules.resolve(.{
            .app_id = window.app_id,
            .class = window.app_id,
            .title = window.title,
            .tag = window.tag,
            .content_type = window.content_type,
        });
        if (aqueous.prepareWindowRuleMatch(window, output.id, rule)) refresh = true;

        const state = aqueous.window_states.get(window.handle) orelse continue;
        const requested = if (rule) |matched| matched.placementFingerprint() else 0;
        if (requested == state.rule_workspace_requested) continue;
        if (requested == 0) {
            state.rule_workspace_owned = false;
            state.rule_workspace_overridden = false;
            state.rule_workspace_requested = 0;
            continue;
        }

        if (!state.rule_workspace_overridden) {
            const matched = rule.?;
            const before = aqueous.api.windowWorkspace(window.handle);
            switch (aqueous.api.applyRulePlacement(
                window.handle,
                output.id,
                matched.placement.output,
                matched.placement.workspace,
            )) {
                .changed => {
                    const after = aqueous.api.windowWorkspace(window.handle);
                    if (before == null or after == null or before.?.output_id != after.?.output_id) {
                        state.needs_output_recovery = true;
                    }
                    state.rule_workspace_owned = true;
                    refresh = true;
                },
                .unchanged => state.rule_workspace_owned = true,
                .unavailable => {
                    state.rule_workspace_owned = false;
                    if (matched.placement.output) |name| {
                        log.warn("window rule target output '{s}' workspace {d} is unavailable; using normal admission placement", .{ name, matched.placement.workspace });
                    } else {
                        log.warn("window rule target workspace {d} is unavailable; using normal admission placement", .{matched.placement.workspace});
                    }
                },
            }
        }
        // Record unavailable targets too. Output rules are initial placement,
        // so a later hotplug must not unexpectedly move an established window.
        state.rule_workspace_requested = requested;
    };
    return refresh;
}

/// Roll back state still owned by an old semantic matcher before placement is
/// resolved. Doing this in the placement pre-pass lets a new rule move directly
/// to its destination while preserving the established property lifecycle.
fn prepareWindowRuleMatch(aqueous: *Aqueous, window: layout_types.Window, output_id: u64, rule: ?Rules.Rule) bool {
    const state = aqueous.window_states.get(window.handle) orelse return false;
    const match = if (rule) |matched| matched.matcherFingerprint() else 0;
    if (!state.ruleChanged(match)) return false;

    if (state.rule_fullscreen_owned) {
        if (state.rule_fullscreen_previous) {
            if (!window.fullscreen) {
                aqueous.api.clearOtherFullscreen(output_id, window.handle);
                _ = aqueous.api.setFullscreen(window.handle, output_id);
            }
        } else {
            aqueous.api.clearFullscreen(window.handle);
        }
    }
    _ = aqueous.window_states.restoreRuleFloating(window.handle);
    state.restoreRuleScrollingFullWidth();
    state.restoreRuleScrollingWidth();
    if (state.rule_stack_layer_owned) state.stack_layer = state.rule_stack_layer_previous;
    state.focus_allowed = true;
    state.fixed_position = false;
    state.skip_switcher = false;
    state.skip_taskbar = false;
    state.acceptRuleMatch(match);
    return true;
}

fn sameWorkspace(
    first: ?CompositorApi.WindowWorkspace,
    second: ?CompositorApi.WindowWorkspace,
) bool {
    if (first == null or second == null) return first == null and second == null;
    return first.?.output_id == second.?.output_id and first.?.workspace_number == second.?.workspace_number;
}

/// Reconcile stateful rule properties only when the semantic match changes.
/// Visual properties are intentionally handled separately on every cycle.
fn reconcileWindowRule(
    aqueous: *Aqueous,
    window: layout_types.Window,
    all_windows: []const layout_types.Window,
    output_id: u64,
    active_workspace: u32,
    output_area: layout_types.Rect,
    usable_area: layout_types.Rect,
    border: layout_types.Border,
    rule: ?Rules.Rule,
) RuleEffect {
    const state = aqueous.window_states.get(window.handle) orelse return .{ .fullscreen = window.fullscreen };
    var effect: RuleEffect = .{
        .fullscreen = window.fullscreen,
        .workspace_visible = aqueous.api.windowOnWorkspace(window.handle, output_id, active_workspace),
    };

    const matched = rule orelse return effect;

    state.reconcileScrollingFullWidth(matched.scrolling_full_width);
    state.reconcileScrollingWidth(matched.scrolling_width);
    state.focus_allowed = matched.focus orelse true;
    state.fixed_position = matched.fixed_position;
    state.skip_switcher = matched.skip_switcher;
    state.skip_taskbar = matched.skip_taskbar;
    const requested_stack_layer: ?layout_types.StackLayer = if (matched.stack_layer) |layer| @enumFromInt(@intFromEnum(layer)) else null;
    if (requested_stack_layer != state.rule_stack_layer_requested) {
        if (requested_stack_layer) |requested| {
            if (!state.rule_stack_layer_overridden) {
                if (!state.rule_stack_layer_owned) state.rule_stack_layer_previous = state.stack_layer;
                state.stack_layer = requested;
                state.rule_stack_layer_owned = true;
            }
        } else if (state.rule_stack_layer_owned) {
            state.stack_layer = state.rule_stack_layer_previous;
            state.rule_stack_layer_owned = false;
            state.rule_stack_layer_overridden = false;
        }
        state.rule_stack_layer_requested = requested_stack_layer;
    }

    if (matched.fullscreen != state.rule_fullscreen_requested) {
        if (matched.fullscreen) {
            if (!state.rule_fullscreen_overridden) {
                state.rule_fullscreen_previous = effect.fullscreen;
                aqueous.api.clearOtherFullscreen(output_id, window.handle);
                if (aqueous.api.setFullscreen(window.handle, output_id)) {
                    state.rule_fullscreen_owned = true;
                    effect.fullscreen = true;
                }
            }
        } else {
            if (state.rule_fullscreen_owned) {
                if (state.rule_fullscreen_previous) {
                    if (!effect.fullscreen) {
                        aqueous.api.clearOtherFullscreen(output_id, window.handle);
                        effect.fullscreen = aqueous.api.setFullscreen(window.handle, output_id);
                    }
                } else {
                    aqueous.api.clearFullscreen(window.handle);
                    effect.fullscreen = false;
                }
            }
            state.rule_fullscreen_owned = false;
            state.rule_fullscreen_overridden = false;
        }
        state.rule_fullscreen_requested = matched.fullscreen;
    }

    const floating_signature = matched.floatingFingerprint();
    if (matched.placement.floating != state.rule_floating_requested or
        (matched.placement.floating and floating_signature != state.rule_floating_signature))
    {
        if (matched.placement.floating) {
            if (!state.rule_floating_overridden) {
                const area = if (matched.ignore_struts) output_area else usable_area;
                var options = aqueous.config.layout.layoutOptions(.floating);
                if (matched.placement_policy) |policy| options.floating_placement = @enumFromInt(@intFromEnum(policy));
                var preferred = window;
                var rule_placement = matched.placement;
                switch (matched.size) {
                    .native => {},
                    .pixels => |size| {
                        rule_placement.width = size.width;
                        rule_placement.height = size.height;
                    },
                    .fraction => |size| {
                        rule_placement.width = @intFromFloat(@as(f64, @floatFromInt(area.width)) * size.width);
                        rule_placement.height = @intFromFloat(@as(f64, @floatFromInt(area.height)) * size.height);
                    },
                }
                if (rule_placement.width > 0) preferred.preferred_width = rule_placement.width;
                if (rule_placement.height > 0) preferred.preferred_height = rule_placement.height;
                var resolved = if (rule_placement.x == 0 and rule_placement.y == 0)
                    aqueous.initialFloatingGeometry(all_windows, preferred, area, options, 0) catch floatingRulePlacement(area, preferred, matched, border).geometry
                else
                    floatingRulePlacement(area, preferred, matched, border).geometry;
                const constrained = geometry.constrainSize(resolved.width, resolved.height, geometry.Constraints.fromWindow(preferred), .{});
                resolved.width = constrained.width;
                resolved.height = constrained.height;
                resolved = geometry.keepReachable(resolved, area, @min(resolved.width, area.width), @min(resolved.height, area.height));
                _ = aqueous.window_states.setRuleFloating(window.handle, resolved);
            }
        } else {
            _ = aqueous.window_states.restoreRuleFloating(window.handle);
            state.rule_floating_overridden = false;
        }
        state.rule_floating_requested = matched.placement.floating;
        state.rule_floating_signature = floating_signature;
    }
    return effect;
}

fn handleReloadTimer(aqueous: *Aqueous) c_int {
    defer if (aqueous.reload_timer) |timer| timer.timerUpdate(1000) catch log.warn("unable to re-arm configuration monitor", .{});
    if (@import("../DisplayPreview.zig").active()) return 0;
    const tx = @import("../ConfigTransaction.zig");
    const io = std.Io.Threaded.global_single_threaded.io();
    const lock = tx.Lock.acquire(util.gpa, io, false) catch return 0;
    var lock_held = true;
    defer if (lock_held) lock.release();
    _ = tx.recover(util.gpa, io) catch |err| {
        log.err("configuration recovery rejected: {}", .{err});
        return 0;
    };
    var replacement = config_loader.load(util.gpa) catch return 0;
    const config_changed = replacement.fingerprint != aqueous.config.fingerprint;
    const rules_fingerprint = rules_config.discoveredFingerprint(util.gpa, replacement.wm.rules_path.slice());
    const rules_changed = rules_fingerprint != aqueous.rules.source_fingerprint;
    const output_changed = aqueous.output_service.pollReload();
    if (!config_changed and !rules_changed and !output_changed) return 0;

    aqueous.cancelOverview();
    if (config_changed) {
        aqueous.cancelSnapPreview();
        aqueous.cancelHoverFocus();
        if (replacement.wm.overlay_planes != aqueous.config.wm.overlay_planes) {
            log.warn("render.overlay_planes is startup-only; restart Aqueous to apply the change", .{});
            replacement.wm.overlay_planes = aqueous.config.wm.overlay_planes;
        }
        if (replacement.wm.color_pipeline != aqueous.config.wm.color_pipeline) {
            log.warn("render.color_pipeline is startup-only; restart Aqueous to apply the change", .{});
            replacement.wm.color_pipeline = aqueous.config.wm.color_pipeline;
        }
        preserveTabletPolicy(aqueous, &replacement);
        aqueous.config = replacement;
        if (!aqueous.config.wm.input.mouse_follows_focus) {
            var seats = server.input_manager.seats.iterator(.forward);
            while (seats.next()) |seat| seat.cancelFocusWarp();
        }
        aqueous.api.setLegacyServerDecorationForce(aqueous.config.wm.force_ssd);
        aqueous.api.configureBell(&aqueous.config.wm.bell);
        if (!aqueous.config.wm.input.focus_new_windows) aqueous.pending_new_focus = 0;
    }
    if (config_changed or rules_changed) {
        rules_config.reloadDiscovered(util.gpa, &aqueous.rules, aqueous.config.wm.rules_path.slice());
        aqueous.applyLayerRules();
    }
    lock.release();
    lock_held = false;
    aqueous.globals_applied = false;
    aqueous.api.requestManageCycle();
    log.info("configuration hot-reloaded layout={s}", .{@tagName(aqueous.config.layout.default)});
    if (config_changed or rules_changed) {
        aqueous.applyInputConfig();
        aqueous.runExec(.reload);
        aqueous.notify("Aqueous configuration reloaded", null, false);
    }
    return 0;
}

pub fn layerNativeBlurAllowed(aqueous: *const Aqueous, namespace: []const u8, popup: bool) bool {
    if (!aqueous.mode.runsInternal()) return true;
    const rule = aqueous.rules.resolveLayer(namespace) orelse return true;
    return rule.blur and (!popup or rule.blur_popups);
}

pub fn layerBlurEnabled(aqueous: *const Aqueous, namespace: []const u8) bool {
    if (!aqueous.mode.runsInternal()) return false;
    const rule = aqueous.rules.resolveLayer(namespace) orelse return false;
    return rule.blur;
}

pub fn layerPopupBlurEnabled(
    aqueous: *const Aqueous,
    namespace: []const u8,
) bool {
    if (!aqueous.mode.runsInternal()) return false;
    const rule = aqueous.rules.resolveLayer(namespace) orelse return false;
    return rule.blur and rule.blur_popups;
}

pub fn hasLayerBlurRules(aqueous: *const Aqueous) bool {
    if (!aqueous.mode.runsInternal()) return false;
    for (aqueous.rules.layer_rules) |rule| {
        if (rule.blur) return true;
    }
    return false;
}

fn applyLayerRules(aqueous: *Aqueous) void {
    if (build_options.xwayland) @import("../XwaylandOverrideRedirect.zig").refreshAll();
    server.background_effect_manager.schedule();
    if (!aqueous.mode.runsInternal()) return;
    var surfaces = server.layer_shell.surfaces.iterator();
    while (surfaces.next()) |surface| {
        const namespace = std.mem.span(surface.wlr_layer_surface.namespace);
        surface.applyBlurRule(
            aqueous.layerBlurEnabled(namespace),
            aqueous.layerPopupBlurEnabled(namespace),
        );
    }
}

fn applyGlobalConfig(aqueous: *Aqueous) void {
    const config = aqueous.config.wm;
    const opacity = if (config.opacity_enabled) config.opacity else 1;
    aqueous.api.applyGlobals(
        config.blur_enabled,
        config.blur_radius,
        config.blur_passes,
        .{
            .noise = @floatCast(config.blur_noise),
            .contrast = @floatCast(config.blur_contrast),
            .brightness = @floatCast(config.blur_brightness),
            .vibrancy = @floatCast(config.blur_vibrancy),
            .vibrancy_darkness = @floatCast(config.blur_vibrancy_darkness),
        },
        opacity,
        config.workspace_transition_enabled,
        config.workspace_transition_rate,
    );
}

fn raiseFocusedPlacement(stack: *WorkspaceStack, placements: []const layout_types.Placement, focused: ?layout_types.Handle) void {
    const handle = focused orelse return;
    for (placements) |placement| {
        if (placement.handle != handle or placement.tiled or !placement.visible) continue;
        _ = stack.raise(handle);
        return;
    }
}

/// Raise at request time because the compositor applies keyboard focus in
/// manageFinish(), after policy has already resolved this transaction's scene
/// order. Waiting to observe the new focus would make click-to-raise lag by one
/// unrelated manage cycle.
fn requestFocus(aqueous: *Aqueous, handle: layout_types.Handle) void {
    if (aqueous.window_states.get(handle)) |state| if (!state.focus_allowed) return;
    aqueous.cancelHoverFocus();
    aqueous.api.requestFocusWithCause(handle, null, aqueous.focus_cause);
    aqueous.requestFocusRaise(handle);
}

/// Assign keyboard focus without treating automatic focus recovery as a
/// raise-on-focus interaction. Explicit pointer, directional, cycle, and
/// activation requests continue to use requestFocus() and retain their normal
/// stacking behavior.
fn requestFocusPreservingStack(aqueous: *Aqueous, handle: layout_types.Handle) void {
    if (aqueous.window_states.get(handle)) |state| if (!state.focus_allowed) return;
    aqueous.cancelHoverFocus();
    aqueous.cancelPendingRaise();
    aqueous.api.requestFocusWithCause(handle, null, aqueous.focus_cause);
}

fn requestFocusRaise(aqueous: *Aqueous, handle: layout_types.Handle) void {
    aqueous.cancelPendingRaise();
    if (!aqueous.config.wm.input.raise_on_focus) return;
    const delay = aqueous.config.wm.input.raise_on_focus_delay_ms;
    if (delay == 0 or aqueous.raise_focus_timer == null) {
        aqueous.requested_stack_focus = aqueous.api.resolveModalHandle(handle);
        return;
    }
    aqueous.pending_raise = aqueous.api.resolveModalHandle(handle);
    aqueous.raise_focus_timer.?.timerUpdate(@intCast(delay)) catch {
        log.warn("unable to arm delayed focus raise; raising immediately", .{});
        aqueous.pending_raise = null;
        aqueous.requested_stack_focus = aqueous.api.resolveModalHandle(handle);
    };
}

fn cancelPendingRaise(aqueous: *Aqueous) void {
    aqueous.pending_raise = null;
    if (aqueous.raise_focus_timer) |timer| {
        timer.timerUpdate(0) catch log.warn("unable to disarm delayed focus raise", .{});
    }
}

fn handleRaiseFocusTimer(aqueous: *Aqueous) c_int {
    const handle = aqueous.pending_raise orelse return 0;
    aqueous.pending_raise = null;
    if (aqueous.api.focusedWindow() != handle) return 0;
    aqueous.requested_stack_focus = handle;
    aqueous.api.requestManageCycle();
    return 0;
}

fn clearFocus(aqueous: *Aqueous) void {
    aqueous.cancelHoverFocus();
    aqueous.api.clearFocus();
}

fn scrollingHoverDelayApplies(aqueous: *Aqueous, handle: layout_types.Handle) bool {
    const workspace = aqueous.api.windowWorkspace(handle) orelse return false;
    const state = aqueous.layout_states.getPtr(.{
        .output = workspace.output_id,
        .workspace = workspace.workspace_number,
    }) orelse return false;
    return layout_engine.canResizeScrolling(state, handle);
}

fn cancelHoverFocus(aqueous: *Aqueous) void {
    if (aqueous.hover_focus.cancel()) aqueous.disarmHoverFocusTimer();
}

fn disarmHoverFocusTimer(aqueous: *Aqueous) void {
    if (aqueous.hover_focus_timer) |timer| {
        timer.timerUpdate(0) catch log.warn("unable to disarm scrolling pointer-focus delay", .{});
    }
}

fn handleHoverFocusTimer(aqueous: *Aqueous) c_int {
    const previous_cause = aqueous.focus_cause;
    aqueous.focus_cause = .pointer;
    defer aqueous.focus_cause = previous_cause;
    const pending = aqueous.hover_focus.pending orelse return 0;
    const valid_context = aqueous.mode.runsInternal() and
        aqueous.config.wm.input.focus_follows_mouse and
        !aqueous.api.clientDragActive() and
        aqueous.config.layout.scrolling_focus_follows_mouse_delay_ms > 0 and
        aqueous.scrollingHoverDelayApplies(pending);
    const target = aqueous.hover_focus.expire(
        aqueous.api.hoveredWindow(),
        aqueous.api.focusedWindow(),
        valid_context,
    ) orelse return 0;
    aqueous.requestFocus(target);
    return 0;
}

fn transactionFocus(
    requested: ?layout_types.Handle,
    committed: ?layout_types.Handle,
) ?layout_types.Handle {
    return requested orelse committed;
}

fn intersectRects(a: layout_types.Rect, b: layout_types.Rect) layout_types.Rect {
    const left = @max(a.x, b.x);
    const top = @max(a.y, b.y);
    const right = @min(a.right(), b.right());
    const bottom = @min(a.bottom(), b.bottom());
    return .{
        .x = left,
        .y = top,
        .width = @max(1, right - left),
        .height = @max(1, bottom - top),
    };
}

fn effectiveUsableArea(aqueous: *const Aqueous, area: layout_types.Rect, live_usable_area: layout_types.Rect) layout_types.Rect {
    return intersectRects(live_usable_area, aqueous.config.wm.struts.apply(area));
}

fn ruleLayout(id: Rules.Layout) layout_config.LayoutId {
    return switch (id) {
        .tile => .tile,
        .monocle => .monocle,
        .grid => .grid,
        .rows => .rows,
        .dwindle => .dwindle,
        .reverse_dwindle => .reverse_dwindle,
        .scrolling => .scrolling,
        .floating => .floating,
        .game_mode => .game_mode,
        .composable => .composable,
    };
}

fn floatingPlacement(area: layout_types.Rect, handle: layout_types.Handle, placement: Rules.Placement, border: layout_types.Border) layout_types.Placement {
    const width = @min(area.width, if (placement.width > 0) placement.width else @max(1, @divTrunc(area.width * 3, 5)));
    const height = @min(area.height, if (placement.height > 0) placement.height else @max(1, @divTrunc(area.height * 3, 5)));
    const x = if (placement.x != 0) area.x + placement.x else area.x + @divTrunc(area.width - width, 2);
    const y = if (placement.y != 0) area.y + placement.y else area.y + @divTrunc(area.height - height, 2);
    return .{
        .handle = handle,
        .geometry = .{ .x = x, .y = y, .width = width, .height = height },
        .z_order = stacking.floating_band,
        .visible = true,
        .border = border,
        .tiled = false,
    };
}

fn initialFloatingGeometry(
    aqueous: *Aqueous,
    all_windows: []const layout_types.Window,
    target: layout_types.Window,
    area: layout_types.Rect,
    options: layout_types.Options,
    cascade_index: usize,
) !layout_types.Rect {
    var freeform: std.ArrayListUnmanaged(layout_types.Window) = .empty;
    defer freeform.deinit(util.gpa);
    var temporary: floating_layout.State = .{ .next_cascade = @truncate(cascade_index) };
    defer temporary.deinit(util.gpa);
    for (all_windows) |window| {
        const state = aqueous.window_states.get(window.handle) orelse continue;
        if (window.handle != target.handle and state.presentation != .floating) continue;
        try freeform.append(util.gpa, if (window.handle == target.handle) target else window);
        if (window.handle != target.handle and state.floating_geometry.width > 0 and state.floating_geometry.height > 0) {
            try floating_layout.setGeometry(&temporary, util.gpa, window.handle, state.floating_geometry);
        }
    }
    const placements = try floating_layout.arrange(util.gpa, &temporary, area, freeform.items, null, options);
    defer util.gpa.free(placements);
    for (placements) |placement| if (placement.handle == target.handle) return placement.geometry;
    return error.WindowNotPlaced;
}

fn floatingRulePlacement(area: layout_types.Rect, window: layout_types.Window, rule: Rules.Rule, border: layout_types.Border) layout_types.Placement {
    var placement = rule.placement;
    switch (rule.size) {
        .native => {
            if (placement.width == 0) placement.width = if (window.preferred_width > 0) window.preferred_width else window.min_width;
            if (placement.height == 0) placement.height = if (window.preferred_height > 0) window.preferred_height else window.min_height;
        },
        .pixels => |size| {
            placement.width = size.width;
            placement.height = size.height;
        },
        .fraction => |size| {
            placement.width = @intFromFloat(@as(f64, @floatFromInt(area.width)) * size.width);
            placement.height = @intFromFloat(@as(f64, @floatFromInt(area.height)) * size.height);
        },
    }
    return floatingPlacement(area, window.handle, placement, border);
}

fn gameOptions(rule: Rules.Rule, config: Rules.GameMode, output_area: layout_types.Rect, layout_snapshot: *const layout_config.Snapshot) game_mode.Options {
    return .{
        .size = switch (rule.size) {
            .native => .native,
            .pixels => |size| .{ .pixels = .{ .width = size.width, .height = size.height } },
            .fraction => |size| .{ .fraction = .{ .width = size.width, .height = size.height } },
        },
        .anchor = switch (rule.anchor) {
            .center => .center,
            .top => .top,
            .bottom => .bottom,
            .left => .left,
            .right => .right,
        },
        .scale = rule.scale,
        .remainder = ruleRemainder(config.remainder_layout),
        .fallback = ruleRemainder(config.fallback_layout),
        .gaps_inner = config.gaps_inner,
        .anchor_area = if (rule.ignore_struts) output_area else null,
        .scrolling_options = game_mode.ScrollingOptions{
            .center_focused = layout_snapshot.scrolling_center_focused,
            .column_fraction = layout_snapshot.scrolling_column_fraction,
            .follow_new = layout_snapshot.scrolling_follow_new,
            .open_new_windows_to_right = layout_snapshot.scrolling_open_new_windows_to_right,
            .prefer_vertical_on_portrait = layout_snapshot.scrolling_prefer_vertical_on_portrait,
            .overscroll = layout_snapshot.scrolling_overscroll,
            .snap = layout_snapshot.scrolling_snap,
        },
    };
}

fn gameConfigOptions(config: Rules.GameMode, layout_snapshot: *const layout_config.Snapshot) game_mode.Options {
    return .{
        .remainder = ruleRemainder(config.remainder_layout),
        .fallback = ruleRemainder(config.fallback_layout),
        .gaps_inner = config.gaps_inner,
        .scrolling_options = game_mode.ScrollingOptions{
            .column_fraction = layout_snapshot.scrolling_column_fraction,
            .center_focused = layout_snapshot.scrolling_center_focused,
            .follow_new = layout_snapshot.scrolling_follow_new,
            .open_new_windows_to_right = layout_snapshot.scrolling_open_new_windows_to_right,
            .prefer_vertical_on_portrait = layout_snapshot.scrolling_prefer_vertical_on_portrait,
            .snap = layout_snapshot.scrolling_snap,
            .overscroll = layout_snapshot.scrolling_overscroll,
        },
    };
}

fn ruleRemainder(id: Rules.Layout) game_mode.Remainder {
    return switch (id) {
        .tile => .tile,
        .monocle => .monocle,
        .grid, .game_mode, .composable => .grid,
        .rows => .rows,
        .dwindle => .dwindle,
        .reverse_dwindle => .reverse_dwindle,
        .scrolling => .scrolling,
        .floating => .floating,
    };
}

test "usable area combines layer-shell zones and static struts without double counting" {
    const live: layout_types.Rect = .{ .x = 0, .y = 32, .width = 1920, .height = 1048 };
    const configured: layout_types.Rect = .{ .x = 0, .y = 32, .width = 1920, .height = 1048 };
    try std.testing.expectEqual(configured, intersectRects(live, configured));

    const dock: layout_types.Rect = .{ .x = 48, .y = 0, .width = 1872, .height = 1080 };
    try std.testing.expectEqual(
        layout_types.Rect{ .x = 48, .y = 32, .width = 1872, .height = 1048 },
        intersectRects(dock, configured),
    );
}

test "new-window focus eligibility rejects hidden, minimized, and input-inert windows" {
    try std.testing.expect(admissionFocusEligible(true, .tiled, true));
    try std.testing.expect(admissionFocusEligible(true, .floating, true));
    try std.testing.expect(!admissionFocusEligible(false, .tiled, true));
    try std.testing.expect(!admissionFocusEligible(true, .minimized, true));
    try std.testing.expect(!admissionFocusEligible(true, .tiled, false));
}

test "pending focus drives the transaction before seat focus commits" {
    try std.testing.expectEqual(
        @as(?layout_types.Handle, 22),
        transactionFocus(22, 11),
    );
    try std.testing.expectEqual(
        @as(?layout_types.Handle, 11),
        transactionFocus(null, 11),
    );
}

test "composable action slots accept names and numeric aliases" {
    try std.testing.expectEqual(layout_config.LayoutId.composable, parseLayoutName("composable").?);
    try std.testing.expectEqualStrings("composable", layoutName(.composable));
    try std.testing.expectEqual(layout_config.LayoutId.reverse_dwindle, parseLayoutName("reverse-dwindle").?);
    try std.testing.expectEqual(layout_config.LayoutId.reverse_dwindle, parseLayoutName("reverse_dwindle").?);
    try std.testing.expectEqualStrings("reverse-dwindle", layoutName(.reverse_dwindle));
    try std.testing.expectEqual(@as(?u8, 0), parseComposableSlot("a"));
    try std.testing.expectEqual(@as(?u8, 3), parseComposableSlot("d"));
    try std.testing.expectEqual(@as(?u8, 0), parseComposableSlot("1"));
    try std.testing.expectEqual(@as(?u8, 3), parseComposableSlot("4"));
    try std.testing.expectEqual(@as(?u8, null), parseComposableSlot("e"));
    try std.testing.expectEqual(@as(?u8, null), parseComposableSlot("10"));
}

fn preserveTabletPolicy(aqueous: *Aqueous, replacement: *config_loader.Snapshot) void {
    if (!replacement.wm.input.tablets.valid) {
        log.warn("invalid tablet configuration near line {}: {s}; retaining previous tablet policy", .{ replacement.wm.input.tablets.error_line, replacement.wm.input.tablets.reason });
        replacement.wm.input.tablets = aqueous.config.wm.input.tablets;
    }
}

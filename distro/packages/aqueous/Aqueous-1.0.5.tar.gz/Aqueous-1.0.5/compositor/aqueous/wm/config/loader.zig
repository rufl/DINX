// SPDX-FileCopyrightText: © 2026 Seafoam Labs
// SPDX-License-Identifier: GPL-3.0-only

const std = @import("std");
const instance = @import("../../Instance.zig");
const layout = @import("layout.zig");
const wm = @import("wm.zig");
const actions = @import("actions.zig");

const log = std.log.scoped(.aqueous);
const max_config_bytes = 1024 * 1024;

pub const Snapshot = struct {
    layout: layout.Snapshot = .{},
    wm: wm.Snapshot = .{},
    actions: actions.Snapshot = .{},
    fingerprint: u64 = 0,
    canonical_digest: [64]u8 = @splat(0),
    canonical_generation: [16]u8 = @splat(0),
    tablet_base: @import("tablet").Policy = .{},
};

/// Build a complete replacement snapshot. Callers publish it only after this
/// function returns, so a manage cycle never observes a half-applied reload.
pub fn load(allocator: std.mem.Allocator) !Snapshot {
    const tx = @import("../../ConfigTransaction.zig");
    const io = std.Io.Threaded.global_single_threaded.io();
    const lock = try tx.Lock.acquire(allocator, io, false);
    defer lock.release();
    _ = try tx.recover(allocator, io);
    var snapshot: Snapshot = .{};
    var canonical = try @import("../../ConfigDocument.zig").ConfigFiles.init(allocator);
    defer canonical.deinit();
    snapshot.canonical_digest = @import("../../ConfigDocument.zig").candidateDigest(&canonical);
    snapshot.canonical_generation = @import("../../ConfigDocument.zig").generation(&canonical);
    actions.initDefaults(&snapshot.actions);
    var wm_path_buffer: [std.fs.max_path_bytes]u8 = undefined;
    const env = Environment.read();
    const wm_path = resolveWmPath(&wm_path_buffer, env) orelse return snapshot;
    if (readFile(allocator, wm_path, &snapshot.wm.input.tablets)) |wm_source| {
        defer allocator.free(wm_source);
        snapshot.fingerprint = hashSource(snapshot.fingerprint, wm_source);
        wm.apply(&snapshot.wm, &snapshot.layout, wm_source);
        diagnoseTabletPolicy(wm_path, &snapshot.wm.input.tablets);
        applyActions(&snapshot.actions, wm_source);
    }

    var path_buffer: [std.fs.max_path_bytes]u8 = undefined;
    if (resolveLayoutPath(&path_buffer, env, snapshot.wm.layout_path.slice(), dirname(wm_path))) |path| {
        applyLayoutFile(allocator, &snapshot, path);
    }
    snapshot.wm.bell.resolve(allocator, wm_path);
    snapshot.tablet_base = snapshot.wm.input.tablets;
    if (resolveInputPath(&path_buffer, env, snapshot.wm.input_path.slice())) |path| {
        applyInputFile(allocator, &snapshot, path);
    }
    return snapshot;
}

fn applyActions(snapshot: *actions.Snapshot, source: []const u8) void {
    const Section = enum { none, action, keybinds, custom, gestures, exec, application };
    var section: Section = .none;
    var pending_exec: ?actions.Exec = null;
    var pending_application: ?actions.Application = null;
    var lines = std.mem.splitScalar(u8, source, '\n');
    while (lines.next()) |raw| {
        const line = wm.cleanLine(raw);
        if (line.len == 0) continue;
        if (line[0] == '[') {
            appendExec(snapshot, pending_exec);
            appendApplication(snapshot, pending_application);
            pending_exec = null;
            pending_application = null;
            if (std.mem.eql(u8, line, "[[exec]]")) {
                section = .exec;
                pending_exec = .{};
            } else if (std.mem.eql(u8, line, "[[application]]")) {
                section = .application;
                pending_application = .{};
            } else if (std.mem.eql(u8, line, "[actions]")) section = .action else if (std.mem.eql(u8, line, "[keybinds]")) section = .keybinds else if (std.mem.eql(u8, line, "[keybinds.custom]")) section = .custom else if (std.mem.eql(u8, line, "[gestures]")) section = .gestures else section = .none;
            continue;
        }
        const equal = wm.indexUnquoted(line, '=') orelse continue;
        const raw_key = std.mem.trim(u8, line[0..equal], " \t");
        const key = wm.unquote(raw_key);
        const raw_value = std.mem.trim(u8, line[equal + 1 ..], " \t");
        const value = wm.unquote(raw_value);
        switch (section) {
            .action => {
                if (std.mem.eql(u8, key, "toggle_start_menu")) _ = snapshot.toggle_start_menu.set(value);
                if (std.mem.eql(u8, key, "spawn_terminal")) _ = snapshot.spawn_terminal.set(value);
                if (std.mem.eql(u8, key, "screenshot")) _ = snapshot.screenshot.set(value);
                if (std.mem.eql(u8, key, "lock_screen")) _ = snapshot.lock_screen.set(value);
            },
            .keybinds => actions.addBuiltinList(snapshot, key, raw_value),
            .custom => {
                var decoded: [256]u8 = undefined;
                actions.addBinding(snapshot, key, decodeBasic(value, &decoded) orelse value);
            },
            .exec => if (pending_exec) |*entry| {
                if (std.mem.eql(u8, key, "name")) _ = entry.name.set(value);
                if (std.mem.eql(u8, key, "command")) _ = entry.command.set(value);
                if (std.mem.eql(u8, key, "when")) entry.when = if (std.mem.eql(u8, value, "reload")) .reload else if (std.mem.eql(u8, value, "always")) .always else .startup;
                if (std.mem.eql(u8, key, "once")) entry.once = parseBool(value) orelse entry.once;
                if (std.mem.eql(u8, key, "restart")) entry.restart = parseBool(value) orelse entry.restart;
                if (std.mem.eql(u8, key, "log")) _ = entry.log_path.set(value);
                if (std.mem.eql(u8, key, "env")) _ = entry.env.set(raw_value);
            },
            .application => if (pending_application) |*application| {
                if (std.mem.eql(u8, key, "name")) _ = application.name.set(value);
                if (std.mem.eql(u8, key, "desktop_id")) _ = application.desktop_id.set(value);
                if (std.mem.eql(u8, key, "command")) _ = application.command.set(value);
                if (std.mem.eql(u8, key, "args")) parseApplicationArgs(application, raw_value);
                if (std.mem.eql(u8, key, "env")) parseApplicationEnv(application, raw_value);
            },
            .gestures => {
                const gesture = parseGestureKey(key) orelse continue;
                var decoded: [256]u8 = undefined;
                actions.addGesture(snapshot, gesture.kind, gesture.direction, gesture.fingers, decodeBasic(value, &decoded) orelse value);
            },
            .none => {},
        }
    }
    appendExec(snapshot, pending_exec);
    appendApplication(snapshot, pending_application);
}

fn appendExec(snapshot: *actions.Snapshot, pending: ?actions.Exec) void {
    const entry = pending orelse return;
    if (entry.name.empty() or entry.command.empty() or snapshot.exec_count == actions.max_exec) return;
    snapshot.exec[snapshot.exec_count] = entry;
    snapshot.exec_count += 1;
}

fn appendApplication(snapshot: *actions.Snapshot, pending: ?actions.Application) void {
    const application = pending orelse return;
    if (application.name.empty() or application.command.empty() or application.command.slice()[0] != '/') return;
    for (snapshot.applications[0..snapshot.application_count], 0..) |existing, index| {
        if (std.mem.eql(u8, existing.name.slice(), application.name.slice())) {
            snapshot.applications[index] = application;
            return;
        }
    }
    if (snapshot.application_count == actions.max_applications) return;
    snapshot.applications[snapshot.application_count] = application;
    snapshot.application_count += 1;
}

fn parseApplicationArgs(application: *actions.Application, raw_value: []const u8) void {
    application.arg_count = 0;
    var rest = std.mem.trim(u8, raw_value, " \t");
    if (rest.len < 2 or rest[0] != '[' or rest[rest.len - 1] != ']') return;
    rest = rest[1 .. rest.len - 1];
    while (rest.len != 0 and application.arg_count < actions.max_application_args) {
        const comma = wm.indexUnquoted(rest, ',') orelse rest.len;
        const raw_item = std.mem.trim(u8, rest[0..comma], " \t");
        if (raw_item.len != 0) {
            const value = wm.unquote(raw_item);
            var decoded: [256]u8 = undefined;
            if (application.args[application.arg_count].set(decodeBasic(value, &decoded) orelse value)) {
                application.arg_count += 1;
            }
        }
        if (comma == rest.len) break;
        rest = rest[comma + 1 ..];
    }
}

fn parseApplicationEnv(application: *actions.Application, raw_value: []const u8) void {
    application.env_count = 0;
    var rest = std.mem.trim(u8, raw_value, " \t");
    if (rest.len < 2 or rest[0] != '{' or rest[rest.len - 1] != '}') return;
    rest = rest[1 .. rest.len - 1];
    while (rest.len != 0 and application.env_count < actions.max_application_env) {
        const comma = wm.indexUnquoted(rest, ',') orelse rest.len;
        const pair = std.mem.trim(u8, rest[0..comma], " \t");
        if (wm.indexUnquoted(pair, '=')) |equal| {
            const name = std.mem.trim(u8, pair[0..equal], " \t");
            const raw_env_value = std.mem.trim(u8, pair[equal + 1 ..], " \t");
            if (validEnvironmentName(name)) {
                var variable: actions.EnvironmentVariable = .{};
                const value = wm.unquote(raw_env_value);
                var decoded: [256]u8 = undefined;
                if (variable.name.set(name) and variable.value.set(decodeBasic(value, &decoded) orelse value)) {
                    application.env[application.env_count] = variable;
                    application.env_count += 1;
                }
            }
        }
        if (comma == rest.len) break;
        rest = rest[comma + 1 ..];
    }
}

fn validEnvironmentName(name: []const u8) bool {
    if (name.len == 0 or !(std.ascii.isAlphabetic(name[0]) or name[0] == '_')) return false;
    for (name[1..]) |char| if (!(std.ascii.isAlphanumeric(char) or char == '_')) return false;
    return true;
}

fn applyGestures(snapshot: *actions.Snapshot, source: []const u8) void {
    var in_gestures = false;
    var lines = std.mem.splitScalar(u8, source, '\n');
    while (lines.next()) |raw| {
        const line = wm.cleanLine(raw);
        if (line.len == 0) continue;
        if (line[0] == '[') {
            in_gestures = std.mem.eql(u8, line, "[gestures]");
            continue;
        }
        if (!in_gestures) continue;

        const equal = wm.indexUnquoted(line, '=') orelse continue;
        const key = wm.unquote(std.mem.trim(u8, line[0..equal], " \t"));
        const gesture = parseGestureKey(key) orelse continue;
        const raw_value = std.mem.trim(u8, line[equal + 1 ..], " \t");
        const value = wm.unquote(raw_value);
        var decoded: [256]u8 = undefined;
        actions.addGesture(snapshot, gesture.kind, gesture.direction, gesture.fingers, decodeBasic(value, &decoded) orelse value);
    }
}

const ParsedGestureKey = struct {
    kind: actions.GestureKind,
    direction: actions.GestureDirection,
    fingers: u8,
};

fn parseGestureKey(key: []const u8) ?ParsedGestureKey {
    var parts = std.mem.splitScalar(u8, key, '_');

    const kind_text = parts.next() orelse return null;
    const fingers_text = parts.next() orelse return null;
    const direction_text = parts.next() orelse return null;

    // Reject extra components such as swipe_3_left_extra.
    if (parts.next() != null) return null;

    const kind = std.meta.stringToEnum(
        actions.GestureKind,
        kind_text,
    ) orelse return null;

    const direction = std.meta.stringToEnum(
        actions.GestureDirection,
        direction_text,
    ) orelse return null;

    const fingers = std.fmt.parseInt(
        u8,
        fingers_text,
        10,
    ) catch return null;

    if (fingers == 0) return null;

    // Only accept directions meaningful for each gesture type.
    switch (kind) {
        .swipe => switch (direction) {
            .left, .right, .up, .down => {},
            .in, .out => return null,
        },
        .pinch => switch (direction) {
            .in, .out => {},
            .left, .right, .up, .down => return null,
        },
    }

    return .{
        .kind = kind,
        .direction = direction,
        .fingers = fingers,
    };
}

pub fn decodeBasic(value: []const u8, buffer: []u8) ?[]const u8 {
    var read: usize = 0;
    var write: usize = 0;
    while (read < value.len) : (read += 1) {
        if (write == buffer.len) return null;
        if (value[read] == '\\' and read + 1 < value.len) {
            read += 1;
            buffer[write] = switch (value[read]) {
                'n' => '\n',
                'r' => '\r',
                't' => '\t',
                else => value[read],
            };
        } else buffer[write] = value[read];
        write += 1;
    }
    return buffer[0..write];
}

fn parseBool(value: []const u8) ?bool {
    if (std.mem.eql(u8, value, "true")) return true;
    if (std.mem.eql(u8, value, "false")) return false;
    return null;
}

test "actions custom bindings and exec are immutable snapshot data" {
    var snapshot: actions.Snapshot = .{};
    actions.initDefaults(&snapshot);
    applyActions(&snapshot,
        \\[actions]
        \\spawn_terminal = "foot"
        \\screenshot = "shot-region"
        \\[keybinds]
        \\screenshot = "PrintScreen"
        \\cycle_focus = []
        \\[keybinds.custom]
        \\"Super+E" = "spawn:nemo"
        \\"CapsLock" = "spawn:wpctl set-mute @DEFAULT_AUDIO_SINK@ toggle"
        \\[gestures]
        \\swipe_3_left = "builtin:focus_workspace_down"
        \\swipe_3_right = "builtin:focus_workspace_up"
        \\pinch_4_in = "builtin:toggle_start_menu"
        \\[[exec]]
        \\name = "agent"
        \\command = "agent --daemon"
        \\when = "always"
        \\restart = true
        \\log = "/tmp/agent.log"
        \\env = { MODE = "native" }
    );
    try std.testing.expectEqualStrings("foot", snapshot.spawn_terminal.slice());
    try std.testing.expectEqualStrings("shot-region", snapshot.screenshot.slice());
    const print = actions.parseChord("Print").?;
    try std.testing.expectEqualStrings("builtin:screenshot", snapshot.find(print.keysym, print.modifiers).?);
    try std.testing.expectEqualStrings("spawn:nemo", snapshot.find('e', 64).?);
    const caps_lock = actions.parseChord("CapsLock").?;
    try std.testing.expectEqualStrings(
        "spawn:wpctl set-mute @DEFAULT_AUDIO_SINK@ toggle",
        snapshot.find(caps_lock.keysym, caps_lock.modifiers).?,
    );
    try std.testing.expectEqual(@as(u8, 1), snapshot.exec_count);
    try std.testing.expectEqual(actions.ExecWhen.always, snapshot.exec[0].when);
    try std.testing.expect(snapshot.exec[0].restart);
    try std.testing.expectEqualStrings("/tmp/agent.log", snapshot.exec[0].log_path.slice());
    try std.testing.expectEqualStrings("{ MODE = \"native\" }", snapshot.exec[0].env.slice());
    try std.testing.expectEqual(@as(u8, 3), snapshot.gestures_count);

    try std.testing.expectEqual(
        actions.GestureKind.swipe,
        snapshot.gestures[0].kind,
    );
    try std.testing.expectEqual(
        actions.GestureDirection.left,
        snapshot.gestures[0].direction,
    );
    try std.testing.expectEqual(@as(u8, 3), snapshot.gestures[0].fingers);
    try std.testing.expectEqualStrings(
        "builtin:focus_workspace_down",
        snapshot.gestures[0].verb.slice(),
    );

    try std.testing.expectEqual(
        actions.GestureKind.pinch,
        snapshot.gestures[2].kind,
    );
    try std.testing.expectEqual(
        actions.GestureDirection.in,
        snapshot.gestures[2].direction,
    );
    try std.testing.expectEqual(@as(u8, 4), snapshot.gestures[2].fingers);
}

test "application profiles parse typed argv and environment without a shell" {
    var snapshot: actions.Snapshot = .{};
    applyActions(&snapshot,
        \\[[application]]
        \\name = "vesktop-ssd"
        \\desktop_id = "vesktop.desktop"
        \\command = "/usr/bin/vesktop"
        \\args = ["--enable-features=WaylandWindowDecorations", "two words"]
        \\env = { ELECTRON_OZONE_PLATFORM_HINT = "auto", APP_MODE = "native" }
    );

    try std.testing.expectEqual(@as(u8, 1), snapshot.application_count);
    const application = snapshot.findApplication("vesktop-ssd").?;
    try std.testing.expectEqualStrings("vesktop.desktop", application.desktop_id.slice());
    try std.testing.expectEqualStrings("/usr/bin/vesktop", application.command.slice());
    try std.testing.expectEqual(@as(u8, 2), application.arg_count);
    try std.testing.expectEqualStrings("--enable-features=WaylandWindowDecorations", application.args[0].slice());
    try std.testing.expectEqualStrings("two words", application.args[1].slice());
    try std.testing.expectEqual(@as(u8, 2), application.env_count);
    try std.testing.expectEqualStrings("ELECTRON_OZONE_PLATFORM_HINT", application.env[0].name.slice());
    try std.testing.expectEqualStrings("auto", application.env[0].value.slice());
}

test "application profiles require absolute commands and replace duplicate names" {
    var snapshot: actions.Snapshot = .{};
    applyActions(&snapshot,
        \\[[application]]
        \\name = "ignored"
        \\command = "vesktop"
        \\[[application]]
        \\name = "editor"
        \\command = "/usr/bin/zed"
        \\[[application]]
        \\name = "editor"
        \\command = "/usr/bin/zeditor"
    );

    try std.testing.expectEqual(@as(u8, 1), snapshot.application_count);
    try std.testing.expectEqualStrings("/usr/bin/zeditor", snapshot.findApplication("editor").?.command.slice());
}

test "overview binding supports defaults overrides unbinds and duplicate chords" {
    var snapshot: actions.Snapshot = .{};
    actions.initDefaults(&snapshot);
    const default = actions.parseChord("Super+W").?;
    try std.testing.expectEqualStrings(
        "builtin:toggle_overview",
        snapshot.find(default.keysym, default.modifiers).?,
    );

    applyActions(&snapshot,
        \\[keybinds]
        \\toggle_overview = ["Alt+W", "Super+O"]
    );
    try std.testing.expect(snapshot.find(default.keysym, default.modifiers) == null);
    const alternate = actions.parseChord("Alt+W").?;
    const second = actions.parseChord("Super+O").?;
    try std.testing.expectEqualStrings(
        "builtin:toggle_overview",
        snapshot.find(alternate.keysym, alternate.modifiers).?,
    );
    try std.testing.expectEqualStrings(
        "builtin:toggle_overview",
        snapshot.find(second.keysym, second.modifiers).?,
    );

    applyActions(&snapshot,
        \\[keybinds]
        \\toggle_overview = []
    );
    try std.testing.expect(snapshot.find(alternate.keysym, alternate.modifiers) == null);
    try std.testing.expect(snapshot.find(second.keysym, second.modifiers) == null);

    applyActions(&snapshot,
        \\[keybinds]
        \\toggle_overview = "Super+W"
        \\close_focused = "Super+W"
    );
    try std.testing.expectEqualStrings(
        "builtin:close_focused",
        snapshot.find(default.keysym, default.modifiers).?,
    );
}

test "gesture parser rejects malformed and incompatible keys" {
    try std.testing.expect(parseGestureKey("swipe_3_left") != null);
    try std.testing.expect(parseGestureKey("pinch_4_in") != null);

    try std.testing.expect(parseGestureKey("swipe_3_in") == null);
    try std.testing.expect(parseGestureKey("pinch_4_left") == null);
    try std.testing.expect(parseGestureKey("swipe_0_left") == null);
    try std.testing.expect(parseGestureKey("swipe_three_left") == null);
    try std.testing.expect(parseGestureKey("swipe_3_left_extra") == null);
}

pub const Environment = struct {
    xdg: ?[]const u8,
    home: ?[]const u8,
    wm_override: ?[]const u8,
    layout_override: ?[]const u8,
    input_override: ?[]const u8,

    pub fn read() Environment {
        return .{
            .xdg = getenv("XDG_CONFIG_HOME"),
            .home = getenv("HOME"),
            .wm_override = getenv("AQUEOUS_CONFIG"),
            .layout_override = getenv("AQUEOUS_LAYOUT"),
            .input_override = getenv("AQUEOUS_INPUT"),
        };
    }
};

fn getenv(name: [*:0]const u8) ?[]const u8 {
    const value = std.c.getenv(name) orelse return null;
    const result = std.mem.span(value);
    return if (result.len == 0) null else result;
}

pub fn resolveWmPath(buffer: []u8, env: Environment) ?[]const u8 {
    return resolveWmPathWithExists(buffer, env, exists);
}

fn resolveWmPathWithExists(buffer: []u8, env: Environment, path_exists: *const fn ([]const u8) bool) ?[]const u8 {
    if (env.wm_override) |path| return expandHome(buffer, path, env.home);
    if (env.xdg) |xdg| {
        const candidate = std.fmt.bufPrint(buffer, "{s}/" ++ instance.name ++ "/wm.toml", .{xdg}) catch return null;
        if (path_exists(candidate)) return candidate;
    }
    if (env.home) |home| {
        const candidate = std.fmt.bufPrint(buffer, "{s}/.config/" ++ instance.name ++ "/wm.toml", .{home}) catch return null;
        if (path_exists(candidate)) return candidate;
    }
    if (path_exists("/etc/xdg/" ++ instance.name ++ "/wm.toml")) return std.fmt.bufPrint(buffer, "/etc/xdg/" ++ instance.name ++ "/wm.toml", .{}) catch null;
    return null;
}

/// Kept as the stable pure helper used by existing tests and downstream code.
pub fn resolvePath(buffer: []u8, xdg_config_home: ?[]const u8, home: ?[]const u8, filename: []const u8) ?[]const u8 {
    if (xdg_config_home) |base| {
        if (base.len == 0) return null;
        return std.fmt.bufPrint(buffer, "{s}/" ++ instance.name ++ "/{s}", .{ base, filename }) catch null;
    }
    const base = home orelse return null;
    if (base.len == 0) return null;
    return std.fmt.bufPrint(buffer, "{s}/.config/" ++ instance.name ++ "/{s}", .{ base, filename }) catch null;
}

pub fn resolveLayoutPath(buffer: []u8, env: Environment, configured: []const u8, wm_dir: []const u8) ?[]const u8 {
    // Preserve the C# reader's unusual compatibility order: the traditional
    // HOME location wins before explicit sidecar overrides when it exists.
    if (env.home) |home| {
        const candidate = std.fmt.bufPrint(buffer, "{s}/.config/" ++ instance.name ++ "/layout.toml", .{home}) catch return null;
        if (exists(candidate)) return candidate;
    }
    if (env.layout_override) |path| return expandHome(buffer, path, env.home);
    if (configured.len > 0) {
        if (std.fs.path.isAbsolute(configured)) return expandHome(buffer, configured, env.home);
        return std.fmt.bufPrint(buffer, "{s}/{s}", .{ wm_dir, configured }) catch null;
    }
    if (env.xdg) |xdg| {
        const candidate = std.fmt.bufPrint(buffer, "{s}/" ++ instance.name ++ "/layout.toml", .{xdg}) catch return null;
        if (exists(candidate)) return candidate;
    }
    if (exists("/etc/xdg/" ++ instance.name ++ "/layout.toml")) return std.fmt.bufPrint(buffer, "/etc/xdg/" ++ instance.name ++ "/layout.toml", .{}) catch null;
    return null;
}

pub fn resolveInputPath(buffer: []u8, env: Environment, configured: []const u8) ?[]const u8 {
    if (env.input_override) |path| return expandHome(buffer, path, env.home);
    if (configured.len > 0) return expandHome(buffer, configured, env.home);
    if (env.xdg) |xdg| {
        const candidate = std.fmt.bufPrint(buffer, "{s}/" ++ instance.name ++ "/input.toml", .{xdg}) catch return null;
        if (exists(candidate)) return candidate;
    }
    if (env.home) |home| {
        const candidate = std.fmt.bufPrint(buffer, "{s}/.config/" ++ instance.name ++ "/input.toml", .{home}) catch return null;
        if (exists(candidate)) return candidate;
    }
    if (exists("/etc/xdg/" ++ instance.name ++ "/input.toml")) return std.fmt.bufPrint(buffer, "/etc/xdg/" ++ instance.name ++ "/input.toml", .{}) catch null;
    return null;
}

fn applyLayoutFile(allocator: std.mem.Allocator, snapshot: *Snapshot, path: []const u8) void {
    const source = readFile(allocator, path, &snapshot.wm.input.tablets) orelse return;
    defer allocator.free(source);
    snapshot.fingerprint = hashSource(snapshot.fingerprint, source);
    applyLayoutSource(snapshot, source);
    diagnoseTabletPolicy(path, &snapshot.wm.input.tablets);
}

fn applyLayoutSource(snapshot: *Snapshot, source: []const u8) void {
    // The sidecar contains more than engine options: existing configurations
    // also place [[output]] and [[workspace]] layout mappings here. Route it
    // through the combined parser so those mappings and [layout] flags such as
    // force_ssd are retained; wm.apply delegates the layout-specific tables to
    // layout.apply at the end.
    wm.apply(&snapshot.wm, &snapshot.layout, source);
}

fn applyInputFile(allocator: std.mem.Allocator, snapshot: *Snapshot, path: []const u8) void {
    const source = readFile(allocator, path, &snapshot.wm.input.tablets) orelse return;
    defer allocator.free(source);
    snapshot.fingerprint = hashSource(snapshot.fingerprint, source);
    applyInputSource(snapshot, source);
    diagnoseTabletPolicy(path, &snapshot.wm.input.tablets);
}

fn diagnoseTabletPolicy(path: []const u8, policy: *const @import("tablet").Policy) void {
    if (!policy.valid) log.warn("{s}: tablet rule '{s}' near line {}: {s}", .{ path, policy.error_id.slice(), policy.error_line, policy.reason });
}

fn applyInputSource(snapshot: *Snapshot, source: []const u8) void {
    // Parse into a temporary default and merge only fields actually represented
    // by the input sidecar's sections. The parser ignores all unrelated tables.
    var overlay_wm: wm.Snapshot = .{};
    var ignored_layout: layout.Snapshot = .{};
    wm.apply(&overlay_wm, &ignored_layout, source);
    mergeInput(&snapshot.wm.input, overlay_wm.input);
    applyGestures(&snapshot.actions, source);
}

test "tablet sidecar replaces inherited rules completely and appends in priority order" {
    var snapshot: Snapshot = .{};
    wm.apply(&snapshot.wm, &snapshot.layout, "[[input.tablet]]\nid='pen'\nmatch_vendor=0x056a\nmatch_product=0x033b\noutput='DP-1'\n" ++
        "[[input.tablet]]\nid='later'\nmatch_name='Pen'\noutput='DP-2'\n");
    applyInputSource(&snapshot, "[[input.tablet]]\nid='pen'\nmatch_name='Pen'\nenabled=false\n");
    const p = &snapshot.wm.input.tablets;
    try std.testing.expect(p.valid and p.count == 2);
    const selected = p.select(.{ .name = "Pen" }).?;
    try std.testing.expect(!selected.enabled and selected.match_vendor == null and selected.output.empty());
    try std.testing.expectEqualStrings("pen", selected.id.slice());
    applyInputSource(&snapshot, "[[input.tablet]]\nid='invalid'\nmatch_name='Pen'\noutput=42\n");
    try std.testing.expect(!p.valid);
}

fn mergeInput(base: *wm.Input, overlay: wm.Input) void {
    base.tablets.overlay(&overlay.tablets);
    const defaults: wm.Input = .{};
    if (overlay.focus_follows_mouse != defaults.focus_follows_mouse) base.focus_follows_mouse = overlay.focus_follows_mouse;
    if (overlay.mouse_follows_focus_set) {
        base.mouse_follows_focus = overlay.mouse_follows_focus;
        base.mouse_follows_focus_set = true;
    }
    if (overlay.focus_new_windows_set) {
        base.focus_new_windows = overlay.focus_new_windows;
        base.focus_new_windows_set = true;
    }
    if (overlay.focus_crosses_workspaces_set) {
        base.focus_crosses_workspaces = overlay.focus_crosses_workspaces;
        base.focus_crosses_workspaces_set = true;
    }
    if (overlay.raise_on_focus_set) {
        base.raise_on_focus = overlay.raise_on_focus;
        base.raise_on_focus_set = true;
    }
    if (overlay.raise_on_focus_delay_set) {
        base.raise_on_focus_delay_ms = overlay.raise_on_focus_delay_ms;
        base.raise_on_focus_delay_set = true;
    }
    if (overlay.pointer_acceleration != defaults.pointer_acceleration) base.pointer_acceleration = overlay.pointer_acceleration;
    if (overlay.pointer_acceleration_factor != defaults.pointer_acceleration_factor) base.pointer_acceleration_factor = overlay.pointer_acceleration_factor;
    if (overlay.repeat_rate_set) {
        base.repeat_rate = overlay.repeat_rate;
        base.repeat_rate_set = true;
    }
    if (overlay.repeat_delay_set) {
        base.repeat_delay = overlay.repeat_delay;
        base.repeat_delay_set = true;
    }
    if (overlay.num_lock_state_set) {
        base.num_lock_state = overlay.num_lock_state;
        base.num_lock_state_set = true;
    }
    mergeDevice(&base.mouse, overlay.mouse);
    mergeDevice(&base.touchpad, overlay.touchpad);
    mergeDevice(&base.trackpoint, overlay.trackpoint);
    if (!overlay.xkb_layout.empty()) base.xkb_layout = overlay.xkb_layout;
    if (!overlay.xkb_variant.empty()) base.xkb_variant = overlay.xkb_variant;
    if (!overlay.xkb_options.empty()) base.xkb_options = overlay.xkb_options;
}

fn mergeDevice(base: *wm.Device, overlay: wm.Device) void {
    if (overlay.accel_profile != .unset) base.accel_profile = overlay.accel_profile;
    if (overlay.accel_speed != null) base.accel_speed = overlay.accel_speed;
    if (overlay.natural_scroll != null) base.natural_scroll = overlay.natural_scroll;
    if (overlay.tap != null) base.tap = overlay.tap;
    if (overlay.dwt != null) base.dwt = overlay.dwt;
    if (overlay.left_handed != null) base.left_handed = overlay.left_handed;
    if (overlay.click_method != .unset) base.click_method = overlay.click_method;
    if (overlay.scroll_method != .unset) base.scroll_method = overlay.scroll_method;
    if (overlay.middle_emulation != null) base.middle_emulation = overlay.middle_emulation;
}

test "input sidecar Num Lock overrides inherited values in both directions" {
    for ([_]bool{ false, true }) |inherited| {
        var snapshot: Snapshot = .{};
        wm.apply(&snapshot.wm, &snapshot.layout, if (inherited)
            "[input]\nnum_lock_state = true"
        else
            "[input]\nnum_lock_state = false");
        applyInputSource(&snapshot, if (inherited)
            "[input]\nnum_lock_state = false"
        else
            "[input]\nnum_lock_state = true");
        try std.testing.expectEqual(!inherited, snapshot.wm.input.num_lock_state);
        try std.testing.expect(snapshot.wm.input.num_lock_state_set);
    }
}

test "input sidecar Num Lock defaults presence and malformed values" {
    var snapshot: Snapshot = .{};
    try std.testing.expect(!snapshot.wm.input.num_lock_state);
    try std.testing.expect(!snapshot.wm.input.num_lock_state_set);
    applyInputSource(&snapshot, "[input]\nnum_lock_state = invalid");
    try std.testing.expect(!snapshot.wm.input.num_lock_state_set);
    applyInputSource(&snapshot, "[input]\nnum_lock_state = true");
    try std.testing.expect(snapshot.wm.input.num_lock_state);
    try std.testing.expect(snapshot.wm.input.num_lock_state_set);
    applyInputSource(&snapshot, "[input]\nrepeat_rate = 55");
    try std.testing.expect(snapshot.wm.input.num_lock_state);
    applyInputSource(&snapshot, "[input]\nnum_lock_state = invalid");
    try std.testing.expect(snapshot.wm.input.num_lock_state);
    applyInputSource(&snapshot, "[input]\nnum_lock_state = false");
    try std.testing.expect(!snapshot.wm.input.num_lock_state);
    try std.testing.expect(snapshot.wm.input.num_lock_state_set);
}

test "removing Num Lock sidecar override restores inherited policy on reload" {
    const wm_source = "[input]\nnum_lock_state = true";
    var initial: Snapshot = .{};
    wm.apply(&initial.wm, &initial.layout, wm_source);
    applyInputSource(&initial, "[input]\nnum_lock_state = false");
    try std.testing.expect(!initial.wm.input.num_lock_state);

    // Reload builds a fresh snapshot from wm.toml before applying the sidecar.
    var replacement: Snapshot = .{};
    wm.apply(&replacement.wm, &replacement.layout, wm_source);
    applyInputSource(&replacement, "[input]\nrepeat_rate = 55");
    try std.testing.expect(replacement.wm.input.num_lock_state);
}

test "input sidecar repeat settings override inherited values including defaults" {
    var base: wm.Input = .{
        .repeat_rate = 75,
        .repeat_rate_set = true,
        .repeat_delay = 150,
        .repeat_delay_set = true,
    };
    var overlay_wm: wm.Snapshot = .{};
    var ignored_layout: layout.Snapshot = .{};
    wm.apply(&overlay_wm, &ignored_layout,
        \\[input]
        \\repeat_rate = 40
        \\repeat_delay = 400
    );
    mergeInput(&base, overlay_wm.input);

    try std.testing.expectEqual(@as(u31, 40), base.repeat_rate);
    try std.testing.expectEqual(@as(u31, 400), base.repeat_delay);
}

test "input sidecar can explicitly disable new-window focus" {
    var base: wm.Input = .{ .focus_new_windows = true, .focus_new_windows_set = true };
    var overlay_wm: wm.Snapshot = .{};
    var ignored_layout: layout.Snapshot = .{};
    wm.apply(&overlay_wm, &ignored_layout,
        \\[input]
        \\focus_new_windows = false
    );

    mergeInput(&base, overlay_wm.input);

    try std.testing.expect(!base.focus_new_windows);
    try std.testing.expect(base.focus_new_windows_set);
}

test "input sidecar applies gestures and overrides matching wm bindings" {
    var snapshot: Snapshot = .{};
    actions.initDefaults(&snapshot.actions);
    applyActions(&snapshot.actions,
        \\[gestures]
        \\swipe_3_left = "builtin:focus_workspace_down"
    );

    applyInputSource(&snapshot,
        \\[input]
        \\repeat_rate = 55
        \\[gestures]
        \\swipe_3_left = "builtin:focus_workspace_up"
        \\pinch_4_in = "builtin:toggle_start_menu"
        \\[keybinds.custom]
        \\"Super+E" = "spawn:nemo"
    );

    try std.testing.expectEqual(@as(u31, 55), snapshot.wm.input.repeat_rate);
    try std.testing.expectEqual(@as(u8, 2), snapshot.actions.gestures_count);
    try std.testing.expectEqualStrings(
        "builtin:focus_workspace_up",
        snapshot.actions.findGesture(.swipe, .left, 3).?,
    );
    try std.testing.expectEqualStrings(
        "builtin:toggle_start_menu",
        snapshot.actions.findGesture(.pinch, .in, 4).?,
    );
    try std.testing.expect(snapshot.actions.find('e', 64) == null);
}

test "layout sidecar applies workspace mappings as well as layout engines" {
    var snapshot: Snapshot = .{};
    applyLayoutSource(&snapshot,
        \\[layout]
        \\default = "game-mode"
        \\force_ssd = true
        \\[layout.slots]
        \\primary = "tile"
        \\[[workspace]]
        \\workspace = 2
        \\layout = "dwindle"
        \\[[workspace]]
        \\workspace = 3
        \\layout = "tile"
    );

    try std.testing.expectEqual(layout.LayoutId.game_mode, snapshot.layout.default);
    try std.testing.expectEqual(layout.LayoutId.tile, snapshot.layout.slots[0]);
    try std.testing.expect(snapshot.wm.force_ssd);
    try std.testing.expectEqual(layout.LayoutId.dwindle, snapshot.wm.resolveWorkspace(null, 2).?);
    try std.testing.expectEqual(layout.LayoutId.tile, snapshot.wm.resolveWorkspace(null, 3).?);
}

test "layout sidecar retains composable region tables" {
    var snapshot: Snapshot = .{};
    applyLayoutSource(&snapshot,
        \\[layout]
        \\default = "composable"
        \\[layout.composable.a]
        \\layout = "rows"
        \\p1 = [0.0, 0.0]
        \\p2 = [1.0, 0.0]
        \\p3 = [1.0, 1.0]
        \\p4 = [0.0, 1.0]
    );

    try std.testing.expectEqual(layout.LayoutId.composable, snapshot.layout.default);
    try std.testing.expect(snapshot.layout.composableValid());
    try std.testing.expectEqual(layout.LayoutId.rows, snapshot.layout.composable[0].layout);
}

fn readFile(allocator: std.mem.Allocator, path: []const u8, tablets: *@import("tablet").Policy) ?[]u8 {
    const io = std.Io.Threaded.global_single_threaded.io();
    return std.Io.Dir.readFileAlloc(std.Io.Dir.cwd(), io, path, allocator, .limited(max_config_bytes)) catch |err| switch (err) {
        error.FileNotFound => null,
        else => {
            log.warn("unable to read {s}: {}", .{ path, err });
            tablets.valid = false;
            tablets.reason = @errorName(err);
            return null;
        },
    };
}

fn exists(path: []const u8) bool {
    const io = std.Io.Threaded.global_single_threaded.io();
    std.Io.Dir.cwd().access(io, path, .{}) catch return false;
    return true;
}

fn expandHome(buffer: []u8, path: []const u8, home: ?[]const u8) ?[]const u8 {
    if (path.len > 0 and path[0] == '~') {
        const base = home orelse return null;
        return std.fmt.bufPrint(buffer, "{s}{s}", .{ base, path[1..] }) catch null;
    }
    return std.fmt.bufPrint(buffer, "{s}", .{path}) catch null;
}

fn dirname(path: []const u8) []const u8 {
    return std.fs.path.dirname(path) orelse ".";
}

fn hashSource(seed: u64, source: []const u8) u64 {
    var hash = std.hash.Wyhash.init(seed);
    hash.update(source);
    return hash.final();
}

test "config paths prefer XDG and fall back to HOME" {
    var buffer: [256]u8 = undefined;
    try std.testing.expectEqualStrings("/xdg/" ++ instance.name ++ "/wm.toml", resolvePath(&buffer, "/xdg", "/home/test", "wm.toml").?);
    try std.testing.expectEqualStrings("/home/test/.config/" ++ instance.name ++ "/layout.toml", resolvePath(&buffer, null, "/home/test", "layout.toml").?);
    try std.testing.expectEqual(@as(?[]const u8, null), resolvePath(&buffer, null, null, "wm.toml"));
}

test "explicit config path expands home" {
    var buffer: [256]u8 = undefined;
    const env: Environment = .{ .xdg = null, .home = "/home/test", .wm_override = "~/wm.toml", .layout_override = null, .input_override = null };
    try std.testing.expectEqualStrings("/home/test/wm.toml", resolveWmPath(&buffer, env).?);
}

fn xdgAndHomeWmExist(path: []const u8) bool {
    return std.mem.eql(u8, path, "/xdg/" ++ instance.name ++ "/wm.toml") or
        std.mem.eql(u8, path, "/home/test/.config/" ++ instance.name ++ "/wm.toml");
}

fn homeWmExists(path: []const u8) bool {
    return std.mem.eql(u8, path, "/home/test/.config/" ++ instance.name ++ "/wm.toml");
}

fn systemWmExists(path: []const u8) bool {
    return std.mem.eql(u8, path, "/etc/xdg/" ++ instance.name ++ "/wm.toml");
}

test "wm config discovery checks XDG HOME and system fallback in order" {
    const env: Environment = .{ .xdg = "/xdg", .home = "/home/test", .wm_override = null, .layout_override = null, .input_override = null };
    var buffer: [256]u8 = undefined;
    try std.testing.expectEqualStrings("/xdg/" ++ instance.name ++ "/wm.toml", resolveWmPathWithExists(&buffer, env, xdgAndHomeWmExist).?);
    try std.testing.expectEqualStrings("/home/test/.config/" ++ instance.name ++ "/wm.toml", resolveWmPathWithExists(&buffer, env, homeWmExists).?);
    try std.testing.expectEqualStrings("/etc/xdg/" ++ instance.name ++ "/wm.toml", resolveWmPathWithExists(&buffer, env, systemWmExists).?);
}

test "mouse follows focus sidecar presence and invalid values" {
    var snapshot: Snapshot = .{};
    try std.testing.expect(!snapshot.wm.input.mouse_follows_focus);
    applyInputSource(&snapshot, "[input]\nmouse_follows_focus = invalid");
    try std.testing.expect(!snapshot.wm.input.mouse_follows_focus_set);
    applyInputSource(&snapshot, "[input]\nmouse_follows_focus = true");
    try std.testing.expect(snapshot.wm.input.mouse_follows_focus);
    applyInputSource(&snapshot, "[input]\nfocus_new_windows = true");
    try std.testing.expect(snapshot.wm.input.mouse_follows_focus);
    applyInputSource(&snapshot, "[input]\nmouse_follows_focus = invalid");
    try std.testing.expect(snapshot.wm.input.mouse_follows_focus);
    applyInputSource(&snapshot, "[input]\nmouse_follows_focus = false");
    try std.testing.expect(!snapshot.wm.input.mouse_follows_focus);
    try std.testing.expect(snapshot.wm.input.mouse_follows_focus_set);
}

test "wheel navigation defaults can be replaced unbound and overridden by custom actions" {
    var snapshot: actions.Snapshot = .{};
    actions.initDefaults(&snapshot);
    try std.testing.expectEqualStrings("builtin:wheel_scroll_left", snapshot.findWheel(.up, 64).?);
    try std.testing.expectEqualStrings("builtin:wheel_scroll_right", snapshot.findWheel(.down, 64).?);
    try std.testing.expectEqualStrings("builtin:wheel_scroll_up", snapshot.findWheel(.up, 72).?);
    try std.testing.expectEqualStrings("builtin:wheel_scroll_down", snapshot.findWheel(.down, 72).?);
    try std.testing.expect(snapshot.findWheel(.left, 64) == null);
    applyActions(&snapshot,
        \\[keybinds]
        \\wheel_scroll_left = ["Ctrl+WheelUp", "Ctrl+WheelLeft"]
        \\wheel_scroll_right = []
        \\wheel_scroll_up = "Ctrl+WheelRight"
        \\[keybinds.custom]
        \\"Alt+Meta+WheelDown" = "builtin:focus_workspace_down"
        \\"WheelRight" = "spawn:example"
    );
    try std.testing.expect(snapshot.findWheel(.up, 64) == null);
    try std.testing.expect(snapshot.findWheel(.down, 64) == null);
    try std.testing.expect(snapshot.findWheel(.up, 72) == null);
    try std.testing.expectEqualStrings("builtin:wheel_scroll_left", snapshot.findWheel(.up, 4).?);
    try std.testing.expectEqualStrings("builtin:wheel_scroll_left", snapshot.findWheel(.left, 4).?);
    try std.testing.expectEqualStrings("builtin:wheel_scroll_up", snapshot.findWheel(.right, 4).?);
    try std.testing.expectEqualStrings("builtin:focus_workspace_down", snapshot.findWheel(.down, 72).?);
    try std.testing.expectEqualStrings("spawn:example", snapshot.findWheel(.right, 0).?);
    // Rebinding the wheel must leave keyboard viewport shortcuts intact.
    try std.testing.expectEqualStrings("builtin:scroll_viewport_left_arrow", snapshot.find(0xff51, 64).?);
    try std.testing.expectEqualStrings("builtin:scroll_viewport_up", snapshot.find(0xff52, 64).?);
}

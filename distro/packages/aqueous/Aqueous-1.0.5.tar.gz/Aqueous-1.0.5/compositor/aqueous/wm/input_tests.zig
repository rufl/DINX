// SPDX-FileCopyrightText: © 2026 Seafoam Labs
// SPDX-License-Identifier: GPL-3.0-only

test {
    _ = @import("geometry.zig");
    _ = @import("input/drag.zig");
    _ = @import("input/gestures.zig");
    _ = @import("input/output_transfer.zig");
    _ = @import("input/wheel.zig");
}

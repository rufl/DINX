// SPDX-FileCopyrightText: © 2026 Seafoam Labs
// SPDX-License-Identifier: GPL-3.0-only

const std = @import("std");
const composable = @import("composable.zig");
const config = @import("../config/layout.zig");
const game_mode = @import("game_mode.zig");
const leaf = @import("leaf.zig");
const types = @import("types.zig");

pub const State = struct {
    active_layout: config.LayoutId = .tile,
    standalone: leaf.State = .{},
    composite: composable.State = .{},

    pub fn deinit(state: *State, allocator: std.mem.Allocator) void {
        state.standalone.deinit(allocator);
        state.composite.deinit(allocator);
    }
};

/// Include dormant layouts and composable regions so returning to a floating
/// layout after an output move cannot restore coordinates from the old origin.
pub fn reconfigureOutput(state: *State, before: types.Rect, after: types.Rect, usable: types.Rect) void {
    const floating = @import("floating.zig");
    floating.reconfigureOutput(&state.standalone.floating, before, after, usable);
    for (&state.composite.children) |*child| floating.reconfigureOutput(&child.floating, before, after, usable);
}

pub fn arrange(allocator: std.mem.Allocator, state: *State, snapshot: *const config.Snapshot, area: types.Rect, windows: []const types.Window, focused: ?types.Handle, game_options: game_mode.Options) ![]types.Placement {
    const id = snapshot.default;
    state.active_layout = id;
    return if (id == .composable)
        composable.arrange(allocator, &state.composite, snapshot, area, windows, focused, game_options)
    else
        leaf.arrange(allocator, &state.standalone, id, snapshot, area, windows, focused, game_options);
}

/// Swap two tiled windows in every initialized layout order. Keeping dormant
/// orders synchronized makes a pointer reorder survive layout switches.
pub fn swap(state: *State, a: types.Handle, b: types.Handle) bool {
    return if (state.active_layout == .composable)
        composable.swap(&state.composite, a, b)
    else
        leaf.swap(&state.standalone, a, b);
}

/// Scope-local order from the layout's existing state. Unknown handles and
/// layouts without a single tiled sequence have no index.
pub fn orderIndex(state: *const State, handle: types.Handle) ?u32 {
    const layout = &state.standalone;
    const order = switch (state.active_layout) {
        .scrolling => {
            var index: u32 = 0;
            for (layout.scrolling.columns.items) |column| {
                for (column.windows.items) |member| {
                    if (member == handle) return index;
                    index += 1;
                }
            }
            return null;
        },
        inline .tile, .monocle, .grid, .rows, .dwindle, .reverse_dwindle => |id| @field(layout, @tagName(id)).order.items.items,
        .floating, .game_mode, .composable => return null,
    };
    return if (std.mem.indexOfScalar(types.Handle, order, handle)) |index| @intCast(index) else null;
}

pub fn drop(allocator: std.mem.Allocator, state: *State, dragged: types.Handle, target: types.Handle, zone: types.DropZone) !bool {
    return if (state.active_layout == .composable)
        composable.drop(allocator, &state.composite, dragged, target, zone)
    else
        leaf.drop(allocator, &state.standalone, dragged, target, zone);
}

test "output transfer admits then reorders in every non-stacking layout" {
    const allocator = std.testing.allocator;
    const source_area: types.Rect = .{ .x = -1280, .y = -100, .width = 1280, .height = 720 };
    const target_area: types.Rect = .{ .x = 100, .y = 80, .width = 480, .height = 853 };
    for (std.enums.values(config.LayoutId)) |id| {
        if (id == .floating) continue;
        var snapshot: config.Snapshot = .{};
        snapshot.default = id;
        var source: State = .{};
        defer source.deinit(allocator);
        var target: State = .{};
        defer target.deinit(allocator);
        const original = [_]types.Window{ .{ .handle = 1 }, .{ .handle = 2 } };
        const residents = [_]types.Window{ .{ .handle = 3 }, .{ .handle = 4 } };
        allocator.free(try arrange(allocator, &source, &snapshot, source_area, &original, 1, .{}));
        allocator.free(try arrange(allocator, &target, &snapshot, target_area, &residents, 3, .{}));
        // A workspace move alone cannot reorder an unadmitted handle.
        try std.testing.expect(!try drop(allocator, &target, 1, 3, .column_before));
        forgetWindow(&source, 1);
        const remaining = try arrange(allocator, &source, &snapshot, source_area, original[1..], 2, .{});
        defer allocator.free(remaining);
        try std.testing.expectEqual(@as(usize, 1), remaining.len);
        try std.testing.expectEqual(@as(types.Handle, 2), remaining[0].handle);
        const admitted = residents ++ [_]types.Window{.{ .handle = 1 }};
        allocator.free(try arrange(allocator, &target, &snapshot, target_area, &admitted, 1, .{}));
        try std.testing.expect(!usesFloatingLayout(&target, 1));
        try std.testing.expect(try drop(allocator, &target, 1, 3, .column_before));
        const reordered = try arrange(allocator, &target, &snapshot, target_area, &admitted, 1, .{});
        defer allocator.free(reordered);
        try std.testing.expectEqual(@as(usize, 3), reordered.len);
        for (admitted) |window| {
            var count: usize = 0;
            for (reordered) |placement| {
                if (placement.handle == window.handle) count += 1;
            }
            try std.testing.expectEqual(@as(usize, 1), count);
        }
        // Moving again remains possible after destination admission/reflow.
        try std.testing.expect(try drop(allocator, &target, 1, 4, .stack_after));
    }
}

test "transferring a scrolling member retains its former column peers" {
    const allocator = std.testing.allocator;
    var snapshot: config.Snapshot = .{};
    snapshot.default = .scrolling;
    var source: State = .{};
    defer source.deinit(allocator);
    const area: types.Rect = .{ .x = 0, .y = 0, .width = 1280, .height = 720 };
    const original = [_]types.Window{ .{ .handle = 1 }, .{ .handle = 2 }, .{ .handle = 3 } };
    allocator.free(try arrange(allocator, &source, &snapshot, area, &original, 1, .{}));
    try std.testing.expect(try drop(allocator, &source, 2, 1, .stack_after));
    allocator.free(try arrange(allocator, &source, &snapshot, area, &original, 1, .{}));
    try std.testing.expectEqualSlices(types.Handle, &.{ 1, 2 }, scrollingColumnMembers(&source, 1).?);
    forgetWindow(&source, 1);
    allocator.free(try arrange(allocator, &source, &snapshot, area, original[1..], 2, .{}));
    try std.testing.expectEqualSlices(types.Handle, &.{2}, scrollingColumnMembers(&source, 2).?);
    try std.testing.expectEqual(@as(usize, 2), source.standalone.scrolling.columns.items.len);
    try std.testing.expect(scrollingColumnMembers(&source, 1) == null);
    forgetWindow(&source, 2);
    allocator.free(try arrange(allocator, &source, &snapshot, area, original[2..], 3, .{}));
    try std.testing.expectEqual(@as(usize, 1), source.standalone.scrolling.columns.items.len);
    try std.testing.expectEqualSlices(types.Handle, &.{3}, scrollingColumnMembers(&source, 3).?);
}

pub fn consumeWindowIntoColumn(allocator: std.mem.Allocator, state: *State, focused: types.Handle) !bool {
    return if (state.active_layout == .composable)
        composable.consumeWindowIntoColumn(allocator, &state.composite, focused)
    else
        leaf.consumeWindowIntoColumn(allocator, &state.standalone, focused);
}

pub fn expelWindowFromColumn(allocator: std.mem.Allocator, state: *State, focused: types.Handle) !bool {
    return if (state.active_layout == .composable)
        composable.expelWindowFromColumn(allocator, &state.composite, focused)
    else
        leaf.expelWindowFromColumn(allocator, &state.standalone, focused);
}

pub fn moveScrolling(allocator: std.mem.Allocator, state: *State, focused: types.Handle, dx: i32, dy: i32) !bool {
    return if (state.active_layout == .composable)
        composable.moveScrolling(allocator, &state.composite, focused, dx, dy)
    else
        leaf.moveScrolling(allocator, &state.standalone, focused, dx, dy);
}

pub fn moveScrollingColumn(allocator: std.mem.Allocator, state: *State, focused: types.Handle, delta: i32) !bool {
    return if (state.active_layout == .composable)
        composable.moveScrollingColumn(allocator, &state.composite, focused, delta)
    else
        leaf.moveScrollingColumn(allocator, &state.standalone, focused, delta);
}

pub fn scrollViewport(state: *State, focused: types.Handle, dx: i32, dy: i32) ?types.Handle {
    return if (state.active_layout == .composable)
        composable.scrollViewport(&state.composite, focused, dx, dy)
    else
        leaf.scrollViewport(&state.standalone, focused, dx, dy);
}

pub fn supportsViewportScroll(state: *const State, handle: types.Handle) bool {
    return if (state.active_layout == .composable)
        composable.supportsViewportScroll(&state.composite, handle)
    else
        leaf.supportsViewportScroll(&state.standalone, handle);
}

pub fn prefersVerticalScroll(state: *const State, handle: types.Handle) bool {
    return if (state.active_layout == .composable)
        composable.prefersVerticalScroll(&state.composite, handle)
    else
        leaf.prefersVerticalScroll(&state.standalone, handle);
}

pub fn canResizeScrolling(state: *const State, handle: types.Handle) bool {
    return if (state.active_layout == .composable)
        composable.canResizeScrolling(&state.composite, handle)
    else
        leaf.canResizeScrolling(&state.standalone, handle);
}

pub fn isGameAnchor(state: *const State, handle: types.Handle) bool {
    return if (state.active_layout == .composable)
        composable.isGameAnchor(&state.composite, handle)
    else
        leaf.isGameAnchor(&state.standalone, handle);
}

pub fn scrollingExpandedOwner(state: *const State, handle: types.Handle) ?types.Handle {
    return if (state.active_layout == .composable)
        composable.scrollingExpandedOwner(&state.composite, handle)
    else
        leaf.scrollingExpandedOwner(&state.standalone, handle);
}

pub fn scrollingColumnMembers(state: *const State, handle: types.Handle) ?[]const types.Handle {
    return if (state.active_layout == .composable)
        composable.scrollingColumnMembers(&state.composite, handle)
    else
        leaf.scrollingColumnMembers(&state.standalone, handle);
}

pub fn resizeScrolling(
    allocator: std.mem.Allocator,
    state: *State,
    handle: types.Handle,
    update: types.ResizeUpdate,
) !bool {
    return if (state.active_layout == .composable)
        composable.resizeScrolling(allocator, &state.composite, handle, update)
    else
        leaf.resizeScrolling(allocator, &state.standalone, handle, update);
}

pub fn resetScrollingSize(state: *State, handle: types.Handle) bool {
    return if (state.active_layout == .composable)
        composable.resetScrollingSize(&state.composite, handle)
    else
        leaf.resetScrollingSize(&state.standalone, handle);
}

pub fn setFloatingGeometry(allocator: std.mem.Allocator, state: *State, handle: types.Handle, geometry: types.Rect) !void {
    if (state.active_layout == .composable) {
        try composable.setFloatingGeometry(allocator, &state.composite, handle, geometry);
    } else {
        try leaf.setFloatingGeometry(allocator, &state.standalone, handle, geometry);
    }
}

pub fn floatingGeometry(state: *const State, handle: types.Handle) ?types.Rect {
    return if (state.active_layout == .composable)
        composable.floatingGeometry(&state.composite, handle)
    else
        leaf.floatingGeometry(&state.standalone, handle);
}

pub fn forgetWindow(state: *State, handle: types.Handle) void {
    leaf.forgetWindow(&state.standalone, handle);
    composable.forgetWindow(&state.composite, handle);
}

pub fn layoutForHandle(state: *const State, handle: types.Handle) config.LayoutId {
    if (state.active_layout != .composable) return state.active_layout;
    return composable.layoutForHandle(&state.composite, handle) orelse .composable;
}

pub fn usesFloatingLayout(state: *const State, handle: types.Handle) bool {
    return layoutForHandle(state, handle) == .floating;
}

pub fn usesSpecialMove(state: *const State, handle: types.Handle) bool {
    return switch (layoutForHandle(state, handle)) {
        .scrolling, .game_mode => true,
        else => false,
    };
}

pub fn focusComposableSlot(state: *const State, slot: u8) ?types.Handle {
    if (state.active_layout != .composable) return null;
    return composable.focusTarget(&state.composite, slot);
}

pub fn moveToComposableSlot(state: *State, handle: types.Handle, slot: u8) bool {
    if (state.active_layout != .composable) return false;
    return composable.moveToSlot(&state.composite, handle, slot);
}

pub fn acceptsFloatingTransfer(state: *const State) bool {
    return if (state.active_layout == .composable)
        composable.activeLayout(&state.composite) == .floating
    else
        state.active_layout == .floating;
}

pub fn prepareFloatingTransfer(state: *State, allocator: std.mem.Allocator) !bool {
    if (!acceptsFloatingTransfer(state)) return false;
    if (state.active_layout == .composable) return composable.prepareAdmission(&state.composite, allocator);
    return true;
}

pub fn commitFloatingTransfer(state: *State, handle: types.Handle) void {
    if (state.active_layout == .composable) composable.admitToActiveAssumeCapacity(&state.composite, handle);
}

pub fn gameModeState(state: *State) *game_mode.State {
    return &state.standalone.game_mode;
}

test "dispatcher selects the configured engine" {
    var state: State = .{};
    defer state.deinit(std.testing.allocator);
    var snapshot: config.Snapshot = .{};
    snapshot.default = .rows;
    snapshot.options[@intFromEnum(config.LayoutId.rows)].gaps_outer = 0;
    snapshot.options[@intFromEnum(config.LayoutId.rows)].gaps_inner = 0;
    const placements = try arrange(std.testing.allocator, &state, &snapshot, .{ .x = 0, .y = 0, .width = 100, .height = 80 }, &.{
        .{ .handle = 1 }, .{ .handle = 2 }, .{ .handle = 3 },
    }, null, .{});
    defer std.testing.allocator.free(placements);
    try std.testing.expectEqual(types.Rect{ .x = 0, .y = 40, .width = 100, .height = 40 }, placements[2].geometry);
}

test "pointer reorder swaps rows without changing window state" {
    var state: State = .{};
    defer state.deinit(std.testing.allocator);
    var snapshot: config.Snapshot = .{};
    snapshot.default = .rows;
    const windows = [_]types.Window{ .{ .handle = 1 }, .{ .handle = 2 } };
    const initial = try arrange(std.testing.allocator, &state, &snapshot, .{ .x = 0, .y = 0, .width = 100, .height = 80 }, &windows, null, .{});
    std.testing.allocator.free(initial);

    try std.testing.expect(swap(&state, 1, 2));
    try std.testing.expectEqualSlices(types.Handle, &.{ 2, 1 }, state.standalone.rows.order.items.items);
}

test "switching away from scrolling returns unclipped placements" {
    var state: State = .{};
    defer state.deinit(std.testing.allocator);
    var snapshot: config.Snapshot = .{};
    snapshot.default = .scrolling;
    snapshot.options[@intFromEnum(config.LayoutId.scrolling)].gaps_outer = 0;
    snapshot.options[@intFromEnum(config.LayoutId.scrolling)].gaps_inner = 0;
    const windows = [_]types.Window{ .{ .handle = 1 }, .{ .handle = 2 } };
    const scrolling_placements = try arrange(std.testing.allocator, &state, &snapshot, .{ .x = 0, .y = 0, .width = 100, .height = 80 }, &windows, 1, .{});
    defer std.testing.allocator.free(scrolling_placements);
    try std.testing.expect(scrolling_placements[0].clip != null);

    snapshot.default = .tile;
    const tiled_placements = try arrange(std.testing.allocator, &state, &snapshot, .{ .x = 0, .y = 0, .width = 100, .height = 80 }, &windows, 1, .{});
    defer std.testing.allocator.free(tiled_placements);
    try std.testing.expectEqual(@as(?types.Rect, null), tiled_placements[0].clip);
    try std.testing.expectEqual(@as(?types.Rect, null), tiled_placements[1].clip);
}

test "all managed layouts advertise tiled placements while floating does not" {
    inline for (.{
        config.LayoutId.tile,
        config.LayoutId.monocle,
        config.LayoutId.grid,
        config.LayoutId.rows,
        config.LayoutId.dwindle,
        config.LayoutId.reverse_dwindle,
        config.LayoutId.scrolling,
        config.LayoutId.game_mode,
        config.LayoutId.composable,
    }) |id| {
        var state: State = .{};
        defer state.deinit(std.testing.allocator);
        var snapshot: config.Snapshot = .{};
        snapshot.default = id;
        if (id == .composable) config.apply(&snapshot,
            \\[layout.composable.a]
            \\layout = "tile"
            \\p1 = [0.0, 0.0]
            \\p2 = [1.0, 0.0]
            \\p3 = [1.0, 1.0]
            \\p4 = [0.0, 1.0]
        );
        const placements = try arrange(
            std.testing.allocator,
            &state,
            &snapshot,
            .{ .x = 0, .y = 0, .width = 100, .height = 80 },
            &.{.{ .handle = 1 }},
            1,
            .{ .fallback = .dwindle },
        );
        defer std.testing.allocator.free(placements);
        try std.testing.expect(placements[0].tiled);
    }

    var floating_state: State = .{};
    defer floating_state.deinit(std.testing.allocator);
    var floating_snapshot: config.Snapshot = .{};
    floating_snapshot.default = .floating;
    const floating_placements = try arrange(
        std.testing.allocator,
        &floating_state,
        &floating_snapshot,
        .{ .x = 0, .y = 0, .width = 100, .height = 80 },
        &.{.{ .handle = 1 }},
        1,
        .{},
    );
    defer std.testing.allocator.free(floating_placements);
    try std.testing.expect(!floating_placements[0].tiled);
}

test "floating geometry survives temporary layout switches" {
    var state: State = .{};
    defer state.deinit(std.testing.allocator);
    var snapshot: config.Snapshot = .{};
    const windows = [_]types.Window{.{ .handle = 1 }};
    const remembered: types.Rect = .{ .x = 17, .y = 29, .width = 420, .height = 260 };

    snapshot.default = .floating;
    try setFloatingGeometry(std.testing.allocator, &state, 1, remembered);
    var placements = try arrange(std.testing.allocator, &state, &snapshot, .{ .x = 0, .y = 0, .width = 1000, .height = 800 }, &windows, 1, .{});
    try std.testing.expectEqual(remembered, placements[0].geometry);
    std.testing.allocator.free(placements);

    snapshot.default = .tile;
    placements = try arrange(std.testing.allocator, &state, &snapshot, .{ .x = 0, .y = 0, .width = 1000, .height = 800 }, &windows, 1, .{});
    std.testing.allocator.free(placements);

    snapshot.default = .floating;
    placements = try arrange(std.testing.allocator, &state, &snapshot, .{ .x = 0, .y = 0, .width = 1000, .height = 800 }, &windows, 1, .{});
    defer std.testing.allocator.free(placements);
    try std.testing.expectEqual(remembered, placements[0].geometry);
}

test "viewport scroll support follows the active standalone layout" {
    var state: State = .{};
    defer state.deinit(std.testing.allocator);
    var snapshot: config.Snapshot = .{};
    const windows = [_]types.Window{ .{ .handle = 1 }, .{ .handle = 2 } };
    const area: types.Rect = .{ .x = 0, .y = 0, .width = 100, .height = 80 };

    snapshot.default = .scrolling;
    var placements = try arrange(std.testing.allocator, &state, &snapshot, area, &windows, 1, .{});
    std.testing.allocator.free(placements);
    try std.testing.expect(supportsViewportScroll(&state, 1));
    try std.testing.expect(!supportsViewportScroll(&state, 99));

    snapshot.default = .tile;
    placements = try arrange(std.testing.allocator, &state, &snapshot, area, &windows, 1, .{});
    std.testing.allocator.free(placements);
    try std.testing.expect(!supportsViewportScroll(&state, 1));

    snapshot.default = .floating;
    placements = try arrange(std.testing.allocator, &state, &snapshot, area, &windows, 1, .{});
    std.testing.allocator.free(placements);
    try std.testing.expect(!supportsViewportScroll(&state, 1));
}

test "tile members resize through the engine like scrolling members" {
    var state: State = .{};
    defer state.deinit(std.testing.allocator);
    var snapshot: config.Snapshot = .{};
    snapshot.default = .tile;
    snapshot.options[@intFromEnum(config.LayoutId.tile)].gaps_outer = 0;
    snapshot.options[@intFromEnum(config.LayoutId.tile)].gaps_inner = 4;
    snapshot.options[@intFromEnum(config.LayoutId.tile)].master_ratio = 0.5;
    const windows = [_]types.Window{ .{ .handle = 1 }, .{ .handle = 2 }, .{ .handle = 3 } };
    const area: types.Rect = .{ .x = 0, .y = 0, .width = 100, .height = 80 };

    var placements = try arrange(std.testing.allocator, &state, &snapshot, area, &windows, 1, .{});
    std.testing.allocator.free(placements);
    try std.testing.expect(canResizeScrolling(&state, 1));
    try std.testing.expect(!canResizeScrolling(&state, 99));
    try std.testing.expect(try resizeScrolling(std.testing.allocator, &state, 1, .{ .width = 70 }));

    placements = try arrange(std.testing.allocator, &state, &snapshot, area, &windows, 1, .{});
    try std.testing.expectEqual(types.Rect{ .x = 0, .y = 0, .width = 70, .height = 80 }, placements[0].geometry);
    std.testing.allocator.free(placements);

    try std.testing.expect(try resizeScrolling(std.testing.allocator, &state, 1, .{ .height = 60 }));
    placements = try arrange(std.testing.allocator, &state, &snapshot, area, &windows, 1, .{});
    try std.testing.expectEqual(types.Rect{ .x = 0, .y = 0, .width = 70, .height = 60 }, placements[0].geometry);
    std.testing.allocator.free(placements);

    try std.testing.expect(resetScrollingSize(&state, 1));
    placements = try arrange(std.testing.allocator, &state, &snapshot, area, &windows, 1, .{});
    defer std.testing.allocator.free(placements);
    try std.testing.expectEqual(types.Rect{ .x = 0, .y = 0, .width = 50, .height = 80 }, placements[0].geometry);
}

test "viewport scroll support routes through game mode and rejects its anchor" {
    const windows = [_]types.Window{ .{ .handle = 1 }, .{ .handle = 2 }, .{ .handle = 3 } };
    const area: types.Rect = .{ .x = 0, .y = 0, .width = 300, .height = 100 };
    var snapshot: config.Snapshot = .{};
    snapshot.default = .game_mode;

    var fallback_state: State = .{};
    defer fallback_state.deinit(std.testing.allocator);
    const fallback = try arrange(
        std.testing.allocator,
        &fallback_state,
        &snapshot,
        area,
        &windows,
        1,
        .{ .fallback = .scrolling },
    );
    std.testing.allocator.free(fallback);
    try std.testing.expect(supportsViewportScroll(&fallback_state, 1));

    var anchored_state: State = .{};
    defer anchored_state.deinit(std.testing.allocator);
    const game_state = gameModeState(&anchored_state);
    game_state.rule_anchor = 1;
    game_state.rule_options = .{
        .size = .{ .pixels = .{ .width = 100, .height = 100 } },
        .remainder = .scrolling,
        .gaps_inner = 0,
    };
    const anchored = try arrange(
        std.testing.allocator,
        &anchored_state,
        &snapshot,
        area,
        &windows,
        2,
        .{},
    );
    std.testing.allocator.free(anchored);
    try std.testing.expect(!supportsViewportScroll(&anchored_state, 1));
    try std.testing.expect(supportsViewportScroll(&anchored_state, 2));
}

test "viewport scroll support routes to the focused composable child" {
    var snapshot: config.Snapshot = .{};
    snapshot.default = .composable;
    config.apply(&snapshot,
        \\[layout.composable.a]
        \\layout = "scrolling"
        \\p1 = [0.0, 0.0]
        \\p2 = [0.5, 0.0]
        \\p3 = [0.5, 1.0]
        \\p4 = [0.0, 1.0]
        \\[layout.composable.b]
        \\layout = "tile"
        \\p1 = [0.5, 0.0]
        \\p2 = [1.0, 0.0]
        \\p3 = [1.0, 1.0]
        \\p4 = [0.5, 1.0]
    );
    var state: State = .{};
    defer state.deinit(std.testing.allocator);
    const windows = [_]types.Window{ .{ .handle = 1 }, .{ .handle = 2 } };
    const area: types.Rect = .{ .x = 0, .y = 0, .width = 200, .height = 100 };

    var placements = try arrange(std.testing.allocator, &state, &snapshot, area, &windows, 1, .{});
    std.testing.allocator.free(placements);
    try std.testing.expect(moveToComposableSlot(&state, 2, 1));
    placements = try arrange(std.testing.allocator, &state, &snapshot, area, &windows, 2, .{});
    std.testing.allocator.free(placements);

    try std.testing.expect(supportsViewportScroll(&state, 1));
    try std.testing.expect(!supportsViewportScroll(&state, 2));
}

test "vertical scroll preference follows the active standalone arrangement" {
    var state: State = .{};
    defer state.deinit(std.testing.allocator);
    var snapshot: config.Snapshot = .{};
    snapshot.default = .scrolling;
    snapshot.scrolling_prefer_vertical_on_portrait = true;
    const windows = [_]types.Window{ .{ .handle = 1 }, .{ .handle = 2 } };
    const portrait: types.Rect = .{ .x = 0, .y = 0, .width = 80, .height = 120 };
    const landscape: types.Rect = .{ .x = 0, .y = 0, .width = 120, .height = 80 };

    var placements = try arrange(std.testing.allocator, &state, &snapshot, portrait, &windows, 1, .{});
    std.testing.allocator.free(placements);
    try std.testing.expect(prefersVerticalScroll(&state, 1));
    try std.testing.expect(!prefersVerticalScroll(&state, 99));

    placements = try arrange(std.testing.allocator, &state, &snapshot, landscape, &windows, 1, .{});
    std.testing.allocator.free(placements);
    try std.testing.expect(!prefersVerticalScroll(&state, 1));
}

test "vertical scroll preference routes through game mode and rejects its anchor" {
    const windows = [_]types.Window{ .{ .handle = 1 }, .{ .handle = 2 }, .{ .handle = 3 } };
    var snapshot: config.Snapshot = .{};
    snapshot.default = .game_mode;

    var fallback_state: State = .{};
    defer fallback_state.deinit(std.testing.allocator);
    const portrait_area: types.Rect = .{ .x = 0, .y = 0, .width = 100, .height = 300 };
    const fallback = try arrange(
        std.testing.allocator,
        &fallback_state,
        &snapshot,
        portrait_area,
        &windows,
        1,
        .{ .fallback = .scrolling, .scrolling_options = .{ .prefer_vertical_on_portrait = true } },
    );
    std.testing.allocator.free(fallback);
    try std.testing.expect(prefersVerticalScroll(&fallback_state, 2));

    const landscape_area: types.Rect = .{ .x = 0, .y = 0, .width = 300, .height = 100 };
    const landscape = try arrange(
        std.testing.allocator,
        &fallback_state,
        &snapshot,
        landscape_area,
        &windows,
        1,
        .{ .fallback = .scrolling, .scrolling_options = .{ .prefer_vertical_on_portrait = true } },
    );
    std.testing.allocator.free(landscape);
    try std.testing.expect(!prefersVerticalScroll(&fallback_state, 2));

    var anchored_state: State = .{};
    defer anchored_state.deinit(std.testing.allocator);
    const game_state = gameModeState(&anchored_state);
    game_state.rule_anchor = 1;
    game_state.rule_options = .{
        .size = .{ .pixels = .{ .width = 100, .height = 100 } },
        .remainder = .scrolling,
        .gaps_inner = 0,
    };
    // A portrait anchor area whose side remainders are themselves portrait,
    // so only the anchor guard can reject the anchor handle.
    const anchored_area: types.Rect = .{ .x = 0, .y = 0, .width = 300, .height = 400 };
    const anchored = try arrange(
        std.testing.allocator,
        &anchored_state,
        &snapshot,
        anchored_area,
        &windows,
        2,
        .{ .scrolling_options = .{ .prefer_vertical_on_portrait = true } },
    );
    std.testing.allocator.free(anchored);
    try std.testing.expect(!prefersVerticalScroll(&anchored_state, 1));
    try std.testing.expect(prefersVerticalScroll(&anchored_state, 2));
}

test "vertical scroll preference routes to the focused composable child" {
    var snapshot: config.Snapshot = .{};
    snapshot.default = .composable;
    snapshot.scrolling_prefer_vertical_on_portrait = true;
    config.apply(&snapshot,
        \\[layout.composable.a]
        \\layout = "scrolling"
        \\p1 = [0.0, 0.0]
        \\p2 = [0.25, 0.0]
        \\p3 = [0.25, 1.0]
        \\p4 = [0.0, 1.0]
        \\[layout.composable.b]
        \\layout = "scrolling"
        \\p1 = [0.25, 0.0]
        \\p2 = [1.0, 0.0]
        \\p3 = [1.0, 1.0]
        \\p4 = [0.25, 1.0]
    );
    var state: State = .{};
    defer state.deinit(std.testing.allocator);
    const windows = [_]types.Window{ .{ .handle = 1 }, .{ .handle = 2 } };
    const area: types.Rect = .{ .x = 0, .y = 0, .width = 200, .height = 100 };

    var placements = try arrange(std.testing.allocator, &state, &snapshot, area, &windows, 1, .{});
    std.testing.allocator.free(placements);
    try std.testing.expect(moveToComposableSlot(&state, 2, 1));
    placements = try arrange(std.testing.allocator, &state, &snapshot, area, &windows, 2, .{});
    std.testing.allocator.free(placements);

    // Region a is 50x100 (portrait) while region b is 150x100 (landscape).
    try std.testing.expect(prefersVerticalScroll(&state, 1));
    try std.testing.expect(!prefersVerticalScroll(&state, 2));
}

test "tile admission preserves natural size for a later floating layout" {
    var state: State = .{};
    defer state.deinit(std.testing.allocator);
    var snapshot: config.Snapshot = .{};
    snapshot.default = .tile;
    snapshot.options[@intFromEnum(config.LayoutId.tile)].gaps_outer = 0;
    snapshot.options[@intFromEnum(config.LayoutId.tile)].gaps_inner = 0;
    snapshot.options[@intFromEnum(config.LayoutId.floating)].gaps_outer = 0;
    const area: types.Rect = .{ .x = 0, .y = 0, .width = 1280, .height = 720 };

    var placements = try arrange(
        std.testing.allocator,
        &state,
        &snapshot,
        area,
        &.{.{ .handle = 1, .preferred_width = 320, .preferred_height = 200 }},
        1,
        .{},
    );
    std.testing.allocator.free(placements);

    // The next snapshot reflects the policy-directed tiled buffer. Entering
    // floating must still recover the natural rectangle captured above.
    snapshot.default = .floating;
    placements = try arrange(
        std.testing.allocator,
        &state,
        &snapshot,
        area,
        &.{.{ .handle = 1, .preferred_width = 1280, .preferred_height = 720 }},
        1,
        .{},
    );
    defer std.testing.allocator.free(placements);
    try std.testing.expectEqual(
        types.Rect{ .x = 480, .y = 260, .width = 320, .height = 200 },
        placements[0].geometry,
    );
    try std.testing.expect(!placements[0].tiled);
}

fn expectPlacementOrder(placements: []const types.Placement, expected: []const types.Handle) !void {
    try std.testing.expectEqual(expected.len, placements.len);
    for (placements, expected) |placement, handle| try std.testing.expectEqual(handle, placement.handle);
}

test "right insertion and pre-admission focus route through standalone and game fallback" {
    const initial = [_]types.Window{ .{ .handle = 1 }, .{ .handle = 2 }, .{ .handle = 3 } };
    const arrivals = initial ++ [_]types.Window{.{ .handle = 4 }};
    const area: types.Rect = .{ .x = 0, .y = 0, .width = 1200, .height = 800 };
    for ([_]config.LayoutId{ .scrolling, .game_mode }) |id| {
        var snapshot: config.Snapshot = .{};
        snapshot.default = id;
        config.apply(&snapshot,
            \\[layout.options.scrolling]
            \\open_new_windows_to_right = true
        );
        const game_options: game_mode.Options = .{
            .fallback = .scrolling,
            .scrolling_options = .{ .open_new_windows_to_right = snapshot.scrolling_open_new_windows_to_right },
        };
        var state: State = .{};
        defer state.deinit(std.testing.allocator);
        var placements = try arrange(std.testing.allocator, &state, &snapshot, area, &initial, 1, game_options);
        std.testing.allocator.free(placements);
        for (&snapshot.options) |*options| options.new_window_anchor = 2;
        placements = try arrange(std.testing.allocator, &state, &snapshot, area, &arrivals, 4, game_options);
        defer std.testing.allocator.free(placements);
        try expectPlacementOrder(placements, &.{ 1, 2, 4, 3 });
    }
}

test "right insertion routes through game remainder and keeps its anchor fixed" {
    var snapshot: config.Snapshot = .{};
    snapshot.default = .game_mode;
    const initial = [_]types.Window{ .{ .handle = 99 }, .{ .handle = 1 }, .{ .handle = 2 }, .{ .handle = 3 } };
    const area: types.Rect = .{ .x = 0, .y = 0, .width = 1200, .height = 800 };
    const game_options: game_mode.Options = .{ .scrolling_options = .{ .open_new_windows_to_right = true } };
    var state: State = .{};
    defer state.deinit(std.testing.allocator);
    const game = gameModeState(&state);
    game.rule_anchor = 99;
    game.rule_options = .{ .anchor = .left, .size = .{ .pixels = .{ .width = 100, .height = 100 } }, .remainder = .scrolling };
    var placements = try arrange(std.testing.allocator, &state, &snapshot, area, &initial, 1, game_options);
    const original_anchor = placements[0].geometry;
    std.testing.allocator.free(placements);
    for (&snapshot.options) |*options| options.new_window_anchor = 2;
    placements = try arrange(std.testing.allocator, &state, &snapshot, area, &(initial ++ [_]types.Window{.{ .handle = 4 }}), 4, game_options);
    defer std.testing.allocator.free(placements);
    try expectPlacementOrder(placements, &.{ 99, 1, 2, 4, 3 });
    try std.testing.expectEqual(original_anchor, placements[0].geometry);
}

test "right insertion stays within the focused composable region" {
    var snapshot: config.Snapshot = .{};
    snapshot.default = .composable;
    config.apply(&snapshot,
        \\[layout.options.scrolling]
        \\open_new_windows_to_right = true
        \\[layout.composable.a]
        \\layout = "scrolling"
        \\p1 = [0.0, 0.0]
        \\p2 = [0.5, 0.0]
        \\p3 = [0.5, 1.0]
        \\p4 = [0.0, 1.0]
        \\[layout.composable.b]
        \\layout = "scrolling"
        \\p1 = [0.5, 0.0]
        \\p2 = [1.0, 0.0]
        \\p3 = [1.0, 1.0]
        \\p4 = [0.5, 1.0]
    );
    const initial = [_]types.Window{ .{ .handle = 1 }, .{ .handle = 2 }, .{ .handle = 3 }, .{ .handle = 4 }, .{ .handle = 5 } };
    const area: types.Rect = .{ .x = 0, .y = 0, .width = 1600, .height = 900 };
    var state: State = .{};
    defer state.deinit(std.testing.allocator);
    var placements = try arrange(std.testing.allocator, &state, &snapshot, area, &initial, 1, .{});
    std.testing.allocator.free(placements);
    try std.testing.expect(moveToComposableSlot(&state, 4, 1));
    try std.testing.expect(moveToComposableSlot(&state, 5, 1));
    placements = try arrange(std.testing.allocator, &state, &snapshot, area, &initial, 2, .{});
    std.testing.allocator.free(placements);
    const arrivals = initial ++ [_]types.Window{.{ .handle = 6 }};
    for (&snapshot.options) |*options| options.new_window_anchor = 2;
    placements = try arrange(std.testing.allocator, &state, &snapshot, area, &arrivals, 6, .{});
    std.testing.allocator.free(placements);
    try std.testing.expectEqual(@as(?u8, 0), state.composite.membership.get(6));
    // Switch regions and admit 7 in one transaction: active still points at
    // region A, while the runtime anchor is a member of region B.
    for (&snapshot.options) |*options| options.new_window_anchor = 4;
    placements = try arrange(std.testing.allocator, &state, &snapshot, area, &(arrivals ++ [_]types.Window{.{ .handle = 7 }}), 7, .{});
    defer std.testing.allocator.free(placements);
    try expectPlacementOrder(placements, &.{ 1, 2, 6, 3, 4, 7, 5 });
    try std.testing.expectEqual(@as(?u8, 1), state.composite.membership.get(7));
}

test "fractional widths route through scrolling and game fallback and leave other layouts alone" {
    const windows = [_]types.Window{.{ .handle = 1, .scrolling_width = 0.65 }};
    const area: types.Rect = .{ .x = 0, .y = 0, .width = 400, .height = 200 };
    var snapshot: config.Snapshot = .{};
    for (&snapshot.options) |*options| {
        options.gaps_outer = 0;
        options.border = .none;
    }
    var state: State = .{};
    defer state.deinit(std.testing.allocator);
    for ([_]config.LayoutId{ .scrolling, .monocle, .game_mode, .scrolling }) |id| {
        snapshot.default = id;
        const result = try arrange(std.testing.allocator, &state, &snapshot, area, &windows, 1, .{ .fallback = .scrolling });
        defer std.testing.allocator.free(result);
        try std.testing.expectEqual(@as(i32, if (id == .monocle) 400 else 260), result[0].geometry.width);
        try std.testing.expectEqual(@as(i32, 200), result[0].geometry.height);
    }
}

test "fractional widths use game remainder and composable region rectangles" {
    const area: types.Rect = .{ .x = 0, .y = 0, .width = 400, .height = 200 };
    const windows = [_]types.Window{ .{ .handle = 1, .scrolling_width = 0.65 }, .{ .handle = 2, .scrolling_width = 0.25 } };
    var snapshot: config.Snapshot = .{};
    for (&snapshot.options) |*options| {
        options.gaps_outer = 0;
        options.gaps_inner = 0;
        options.border = .none;
    }
    snapshot.default = .game_mode;
    var state: State = .{};
    defer state.deinit(std.testing.allocator);
    const game = gameModeState(&state);
    game.rule_anchor = 1;
    game.rule_options = .{
        .anchor = .left,
        .size = .{ .pixels = .{ .width = 100, .height = 100 } },
        .remainder = .scrolling,
        .gaps_inner = 0,
    };
    var result = try arrange(std.testing.allocator, &state, &snapshot, area, &windows, 2, .{});
    try std.testing.expectEqual(@as(i32, 100), result[0].geometry.width);
    try std.testing.expectEqual(@as(i32, 75), result[1].geometry.width);
    std.testing.allocator.free(result);

    snapshot.default = .composable;
    config.apply(&snapshot,
        \\[layout.composable.a]
        \\layout = "scrolling"
        \\p1 = [0.0, 0.0]
        \\p2 = [0.25, 0.0]
        \\p3 = [0.25, 1.0]
        \\p4 = [0.0, 1.0]
        \\[layout.composable.b]
        \\layout = "scrolling"
        \\p1 = [0.25, 0.0]
        \\p2 = [1.0, 0.0]
        \\p3 = [1.0, 1.0]
        \\p4 = [0.25, 1.0]
    );
    std.testing.allocator.free(try arrange(std.testing.allocator, &state, &snapshot, area, &windows, 1, .{}));
    try std.testing.expect(moveToComposableSlot(&state, 2, 1));
    result = try arrange(std.testing.allocator, &state, &snapshot, area, &windows, 2, .{});
    defer std.testing.allocator.free(result);
    try std.testing.expectEqual(@as(i32, 65), result[0].geometry.width);
    try std.testing.expectEqual(@as(i32, 75), result[1].geometry.width);
}

test "published order follows layout moves without focus ordering" {
    const a = std.testing.allocator;
    const area: types.Rect = .{ .x = 0, .y = 0, .width = 300, .height = 100 };
    const windows = [_]types.Window{ .{ .handle = 1 }, .{ .handle = 2 }, .{ .handle = 3 } };
    for ([_]config.LayoutId{ .tile, .monocle, .grid, .rows, .dwindle, .reverse_dwindle, .scrolling }) |id| {
        var state: State = .{};
        defer state.deinit(a);
        var snapshot: config.Snapshot = .{};
        snapshot.default = id;
        try std.testing.expectEqual(null, orderIndex(&state, 1));
        a.free(try arrange(a, &state, &snapshot, area, &windows, 1, .{}));
        try std.testing.expectEqual(@as(?u32, 0), orderIndex(&state, 1));
        try std.testing.expectEqual(@as(?u32, 2), orderIndex(&state, 3));
        a.free(try arrange(a, &state, &snapshot, area, &windows, 3, .{}));
        try std.testing.expectEqual(@as(?u32, 0), orderIndex(&state, 1));
        try std.testing.expect(swap(&state, 1, 3));
        try std.testing.expectEqual(@as(?u32, 2), orderIndex(&state, 1));
        try std.testing.expectEqual(@as(?u32, 0), orderIndex(&state, 3));
        // Inactive workspaces retain their last order; new arrivals are unknown.
        try std.testing.expectEqual(null, orderIndex(&state, 4));
        a.free(try arrange(a, &state, &snapshot, area, windows[0..2], 1, .{}));
        try std.testing.expectEqual(null, orderIndex(&state, 3));
    }
    var state: State = .{};
    defer state.deinit(a);
    var snapshot: config.Snapshot = .{};
    snapshot.default = .scrolling;
    a.free(try arrange(a, &state, &snapshot, area, &windows, 1, .{}));
    try std.testing.expect(try drop(a, &state, 3, 1, .stack_after));
    a.free(try arrange(a, &state, &snapshot, area, &windows, 1, .{}));
    try std.testing.expectEqual(@as(?u32, 1), orderIndex(&state, 3));
    try std.testing.expectEqual(@as(?u32, 2), orderIndex(&state, 2));
    for ([_]config.LayoutId{ .floating, .game_mode, .composable }) |id| {
        state.active_layout = id;
        try std.testing.expectEqual(null, orderIndex(&state, 1));
    }
}

test "single tile centering follows zero one two one transitions in every supported layout" {
    const allocator = std.testing.allocator;
    const area: types.Rect = .{ .x = -2200, .y = 40, .width = 2017, .height = 817 };
    const windows = [_]types.Window{ .{ .handle = 1 }, .{ .handle = 2 } };
    for ([_]config.LayoutId{ .tile, .grid, .rows, .dwindle, .reverse_dwindle }) |id| {
        var snapshot: config.Snapshot = .{};
        snapshot.default = id;
        const options = &snapshot.options[@intFromEnum(id)];
        options.gaps_outer = 8;
        options.center_single_window = true;
        options.single_window_aspect_ratio = 1.5;
        options.border.width = 2;
        var state: State = .{};
        defer state.deinit(allocator);
        for ([_]usize{ 0, 1, 2, 1 }) |count| {
            const result = try arrange(allocator, &state, &snapshot, area, windows[0..count], 1, .{});
            defer allocator.free(result);
            try std.testing.expectEqual(count, result.len);
            if (count == 1) {
                try std.testing.expectEqual(types.Rect{ .x = -1793, .y = 48, .width = 1202, .height = 801 }, result[0].geometry);
                try std.testing.expectEqual(@as(i32, 2), result[0].border.width);
                try std.testing.expect(result[0].tiled and result[0].visible);
            } else if (count == 2) {
                var baseline_state: State = .{};
                defer baseline_state.deinit(allocator);
                var baseline_snapshot = snapshot;
                baseline_snapshot.options[@intFromEnum(id)].center_single_window = false;
                const baseline = try arrange(allocator, &baseline_state, &baseline_snapshot, area, &windows, 1, .{});
                defer allocator.free(baseline);
                try std.testing.expectEqualDeep(baseline, result);
            }
        }
        // A config reload applies on the same live layout state.
        options.center_single_window = false;
        const disabled = try arrange(allocator, &state, &snapshot, area, windows[0..1], 1, .{});
        defer allocator.free(disabled);
        try std.testing.expectEqual(types.Rect{ .x = -2192, .y = 48, .width = 2001, .height = 801 }, disabled[0].geometry);
        try std.testing.expectEqual(id, state.active_layout);
    }
}

test "single window centering leaves specialized layouts alone" {
    const allocator = std.testing.allocator;
    for ([_]config.LayoutId{ .monocle, .scrolling, .floating, .game_mode }) |id| {
        var snapshot: config.Snapshot = .{};
        snapshot.default = id;
        var ordinary: State = .{};
        defer ordinary.deinit(allocator);
        var centered: State = .{};
        defer centered.deinit(allocator);
        const area: types.Rect = .{ .x = 0, .y = 0, .width = 3000, .height = 800 };
        const baseline = try arrange(allocator, &ordinary, &snapshot, area, &.{.{ .handle = 1 }}, 1, .{});
        defer allocator.free(baseline);
        for (&snapshot.options) |*options| options.center_single_window = true;
        const result = try arrange(allocator, &centered, &snapshot, area, &.{.{ .handle = 1 }}, 1, .{});
        defer allocator.free(result);
        try std.testing.expectEqualDeep(baseline, result);
    }
}

test "single window centering preserves tile resize state and composable membership" {
    const allocator = std.testing.allocator;
    var snapshot: config.Snapshot = .{};
    config.apply(&snapshot,
        \\[layout]
        \\default = "composable"
        \\gaps_outer = 0
        \\center_single_window = true
        \\single_window_aspect_ratio = 1.0
        \\[layout.composable.a]
        \\layout = "tile"
        \\p1 = [0.0, 0.0]
        \\p2 = [0.5, 0.0]
        \\p3 = [0.5, 1.0]
        \\p4 = [0.0, 1.0]
        \\[layout.composable.b]
        \\layout = "reverse-dwindle"
        \\p1 = [0.5, 0.0]
        \\p2 = [1.0, 0.0]
        \\p3 = [1.0, 1.0]
        \\p4 = [0.5, 1.0]
    );
    var state: State = .{};
    defer state.deinit(allocator);
    try state.composite.membership.put(allocator, 1, 0);
    try state.composite.membership.put(allocator, 2, 1);
    state.composite.children[0].tile.master_ratio_override = 0.7;
    try state.composite.children[0].tile.height_overrides.put(allocator, 1, 300);
    const placements = try arrange(allocator, &state, &snapshot, .{ .x = 100, .y = 20, .width = 4000, .height = 1000 }, &.{ .{ .handle = 1 }, .{ .handle = 2 } }, 1, .{});
    defer allocator.free(placements);
    try std.testing.expectEqual(types.Rect{ .x = 600, .y = 20, .width = 1000, .height = 1000 }, placements[0].geometry);
    try std.testing.expectEqual(types.Rect{ .x = 2600, .y = 20, .width = 1000, .height = 1000 }, placements[1].geometry);
    try std.testing.expectEqual(@as(?f64, 0.7), state.composite.children[0].tile.master_ratio_override);
    try std.testing.expectEqual(@as(?i32, 300), state.composite.children[0].tile.height_overrides.get(1));
    try std.testing.expectEqual(@as(?u8, 1), state.composite.membership.get(2));
}

test "output relocation updates dormant standalone and composable floating caches" {
    const floating = @import("floating.zig");
    var state: State = .{};
    defer state.deinit(std.testing.allocator);
    const before: types.Rect = .{ .x = 1920, .y = 0, .width = 1920, .height = 1080 };
    const after: types.Rect = .{ .x = -1920, .y = 0, .width = 1920, .height = 1080 };
    const original: types.Rect = .{ .x = 2020, .y = 100, .width = 500, .height = 300 };
    try floating.setGeometry(&state.standalone.floating, std.testing.allocator, 1, original);
    try floating.setGeometry(&state.composite.children[2].floating, std.testing.allocator, 2, original);
    reconfigureOutput(&state, before, after, after);
    const moved: types.Rect = .{ .x = -1820, .y = 100, .width = 500, .height = 300 };
    try std.testing.expectEqual(moved, floating.geometry(&state.standalone.floating, 1).?);
    try std.testing.expectEqual(moved, floating.geometry(&state.composite.children[2].floating, 2).?);
    reconfigureOutput(&state, after, before, before);
    try std.testing.expectEqual(original, floating.geometry(&state.standalone.floating, 1).?);
    try std.testing.expectEqual(original, floating.geometry(&state.composite.children[2].floating, 2).?);
}

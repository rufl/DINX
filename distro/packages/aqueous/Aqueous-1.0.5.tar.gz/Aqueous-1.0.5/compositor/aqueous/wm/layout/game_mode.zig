// SPDX-FileCopyrightText: © 2026 Seafoam Labs
// SPDX-License-Identifier: GPL-3.0-only

const std = @import("std");
const geometry = @import("game_geometry.zig");
const dwindle = @import("dwindle.zig");
const floating = @import("floating.zig");
const grid = @import("grid.zig");
const math = @import("math.zig");
const monocle = @import("monocle.zig");
const order = @import("order.zig");
const rows = @import("rows.zig");
const scrolling = @import("scrolling.zig");
const tile = @import("tile.zig");
const types = @import("types.zig");

pub const RemainderState = struct {
    grid: grid.State = .{},
    rows: rows.State = .{},
    tile: tile.State = .{},
    monocle: monocle.State = .{},
    dwindle: dwindle.State = .{},
    reverse_dwindle: dwindle.State = .{},
    scrolling: scrolling.State = .{},
    floating: floating.State = .{},
    pub fn deinit(state: *RemainderState, allocator: std.mem.Allocator) void {
        state.grid.deinit(allocator);
        state.rows.deinit(allocator);
        state.tile.deinit(allocator);
        state.monocle.deinit(allocator);
        state.dwindle.deinit(allocator);
        state.reverse_dwindle.deinit(allocator);
        state.scrolling.deinit(allocator);
        state.floating.deinit(allocator);
    }

    fn orderFor(state: *RemainderState, kind: Remainder) ?*order.State {
        return switch (kind) {
            .tile => &state.tile.order,
            .monocle => &state.monocle.order,
            .grid => &state.grid.order,
            .rows => &state.rows.order,
            .dwindle => &state.dwindle.order,
            .reverse_dwindle => &state.reverse_dwindle.order,
            .scrolling => null,
            .floating => null,
        };
    }
};

pub const State = struct {
    fallback: RemainderState = .{},
    left: RemainderState = .{},
    right: RemainderState = .{},
    /// A matched game rule claimed this workspace's layout. The claim remains
    /// after its anchor closes so fallback_layout is actually reachable, and
    /// is released only by an explicit user layout selection.
    rule_layout_owned: bool = false,
    anchor: ?types.Handle = null,
    rule_anchor: ?types.Handle = null,
    rule_options: Options = .{},
    active_remainder: Remainder = .grid,

    pub fn deinit(state: *State, allocator: std.mem.Allocator) void {
        state.fallback.deinit(allocator);
        state.left.deinit(allocator);
        state.right.deinit(allocator);
    }
};

pub const ScrollingOptions = struct {
    column_fraction: f64 = 0.5,
    center_focused: bool = true,
    follow_new: bool = true,
    open_new_windows_to_right: bool = false,
    prefer_vertical_on_portrait: bool = false,
    snap: bool = false,
    overscroll: bool = true,
};

pub const Options = struct {
    size: geometry.Size = .{ .fraction = .{ .width = 0.5, .height = 1.0 } },
    anchor: geometry.Anchor = .center,
    scale: f64 = 1,
    remainder: Remainder = .grid,
    fallback: Remainder = .grid,
    gaps_inner: ?i32 = null,
    anchor_area: ?types.Rect = null,
    scrolling_options: ScrollingOptions = .{},
};

pub const Remainder = enum { tile, monocle, grid, rows, dwindle, reverse_dwindle, scrolling, floating };

pub fn arrange(allocator: std.mem.Allocator, state: *State, usable_area: types.Rect, windows: []const types.Window, focused: ?types.Handle, options: types.Options, game_options: Options) ![]types.Placement {
    const result = try allocator.alloc(types.Placement, windows.len);
    if (windows.len == 0) {
        state.anchor = null;
        return result;
    }
    const effective = if (state.rule_anchor != null) state.rule_options else game_options;
    if (state.rule_anchor == null) {
        state.anchor = null;
        state.active_remainder = effective.fallback;
        const placements = try arrangeRemainder(allocator, &state.fallback, effective.fallback, usable_area, windows, focused, options, game_options.scrolling_options);
        defer allocator.free(placements);
        @memcpy(result, placements);
        return result;
    }
    state.active_remainder = effective.remainder;
    if (state.rule_anchor) |anchor| {
        if (contains(windows, anchor)) state.anchor = anchor;
    } else if (focused != null and contains(windows, focused.?)) state.anchor = focused;
    if (state.anchor == null or !contains(windows, state.anchor.?)) state.anchor = windows[0].handle;
    const anchor_window = find(windows, state.anchor.?).?;
    const area = math.shrink(usable_area, options.gaps_outer);
    const anchor_area = if (effective.anchor_area) |raw| math.shrink(raw, options.gaps_outer) else area;
    const anchor_rect = geometry.resolveAnchor(anchor_area, @max(1, anchor_window.min_width), @max(1, anchor_window.min_height), effective.size, effective.anchor, effective.scale);
    result[0] = .{ .handle = state.anchor.?, .geometry = anchor_rect, .z_order = 1, .visible = true, .border = .none };

    const columns = geometry.resolveSideColumns(area, anchor_rect);
    var left_windows: std.ArrayListUnmanaged(types.Window) = .empty;
    defer left_windows.deinit(allocator);
    var right_windows: std.ArrayListUnmanaged(types.Window) = .empty;
    defer right_windows.deinit(allocator);
    const left_empty = columns.left.width <= 0 or columns.left.height <= 0;
    const right_empty = columns.right.width <= 0 or columns.right.height <= 0;
    var non_anchor_index: usize = 0;
    for (windows) |window| {
        if (window.handle == state.anchor.?) continue;
        if (left_empty and right_empty) {
            non_anchor_index += 1;
            continue;
        }
        if (left_empty) {
            try right_windows.append(allocator, window);
        } else if (right_empty or non_anchor_index % 2 == 0) {
            try left_windows.append(allocator, window);
        } else {
            try right_windows.append(allocator, window);
        }
        non_anchor_index += 1;
    }

    if (left_empty and right_empty) {
        var write: usize = 1;
        for (windows) |window| {
            if (window.handle == state.anchor.?) continue;
            result[write] = .{ .handle = window.handle, .geometry = .empty, .z_order = 0, .visible = false, .border = .none };
            write += 1;
        }
        return result;
    }

    var remainder_options = options;
    remainder_options.gaps_outer = 0;
    remainder_options.gaps_inner = effective.gaps_inner orelse options.gaps_inner;
    var write: usize = 1;
    const left_placements = try arrangeRemainder(allocator, &state.left, effective.remainder, columns.left, left_windows.items, focused, remainder_options, game_options.scrolling_options);
    defer allocator.free(left_placements);
    @memcpy(result[write .. write + left_placements.len], left_placements);
    write += left_placements.len;
    const right_placements = try arrangeRemainder(allocator, &state.right, effective.remainder, columns.right, right_windows.items, focused, remainder_options, game_options.scrolling_options);
    defer allocator.free(right_placements);
    @memcpy(result[write .. write + right_placements.len], right_placements);
    write += right_placements.len;
    std.debug.assert(write == result.len);
    return result;
}

fn arrangeRemainder(allocator: std.mem.Allocator, state: *RemainderState, kind: Remainder, area: types.Rect, windows: []const types.Window, focused: ?types.Handle, options: types.Options, scrolling_options: ScrollingOptions) ![]types.Placement {
    return switch (kind) {
        .tile => tile.arrange(allocator, &state.tile, area, windows, options),
        .monocle => monocle.arrange(allocator, &state.monocle, area, windows, focused, options, .{}),
        .grid => grid.arrange(allocator, &state.grid, area, windows, options),
        .rows => rows.arrange(allocator, &state.rows, area, windows, options),
        .dwindle => dwindle.arrange(allocator, &state.dwindle, area, windows, options, .{}),
        .reverse_dwindle => dwindle.arrange(allocator, &state.reverse_dwindle, area, windows, options, .{ .reverse = true }),
        .scrolling => scrolling.arrange(allocator, &state.scrolling, area, windows, focused, options, .{
            .allow_overscroll = scrolling_options.overscroll,
            .center_focused = scrolling_options.center_focused,
            .column_width = scrolling_options.column_fraction,
            .follow_new_windows = scrolling_options.follow_new,
            .open_new_windows_to_right = scrolling_options.open_new_windows_to_right,
            .prefer_vertical_on_portrait = scrolling_options.prefer_vertical_on_portrait,
            .snap_to_columns = scrolling_options.snap,
        }),
        .floating => floating.arrange(allocator, &state.floating, area, windows, focused, options),
    };
}

pub fn swap(state: *State, a: types.Handle, b: types.Handle) bool {
    var changed = false;
    inline for (.{ &state.fallback, &state.left, &state.right }) |side| {
        inline for (.{ &side.tile.order, &side.monocle.order, &side.grid.order, &side.rows.order, &side.dwindle.order, &side.reverse_dwindle.order }) |layout_order| {
            if (layout_order.swap(a, b)) changed = true;
        }
        if (scrolling.swap(&side.scrolling, a, b)) changed = true;
    }
    return changed;
}

pub fn moveAdjacent(state: *State, focused: types.Handle, delta: i32) bool {
    if (state.active_remainder == .scrolling) return false;
    for ([_]*RemainderState{ &state.fallback, &state.left, &state.right }) |side| {
        const layout_order = side.orderFor(state.active_remainder) orelse return false;
        const index = std.mem.indexOfScalar(types.Handle, layout_order.items.items, focused) orelse continue;
        const target = @as(isize, @intCast(index)) + delta;
        if (target < 0 or target >= layout_order.items.items.len) return false;
        std.mem.swap(types.Handle, &layout_order.items.items[index], &layout_order.items.items[@intCast(target)]);
        return true;
    }
    return false;
}

/// Apply ordinary move-window semantics inside the active remainder engine.
/// The game anchor never belongs to a remainder state and is therefore
/// immovable. A scrolling remainder joins adjacent columns horizontally and
/// reorders members vertically, matching the standalone scrolling layout.
pub fn moveWindow(
    state: *State,
    allocator: std.mem.Allocator,
    focused: types.Handle,
    dx: i32,
    dy: i32,
) !bool {
    if (dx == 0 and dy == 0) return false;
    if (state.anchor == focused) return false;
    if (state.active_remainder != .scrolling) {
        return moveAdjacent(state, focused, if (dx != 0) dx else dy);
    }
    for ([_]*RemainderState{ &state.fallback, &state.left, &state.right }) |side| {
        if (!scrolling.containsHandle(&side.scrolling, focused)) continue;
        return if (dx != 0)
            try scrolling.moveToAdjacentColumn(&side.scrolling, allocator, focused, dx)
        else
            scrolling.moveWithinColumn(&side.scrolling, focused, dy);
    }
    return false;
}

pub fn scrollViewport(state: *State, focused: types.Handle, dx: i32, dy: i32) bool {
    if (state.active_remainder != .scrolling) return false;
    for ([_]*RemainderState{ &state.fallback, &state.left, &state.right }) |side| {
        if (scrolling.containsHandle(&side.scrolling, focused)) {
            return if (dx != 0)
                scrolling.scrollViewport(&side.scrolling, dx)
            else
                scrolling.scrollColumn(&side.scrolling, focused, dy);
        }
    }
    return false;
}

pub fn viewportFocusTarget(state: *const State, focused: types.Handle) ?types.Handle {
    if (state.active_remainder != .scrolling) return null;
    for ([_]*const RemainderState{ &state.fallback, &state.left, &state.right }) |side| {
        if (scrolling.containsHandle(&side.scrolling, focused)) {
            return scrolling.viewportFocusTarget(&side.scrolling);
        }
    }
    return null;
}

pub fn supportsViewportScroll(state: *const State, handle: types.Handle) bool {
    if (state.active_remainder != .scrolling or state.anchor == handle) return false;
    for ([_]*const RemainderState{ &state.fallback, &state.left, &state.right }) |side| {
        if (scrolling.containsHandle(&side.scrolling, handle)) return true;
    }
    return false;
}

pub fn prefersVerticalScroll(state: *const State, handle: types.Handle) bool {
    if (state.active_remainder != .scrolling or state.anchor == handle) return false;
    for ([_]*const RemainderState{ &state.fallback, &state.left, &state.right }) |side| {
        if (scrolling.prefersVerticalScroll(&side.scrolling, handle)) return true;
    }
    return false;
}

pub fn canResizeScrolling(state: *const State, handle: types.Handle) bool {
    return supportsViewportScroll(state, handle);
}

pub fn isAnchor(state: *const State, handle: types.Handle) bool {
    return state.anchor == handle;
}

pub fn scrollingExpandedOwner(state: *const State, handle: types.Handle) ?types.Handle {
    if (!canResizeScrolling(state, handle)) return null;
    for ([_]*const RemainderState{ &state.fallback, &state.left, &state.right }) |side| {
        if (scrolling.containsHandle(&side.scrolling, handle)) {
            return scrolling.expandedOwner(&side.scrolling, handle);
        }
    }
    return null;
}

pub fn scrollingColumnMembers(state: *const State, handle: types.Handle) ?[]const types.Handle {
    if (!canResizeScrolling(state, handle)) return null;
    for ([_]*const RemainderState{ &state.fallback, &state.left, &state.right }) |side| {
        if (scrolling.columnMembers(&side.scrolling, handle)) |members| return members;
    }
    return null;
}

pub fn resizeScrolling(
    state: *State,
    allocator: std.mem.Allocator,
    handle: types.Handle,
    update: types.ResizeUpdate,
) !bool {
    if (state.active_remainder != .scrolling or state.anchor == handle) return false;
    for ([_]*RemainderState{ &state.fallback, &state.left, &state.right }) |side| {
        if (!scrolling.containsHandle(&side.scrolling, handle)) continue;
        return scrolling.resize(&side.scrolling, allocator, handle, update);
    }
    return false;
}

pub fn resetScrollingSize(state: *State, handle: types.Handle) bool {
    if (state.active_remainder != .scrolling or state.anchor == handle) return false;
    for ([_]*RemainderState{ &state.fallback, &state.left, &state.right }) |side| {
        if (!scrolling.containsHandle(&side.scrolling, handle)) continue;
        return scrolling.resetSize(&side.scrolling, handle);
    }
    return false;
}

fn contains(windows: []const types.Window, handle: types.Handle) bool {
    return find(windows, handle) != null;
}

fn find(windows: []const types.Window, handle: types.Handle) ?types.Window {
    for (windows) |window| if (window.handle == handle) return window;
    return null;
}

test "game mode anchors focus and tiles the remainder" {
    var state: State = .{
        .rule_anchor = 2,
        .rule_options = .{ .gaps_inner = 0 },
    };
    defer state.deinit(std.testing.allocator);
    const placements = try arrange(std.testing.allocator, &state, .{ .x = 0, .y = 0, .width = 200, .height = 100 }, &.{
        .{ .handle = 1 }, .{ .handle = 2 }, .{ .handle = 3 },
    }, 2, .{ .gaps_outer = 0, .gaps_inner = 0 }, .{});
    defer std.testing.allocator.free(placements);
    try std.testing.expectEqual(@as(types.Handle, 2), placements[0].handle);
    try std.testing.expectEqual(types.Rect{ .x = 50, .y = 0, .width = 100, .height = 100 }, placements[0].geometry);
    try std.testing.expect(placements[1].visible);
    try std.testing.expect(placements[2].visible);
}

test "game mode delegates a no-anchor output to the configured tile fallback" {
    var state: State = .{};
    defer state.deinit(std.testing.allocator);
    const placements = try arrange(std.testing.allocator, &state, .{ .x = 0, .y = 0, .width = 100, .height = 80 }, &.{
        .{ .handle = 1 }, .{ .handle = 2 }, .{ .handle = 3 },
    }, 1, .{ .gaps_outer = 0, .gaps_inner = 4, .master_ratio = 0.5 }, .{ .fallback = .tile });
    defer std.testing.allocator.free(placements);

    try std.testing.expectEqual(@as(?types.Handle, null), state.anchor);
    try std.testing.expectEqual(Remainder.tile, state.active_remainder);
    try std.testing.expectEqual(types.Rect{ .x = 0, .y = 0, .width = 50, .height = 80 }, findPlacement(placements, 1).geometry);
    try std.testing.expectEqual(types.Rect{ .x = 54, .y = 0, .width = 46, .height = 38 }, findPlacement(placements, 2).geometry);
    try std.testing.expectEqual(types.Rect{ .x = 54, .y = 42, .width = 46, .height = 38 }, findPlacement(placements, 3).geometry);
    try std.testing.expectEqualSlices(types.Handle, &.{ 1, 2, 3 }, state.fallback.tile.order.items.items);
    try std.testing.expectEqual(@as(usize, 0), state.fallback.grid.order.items.items.len);
}

test "game mode routes viewport movement to a scrolling fallback" {
    var state: State = .{};
    defer state.deinit(std.testing.allocator);
    const placements = try arrange(std.testing.allocator, &state, .{ .x = 0, .y = 0, .width = 100, .height = 80 }, &.{
        .{ .handle = 1 }, .{ .handle = 2 }, .{ .handle = 3 },
    }, 1, .{ .gaps_outer = 0, .gaps_inner = 0 }, .{ .fallback = .scrolling });
    std.testing.allocator.free(placements);

    try std.testing.expect(scrollViewport(&state, 1, 1, 0));
    try std.testing.expectEqual(@as(?types.Handle, 2), viewportFocusTarget(&state, 1));
    try std.testing.expectEqual(@as(usize, 1), state.fallback.scrolling.viewport_column);
}

test "game mode resizes a tiled member in a scrolling fallback" {
    var state: State = .{};
    defer state.deinit(std.testing.allocator);
    const windows = [_]types.Window{ .{ .handle = 1 }, .{ .handle = 2 } };
    const area: types.Rect = .{ .x = 0, .y = 0, .width = 100, .height = 80 };
    const options: types.Options = .{ .gaps_outer = 0, .gaps_inner = 0 };
    const game_options: Options = .{ .fallback = .scrolling };
    const initial = try arrange(std.testing.allocator, &state, area, &windows, 1, options, game_options);
    std.testing.allocator.free(initial);

    try std.testing.expect(canResizeScrolling(&state, 1));
    try std.testing.expect(try resizeScrolling(&state, std.testing.allocator, 1, .{ .width = 70 }));
    try std.testing.expect(try resizeScrolling(&state, std.testing.allocator, 1, .{ .height = 30 }));
    const resized = try arrange(std.testing.allocator, &state, area, &windows, 1, options, game_options);
    defer std.testing.allocator.free(resized);
    try std.testing.expectEqual(@as(i32, 70), findPlacement(resized, 1).geometry.width);
    try std.testing.expectEqual(@as(i32, 30), findPlacement(resized, 1).geometry.height);

    try std.testing.expect(resetScrollingSize(&state, 1));
    const reset = try arrange(std.testing.allocator, &state, area, &windows, 1, options, game_options);
    defer std.testing.allocator.free(reset);
    try std.testing.expectEqual(@as(i32, 50), findPlacement(reset, 1).geometry.width);
    try std.testing.expectEqual(@as(i32, 80), findPlacement(reset, 1).geometry.height);
}

test "game mode joins windows across columns in a scrolling fallback" {
    var state: State = .{};
    defer state.deinit(std.testing.allocator);
    const windows = [_]types.Window{ .{ .handle = 1 }, .{ .handle = 2 }, .{ .handle = 3 } };
    const placements = try arrange(
        std.testing.allocator,
        &state,
        .{ .x = 0, .y = 0, .width = 100, .height = 80 },
        &windows,
        2,
        .{ .gaps_outer = 0, .gaps_inner = 0 },
        .{ .fallback = .scrolling },
    );
    std.testing.allocator.free(placements);

    try std.testing.expect(try moveWindow(&state, std.testing.allocator, 2, -1, 0));
    try std.testing.expectEqual(@as(usize, 2), state.fallback.scrolling.columns.items.len);
    try std.testing.expectEqualSlices(types.Handle, &.{ 1, 2 }, state.fallback.scrolling.columns.items[0].windows.items);
    try std.testing.expectEqualSlices(types.Handle, &.{3}, state.fallback.scrolling.columns.items[1].windows.items);
}

test "game mode joins windows within an anchored scrolling remainder" {
    var state: State = .{
        .rule_anchor = 1,
        .rule_options = .{
            .size = .{ .pixels = .{ .width = 100, .height = 100 } },
            .remainder = .scrolling,
            .gaps_inner = 0,
        },
    };
    defer state.deinit(std.testing.allocator);
    const windows = [_]types.Window{
        .{ .handle = 1 }, .{ .handle = 2 }, .{ .handle = 3 }, .{ .handle = 4 }, .{ .handle = 5 },
    };
    const placements = try arrange(
        std.testing.allocator,
        &state,
        .{ .x = 0, .y = 0, .width = 300, .height = 100 },
        &windows,
        4,
        .{ .gaps_outer = 0, .gaps_inner = 0 },
        .{},
    );
    std.testing.allocator.free(placements);

    try std.testing.expect(try moveWindow(&state, std.testing.allocator, 4, -1, 0));
    try std.testing.expectEqual(@as(usize, 1), state.left.scrolling.columns.items.len);
    try std.testing.expectEqualSlices(types.Handle, &.{ 2, 4 }, state.left.scrolling.columns.items[0].windows.items);
    try std.testing.expectEqual(@as(usize, 2), state.right.scrolling.columns.items.len);
    try std.testing.expect(!try moveWindow(&state, std.testing.allocator, 1, 1, 0));
}

test "game mode routes resize to a side remainder and rejects its anchor" {
    var state: State = .{
        .rule_anchor = 1,
        .rule_options = .{
            .size = .{ .pixels = .{ .width = 100, .height = 100 } },
            .remainder = .scrolling,
            .gaps_inner = 0,
        },
    };
    defer state.deinit(std.testing.allocator);
    const windows = [_]types.Window{ .{ .handle = 1 }, .{ .handle = 2 }, .{ .handle = 3 } };
    const area: types.Rect = .{ .x = 0, .y = 0, .width = 300, .height = 100 };
    const options: types.Options = .{ .gaps_outer = 0, .gaps_inner = 0 };
    const initial = try arrange(std.testing.allocator, &state, area, &windows, 2, options, .{});
    std.testing.allocator.free(initial);

    try std.testing.expect(!canResizeScrolling(&state, 1));
    try std.testing.expect(!(try resizeScrolling(&state, std.testing.allocator, 1, .{ .width = 40 })));
    try std.testing.expect(canResizeScrolling(&state, 2));
    try std.testing.expect(try resizeScrolling(&state, std.testing.allocator, 2, .{ .width = 40 }));
    try std.testing.expect(try resizeScrolling(&state, std.testing.allocator, 2, .{ .height = 35 }));
    const resized = try arrange(std.testing.allocator, &state, area, &windows, 2, options, .{});
    defer std.testing.allocator.free(resized);
    try std.testing.expectEqual(@as(i32, 40), findPlacement(resized, 2).geometry.width);
    try std.testing.expectEqual(@as(i32, 35), findPlacement(resized, 2).geometry.height);
    try std.testing.expect(resetScrollingSize(&state, 2));
}

test "game mode routes vertical movement to the focused scrolling column" {
    var state: State = .{};
    defer state.deinit(std.testing.allocator);
    const windows = [_]types.Window{
        .{ .handle = 1, .min_height = 60 },
        .{ .handle = 2, .min_height = 60 },
        .{ .handle = 3 },
    };
    const area: types.Rect = .{ .x = 0, .y = 0, .width = 100, .height = 80 };
    const options: types.Options = .{ .gaps_outer = 0, .gaps_inner = 0 };
    const game_options: Options = .{ .fallback = .scrolling };
    const initial = try arrange(std.testing.allocator, &state, area, &windows, 1, options, game_options);
    std.testing.allocator.free(initial);
    try std.testing.expect(try scrolling.consumeFromRight(&state.fallback.scrolling, std.testing.allocator, 1));
    const stacked = try arrange(std.testing.allocator, &state, area, &windows, 1, options, game_options);
    std.testing.allocator.free(stacked);

    try std.testing.expect(scrollViewport(&state, 1, 0, 1));
    try std.testing.expectEqual(@as(?types.Handle, 2), viewportFocusTarget(&state, 1));
    const scrolled = try arrange(std.testing.allocator, &state, area, &windows, 1, options, game_options);
    defer std.testing.allocator.free(scrolled);
    try std.testing.expectEqual(@as(i32, -80), findPlacement(scrolled, 1).geometry.y);
    try std.testing.expectEqual(@as(i32, 0), findPlacement(scrolled, 2).geometry.y);
}

test "game mode preserves each scrolling side column as its own viewport" {
    var state: State = .{
        .rule_anchor = 1,
        .rule_options = .{
            .size = .{ .pixels = .{ .width = 100, .height = 100 } },
            .remainder = .scrolling,
            .gaps_inner = 0,
        },
    };
    defer state.deinit(std.testing.allocator);
    const placements = try arrange(std.testing.allocator, &state, .{ .x = 0, .y = 0, .width = 300, .height = 100 }, &.{
        .{ .handle = 1 }, .{ .handle = 2 }, .{ .handle = 3 }, .{ .handle = 4 }, .{ .handle = 5 },
    }, 1, .{ .gaps_outer = 0, .gaps_inner = 0 }, .{});
    defer std.testing.allocator.free(placements);

    try std.testing.expectEqual(types.Rect{ .x = 25, .y = 0, .width = 100, .height = 100 }, findPlacement(placements, 2).clip.?);
    try std.testing.expectEqual(types.Rect{ .x = 25, .y = 0, .width = 100, .height = 100 }, findPlacement(placements, 3).clip.?);
    try std.testing.expectEqual(types.Rect{ .x = -25, .y = 0, .width = 100, .height = 100 }, findPlacement(placements, 4).clip.?);
    try std.testing.expectEqual(types.Rect{ .x = -25, .y = 0, .width = 100, .height = 100 }, findPlacement(placements, 5).clip.?);
}

test "game mode applies rows independently to both side columns" {
    var state: State = .{
        .rule_anchor = 1,
        .rule_options = .{
            .size = .{ .pixels = .{ .width = 100, .height = 100 } },
            .remainder = .rows,
            .gaps_inner = 0,
        },
    };
    defer state.deinit(std.testing.allocator);
    const placements = try arrange(std.testing.allocator, &state, .{ .x = 0, .y = 0, .width = 300, .height = 100 }, &.{
        .{ .handle = 1 }, .{ .handle = 2 }, .{ .handle = 3 }, .{ .handle = 4 }, .{ .handle = 5 },
    }, 1, .{ .gaps_outer = 0, .gaps_inner = 0 }, .{});
    defer std.testing.allocator.free(placements);

    try std.testing.expectEqual(types.Rect{ .x = 100, .y = 0, .width = 100, .height = 100 }, findPlacement(placements, 1).geometry);
    try std.testing.expectEqual(types.Rect{ .x = 0, .y = 0, .width = 100, .height = 50 }, findPlacement(placements, 2).geometry);
    try std.testing.expectEqual(types.Rect{ .x = 200, .y = 0, .width = 100, .height = 50 }, findPlacement(placements, 3).geometry);
    try std.testing.expectEqual(types.Rect{ .x = 0, .y = 50, .width = 100, .height = 50 }, findPlacement(placements, 4).geometry);
    try std.testing.expectEqual(types.Rect{ .x = 200, .y = 50, .width = 100, .height = 50 }, findPlacement(placements, 5).geometry);
    try std.testing.expectEqualSlices(types.Handle, &.{ 2, 4 }, state.left.rows.order.items.items);
    try std.testing.expectEqualSlices(types.Handle, &.{ 3, 5 }, state.right.rows.order.items.items);
}

test "game mode sends all remainder windows to a surviving edge column" {
    var state: State = .{
        .rule_anchor = 1,
        .rule_options = .{
            .size = .{ .pixels = .{ .width = 100, .height = 100 } },
            .anchor = .left,
            .remainder = .rows,
            .gaps_inner = 0,
        },
    };
    defer state.deinit(std.testing.allocator);
    const placements = try arrange(std.testing.allocator, &state, .{ .x = 0, .y = 0, .width = 300, .height = 100 }, &.{
        .{ .handle = 1 }, .{ .handle = 2 }, .{ .handle = 3 }, .{ .handle = 4 },
    }, 1, .{ .gaps_outer = 0, .gaps_inner = 0 }, .{});
    defer std.testing.allocator.free(placements);

    try std.testing.expectEqual(types.Rect{ .x = 100, .y = 0, .width = 100, .height = 50 }, findPlacement(placements, 2).geometry);
    try std.testing.expectEqual(types.Rect{ .x = 200, .y = 0, .width = 100, .height = 50 }, findPlacement(placements, 3).geometry);
    try std.testing.expectEqual(types.Rect{ .x = 100, .y = 50, .width = 200, .height = 50 }, findPlacement(placements, 4).geometry);
    try std.testing.expectEqual(@as(usize, 0), state.left.rows.order.items.items.len);
    try std.testing.expectEqualSlices(types.Handle, &.{ 2, 3, 4 }, state.right.rows.order.items.items);
}

test "game mode reverse dwindle fallback mirrors dwindle" {
    var normal_state: State = .{};
    defer normal_state.deinit(std.testing.allocator);
    var reverse_state: State = .{};
    defer reverse_state.deinit(std.testing.allocator);
    const area: types.Rect = .{ .x = 9, .y = 5, .width = 101, .height = 79 };
    const windows = [_]types.Window{ .{ .handle = 1 }, .{ .handle = 2 }, .{ .handle = 3 }, .{ .handle = 4 } };
    const layout_options: types.Options = .{ .gaps_outer = 2, .gaps_inner = 3, .master_ratio = 0.6 };

    const normal = try arrange(std.testing.allocator, &normal_state, area, &windows, 1, layout_options, .{ .fallback = .dwindle });
    defer std.testing.allocator.free(normal);
    const reverse = try arrange(std.testing.allocator, &reverse_state, area, &windows, 1, layout_options, .{ .fallback = .reverse_dwindle });
    defer std.testing.allocator.free(reverse);

    const bounds = math.shrink(area, layout_options.gaps_outer);
    for (normal, reverse) |ordinary, mirrored| {
        try std.testing.expectEqual(ordinary.handle, mirrored.handle);
        try std.testing.expectEqual(ordinary.geometry.width, mirrored.geometry.width);
        try std.testing.expectEqual(ordinary.geometry.height, mirrored.geometry.height);
        try std.testing.expectEqual(ordinary.geometry.y, mirrored.geometry.y);
        try std.testing.expectEqual(
            bounds.x + bounds.width - (ordinary.geometry.x - bounds.x) - ordinary.geometry.width,
            mirrored.geometry.x,
        );
    }
}

fn findPlacement(placements: []const types.Placement, handle: types.Handle) types.Placement {
    for (placements) |placement| if (placement.handle == handle) return placement;
    unreachable;
}

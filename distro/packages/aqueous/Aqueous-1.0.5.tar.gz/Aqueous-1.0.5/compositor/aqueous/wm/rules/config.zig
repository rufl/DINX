// SPDX-FileCopyrightText: © 2026 Seafoam Labs
// SPDX-License-Identifier: GPL-3.0-only

const std = @import("std");
const instance = @import("../../Instance.zig");
const Engine = @import("engine.zig");
const toml = @import("../config/wm.zig");
const wp = @import("wayland").server.wp;
const scaling = @import("scaling");

const log = std.log.scoped(.aqueous);
const max_config_bytes = 1024 * 1024;

pub fn reloadFromDefaultPath(allocator: std.mem.Allocator, engine: *Engine) void {
    reloadDiscovered(allocator, engine, "");
}

pub fn reloadDiscovered(allocator: std.mem.Allocator, engine: *Engine, configured_path: []const u8) void {
    var buffer: [std.fs.max_path_bytes]u8 = undefined;
    const env_override = getenv("AQUEOUS_RULES");
    const xdg = getenv("XDG_CONFIG_HOME");
    const home = getenv("HOME");
    const path = resolveDiscoveredPath(&buffer, env_override, configured_path, xdg, home) orelse {
        engine.reloadSnapshot(&.{}, &.{}, .{}) catch {};
        engine.source_fingerprint = 0;
        return;
    };
    const io = std.Io.Threaded.global_single_threaded.io();
    const source = std.Io.Dir.readFileAlloc(std.Io.Dir.cwd(), io, path, allocator, .limited(max_config_bytes)) catch |err| switch (err) {
        error.FileNotFound => {
            engine.reloadSnapshot(&.{}, &.{}, .{}) catch {};
            engine.source_fingerprint = 0;
            return;
        },
        else => {
            log.warn("unable to read {s}: {}", .{ path, err });
            return;
        },
    };
    defer allocator.free(source);
    parseAndReload(allocator, engine, source) catch |err| log.warn("unable to parse {s}: {}", .{ path, err });
}

fn getenv(name: [*:0]const u8) ?[]const u8 {
    const raw = std.c.getenv(name) orelse return null;
    const value = std.mem.span(raw);
    return if (value.len == 0) null else value;
}

pub fn resolvePath(buffer: []u8, xdg_config_home: ?[]const u8, home: ?[]const u8) ?[]const u8 {
    if (xdg_config_home) |base| {
        if (base.len == 0) return null;
        return std.fmt.bufPrint(buffer, "{s}/" ++ instance.name ++ "/rules.toml", .{base}) catch null;
    }
    const base = home orelse return null;
    if (base.len == 0) return null;
    return std.fmt.bufPrint(buffer, "{s}/.config/" ++ instance.name ++ "/rules.toml", .{base}) catch null;
}

pub fn resolveDiscoveredPath(buffer: []u8, env_override: ?[]const u8, configured: []const u8, xdg: ?[]const u8, home: ?[]const u8) ?[]const u8 {
    if (env_override) |path| return expandHome(buffer, path, home);
    if (configured.len > 0) return expandHome(buffer, configured, home);
    if (xdg) |base| {
        const candidate = std.fmt.bufPrint(buffer, "{s}/" ++ instance.name ++ "/rules.toml", .{base}) catch return null;
        if (exists(candidate)) return candidate;
    }
    if (home) |base| {
        const candidate = std.fmt.bufPrint(buffer, "{s}/.config/" ++ instance.name ++ "/rules.toml", .{base}) catch return null;
        if (exists(candidate)) return candidate;
    }
    return null;
}

pub fn parseAndReload(allocator: std.mem.Allocator, engine: *Engine, source: []const u8) !void {
    var strings = std.heap.ArenaAllocator.init(allocator);
    defer strings.deinit();
    var parsed: std.ArrayListUnmanaged(Engine.Rule) = .empty;
    defer parsed.deinit(allocator);
    var parsed_layers: std.ArrayListUnmanaged(Engine.LayerRule) = .empty;
    defer parsed_layers.deinit(allocator);
    var current: ?Engine.Rule = null;
    var unsupported_popup_key = false;
    var current_layer: ?Engine.LayerRule = null;
    var game_mode: Engine.GameMode = .{};
    var section: enum { none, game_mode, window, layer } = .none;
    var lines = std.mem.splitScalar(u8, source, '\n');
    while (lines.next()) |raw_line| {
        const line = toml.cleanLine(raw_line);
        if (line.len == 0) continue;
        if (line[0] == '[') {
            if (current) |rule| try appendValid(allocator, &parsed, rule, unsupported_popup_key);
            if (current_layer) |rule| try appendValidLayer(
                allocator,
                &parsed_layers,
                rule,
            );
            current = null;
            unsupported_popup_key = false;
            current_layer = null;
            if (std.mem.eql(u8, line, "[[window]]")) {
                current = .{};
                section = .window;
            } else if (std.mem.eql(u8, line, "[[layer]]")) {
                current_layer = .{};
                section = .layer;
            } else if (std.mem.eql(u8, line, "[game_mode]")) {
                section = .game_mode;
            } else section = .none;
            continue;
        }
        const equal = toml.indexUnquoted(line, '=') orelse continue;
        const key = std.mem.trim(u8, line[0..equal], " \t");
        const raw = std.mem.trim(u8, line[equal + 1 ..], " \t");
        // Decode basic-string escapes for tags so inspection-generated literal
        // glob patterns round-trip. Single-quoted TOML strings stay literal.
        const value = if (section == .window and std.mem.eql(u8, key, "tag") and raw.len > 0 and raw[0] == '"')
            try std.json.parseFromSliceLeaky([]const u8, strings.allocator(), raw, .{})
        else
            toml.unquote(raw);
        switch (section) {
            .window => if (current) |*rule| {
                if (std.mem.eql(u8, key, "scope")) rule.scope = std.meta.stringToEnum(Engine.Scope, value) orelse return error.InvalidRuleScope;
                if (std.mem.eql(u8, key, "window_type")) rule.window_type = std.meta.stringToEnum(Engine.X11WindowType, value) orelse return error.InvalidWindowType;
                if (!overrideRedirectKey(key)) unsupported_popup_key = true;
                if (std.mem.eql(u8, key, "opacity") and parseOpacity(value) == null) unsupported_popup_key = true;
                if (std.mem.eql(u8, key, "focus") and parseBool(value) == null) unsupported_popup_key = true;
                if (std.mem.eql(u8, key, "x") or std.mem.eql(u8, key, "y")) {
                    const coordinate = std.fmt.parseInt(i32, value, 10) catch 100_001;
                    if (coordinate < -100_000 or coordinate > 100_000) unsupported_popup_key = true;
                }
                applyValue(rule, key, value);
            },
            .layer => if (current_layer) |*rule| applyLayerValue(
                rule,
                key,
                value,
            ),
            .game_mode => applyGameMode(&game_mode, key, value),
            .none => {},
        }
    }
    if (current) |rule| try appendValid(allocator, &parsed, rule, unsupported_popup_key);
    if (current_layer) |rule| try appendValidLayer(
        allocator,
        &parsed_layers,
        rule,
    );
    try engine.reloadSnapshot(parsed.items, parsed_layers.items, game_mode);
    engine.source_fingerprint = hash(source);
}

pub fn discoveredFingerprint(allocator: std.mem.Allocator, configured_path: []const u8) u64 {
    var buffer: [std.fs.max_path_bytes]u8 = undefined;
    const path = resolveDiscoveredPath(&buffer, getenv("AQUEOUS_RULES"), configured_path, getenv("XDG_CONFIG_HOME"), getenv("HOME")) orelse return 0;
    const io = std.Io.Threaded.global_single_threaded.io();
    const source = std.Io.Dir.readFileAlloc(std.Io.Dir.cwd(), io, path, allocator, .limited(max_config_bytes)) catch return 0;
    defer allocator.free(source);
    return hash(source);
}

fn hash(source: []const u8) u64 {
    var state = std.hash.Wyhash.init(0);
    state.update(source);
    return state.final();
}

fn appendValid(allocator: std.mem.Allocator, rules: *std.ArrayListUnmanaged(Engine.Rule), rule: Engine.Rule, unsupported_popup_key: bool) !void {
    if (rule.scope == .override_redirect and (unsupported_popup_key or rule.focus == true)) return error.UnsupportedOverrideRedirectRule;
    if (rule.scope == .override_redirect and rule.class == null and rule.title == null and rule.window_type == null) return error.MissingOverrideRedirectMatcher;
    if (rule.scope == .managed and rule.window_type != null) return error.WindowTypeRequiresOverrideRedirectScope;
    if (rule.app_id == null and rule.class == null and rule.title == null and rule.tag == null and rule.content_type == null and rule.window_type == null) return;
    try rules.append(allocator, rule);
}

fn appendValidLayer(
    allocator: std.mem.Allocator,
    rules: *std.ArrayListUnmanaged(Engine.LayerRule),
    rule: Engine.LayerRule,
) !void {
    if (rule.namespace == null or rule.namespace.?.len == 0) return;
    try rules.append(allocator, rule);
}

fn applyGameMode(options: *Engine.GameMode, key: []const u8, value: []const u8) void {
    if (std.mem.eql(u8, key, "remainder_layout")) if (parseLayout(value)) |layout| {
        if (layout != .game_mode and layout != .composable) options.remainder_layout = layout;
    };
    if (std.mem.eql(u8, key, "fallback_layout")) if (parseLayout(value)) |layout| {
        if (layout != .game_mode and layout != .composable) options.fallback_layout = layout;
    };
    if (std.mem.eql(u8, key, "gaps_inner")) {
        const parsed = std.fmt.parseInt(i32, value, 10) catch return;
        if (parsed >= 0) options.gaps_inner = parsed;
    }
}

pub fn overrideRedirectKey(key: []const u8) bool {
    inline for (.{ "scope", "class", "title", "window_type", "opacity", "focus", "x", "y", "output" }) |allowed| {
        if (std.mem.eql(u8, key, allowed)) return true;
    }
    return false;
}

fn applyValue(rule: *Engine.Rule, key: []const u8, value: []const u8) void {
    if (std.mem.eql(u8, key, "app_id")) rule.app_id = value;
    if (std.mem.eql(u8, key, "class")) rule.class = value;
    if (std.mem.eql(u8, key, "title")) rule.title = value;
    if (std.mem.eql(u8, key, "tag")) rule.tag = value;
    if (std.mem.eql(u8, key, "content_type")) rule.content_type = parseContentType(value) orelse rule.content_type;
    if (std.mem.eql(u8, key, "floating")) rule.placement.floating = parseBool(value) orelse rule.placement.floating;
    if (std.mem.eql(u8, key, "output") and value.len > 0) rule.placement.output = value;
    if (std.mem.eql(u8, key, "workspace")) rule.placement.workspace = std.fmt.parseInt(u32, value, 10) catch rule.placement.workspace;
    if (std.mem.eql(u8, key, "width")) rule.placement.width = parsePositive(value) orelse rule.placement.width;
    if (std.mem.eql(u8, key, "height")) rule.placement.height = parsePositive(value) orelse rule.placement.height;
    if (std.mem.eql(u8, key, "x")) {
        rule.position_x = std.fmt.parseInt(i32, value, 10) catch rule.position_x;
        rule.placement.x = rule.position_x orelse rule.placement.x;
    }
    if (std.mem.eql(u8, key, "y")) {
        rule.position_y = std.fmt.parseInt(i32, value, 10) catch rule.position_y;
        rule.placement.y = rule.position_y orelse rule.placement.y;
    }
    if (std.mem.eql(u8, key, "layout")) {
        rule.layout = parseLayout(value) orelse rule.layout;
        if (rule.layout == .floating) rule.placement.floating = true;
    }
    if (std.mem.eql(u8, key, "anchor")) rule.anchor = parseAnchor(value) orelse rule.anchor;
    if (std.mem.eql(u8, key, "size")) rule.size = parseSize(value) orelse rule.size;
    if (std.mem.eql(u8, key, "scale")) rule.scale = parseScale(value) orelse rule.scale;
    if (std.mem.eql(u8, key, "fullscreen")) rule.fullscreen = parseBool(value) orelse rule.fullscreen;
    if (std.mem.eql(u8, key, "scrolling_full_width")) rule.scrolling_full_width = parseBool(value) orelse rule.scrolling_full_width;
    if (std.mem.eql(u8, key, "scrolling_width")) rule.scrolling_width = parseScrollingWidth(value) orelse rule.scrolling_width;
    if (std.mem.eql(u8, key, "ignore_struts")) rule.ignore_struts = parseBool(value) orelse rule.ignore_struts;
    if (std.mem.eql(u8, key, "blur")) rule.blur = parseBool(value) orelse rule.blur;
    if (std.mem.eql(u8, key, "opacity")) rule.opacity = parseOpacity(value) orelse rule.opacity;
    if (std.mem.eql(u8, key, "buffer_scale_policy")) {
        rule.buffer_scale_policy = scaling.BufferScalePolicy.parse(value) orelse rule.buffer_scale_policy;
    }
    if (std.mem.eql(u8, key, "hdr_expand")) rule.hdr_expand = parseBool(value) orelse rule.hdr_expand;
    if (std.mem.eql(u8, key, "overlay_plane")) {
        rule.overlay_plane = Engine.OverlayPreference.parse(value) orelse rule.overlay_plane;
    }
    if (std.mem.eql(u8, key, "stack_layer") or std.mem.eql(u8, key, "layer")) rule.stack_layer = parseStackLayer(value) orelse rule.stack_layer;
    if (std.mem.eql(u8, key, "placement_policy")) rule.placement_policy = parsePlacementPolicy(value) orelse rule.placement_policy;
    if (std.mem.eql(u8, key, "focus")) rule.focus = parseBool(value) orelse rule.focus;
    if (std.mem.eql(u8, key, "fixed_position")) rule.fixed_position = parseBool(value) orelse rule.fixed_position;
    if (std.mem.eql(u8, key, "skip_switcher")) rule.skip_switcher = parseBool(value) orelse rule.skip_switcher;
    if (std.mem.eql(u8, key, "skip_taskbar")) rule.skip_taskbar = parseBool(value) orelse rule.skip_taskbar;
}

fn parseStackLayer(value: []const u8) ?Engine.StackLayer {
    if (std.mem.eql(u8, value, "below")) return .below;
    if (std.mem.eql(u8, value, "normal")) return .normal;
    if (std.mem.eql(u8, value, "above") or std.mem.eql(u8, value, "always-above")) return .above;
    return null;
}

fn parsePlacementPolicy(value: []const u8) ?Engine.PlacementPolicy {
    if (std.mem.eql(u8, value, "cascade")) return .cascade;
    if (std.mem.eql(u8, value, "center")) return .center;
    if (std.mem.eql(u8, value, "under-pointer") or std.mem.eql(u8, value, "cursor")) return .under_pointer;
    if (std.mem.eql(u8, value, "minimal-overlap")) return .minimal_overlap;
    return null;
}

fn applyLayerValue(rule: *Engine.LayerRule, key: []const u8, value: []const u8) void {
    if (std.mem.eql(u8, key, "namespace")) rule.namespace = value;
    if (std.mem.eql(u8, key, "blur")) {
        rule.blur = parseBool(value) orelse rule.blur;
    }
    if (std.mem.eql(u8, key, "blur_popups")) {
        rule.blur_popups = parseBool(value) orelse rule.blur_popups;
    }
}

fn parseLayout(value: []const u8) ?Engine.Layout {
    if (std.mem.eql(u8, value, "tile")) return .tile;
    if (std.mem.eql(u8, value, "monocle")) return .monocle;
    if (std.mem.eql(u8, value, "grid")) return .grid;
    if (std.mem.eql(u8, value, "rows")) return .rows;
    if (std.mem.eql(u8, value, "dwindle")) return .dwindle;
    if (std.mem.eql(u8, value, "reverse-dwindle") or std.mem.eql(u8, value, "reverse_dwindle")) return .reverse_dwindle;
    if (std.mem.eql(u8, value, "scrolling")) return .scrolling;
    if (std.mem.eql(u8, value, "float") or std.mem.eql(u8, value, "floating") or std.mem.eql(u8, value, "stack") or std.mem.eql(u8, value, "stacking")) return .floating;
    if (std.mem.eql(u8, value, "game-mode") or std.mem.eql(u8, value, "game_mode")) return .game_mode;
    if (std.mem.eql(u8, value, "composable")) return .composable;
    return null;
}

fn parseAnchor(value: []const u8) ?Engine.Anchor {
    inline for (.{ .center, .top, .bottom, .left, .right }) |anchor| if (std.mem.eql(u8, value, @tagName(anchor))) return anchor;
    return null;
}

fn parseContentType(value: []const u8) ?wp.ContentTypeV1.Type {
    inline for (.{ wp.ContentTypeV1.Type.none, .photo, .video, .game }) |content_type| {
        if (std.mem.eql(u8, value, @tagName(content_type))) return content_type;
    }
    return null;
}

fn parseSize(value: []const u8) ?Engine.Size {
    if (std.mem.eql(u8, value, "native")) return .native;
    const split = std.mem.indexOfScalar(u8, value, 'x') orelse return null;
    const left = value[0..split];
    const right = value[split + 1 ..];
    if (std.mem.indexOfScalar(u8, left, '.') != null or std.mem.indexOfScalar(u8, right, '.') != null) {
        const width = std.fmt.parseFloat(f64, left) catch return null;
        const height = std.fmt.parseFloat(f64, right) catch return null;
        if (!std.math.isFinite(width) or !std.math.isFinite(height) or width <= 0 or width > 1 or height <= 0 or height > 1) return null;
        return .{ .fraction = .{ .width = width, .height = height } };
    }
    const width = std.fmt.parseInt(i32, left, 10) catch return null;
    const height = std.fmt.parseInt(i32, right, 10) catch return null;
    if (width <= 0 or height <= 0) return null;
    return .{ .pixels = .{ .width = width, .height = height } };
}

fn parsePositive(value: []const u8) ?i32 {
    const parsed = std.fmt.parseInt(i32, value, 10) catch return null;
    return if (parsed > 0) parsed else null;
}
fn parseBool(value: []const u8) ?bool {
    if (std.mem.eql(u8, value, "true")) return true;
    if (std.mem.eql(u8, value, "false")) return false;
    return null;
}
fn parseScale(value: []const u8) ?f64 {
    const result = std.fmt.parseFloat(f64, value) catch return null;
    return if (std.math.isFinite(result) and result > 0) result else null;
}
fn parseOpacity(value: []const u8) ?f64 {
    const result = std.fmt.parseFloat(f64, value) catch return null;
    return if (std.math.isFinite(result) and result >= 0 and result <= 1) result else null;
}

fn parseScrollingWidth(value: []const u8) ?f64 {
    const result = std.fmt.parseFloat(f64, value) catch return null;
    return if (std.math.isFinite(result) and result > 0 and result <= 1) result else null;
}

fn exists(path: []const u8) bool {
    const io = std.Io.Threaded.global_single_threaded.io();
    std.Io.Dir.cwd().access(io, path, .{}) catch return false;
    return true;
}
fn expandHome(buffer: []u8, path: []const u8, home: ?[]const u8) ?[]const u8 {
    if (path.len > 0 and path[0] == '~') return std.fmt.bufPrint(buffer, "{s}{s}", .{ home orelse return null, path[1..] }) catch null;
    return std.fmt.bufPrint(buffer, "{s}", .{path}) catch null;
}

test "rules parser preserves order and parses native placement behavior" {
    var engine = Engine.init(std.testing.allocator);
    defer engine.deinit();
    try parseAndReload(std.testing.allocator, &engine,
        \\[game_mode]
        \\remainder_layout = "rows"
        \\fallback_layout = "tile"
        \\gaps_inner = 3
        \\[[window]]
        \\layout = "grid"
        \\[[window]]
        \\app_id = "game*"
        \\layout = "game-mode"
        \\anchor = "left"
        \\size = "0.7x0.5"
        \\scale = 1.2
        \\output = "DP-2"
        \\workspace = 9
        \\fullscreen = true
        \\ignore_struts = true
        \\opacity = 0.8
        \\buffer_scale_policy = "integer-ceil"
        \\hdr_expand = false
        \\overlay_plane = "prefer"
        \\stack_layer = "above"
        \\placement_policy = "minimal-overlap"
        \\focus = false
        \\fixed_position = true
        \\skip_switcher = true
        \\skip_taskbar = true
        \\[[window]]
        \\title = "Dialog #1"
        \\layout = "float"
        \\width = 800
        \\height = bad
        \\[[layer]]
        \\namespace = "panel-*"
        \\blur = true
        \\blur_popups = true
        \\[[layer]]
        \\blur = true
    );
    try std.testing.expectEqual(@as(usize, 2), engine.rules.len);
    const game = engine.resolve(.{ .app_id = "game-one" }).?;
    try std.testing.expectEqual(Engine.Layout.game_mode, game.layout.?);
    try std.testing.expectEqualStrings("DP-2", game.placement.output.?);
    try std.testing.expectEqual(@as(u32, 9), game.placement.workspace);
    try std.testing.expect(game.fullscreen and game.ignore_struts);
    try std.testing.expectEqual(@as(?bool, false), game.hdr_expand);
    try std.testing.expectEqual(Engine.OverlayPreference.prefer, game.overlay_plane);
    try std.testing.expectEqual(Engine.StackLayer.above, game.stack_layer.?);
    try std.testing.expectEqual(Engine.PlacementPolicy.minimal_overlap, game.placement_policy.?);
    try std.testing.expectEqual(@as(?bool, false), game.focus);
    try std.testing.expect(game.fixed_position and game.skip_switcher and game.skip_taskbar);
    try std.testing.expectEqual(scaling.BufferScalePolicy.integer_ceil, game.buffer_scale_policy.?);
    try std.testing.expectEqual(Engine.Layout.rows, engine.game_mode.remainder_layout);
    try std.testing.expectEqual(Engine.Layout.tile, engine.game_mode.fallback_layout);
    try std.testing.expectEqual(@as(i32, 3), engine.game_mode.gaps_inner);
    const dialog = engine.resolve(.{ .title = "Dialog #1" }).?;
    try std.testing.expect(dialog.placement.floating);
    try std.testing.expectEqual(@as(i32, 800), dialog.placement.width);
    try std.testing.expectEqual(@as(?bool, null), dialog.hdr_expand);
    try std.testing.expectEqual(@as(usize, 1), engine.layer_rules.len);
    const panel = engine.resolveLayer("panel-main").?;
    try std.testing.expect(panel.blur);
    try std.testing.expect(panel.blur_popups);
}

test "scrolling width rules preserve the current layout and explicit layout choices" {
    var engine = Engine.init(std.testing.allocator);
    defer engine.deinit();
    try parseAndReload(std.testing.allocator, &engine,
        \\[[window]]
        \\app_id = "browser"
        \\scrolling_full_width = true
        \\scrolling_width = 0.65
        \\[[window]]
        \\app_id = "browser"
        \\scrolling_full_width = false
        \\scrolling_width = 0.25
        \\[[window]]
        \\class = "editor"
        \\scrolling_full_width = false
        \\[[window]]
        \\title = "size-only"
        \\size = "800x600"
        \\[[window]]
        \\app_id = "explicit-before"
        \\layout = "game-mode"
        \\scrolling_full_width = true
        \\[[window]]
        \\app_id = "explicit-after"
        \\scrolling_full_width = true
        \\layout = "scrolling"
        \\[[window]]
        \\app_id = "invalid"
        \\scrolling_full_width = "not-a-bool"
    );
    const browser = engine.resolve(.{ .app_id = "browser" }).?;
    try std.testing.expectEqual(@as(?bool, true), browser.scrolling_full_width);
    try std.testing.expectEqual(@as(?f64, 0.65), browser.scrolling_width);
    try std.testing.expectEqual(@as(?Engine.Layout, null), browser.layout);
    const editor = engine.resolve(.{ .class = "editor" }).?;
    try std.testing.expectEqual(@as(?bool, false), editor.scrolling_full_width);
    try std.testing.expectEqual(@as(?Engine.Layout, null), editor.layout);
    try std.testing.expectEqual(@as(?Engine.Layout, null), engine.resolve(.{ .title = "size-only" }).?.layout);
    try std.testing.expectEqual(Engine.Layout.game_mode, engine.resolve(.{ .app_id = "explicit-before" }).?.layout.?);
    try std.testing.expectEqual(Engine.Layout.scrolling, engine.resolve(.{ .app_id = "explicit-after" }).?.layout.?);
    try std.testing.expectEqual(@as(?bool, null), engine.resolve(.{ .app_id = "invalid" }).?.scrolling_full_width);
    try std.testing.expectEqual(@as(?Engine.Layout, null), engine.resolve(.{ .app_id = "invalid" }).?.layout);
}

test "omitted layouts preserve visual and placement rules without selecting game mode" {
    var engine = Engine.init(std.testing.allocator);
    defer engine.deinit();
    try parseAndReload(std.testing.allocator, &engine,
        \\[game_mode]
        \\fallback_layout = "rows"
        \\[[window]]
        \\app_id = "visual"
        \\opacity = 0.8
        \\blur = false
        \\[[window]]
        \\app_id = "visual"
        \\layout = "game-mode"
        \\[[window]]
        \\app_id = "placement"
        \\output = "DP-2"
        \\workspace = 3
        \\[[window]]
        \\app_id = "floating"
        \\floating = true
        \\width = 800
        \\height = 600
        \\[[window]]
        \\app_id = "matcher-only"
        \\[[window]]
        \\app_id = "invalid-layout"
        \\layout = "unknown"
        \\[[window]]
        \\app_id = "explicit-game"
        \\layout = "game_mode"
    );
    for ([_][]const u8{ "visual", "placement", "floating", "matcher-only", "invalid-layout" }) |app_id| {
        try std.testing.expectEqual(@as(?Engine.Layout, null), engine.resolve(.{ .app_id = app_id }).?.layout);
    }
    // An unset layout in the first match must not inherit a later game rule.
    const visual = engine.resolve(.{ .app_id = "visual" }).?;
    try std.testing.expectEqual(@as(?f64, 0.8), visual.opacity);
    try std.testing.expectEqual(@as(?bool, false), visual.blur);
    const placement = engine.resolve(.{ .app_id = "placement" }).?.placement;
    try std.testing.expectEqualStrings("DP-2", placement.output.?);
    try std.testing.expectEqual(@as(u32, 3), placement.workspace);
    const floating = engine.resolve(.{ .app_id = "floating" }).?.placement;
    try std.testing.expect(floating.floating);
    try std.testing.expectEqual(@as(i32, 800), floating.width);
    try std.testing.expectEqual(@as(i32, 600), floating.height);
    try std.testing.expectEqual(Engine.Layout.game_mode, engine.resolve(.{ .app_id = "explicit-game" }).?.layout.?);
}

test "reloading a rule can add and remove an explicit game layout" {
    var engine = Engine.init(std.testing.allocator);
    defer engine.deinit();
    const without_layout =
        \\[[window]]
        \\app_id = "game"
        \\blur = false
    ;
    const with_layout = without_layout ++ "\nlayout = \"game-mode\"\n";
    try parseAndReload(std.testing.allocator, &engine, without_layout);
    const initial = engine.resolve(.{ .app_id = "game" }).?;
    const fingerprint = initial.fingerprint();
    const matcher = initial.matcherFingerprint();
    try std.testing.expectEqual(@as(?Engine.Layout, null), initial.layout);

    try parseAndReload(std.testing.allocator, &engine, with_layout);
    const game = engine.resolve(.{ .app_id = "game" }).?;
    try std.testing.expectEqual(Engine.Layout.game_mode, game.layout.?);
    try std.testing.expect(game.fingerprint() != fingerprint);
    try std.testing.expectEqual(matcher, game.matcherFingerprint());

    try parseAndReload(std.testing.allocator, &engine, without_layout);
    const reloaded = engine.resolve(.{ .app_id = "game" }).?;
    try std.testing.expectEqual(@as(?Engine.Layout, null), reloaded.layout);
    try std.testing.expectEqual(@as(?bool, false), reloaded.blur);
    try std.testing.expectEqual(fingerprint, reloaded.fingerprint());
}

test "rules parser accepts content_type matchers and rejects invalid values" {
    var engine = Engine.init(std.testing.allocator);
    defer engine.deinit();
    try parseAndReload(std.testing.allocator, &engine,
        \\[[window]]
        \\content_type = "game"
        \\blur = false
        \\hdr_expand = true
        \\output = "DP-2"
        \\workspace = 5
        \\[[window]]
        \\content_type = "bogus"
        \\blur = true
    );
    // The invalid content_type value leaves its rule matcher-less, so it is dropped.
    try std.testing.expectEqual(@as(usize, 1), engine.rules.len);
    const game = engine.resolve(.{ .content_type = .game }).?;
    try std.testing.expectEqual(@as(?bool, false), game.blur);
    try std.testing.expectEqual(@as(?bool, true), game.hdr_expand);
    // The placement edit parsed but is dropped at resolve time.
    try std.testing.expect(game.placement.output == null);
    try std.testing.expectEqual(@as(u32, 0), game.placement.workspace);
}

test "rules accept composable workspaces but reject it as a game-mode child" {
    var engine = Engine.init(std.testing.allocator);
    defer engine.deinit();
    try parseAndReload(std.testing.allocator, &engine,
        \\[game_mode]
        \\remainder_layout = "composable"
        \\fallback_layout = "game-mode"
        \\[[window]]
        \\app_id = "editor"
        \\layout = "composable"
    );

    try std.testing.expectEqual(Engine.Layout.composable, engine.resolve(.{ .app_id = "editor" }).?.layout.?);
    try std.testing.expectEqual(Engine.Layout.grid, engine.game_mode.remainder_layout);
    try std.testing.expectEqual(Engine.Layout.grid, engine.game_mode.fallback_layout);
}

test "rules accept reverse dwindle layouts and game-mode children" {
    var engine = Engine.init(std.testing.allocator);
    defer engine.deinit();
    try parseAndReload(std.testing.allocator, &engine,
        \\[game_mode]
        \\remainder_layout = "reverse-dwindle"
        \\fallback_layout = "reverse_dwindle"
        \\[[window]]
        \\app_id = "editor"
        \\layout = "reverse-dwindle"
    );

    try std.testing.expectEqual(Engine.Layout.reverse_dwindle, engine.resolve(.{ .app_id = "editor" }).?.layout.?);
    try std.testing.expectEqual(Engine.Layout.reverse_dwindle, engine.game_mode.remainder_layout);
    try std.testing.expectEqual(Engine.Layout.reverse_dwindle, engine.game_mode.fallback_layout);
}

test "tag rules parse empty, literal and escaped basic strings and survive reload" {
    var engine = Engine.init(std.testing.allocator);
    defer engine.deinit();
    try parseAndReload(std.testing.allocator, &engine,
        \\[[window]]
        \\tag = ""
        \\skip_taskbar = true
        \\[[window]]
        \\app_id = "editor"
        \\tag = "literal\\*\\?\\\\purpose\"#\n\t"
        \\floating = true
        \\[[window]]
        \\tag = 'settings'
        \\skip_switcher = true
    );
    try std.testing.expectEqual(@as(usize, 3), engine.rules.len);
    try std.testing.expect(engine.resolve(.{}) == null);
    try std.testing.expect(engine.resolve(.{ .tag = "" }).?.skip_taskbar);
    try std.testing.expect(engine.resolve(.{ .app_id = "editor", .tag = "literal*?\\purpose\"#\n\t" }).?.placement.floating);
    try std.testing.expect(engine.resolve(.{ .app_id = "editor", .tag = "literalXXpurpose\"#\n\t" }) == null);
    try std.testing.expect(engine.resolve(.{ .tag = "settings" }).?.skip_switcher);
    try std.testing.expectError(error.SyntaxError, parseAndReload(std.testing.allocator, &engine, "[[window]]\ntag = \"bad\\q\""));
    try std.testing.expectEqual(@as(usize, 3), engine.rules.len);
}

test "scrolling fractions accept only finite positive values through one" {
    const cases = .{
        .{ "0.25", @as(?f64, 0.25) },        .{ "0.65", @as(?f64, 0.65) },
        .{ "1", @as(?f64, 1) },              .{ "1.0", @as(?f64, 1) },
        .{ "0", @as(?f64, null) },           .{ "-0.1", @as(?f64, null) },
        .{ "1.01", @as(?f64, null) },        .{ "nan", @as(?f64, null) },
        .{ "inf", @as(?f64, null) },         .{ "-inf", @as(?f64, null) },
        .{ "\"invalid\"", @as(?f64, null) },
    };
    inline for (cases) |case| {
        var engine = Engine.init(std.testing.allocator);
        defer engine.deinit();
        try parseAndReload(std.testing.allocator, &engine, "[[window]]\napp_id = \"test\"\nscrolling_width = " ++ case[0] ++ "\n");
        const rule = engine.resolve(.{ .app_id = "test" }).?;
        try std.testing.expectEqual(case[1], rule.scrolling_width);
        try std.testing.expectEqual(@as(?Engine.Layout, null), rule.layout);
    }
    var engine = Engine.init(std.testing.allocator);
    defer engine.deinit();
    try parseAndReload(std.testing.allocator, &engine, "[[window]]\napp_id = \"test\"\nlayout = \"scrolling\"\nscrolling_width = 0.65\n");
    try std.testing.expectEqual(Engine.Layout.scrolling, engine.resolve(.{ .app_id = "test" }).?.layout.?);
}

test "popup rules validate atomically and preserve explicit zero placement" {
    var engine = Engine.init(std.testing.allocator);
    defer engine.deinit();
    try parseAndReload(std.testing.allocator, &engine, "[[window]]\nscope = \"override_redirect\"\nwindow_type = \"notification\"\nx = 0\nopacity = 0.8\nfocus = false\n");
    try std.testing.expectEqual(@as(?i32, 0), engine.rules[0].position_x);
    try std.testing.expectEqual(@as(?i32, null), engine.rules[0].position_y);
    inline for (.{ "floating = false", "focus = true", "workspace = 2", "blur = false", "typo = 1", "opacity = nan", "focus = typo", "x = 100001" }) |property| {
        try std.testing.expectError(error.UnsupportedOverrideRedirectRule, parseAndReload(std.testing.allocator, &engine, "[[window]]\nscope = \"override_redirect\"\nclass = \"*\"\n" ++ property));
        try std.testing.expectEqual(@as(?f64, 0.8), engine.rules[0].opacity);
    }
    try std.testing.expectError(error.InvalidRuleScope, parseAndReload(std.testing.allocator, &engine, "[[window]]\nclass = \"*\"\nscope = \"typo\""));
    try std.testing.expectError(error.WindowTypeRequiresOverrideRedirectScope, parseAndReload(std.testing.allocator, &engine, "[[window]]\nwindow_type = \"notification\""));
}

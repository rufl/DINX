// SPDX-FileCopyrightText: © 2026 Seafoam Labs
// SPDX-License-Identifier: GPL-3.0-only

const std = @import("std");
const layout_config = @import("../config/layout.zig");
const types = @import("../layout/types.zig");
const PolicyState = @This();

/// Compatibility view used at layout/input boundaries. Policy stores the
/// underlying axes independently so minimize/maximize never erase the window's
/// presentation or restore target.
pub const Kind = enum { tiled, floating, maximized, minimized };
pub const Presentation = enum { tiled, floating };
pub const Visibility = enum { visible, minimized };
pub const GeometryState = enum { normal, maximized };
pub const StackLayer = types.StackLayer;
pub const ClientMaximizeOrigin = enum {
    none,
    floating_overlay,
    workspace_floating,
};
pub const SnapState = enum {
    none,
    left,
    right,
    up,
    down,
    up_left,
    up_right,
    down_left,
    down_right,
    center,
    maximized_horizontal,
    maximized_vertical,
};

presentation: Presentation = .tiled,
visibility: Visibility = .visible,
geometry_state: GeometryState = .normal,
stack_layer: StackLayer = .normal,
snap_state: SnapState = .none,
snap_restore_geometry: types.Rect = .empty,
custom_snap_zone: u8 = std.math.maxInt(u8),
snap_layout_id: layout_config.SnapId = .{},
snap_zone_id: layout_config.SnapId = .{},
/// Records only maximizes accepted from a client request. This distinguishes a
/// workspace-floating presentation (whose policy kind remains tiled) from a
/// persistent floating overlay and prevents client unmaximize from undoing a
/// compositor/keybinding-owned maximize.
client_maximize_origin: ClientMaximizeOrigin = .none,
floating_geometry: types.Rect = .empty,
/// Set when the last output vanished without an available recovery target.
/// The next output which admits this window clamps it back into usable space.
needs_output_recovery: bool = false,
/// Scrolling-layout column width override. This is independent of `kind` so
/// the window remains part of the layout and viewport navigation keeps working.
scrolling_full_width: bool = false,
/// Fractional base width remains independent of the full-width preset.
scrolling_width: ?f64 = null,

/// Last non-null toplevel parent for which automatic transient placement was
/// applied. Keeping this edge-triggered lets a user tile the dialog manually
/// without the next manage cycle immediately forcing it floating again.
auto_float_parent: types.Handle = 0,
/// Parent whose native transient is waiting for its first client-selected
/// buffer size after an unspecified-size XDG configure.
pending_natural_parent: types.Handle = 0,

/// Semantic identity of the rule last reconciled for this window. A zero hash
/// represents no match. `rule_initialized` distinguishes that from a window
/// which has not reached its first rule evaluation yet.
rule_initialized: bool = false,
rule_match: u64 = 0,

/// Placement properties are claimed independently. User actions release the
/// corresponding claim, preventing an unchanged rule from reasserting it on
/// the next manage cycle.
rule_workspace_owned: bool = false,
rule_fullscreen_owned: bool = false,
rule_floating_owned: bool = false,
rule_workspace_overridden: bool = false,
rule_fullscreen_overridden: bool = false,
rule_floating_overridden: bool = false,
rule_stack_layer_owned: bool = false,
rule_stack_layer_overridden: bool = false,
/// Fingerprint of the last composite output/workspace target reconciled for
/// the active matcher. Zero represents ordinary admission placement.
rule_workspace_requested: u64 = 0,
rule_fullscreen_requested: bool = false,
rule_floating_requested: bool = false,
rule_floating_signature: u64 = 0,
rule_fullscreen_previous: bool = false,
rule_floating_previous: Presentation = .tiled,
rule_stack_layer_previous: StackLayer = .normal,
rule_stack_layer_requested: ?StackLayer = null,
rule_scrolling_full_width_owned: bool = false,
rule_scrolling_full_width_overridden: bool = false,
rule_scrolling_full_width_requested: ?bool = null,
rule_scrolling_full_width_previous: bool = false,
rule_scrolling_width_owned: bool = false,
rule_scrolling_width_overridden: bool = false,
rule_scrolling_width_requested: ?f64 = null,
rule_scrolling_width_previous: ?f64 = null,
focus_allowed: bool = true,
fixed_position: bool = false,
skip_switcher: bool = false,
skip_taskbar: bool = false,

pub fn kind(state: *const PolicyState) Kind {
    if (state.visibility == .minimized) return .minimized;
    if (state.geometry_state == .maximized) return .maximized;
    return switch (state.presentation) {
        .tiled => .tiled,
        .floating => .floating,
    };
}

pub fn isTiled(state: *const PolicyState) bool {
    return state.presentation == .tiled;
}

pub fn isFloating(state: *const PolicyState) bool {
    return state.presentation == .floating;
}

pub fn isVisible(state: *const PolicyState) bool {
    return state.visibility == .visible;
}

/// Cancel an unfinished initial natural-size handshake. If that handshake was
/// the only reason the window became floating, restore its tiled presentation
/// so a later remap or parent removal can be admitted normally.
pub fn cancelPendingNaturalSize(state: *PolicyState) void {
    if (state.pending_natural_parent == 0) return;
    state.pending_natural_parent = 0;
    if (state.auto_float_parent == 0 and
        state.presentation == .floating and
        state.floating_geometry.width <= 0 and
        state.floating_geometry.height <= 0 and
        !state.rule_floating_owned)
    {
        state.presentation = .tiled;
    }
}

pub fn isMaximized(state: *const PolicyState) bool {
    return state.geometry_state == .maximized;
}

pub fn overrideWorkspace(state: *PolicyState) void {
    state.rule_workspace_owned = false;
    state.rule_workspace_overridden = true;
}

pub fn overrideFullscreen(state: *PolicyState) void {
    state.rule_fullscreen_owned = false;
    state.rule_fullscreen_overridden = true;
}

pub fn overrideFloating(state: *PolicyState) void {
    state.rule_floating_owned = false;
    state.rule_floating_overridden = true;
}

pub fn overrideStackLayer(state: *PolicyState) void {
    state.rule_stack_layer_owned = false;
    state.rule_stack_layer_overridden = true;
}

pub fn toggleScrollingFullWidth(state: *PolicyState) bool {
    state.overrideScrollingFullWidth();
    state.scrolling_full_width = !state.scrolling_full_width;
    return state.scrolling_full_width;
}

pub fn overrideScrollingFullWidth(state: *PolicyState) void {
    state.rule_scrolling_full_width_owned = false;
    state.rule_scrolling_full_width_overridden = true;
}

pub fn restoreRuleScrollingFullWidth(state: *PolicyState) void {
    if (state.rule_scrolling_full_width_owned) {
        state.scrolling_full_width = state.rule_scrolling_full_width_previous;
        state.rule_scrolling_full_width_owned = false;
    }
}

/// Reconcile only changes to the requested preset. Manual sizing wins until
/// another matcher is accepted, including across reloads of the same rule.
pub fn reconcileScrollingFullWidth(state: *PolicyState, requested: ?bool) void {
    if (requested == state.rule_scrolling_full_width_requested) return;
    if (requested) |value| {
        if (!state.rule_scrolling_full_width_overridden) {
            if (!state.rule_scrolling_full_width_owned) state.rule_scrolling_full_width_previous = state.scrolling_full_width;
            state.scrolling_full_width = value;
            state.rule_scrolling_full_width_owned = true;
        }
    } else {
        state.restoreRuleScrollingFullWidth();
    }
    state.rule_scrolling_full_width_requested = requested;
}

pub fn ruleChanged(state: *const PolicyState, match: u64) bool {
    return !state.rule_initialized or state.rule_match != match;
}

/// Manual horizontal sizing releases the fractional rule for this matcher.
pub fn overrideScrollingWidth(state: *PolicyState) void {
    state.rule_scrolling_width_owned = false;
    state.rule_scrolling_width_overridden = true;
    state.scrolling_width = null;
}

pub fn restoreRuleScrollingWidth(state: *PolicyState) void {
    if (state.rule_scrolling_width_owned) {
        state.scrolling_width = state.rule_scrolling_width_previous;
        state.rule_scrolling_width_owned = false;
    }
}

pub fn reconcileScrollingWidth(state: *PolicyState, requested: ?f64) void {
    if (requested == state.rule_scrolling_width_requested) return;
    if (requested) |value| {
        if (!state.rule_scrolling_width_overridden) {
            if (!state.rule_scrolling_width_owned) state.rule_scrolling_width_previous = state.scrolling_width;
            state.scrolling_width = value;
            state.rule_scrolling_width_owned = true;
        }
    } else {
        state.restoreRuleScrollingWidth();
    }
    state.rule_scrolling_width_requested = requested;
}

/// Start ownership tracking for a different semantic matcher after the caller
/// has rolled back properties still owned by the prior match.
pub fn acceptRuleMatch(state: *PolicyState, match: u64) void {
    state.rule_workspace_owned = false;
    state.rule_fullscreen_owned = false;
    state.rule_floating_owned = false;
    state.rule_stack_layer_owned = false;
    state.rule_workspace_overridden = false;
    state.rule_fullscreen_overridden = false;
    state.rule_floating_overridden = false;
    state.rule_stack_layer_overridden = false;
    state.rule_workspace_requested = 0;
    state.rule_fullscreen_requested = false;
    state.rule_floating_requested = false;
    state.rule_floating_signature = 0;
    state.rule_stack_layer_requested = null;
    state.rule_scrolling_full_width_owned = false;
    state.rule_scrolling_full_width_overridden = false;
    state.rule_scrolling_full_width_requested = null;
    state.rule_scrolling_width_owned = false;
    state.rule_scrolling_width_overridden = false;
    state.rule_scrolling_width_requested = null;
    state.rule_initialized = true;
    state.rule_match = match;
}

test "manual overrides release only their corresponding rule property" {
    var state: PolicyState = .{
        .rule_initialized = true,
        .rule_match = 42,
        .rule_workspace_owned = true,
        .rule_fullscreen_owned = true,
        .rule_floating_owned = true,
    };

    state.overrideFullscreen();
    try std.testing.expect(state.rule_workspace_owned);
    try std.testing.expect(!state.rule_fullscreen_owned);
    try std.testing.expect(state.rule_fullscreen_overridden);
    try std.testing.expect(state.rule_floating_owned);
    try std.testing.expect(!state.ruleChanged(42));
    try std.testing.expect(state.ruleChanged(7));

    // Re-evaluating the same matcher leaves the override intact. Only an
    // actual matcher transition opens a new rule-ownership lifecycle.
    try std.testing.expect(state.rule_fullscreen_overridden);
    state.acceptRuleMatch(7);
    try std.testing.expect(!state.rule_fullscreen_overridden);
    try std.testing.expect(!state.ruleChanged(7));
}

test "scrolling full width toggles independently of window kind" {
    var state: PolicyState = .{};

    try std.testing.expect(state.toggleScrollingFullWidth());
    try std.testing.expectEqual(Kind.tiled, state.kind());
    try std.testing.expect(!state.toggleScrollingFullWidth());
    try std.testing.expectEqual(Kind.tiled, state.kind());
}

test "scrolling width rules reconcile reloads and restore the prior preset" {
    var state: PolicyState = .{};
    state.acceptRuleMatch(1);
    state.reconcileScrollingFullWidth(true);
    try std.testing.expect(state.scrolling_full_width);
    try std.testing.expect(state.rule_scrolling_full_width_owned);
    state.reconcileScrollingFullWidth(true);
    state.reconcileScrollingFullWidth(false);
    try std.testing.expect(!state.scrolling_full_width);
    state.reconcileScrollingFullWidth(true);
    state.reconcileScrollingFullWidth(null);
    try std.testing.expect(!state.scrolling_full_width);
    try std.testing.expect(!state.rule_scrolling_full_width_owned);

    // An explicit false can temporarily replace a manually enabled preset.
    _ = state.toggleScrollingFullWidth();
    state.acceptRuleMatch(2);
    state.reconcileScrollingFullWidth(false);
    try std.testing.expect(!state.scrolling_full_width);
    state.restoreRuleScrollingFullWidth();
    state.acceptRuleMatch(0);
    try std.testing.expect(state.scrolling_full_width);
}

test "manual scrolling width overrides survive reloads until the matcher changes" {
    var state: PolicyState = .{};
    state.acceptRuleMatch(1);
    state.reconcileScrollingFullWidth(true);
    try std.testing.expect(!state.toggleScrollingFullWidth());
    state.reconcileScrollingFullWidth(true);
    state.reconcileScrollingFullWidth(false);
    state.reconcileScrollingFullWidth(true);
    try std.testing.expect(!state.scrolling_full_width);
    state.reconcileScrollingFullWidth(null);
    state.reconcileScrollingFullWidth(true);
    try std.testing.expect(!state.scrolling_full_width);
    state.restoreRuleScrollingFullWidth();
    state.acceptRuleMatch(2);
    state.reconcileScrollingFullWidth(true);
    try std.testing.expect(state.scrolling_full_width);

    // Pointer sizing releases ownership without toggling the preset on.
    state.overrideScrollingFullWidth();
    state.scrolling_full_width = false;
    state.reconcileScrollingFullWidth(true);
    state.restoreRuleScrollingFullWidth();
    try std.testing.expect(!state.scrolling_full_width);
}

test "cancelling a pending natural size rolls back only its automatic float" {
    var state: PolicyState = .{
        .presentation = .floating,
        .pending_natural_parent = 12,
    };
    state.cancelPendingNaturalSize();
    try std.testing.expectEqual(Presentation.tiled, state.presentation);
    try std.testing.expectEqual(@as(types.Handle, 0), state.pending_natural_parent);

    state = .{
        .presentation = .floating,
        .pending_natural_parent = 12,
        .rule_floating_owned = true,
    };
    state.cancelPendingNaturalSize();
    try std.testing.expectEqual(Presentation.floating, state.presentation);
}

test "presentation visibility geometry and stack layer compose" {
    var state: PolicyState = .{
        .presentation = .floating,
        .visibility = .minimized,
        .geometry_state = .maximized,
        .stack_layer = .above,
    };

    try std.testing.expectEqual(Kind.minimized, state.kind());
    state.visibility = .visible;
    try std.testing.expectEqual(Kind.maximized, state.kind());
    state.geometry_state = .normal;
    try std.testing.expectEqual(Kind.floating, state.kind());
    try std.testing.expectEqual(StackLayer.above, state.stack_layer);
}

test "snap state remains independent of presentation and visibility" {
    var state: PolicyState = .{ .presentation = .floating, .snap_state = .left, .snap_restore_geometry = .{ .x = 10, .y = 20, .width = 300, .height = 200 } };
    state.visibility = .minimized;
    try std.testing.expectEqual(SnapState.left, state.snap_state);
    state.visibility = .visible;
    try std.testing.expectEqual(Kind.floating, state.kind());
    try std.testing.expectEqual(@as(i32, 300), state.snap_restore_geometry.width);
}

test "fractional width reloads restore previous state and preserve manual intent" {
    var state: PolicyState = .{ .scrolling_width = 0.25 };
    state.acceptRuleMatch(1);
    state.reconcileScrollingWidth(0.65);
    try std.testing.expectEqual(@as(?f64, 0.65), state.scrolling_width);
    state.reconcileScrollingWidth(1);
    try std.testing.expectEqual(@as(?f64, 1), state.scrolling_width);
    state.reconcileScrollingWidth(null);
    try std.testing.expectEqual(@as(?f64, 0.25), state.scrolling_width);
    state.reconcileScrollingWidth(0.65);
    // Full-width toggles are an independent overlay on the base fraction.
    try std.testing.expect(state.toggleScrollingFullWidth());
    try std.testing.expect(!state.toggleScrollingFullWidth());
    try std.testing.expectEqual(@as(?f64, 0.65), state.scrolling_width);
    state.overrideScrollingWidth();
    state.reconcileScrollingWidth(0.65);
    state.reconcileScrollingWidth(0.75);
    state.reconcileScrollingWidth(null);
    state.reconcileScrollingWidth(1);
    state.restoreRuleScrollingWidth();
    try std.testing.expectEqual(@as(?f64, null), state.scrolling_width);
    state.acceptRuleMatch(2);
    state.reconcileScrollingWidth(0.75);
    try std.testing.expectEqual(@as(?f64, 0.75), state.scrolling_width);
    state.restoreRuleScrollingWidth();
    state.acceptRuleMatch(0);
    try std.testing.expectEqual(@as(?f64, null), state.scrolling_width);
}

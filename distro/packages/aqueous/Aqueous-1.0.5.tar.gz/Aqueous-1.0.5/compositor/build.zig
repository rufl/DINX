// SPDX-FileCopyrightText: © 2026 Seafoam Labs
// SPDX-License-Identifier: GPL-3.0-only

const std = @import("std");
const assert = std.debug.assert;
const Build = std.Build;
const fs = std.fs;
const mem = std.mem;

const manifest = @import("build.zig.zon");
const version = manifest.version;

const Scanner = @import("wayland").Scanner;
const Translator = @import("translate_c").Translator;

pub fn build(b: *Build) !void {
    const target = b.standardTargetOptions(.{});
    const optimize = b.standardOptimizeOption(.{});

    const strip = b.option(bool, "strip", "Omit debug information") orelse false;
    const pie = b.option(bool, "pie", "Build a Position Independent Executable") orelse false;
    const use_llvm = b.option(bool, "llvm", "Force use of Zig's LLVM backend and the lld linker") orelse false;

    const omit_frame_pointer = switch (optimize) {
        .Debug, .ReleaseSafe => false,
        .ReleaseFast, .ReleaseSmall => true,
    };

    const man_pages = b.option(
        bool,
        "man-pages",
        "Set to true to build man pages. Requires scdoc. Defaults to true if scdoc is found.",
    ) orelse scdoc_found: {
        _ = b.findProgram(&.{"scdoc"}, &.{}) catch |err| switch (err) {
            error.FileNotFound => break :scdoc_found false,
        };
        break :scdoc_found true;
    };

    const xwayland = b.option(
        bool,
        "xwayland",
        "Set to true to enable xwayland support",
    ) orelse false;

    const wlroots_pkgconf = "wlroots-0.20";
    const vulkan_effects = b.option(
        bool,
        "vulkan-effects",
        "Enable Aqueous Vulkan effects on the wlroots Vulkan renderer. Defaults to true.",
    ) orelse true;

    const full_version = blk: {
        if (b.option([]const u8, "version-string", "Override `aqueous -version` output.")) |version_override| {
            break :blk version_override;
        } else if (mem.endsWith(u8, version, "-dev")) {
            var ret: u8 = undefined;

            const git_describe_long = b.runAllowFail(
                &.{ "git", "-C", b.build_root.path orelse ".", "describe", "--long" },
                &ret,
                .ignore,
            ) catch break :blk version;

            var it = mem.splitSequence(u8, mem.trim(u8, git_describe_long, &std.ascii.whitespace), "-");
            _ = it.next().?; // previous tag
            const commit_count = it.next().?;
            const commit_hash = it.next().?;
            assert(it.next() == null);
            assert(commit_hash[0] == 'g');

            // Follow semantic versioning, e.g. 0.2.0-dev.42+d1cf95b
            break :blk b.fmt(version ++ ".{s}+{s}", .{ commit_count, commit_hash[1..] });
        } else {
            break :blk version;
        }
    };

    const animations = b.option(
        bool,
        "animations",
        "Enable compositor-side window position animations (smooth scrolling). Defaults to true.",
    ) orelse true;

    const external_policy = b.option(
        bool,
        "external-policy",
        "Enable aqueous_window_manager_v1 external/compare policy modes for diagnostics. Defaults to false.",
    ) orelse false;

    const options = b.addOptions();
    const instance_name = b.option([]const u8, "instance-name", "Private package configuration/state namespace") orelse "aqueous";
    options.addOption([]const u8, "instance_name", instance_name);
    const instance_metadata = b.addWriteFiles().add("build-instance.json", b.fmt("{{\"schema\":1,\"instance\":\"{s}\"}}\n", .{instance_name}));
    b.getInstallStep().dependOn(&b.addInstallFile(instance_metadata, "share/aqueous/build-instance.json").step);
    options.addOption(bool, "xwayland", xwayland);
    options.addOption(bool, "vulkan_effects", vulkan_effects);
    options.addOption(bool, "animations", animations);
    options.addOption(bool, "external_policy", external_policy);
    options.addOption(bool, "toplevel_drag_testing", b.option(bool, "toplevel-drag-testing", "Enable private synthetic touch input (tests only)") orelse false);
    options.addOption(bool, "tablet_testing", b.option(bool, "tablet-testing", "Enable private synthetic tablet input (tests only)") orelse false);
    const output_retry_testing = b.option(bool, "output-retry-testing", "Enable private output retry fault injection (tests only)") orelse false;
    options.addOption(bool, "output_retry_testing", output_retry_testing);
    const display_preview_acceptance = b.option(bool, "display-preview-acceptance", "Enable explicitly selected DRM feature preview acceptance tests; never ship this build") orelse false;
    options.addOption(bool, "display_preview_acceptance", display_preview_acceptance);
    options.addOption([]const u8, "version", full_version);
    const input_activity_testing = b.option(bool, "input-activity-testing", "Compile isolated input activity fixture support (never ship)") orelse false;
    options.addOption(bool, "input_activity_testing", input_activity_testing);
    // Generated from the actual build options, never supplied by a packaging caller.
    const policy = b.addWriteFiles().add("build-policy.json", b.fmt(
        "{{\"schema\":1,\"output_retry_testing\":{},\"display_preview_acceptance\":{},\"input_activity_testing\":{}}}\n",
        .{ output_retry_testing, display_preview_acceptance, input_activity_testing },
    ));
    b.getInstallStep().dependOn(&b.addInstallFile(policy, "share/aqueous/build-policy.json").step);

    const scanner = Scanner.create(b, .{});

    scanner.addSystemProtocol("staging/content-type/content-type-v1.xml");
    scanner.addSystemProtocol("staging/ext-background-effect/ext-background-effect-v1.xml");
    scanner.addSystemProtocol("stable/tablet/tablet-v2.xml");
    scanner.addSystemProtocol("stable/xdg-shell/xdg-shell.xml");
    scanner.addSystemProtocol("staging/color-management/color-management-v1.xml");
    scanner.addSystemProtocol("staging/color-representation/color-representation-v1.xml");
    scanner.addSystemProtocol("staging/cursor-shape/cursor-shape-v1.xml");
    scanner.addSystemProtocol("staging/ext-session-lock/ext-session-lock-v1.xml");
    scanner.addSystemProtocol("staging/ext-foreign-toplevel-list/ext-foreign-toplevel-list-v1.xml");
    scanner.addSystemProtocol("staging/tearing-control/tearing-control-v1.xml");
    scanner.addSystemProtocol("unstable/pointer-constraints/pointer-constraints-unstable-v1.xml");
    scanner.addSystemProtocol("unstable/pointer-gestures/pointer-gestures-unstable-v1.xml");
    scanner.addSystemProtocol("unstable/xwayland-keyboard-grab/xwayland-keyboard-grab-unstable-v1.xml");
    scanner.addSystemProtocol("unstable/xdg-decoration/xdg-decoration-unstable-v1.xml");
    scanner.addSystemProtocol("unstable/xdg-foreign/xdg-foreign-unstable-v2.xml");

    scanner.addCustomProtocol(b.path("protocol/aqueous-window-management-v1.xml"));
    scanner.addCustomProtocol(b.path("protocol/aqueous-window-info-v1.xml"));
    scanner.addCustomProtocol(b.path("protocol/aqueous-shell-v1.xml"));
    scanner.addCustomProtocol(b.path("protocol/aqueous-input-activity-v1.xml"));
    scanner.addCustomProtocol(b.path("protocol/aqueous-output-warming-v1.xml"));
    scanner.generate("aqueous_output_warming_manager_v1", 1);
    scanner.generate("aqueous_input_activity_manager_v1", 1);
    scanner.addCustomProtocol(b.path("protocol/aqueous-xkb-bindings-v1.xml"));
    scanner.addCustomProtocol(b.path("protocol/aqueous-layer-shell-v1.xml"));
    scanner.addCustomProtocol(b.path("protocol/aqueous-input-management-v1.xml"));
    scanner.addCustomProtocol(b.path("protocol/aqueous-libinput-config-v1.xml"));
    scanner.addCustomProtocol(b.path("protocol/aqueous-xkb-config-v1.xml"));

    scanner.addCustomProtocol(b.path("protocol/upstream/wlr-layer-shell-unstable-v1.xml"));
    scanner.addCustomProtocol(b.path("protocol/upstream/wlr-output-management-unstable-v1.xml"));
    scanner.addCustomProtocol(b.path("protocol/upstream/wlr-output-power-management-unstable-v1.xml"));
    scanner.addCustomProtocol(b.path("protocol/upstream/wlr-screencopy-unstable-v1.xml"));
    scanner.addCustomProtocol(b.path("protocol/upstream/virtual-keyboard-unstable-v1.xml"));
    // ext-workspace-v1: vendored pinned copy of the staging protocol merged upstream
    // (wayland-protocols MR !40). wlroots ships no implementation; bindings are generated
    // here for the hand-rolled WorkspaceManager.
    scanner.addCustomProtocol(b.path("protocol/upstream/ext-workspace-v1.xml"));

    // Some of these versions may be out of date with what wlroots implements.
    // This is not a problem in practice though as long as river successfully compiles.
    // These versions control Zig code generation and have no effect on anything internal
    // to wlroots. Therefore, the only thing that can happen due to a version being too
    // old is that river fails to compile.
    scanner.addSystemProtocol("staging/pointer-warp/pointer-warp-v1.xml");
    scanner.addSystemProtocol("staging/ext-image-copy-capture/ext-image-copy-capture-v1.xml");
    scanner.generate("wp_pointer_warp_v1", 1);
    scanner.generate("wp_content_type_manager_v1", 1);
    scanner.generate("ext_background_effect_manager_v1", 1);
    scanner.generate("wl_compositor", 4);
    scanner.generate("wl_subcompositor", 1);
    scanner.generate("wl_shm", 1);
    scanner.generate("wl_output", 4);
    scanner.generate("wl_seat", 7);
    scanner.generate("wl_data_device_manager", 3);

    scanner.generate("xdg_wm_base", 7);
    scanner.generate("zwp_pointer_gestures_v1", 3);
    scanner.generate("zwp_pointer_constraints_v1", 1);
    scanner.generate("zwp_tablet_manager_v2", 2);
    scanner.generate("zwp_xwayland_keyboard_grab_manager_v1", 1);
    scanner.generate("zxdg_decoration_manager_v1", 2);
    scanner.generate("zxdg_importer_v2", 1);
    scanner.generate("zxdg_exporter_v2", 1);
    scanner.generate("ext_session_lock_manager_v1", 1);
    scanner.generate("ext_foreign_toplevel_list_v1", 1);
    scanner.generate("ext_image_copy_capture_manager_v1", 1);
    scanner.generate("wp_cursor_shape_manager_v1", 1);
    scanner.generate("wp_tearing_control_manager_v1", 1);
    scanner.generate("wp_color_manager_v1", 3);
    scanner.generate("wp_color_representation_manager_v1", 1);

    scanner.generate("aqueous_window_manager_v1", 10);
    scanner.generate("aqueous_window_info_manager_v1", 9);
    scanner.generate("aqueous_shell_manager_v1", 3);
    scanner.generate("aqueous_xkb_bindings_v1", 3);
    scanner.generate("aqueous_layer_shell_v1", 1);
    scanner.generate("aqueous_input_manager_v1", 2);
    scanner.generate("aqueous_libinput_config_v1", 2);
    scanner.generate("aqueous_xkb_config_v1", 2);

    scanner.generate("zwlr_output_power_manager_v1", 1);
    scanner.generate("zwlr_output_manager_v1", 4);
    scanner.generate("zwlr_layer_shell_v1", 4);
    scanner.generate("zwlr_screencopy_manager_v1", 3);
    scanner.generate("zwp_virtual_keyboard_manager_v1", 1);
    scanner.generate("ext_workspace_manager_v1", 1);

    const wayland = b.createModule(.{ .root_source_file = scanner.result });

    const xkbcommon = b.dependency("xkbcommon", .{}).module("xkbcommon");
    const pixman = b.dependency("pixman", .{}).module("pixman");

    const wlroots = b.dependency("wlroots", .{}).module("wlroots");
    wlroots.addImport("wayland", wayland);
    wlroots.addImport("xkbcommon", xkbcommon);
    wlroots.addImport("pixman", pixman);

    // We need to ensure the wlroots include path obtained from pkg-config is
    // exposed to the wlroots module for @cImport() to work. This seems to be
    // the best way to do so with the current std.Build API.
    wlroots.resolved_target = target;
    wlroots.linkSystemLibrary(wlroots_pkgconf, .{});

    const tablet = b.createModule(.{ .root_source_file = b.path("common/tablet.zig"), .target = target, .optimize = optimize });
    const flags = b.createModule(.{ .root_source_file = b.path("common/flags.zig") });
    const slotmap = b.createModule(.{ .root_source_file = b.path("common/slotmap.zig") });
    const scaling = b.createModule(.{
        .root_source_file = b.path("aqueous/scaling.zig"),
        .target = target,
        .optimize = optimize,
    });

    const translate_c: Translator = .init(b.dependency("translate_c", .{}), .{
        .name = "c",
        .c_source_file = b.path("aqueous/c.h"),
        .target = target,
        .optimize = optimize,
    });
    translate_c.linkSystemLibrary("libevdev", .{});
    translate_c.linkSystemLibrary("libinput", .{});
    translate_c.linkSystemLibrary(wlroots_pkgconf, .{});
    translate_c.defineCMacro("WLR_USE_UNSTABLE", null);
    if (vulkan_effects) {
        translate_c.linkSystemLibrary("vulkan", .{});
        translate_c.defineCMacro("RIVER_VULKAN_EFFECTS", null);
    }

    const unmanaged_tests: [3]*Build.Step.Run = blk: {
        const step = b.step("test-unmanaged-xwayland", "Headless popup discovery/rules regression (requires -Dxwayland -Dvulkan-effects=false)");
        var commands: [3]*Build.Step.Run = undefined;
        for (&commands, 0..) |*command, index| {
            command.* = b.addSystemCommand(&.{"python3"});
            command.*.addFileArg(b.path("scripts/test-unmanaged-xwayland.py"));
            command.*.setEnvironmentVariable("AQUEOUS_UNMANAGED_SCALED", if (index == 0) "0" else "1");
            command.*.setEnvironmentVariable("AQUEOUS_UNMANAGED_SCALING", if (index == 2) "native" else "legacy");
            step.dependOn(&command.*.step);
        }
        break :blk commands;
    };

    {
        const river = b.addExecutable(.{
            .name = "aqueous",
            .root_module = b.createModule(.{
                .root_source_file = b.path("aqueous/main.zig"),
                .target = target,
                .optimize = optimize,
                .strip = strip,
                .link_libc = true,
            }),
            .use_llvm = use_llvm,
            .use_lld = use_llvm,
        });
        river.build_id = .sha1;
        for (unmanaged_tests) |command| command.addArtifactArg(river);
        river.root_module.addOptions("build_options", options);

        river.root_module.linkSystemLibrary("libevdev", .{});
        river.root_module.linkSystemLibrary("libinput", .{});
        river.root_module.linkSystemLibrary("libudev", .{});
        river.root_module.linkSystemLibrary("wayland-server", .{});
        if (xwayland) {
            river.root_module.linkSystemLibrary("xcb", .{});
        }
        river.root_module.linkSystemLibrary(wlroots_pkgconf, .{});
        river.root_module.addRPathSpecial("$ORIGIN/../lib/aqueous");
        if (vulkan_effects) {
            river.root_module.linkSystemLibrary("vulkan", .{});
        }
        river.root_module.linkSystemLibrary("xkbcommon", .{});
        river.root_module.linkSystemLibrary("pixman-1", .{});
        river.root_module.linkSystemLibrary("libpng", .{});
        river.root_module.linkSystemLibrary("pthread", .{});
        river.root_module.linkSystemLibrary("libsystemd", .{});
        river.root_module.addCSourceFile(.{ .file = b.path("aqueous/activity_bootstrap.c"), .flags = if (input_activity_testing) &.{ "-std=c11", "-Wall", "-Wextra", "-Werror", "-DAQUEOUS_ACTIVITY_TESTING" } else &.{ "-std=c11", "-Wall", "-Wextra", "-Werror" } });
        river.root_module.addCSourceFile(.{ .file = b.path("aqueous/icon_png.c"), .flags = &.{ "-std=c11", "-O2", "-Wall", "-Wextra" } });

        river.root_module.addCSourceFile(.{ .file = b.path("aqueous/bell_audio.c"), .flags = &.{ "-std=c11", "-O2", "-Wall", "-Wextra", "-Werror" } });
        river.root_module.addImport("wayland", wayland);
        river.root_module.addImport("xkbcommon", xkbcommon);
        river.root_module.addImport("pixman", pixman);
        river.root_module.addImport("wlroots", wlroots);
        river.root_module.addImport("flags", flags);
        river.root_module.addImport("slotmap", slotmap);
        river.root_module.addImport("scaling", scaling);
        river.root_module.addImport("tablet", tablet);
        river.root_module.addImport("c", translate_c.mod);

        river.root_module.addCSourceFile(.{
            .file = b.path("aqueous/wlroots_log_wrapper.c"),
            .flags = &.{ "-std=c99", "-O2" },
        });

        river.pie = pie;
        river.root_module.omit_frame_pointer = omit_frame_pointer;

        b.installArtifact(river);
        const library = b.option(
            []const u8,
            "wlroots-render-hook-library",
            "Path to the patched wlroots shared library installed with Aqueous.",
        ) orelse findWlrootsRenderHook(b) orelse std.process.fatal(
            "unable to locate the pinned Aqueous libwlroots-0.20.so",
            .{},
        );
        b.getInstallStep().dependOn(&b.addInstallFile(
            .{ .cwd_relative = library },
            "lib/aqueous/libwlroots-0.20.so",
        ).step);
    }

    {
        const launcher = b.addExecutable(.{ .name = "aqueous-activity-launch", .root_module = b.createModule(.{ .target = target, .optimize = optimize, .link_libc = true }) });
        launcher.root_module.addCSourceFile(.{ .file = b.path("aqueous/activity_launch.c"), .flags = &.{ "-std=c11", "-Wall", "-Wextra", "-Werror" } });
        b.installArtifact(launcher);
    }

    const shell_switch_test = b.addSystemCommand(&.{"python3"});
    shell_switch_test.addFileArg(b.path("scripts/test-aqueousctl-shell-switch.py"));
    b.step("test-shell-switch", "Test retired shell-switch command migration errors").dependOn(&shell_switch_test.step);
    {
        const aqueousctl = b.addExecutable(.{
            .name = "aqueousctl",
            .root_module = b.createModule(.{
                .root_source_file = b.path("aqueousctl/main.zig"),
                .target = target,
                .optimize = optimize,
                .strip = strip,
                .link_libc = true,
            }),
            .use_llvm = use_llvm,
            .use_lld = use_llvm,
        });
        aqueousctl.root_module.addImport("wayland", wayland);
        aqueousctl.root_module.addOptions("build_options", options);
        aqueousctl.root_module.addImport("tablet", tablet);
        aqueousctl.root_module.linkSystemLibrary("wayland-client", .{});
        aqueousctl.pie = pie;
        aqueousctl.root_module.omit_frame_pointer = omit_frame_pointer;
        b.installArtifact(aqueousctl);
        shell_switch_test.addArtifactArg(aqueousctl);
        for (unmanaged_tests) |command| command.addArtifactArg(aqueousctl);
        shell_switch_test.addArg(instance_name);
    }

    {
        const wf = Build.Step.WriteFile.create(b);
        const pc_file = wf.add("aqueous-protocols.pc", b.fmt(
            \\prefix={s}
            \\datarootdir=${{prefix}}/share
            \\pkgdatadir=${{pc_sysrootdir}}${{datarootdir}}/aqueous-protocols
            \\
            \\Name: aqueous-protocols
            \\URL: https://github.com/Seafoam-Labs/Aqueous
            \\Description: Wayland protocol files provided by Aqueous
            \\Version: {s}
        , .{ b.install_prefix, full_version }));
        b.getInstallStep().dependOn(&b.addInstallFile(pc_file, "share/pkgconfig/aqueous-protocols.pc").step);
        inline for (&.{
            "aqueous-window-management-v1.xml",
            "aqueous-window-info-v1.xml",
            "aqueous-shell-v1.xml",
            "aqueous-input-activity-v1.xml",
            "aqueous-input-activity-v1.md",
            "aqueous-shell-v1.md",
            "aqueous-shell-v1.schema.json",
            "aqueous-xkb-bindings-v1.xml",
            "aqueous-layer-shell-v1.xml",
            "aqueous-input-management-v1.xml",
            "aqueous-libinput-config-v1.xml",
            "aqueous-xkb-config-v1.xml",
        }) |protocol| {
            b.installFile("protocol/" ++ protocol, "share/aqueous-protocols/stable/" ++ protocol);
        }
        b.installFile("protocol/aqueous-output-warming-v1.xml", "share/aqueous-protocols/experimental/aqueous-output-warming-v1.xml");
        b.installFile("protocol/aqueous-capture-color-v1.xml", "share/aqueous-protocols/experimental/aqueous-capture-color-v1.xml");
    }

    if (man_pages) {
        inline for (.{ "aqueous", "aqueousctl" }) |page| {
            // Workaround for https://github.com/ziglang/zig/issues/16369
            // Even passing a buffer to std.Build.Step.Run appears to be racy and occasionally deadlocks.
            const scdoc = b.addSystemCommand(&.{ "/bin/sh", "-c", "exec scdoc < \"$1\"", "scdoc" });
            // Track the input for caching and pass its resolved path as $1 so
            // --build-file works from outside the compositor directory.
            scdoc.addFileArg(b.path("doc/" ++ page ++ ".1.scd"));

            const stdout = scdoc.captureStdOut(.{});
            b.getInstallStep().dependOn(&b.addInstallFile(stdout, "share/man/man1/" ++ page ++ ".1").step);
        }
    }

    {
        const slotmap_test = b.addTest(.{
            .root_module = b.createModule(.{
                .root_source_file = b.path("common/slotmap.zig"),
                .target = target,
                .optimize = optimize,
            }),
            .use_llvm = use_llvm,
            .use_lld = use_llvm,
        });
        const run_slotmap_test = b.addRunArtifact(slotmap_test);

        const effect_metadata_test = b.addTest(.{
            .root_module = b.createModule(.{
                .root_source_file = b.path("aqueous/render/EffectMetadata.zig"),
                .target = target,
                .optimize = optimize,
                .link_libc = true,
            }),
            .use_llvm = use_llvm,
            .use_lld = use_llvm,
        });
        effect_metadata_test.root_module.addImport("wayland", wayland);
        effect_metadata_test.root_module.addImport("wlroots", wlroots);
        effect_metadata_test.root_module.addImport("slotmap", slotmap);
        const run_effect_metadata_test = b.addRunArtifact(effect_metadata_test);

        const output_hdr_test = b.addTest(.{
            .root_module = b.createModule(.{
                .root_source_file = b.path("aqueous/output_hdr.zig"),
                .target = target,
                .optimize = optimize,
                .link_libc = true,
            }),
            .use_llvm = use_llvm,
            .use_lld = use_llvm,
        });
        output_hdr_test.root_module.addOptions("build_options", options);
        output_hdr_test.root_module.addImport("wlroots", wlroots);
        output_hdr_test.root_module.addImport("c", translate_c.mod);
        output_hdr_test.root_module.linkSystemLibrary(wlroots_pkgconf, .{});
        const run_output_hdr_test = b.addRunArtifact(output_hdr_test);

        const auto_hdr_test = b.addTest(.{
            .root_module = b.createModule(.{
                .root_source_file = b.path("aqueous/auto_hdr.zig"),
                .target = target,
                .optimize = optimize,
            }),
            .use_llvm = use_llvm,
            .use_lld = use_llvm,
        });
        const run_auto_hdr_test = b.addRunArtifact(auto_hdr_test);

        const color_management_test = b.addTest(.{
            .root_module = b.createModule(.{
                .root_source_file = b.path("aqueous/color_management.zig"),
                .target = target,
                .optimize = optimize,
                .link_libc = true,
            }),
            .use_llvm = use_llvm,
            .use_lld = use_llvm,
        });
        color_management_test.root_module.addImport("wayland", wayland);
        color_management_test.root_module.addImport("wlroots", wlroots);
        const run_color_management_test = b.addRunArtifact(color_management_test);

        const global_filter_test = b.addTest(.{
            .root_module = b.createModule(.{
                .root_source_file = b.path("aqueous/global_filter.zig"),
                .target = target,
                .optimize = optimize,
            }),
            .use_llvm = use_llvm,
            .use_lld = use_llvm,
        });
        const run_global_filter_test = b.addRunArtifact(global_filter_test);

        const legacy_server_decoration_test = b.addTest(.{
            .root_module = b.createModule(.{
                .root_source_file = b.path("aqueous/LegacyServerDecoration.zig"),
                .target = target,
                .optimize = optimize,
            }),
            .use_llvm = use_llvm,
            .use_lld = use_llvm,
        });
        legacy_server_decoration_test.root_module.addImport("wayland", wayland);
        const run_legacy_server_decoration_test = b.addRunArtifact(legacy_server_decoration_test);

        const blur_cache_test = b.addTest(.{
            .root_module = b.createModule(.{
                .root_source_file = b.path("aqueous/render/BlurCache.zig"),
                .target = target,
                .optimize = optimize,
            }),
            .use_llvm = use_llvm,
            .use_lld = use_llvm,
        });
        const run_blur_cache_test = b.addRunArtifact(blur_cache_test);

        const scaling_test = b.addTest(.{
            .root_module = b.createModule(.{
                .root_source_file = b.path("aqueous/scaling.zig"),
                .target = target,
                .optimize = optimize,
            }),
            .use_llvm = use_llvm,
            .use_lld = use_llvm,
        });
        const run_scaling_test = b.addRunArtifact(scaling_test);

        const xwayland_projection_test = b.addTest(.{
            .root_module = b.createModule(.{
                .root_source_file = b.path("aqueous/xwayland_projection.zig"),
                .target = target,
                .optimize = optimize,
            }),
            .use_llvm = use_llvm,
            .use_lld = use_llvm,
        });
        const run_xwayland_projection_test = b.addRunArtifact(xwayland_projection_test);
        const dpi_policy_test = b.addTest(.{
            .root_module = b.createModule(.{
                .root_source_file = b.path("aqueous/xwayland_dpi_policy.zig"),
                .target = target,
                .optimize = optimize,
            }),
            .use_llvm = use_llvm,
            .use_lld = use_llvm,
        });
        const run_dpi_policy_test = b.addRunArtifact(dpi_policy_test);
        const run_dpi_worker_test = if (xwayland) blk: {
            const dpi_worker_test = b.addExecutable(.{
                .name = "xwayland-dpi-unit",
                .root_module = b.createModule(.{ .root_source_file = b.path("aqueous/xwayland_dpi_test.zig"), .target = target, .optimize = optimize, .link_libc = true }),
                .use_llvm = use_llvm,
                .use_lld = use_llvm,
            });
            dpi_worker_test.root_module.linkSystemLibrary("xcb", .{});
            break :blk b.addRunArtifact(dpi_worker_test);
        } else null;

        const visual_state_test = b.addTest(.{
            .root_module = b.createModule(.{
                .root_source_file = b.path("aqueous/visual_state.zig"),
                .target = target,
                .optimize = optimize,
            }),
            .use_llvm = use_llvm,
            .use_lld = use_llvm,
        });
        const run_visual_state_test = b.addRunArtifact(visual_state_test);

        const scene_opacity_test = b.addTest(.{
            .root_module = b.createModule(.{
                .root_source_file = b.path("aqueous/scene_opacity.zig"),
                .target = target,
                .optimize = optimize,
                .link_libc = true,
            }),
            .use_llvm = use_llvm,
            .use_lld = use_llvm,
        });
        scene_opacity_test.root_module.addImport("wlroots", wlroots);
        scene_opacity_test.root_module.addImport("pixman", pixman);
        scene_opacity_test.root_module.linkSystemLibrary(wlroots_pkgconf, .{});
        scene_opacity_test.root_module.linkSystemLibrary("pixman-1", .{});
        const run_scene_opacity_test = b.addRunArtifact(scene_opacity_test);
        b.step("test-scene-opacity", "Test opacity and derived scene occlusion").dependOn(&run_scene_opacity_test.step);

        const cursor_lock_restore_test = b.addTest(.{
            .root_module = b.createModule(.{
                .root_source_file = b.path("aqueous/cursor_lock_restore.zig"),
                .target = target,
                .optimize = optimize,
            }),
            .use_llvm = use_llvm,
            .use_lld = use_llvm,
        });
        const run_cursor_lock_restore_test = b.addRunArtifact(cursor_lock_restore_test);

        const cursor_config_test = b.addTest(.{
            .root_module = b.createModule(.{
                .root_source_file = b.path("aqueous/cursor_config.zig"),
                .target = target,
                .optimize = optimize,
                .link_libc = true,
            }),
            .use_llvm = use_llvm,
            .use_lld = use_llvm,
        });
        const run_cursor_config_test = b.addRunArtifact(cursor_config_test);

        const child_processes_test = b.addTest(.{
            .root_module = b.createModule(.{
                .root_source_file = b.path("aqueous/ChildProcesses.zig"),
                .target = target,
                .optimize = optimize,
                .link_libc = true,
            }),
            .use_llvm = use_llvm,
            .use_lld = use_llvm,
        });
        child_processes_test.root_module.addImport("wayland", wayland);
        child_processes_test.root_module.linkSystemLibrary("wayland-server", .{});
        const run_child_processes_test = b.addRunArtifact(child_processes_test);
        b.step("test-child-processes", "Test spawned child ownership and reaping").dependOn(&run_child_processes_test.step);

        const overlay_planes_test = b.addTest(.{
            .root_module = b.createModule(.{
                .root_source_file = b.path("aqueous/overlay_planes.zig"),
                .target = target,
                .optimize = optimize,
            }),
            .use_llvm = use_llvm,
            .use_lld = use_llvm,
        });
        const run_overlay_planes_test = b.addRunArtifact(overlay_planes_test);

        const output_retry_test = b.addTest(.{
            .root_module = b.createModule(.{
                .root_source_file = b.path("aqueous/output_retry.zig"),
                .target = target,
                .optimize = optimize,
            }),
            .use_llvm = use_llvm,
            .use_lld = use_llvm,
        });
        const run_output_retry_test = b.addRunArtifact(output_retry_test);
        const preview_policy_test = b.addTest(.{ .root_module = b.createModule(.{
            .root_source_file = b.path("aqueous/display_preview_policy.zig"),
            .target = target,
            .optimize = optimize,
        }) });
        const run_preview_policy_test = b.addRunArtifact(preview_policy_test);
        b.step("test-output-retry", "Test output recovery policy").dependOn(&run_output_retry_test.step);

        const aqueous_test = b.addTest(.{
            .root_module = b.createModule(.{
                .root_source_file = b.path("aqueous/wm/Mode.zig"),
                .target = target,
                .optimize = optimize,
            }),
            .use_llvm = use_llvm,
            .use_lld = use_llvm,
        });
        const run_aqueous_test = b.addRunArtifact(aqueous_test);

        const trace_test = b.addTest(.{
            .root_module = b.createModule(.{
                .root_source_file = b.path("aqueous/wm/Trace.zig"),
                .target = target,
                .optimize = optimize,
            }),
            .use_llvm = use_llvm,
            .use_lld = use_llvm,
        });
        const run_trace_test = b.addRunArtifact(trace_test);

        const config_test = b.addTest(.{
            .root_module = b.createModule(.{
                .root_source_file = b.path("aqueous/config_tests.zig"),
                .target = target,
                .optimize = optimize,
            }),
            .use_llvm = use_llvm,
            .use_lld = use_llvm,
        });
        config_test.root_module.addImport("scaling", scaling);
        config_test.root_module.addImport("tablet", tablet);
        config_test.root_module.addImport("wayland", wayland);
        const run_config_test = b.addRunArtifact(config_test);

        const keyboard_test = b.addTest(.{
            // Keyboard types reference the server; run this fixture without
            // also collecting unrelated tests from the whole compositor.
            .filters = &.{"keyboard policy:"},
            .root_module = b.createModule(.{
                .root_source_file = b.path("aqueous/keyboard_tests.zig"),
                .target = target,
                .optimize = optimize,
                .link_libc = true,
            }),
            .use_llvm = use_llvm,
            .use_lld = use_llvm,
        });
        keyboard_test.root_module.addOptions("build_options", options);
        keyboard_test.root_module.addImport("wayland", wayland);
        keyboard_test.root_module.addImport("wlroots", wlroots);
        keyboard_test.root_module.addImport("xkbcommon", xkbcommon);
        keyboard_test.root_module.addImport("pixman", pixman);
        keyboard_test.root_module.addImport("flags", flags);
        keyboard_test.root_module.addImport("slotmap", slotmap);
        keyboard_test.root_module.addImport("scaling", scaling);
        keyboard_test.root_module.addImport("tablet", tablet);
        keyboard_test.root_module.addImport("c", translate_c.mod);
        keyboard_test.root_module.linkSystemLibrary(wlroots_pkgconf, .{});
        keyboard_test.root_module.linkSystemLibrary("xkbcommon", .{});
        keyboard_test.root_module.linkSystemLibrary("wayland-server", .{});
        keyboard_test.root_module.linkSystemLibrary("libinput", .{});
        keyboard_test.root_module.linkSystemLibrary("libudev", .{});
        keyboard_test.root_module.linkSystemLibrary("libevdev", .{});
        keyboard_test.root_module.linkSystemLibrary("pixman-1", .{});
        keyboard_test.root_module.linkSystemLibrary("libpng", .{});
        keyboard_test.root_module.linkSystemLibrary("pthread", .{});
        keyboard_test.root_module.linkSystemLibrary("libsystemd", .{});
        keyboard_test.root_module.addCSourceFile(.{ .file = b.path("aqueous/activity_bootstrap.c"), .flags = &.{ "-std=c11", "-Wall", "-Wextra", "-Werror" } });
        keyboard_test.root_module.addCSourceFile(.{ .file = b.path("aqueous/bell_audio.c"), .flags = &.{ "-std=c11", "-O2", "-Wall", "-Wextra", "-Werror" } });
        if (xwayland) {
            keyboard_test.root_module.linkSystemLibrary("xcb", .{});
        }
        keyboard_test.root_module.addCSourceFile(.{ .file = b.path("aqueous/icon_png.c"), .flags = &.{ "-std=c11", "-O2" } });
        if (vulkan_effects) keyboard_test.root_module.linkSystemLibrary("vulkan", .{});
        keyboard_test.root_module.addCSourceFile(.{
            .file = b.path("aqueous/wlroots_log_wrapper.c"),
            .flags = &.{ "-std=c99", "-O2" },
        });
        const run_keyboard_test = b.addRunArtifact(keyboard_test);

        const layout_test = b.addTest(.{
            .root_module = b.createModule(.{
                .root_source_file = b.path("aqueous/wm/layout/tests.zig"),
                .target = target,
                .optimize = optimize,
            }),
            .use_llvm = use_llvm,
            .use_lld = use_llvm,
        });
        layout_test.root_module.addImport("wayland", wayland);
        const run_layout_test = b.addRunArtifact(layout_test);

        const overview_model_test = b.addTest(.{
            .root_module = b.createModule(.{
                .root_source_file = b.path("aqueous/wm/overview_tests.zig"),
                .target = target,
                .optimize = optimize,
            }),
            .use_llvm = use_llvm,
            .use_lld = use_llvm,
        });
        const run_overview_model_test = b.addRunArtifact(overview_model_test);

        const rules_test = b.addTest(.{
            .root_module = b.createModule(.{
                .root_source_file = b.path("aqueous/wm/rules/tests.zig"),
                .target = target,
                .optimize = optimize,
            }),
            .use_llvm = use_llvm,
            .use_lld = use_llvm,
        });
        rules_test.root_module.addImport("scaling", scaling);
        rules_test.root_module.addImport("tablet", tablet);
        rules_test.root_module.addImport("wayland", wayland);
        const run_rules_test = b.addRunArtifact(rules_test);

        const focus_test = b.addTest(.{
            .root_module = b.createModule(.{
                .root_source_file = b.path("aqueous/wm/focus/tests.zig"),
                .target = target,
                .optimize = optimize,
            }),
            .use_llvm = use_llvm,
            .use_lld = use_llvm,
        });
        const run_focus_test = b.addRunArtifact(focus_test);

        const output_navigation_test = b.addTest(.{
            .root_module = b.createModule(.{
                .root_source_file = b.path("aqueous/wm/output/navigation.zig"),
                .target = target,
                .optimize = optimize,
            }),
            .use_llvm = use_llvm,
            .use_lld = use_llvm,
        });
        const run_output_navigation_test = b.addRunArtifact(output_navigation_test);

        const input_drag_test = b.addTest(.{
            .root_module = b.createModule(.{
                .root_source_file = b.path("aqueous/wm/input_tests.zig"),
                .target = target,
                .optimize = optimize,
            }),
            .use_llvm = use_llvm,
            .use_lld = use_llvm,
        });
        input_drag_test.root_module.addImport("scaling", scaling);
        input_drag_test.root_module.addImport("tablet", tablet);
        const run_input_drag_test = b.addRunArtifact(input_drag_test);

        const workspaces_test = b.addTest(.{
            .root_module = b.createModule(.{
                .root_source_file = b.path("aqueous/wm/workspaces/coalescer.zig"),
                .target = target,
                .optimize = optimize,
            }),
            .use_llvm = use_llvm,
            .use_lld = use_llvm,
        });
        const run_workspaces_test = b.addRunArtifact(workspaces_test);

        const workspace_navigation_test = b.addTest(.{
            .root_module = b.createModule(.{
                .root_source_file = b.path("aqueous/wm/workspaces/navigation.zig"),
                .target = target,
                .optimize = optimize,
            }),
            .use_llvm = use_llvm,
            .use_lld = use_llvm,
        });
        const run_workspace_navigation_test = b.addRunArtifact(workspace_navigation_test);

        const ipc_test = b.addTest(.{
            .root_module = b.createModule(.{
                .root_source_file = b.path("aqueous/IpcProtocol.zig"),
                .target = target,
                .optimize = optimize,
            }),
            .use_llvm = use_llvm,
            .use_lld = use_llvm,
        });
        const run_ipc_test = b.addRunArtifact(ipc_test);

        const aqueousctl_test = b.addTest(.{
            .root_module = b.createModule(.{
                .root_source_file = b.path("aqueousctl/main.zig"),
                .target = target,
                .optimize = optimize,
                .link_libc = true,
            }),
            .use_llvm = use_llvm,
            .use_lld = use_llvm,
        });
        aqueousctl_test.root_module.addImport("wayland", wayland);
        aqueousctl_test.root_module.addOptions("build_options", options);
        aqueousctl_test.root_module.addImport("tablet", tablet);
        aqueousctl_test.root_module.linkSystemLibrary("wayland-client", .{});
        const run_aqueousctl_test = b.addRunArtifact(aqueousctl_test);

        const scene_buffer_clone_test = b.addTest(.{
            .root_module = b.createModule(.{
                .root_source_file = b.path("aqueous/scene_buffer_clone.zig"),
                .target = target,
                .optimize = optimize,
                .link_libc = true,
            }),
            .use_llvm = use_llvm,
            .use_lld = use_llvm,
        });
        scene_buffer_clone_test.root_module.addImport("wlroots", wlroots);
        const run_scene_buffer_clone_test = b.addRunArtifact(scene_buffer_clone_test);
        const snapshot_test_step = b.step("test-snapshot", "Test scene-buffer snapshot rendering state");
        snapshot_test_step.dependOn(&run_scene_buffer_clone_test.step);

        const warming_test = b.addTest(.{
            .root_module = b.createModule(.{
                .root_source_file = b.path("aqueous/OutputWarming.zig"),
                .target = target,
                .optimize = .Debug,
                .link_libc = true,
            }),
            .use_llvm = use_llvm,
            .use_lld = use_llvm,
        });
        warming_test.root_module.addImport("wayland", wayland);
        warming_test.root_module.addImport("wlroots", wlroots);
        warming_test.root_module.addImport("c", translate_c.mod);
        warming_test.root_module.linkSystemLibrary(wlroots_pkgconf, .{});
        warming_test.root_module.linkSystemLibrary("wayland-server", .{});
        warming_test.root_module.linkSystemLibrary("pixman-1", .{});
        const run_warming_test = b.addRunArtifact(warming_test);
        b.step("test-output-warming", "Test warming handlers with private Wayland resources and headless commits").dependOn(&run_warming_test.step);

        const test_step = b.step("test", "Run the tests");
        if (run_dpi_worker_test) |run| test_step.dependOn(&run.step);
        const adaptive_sync_test = b.addTest(.{ .root_module = b.createModule(.{ .root_source_file = b.path("aqueous/adaptive_sync_policy.zig"), .target = target, .optimize = optimize }) });
        test_step.dependOn(&b.addRunArtifact(adaptive_sync_test).step);
        const activity_test = b.addTest(.{ .root_module = b.createModule(.{ .root_source_file = b.path("aqueous/input_activity.zig"), .target = target, .optimize = optimize }) });
        test_step.dependOn(&b.addRunArtifact(activity_test).step);
        test_step.dependOn(&run_preview_policy_test.step);
        const panel_orientation_test = b.addTest(.{ .root_module = b.createModule(.{ .root_source_file = b.path("aqueous/panel_orientation.zig"), .target = target, .optimize = optimize }) });
        panel_orientation_test.root_module.addImport("wayland", wayland);
        const run_panel_orientation_test = b.addRunArtifact(panel_orientation_test);
        test_step.dependOn(&run_panel_orientation_test.step);
        b.step("test-panel-orientation", "Test built-in panel orientation quirks").dependOn(&run_panel_orientation_test.step);
        const tablet_test = b.addTest(.{ .root_module = tablet });
        const run_tablet_test = b.addRunArtifact(tablet_test);
        test_step.dependOn(&run_tablet_test.step);
        b.step("test-tablet", "Test tablet policy and coordinates").dependOn(&run_tablet_test.step);
        const icon_state_test = b.addTest(.{
            .root_module = b.createModule(.{
                .root_source_file = b.path("aqueous/ToplevelIcon.zig"),
                .target = target,
                .optimize = optimize,
                .link_libc = true,
            }),
        });
        icon_state_test.root_module.addImport("c", translate_c.mod);
        icon_state_test.root_module.addImport("wlroots", wlroots);
        icon_state_test.root_module.linkSystemLibrary(wlroots_pkgconf, .{});
        test_step.dependOn(&b.addRunArtifact(icon_state_test).step);
        const icon_selection_test = b.addTest(.{
            .root_module = b.createModule(.{
                .root_source_file = b.path("aqueous/icon_selection.zig"),
                .target = target,
                .optimize = optimize,
            }),
        });
        test_step.dependOn(&b.addRunArtifact(icon_selection_test).step);
        const xdg_state_test = b.addTest(.{
            .root_module = b.createModule(.{
                .root_source_file = b.path("aqueous/xdg_state.zig"),
                .target = target,
                .optimize = optimize,
            }),
        });
        test_step.dependOn(&b.addRunArtifact(xdg_state_test).step);
        const bell_test = b.addTest(.{ .root_module = b.createModule(.{ .root_source_file = b.path("aqueous/system_bell.zig"), .target = target, .optimize = optimize }) });
        test_step.dependOn(&b.addRunArtifact(bell_test).step);
        const tag_test = b.addTest(.{ .root_module = b.createModule(.{ .root_source_file = b.path("aqueous/ToplevelTag.zig"), .target = target, .optimize = optimize }) });
        test_step.dependOn(&b.addRunArtifact(tag_test).step);
        test_step.dependOn(&run_scene_buffer_clone_test.step);
        test_step.dependOn(&run_slotmap_test.step);
        test_step.dependOn(&run_effect_metadata_test.step);
        test_step.dependOn(&run_output_hdr_test.step);
        test_step.dependOn(&run_auto_hdr_test.step);
        test_step.dependOn(&run_color_management_test.step);
        test_step.dependOn(&run_global_filter_test.step);
        const drm_lease_policy_test = b.addTest(.{ .root_module = b.createModule(.{
            .root_source_file = b.path("aqueous/drm_lease_policy.zig"),
            .target = target,
            .optimize = optimize,
        }) });
        test_step.dependOn(&b.addRunArtifact(drm_lease_policy_test).step);
        const drm_lease_test = b.addTest(.{ .root_module = b.createModule(.{
            .root_source_file = b.path("aqueous/drm_lease_tests.zig"),
            .target = target,
            .optimize = optimize,
            .link_libc = true,
        }), .use_llvm = use_llvm, .use_lld = use_llvm });
        drm_lease_test.root_module.addImport("wayland", wayland);
        drm_lease_test.root_module.addImport("wlroots", wlroots);
        drm_lease_test.root_module.addImport("c", translate_c.mod);
        drm_lease_test.root_module.linkSystemLibrary(wlroots_pkgconf, .{});
        drm_lease_test.root_module.linkSystemLibrary("wayland-server", .{});
        drm_lease_test.root_module.addCSourceFile(.{
            .file = b.path("scripts/fixtures/drm-lease-manager.c"),
            .flags = &.{ "-std=c11", "-DWLR_USE_UNSTABLE", "-DWLR_PRIVATE=", "-Wall", "-Wextra", "-Werror", "-Wno-unused-parameter" },
        });
        const run_drm_lease_test = b.addRunArtifact(drm_lease_test);
        test_step.dependOn(&run_drm_lease_test.step);
        b.step("test-drm-lease", "Test DRM lease policy and manager lifecycle").dependOn(&run_drm_lease_test.step);
        test_step.dependOn(&run_legacy_server_decoration_test.step);
        test_step.dependOn(&run_blur_cache_test.step);
        test_step.dependOn(&run_scaling_test.step);
        test_step.dependOn(&run_xwayland_projection_test.step);
        test_step.dependOn(&run_dpi_policy_test.step);
        test_step.dependOn(&run_visual_state_test.step);
        test_step.dependOn(&run_scene_opacity_test.step);
        test_step.dependOn(&run_cursor_lock_restore_test.step);
        test_step.dependOn(&run_cursor_config_test.step);
        test_step.dependOn(&run_child_processes_test.step);
        test_step.dependOn(&run_overlay_planes_test.step);
        test_step.dependOn(&run_output_retry_test.step);
        test_step.dependOn(&run_aqueous_test.step);
        test_step.dependOn(&run_trace_test.step);
        test_step.dependOn(&run_config_test.step);
        test_step.dependOn(&run_keyboard_test.step);
        test_step.dependOn(&run_layout_test.step);
        test_step.dependOn(&run_overview_model_test.step);
        test_step.dependOn(&run_rules_test.step);
        test_step.dependOn(&run_focus_test.step);
        test_step.dependOn(&run_output_navigation_test.step);
        test_step.dependOn(&run_input_drag_test.step);
        test_step.dependOn(&run_workspaces_test.step);
        test_step.dependOn(&run_workspace_navigation_test.step);
        test_step.dependOn(&run_aqueousctl_test.step);
        test_step.dependOn(&shell_switch_test.step);
        test_step.dependOn(&run_ipc_test.step);
    }
}

fn findWlrootsRenderHook(b: *Build) ?[]const u8 {
    if (b.graph.environ_map.get("PKG_CONFIG_PATH")) |paths| {
        var it = mem.splitScalar(u8, paths, ':');
        while (it.next()) |pkgconfig_dir| {
            const pc_file = b.pathJoin(&.{ pkgconfig_dir, "wlroots-0.20.pc" });
            std.Io.Dir.cwd().access(b.graph.io, pc_file, .{}) catch continue;
            const libdir = fs.path.dirname(pkgconfig_dir) orelse continue;
            const library = b.pathJoin(&.{ libdir, "libwlroots-0.20.so" });
            std.Io.Dir.cwd().access(b.graph.io, library, .{}) catch continue;
            return library;
        }
    }

    var ret: u8 = 1;
    const output = b.runAllowFail(
        &.{ "pkg-config", "--variable=libdir", "wlroots-0.20" },
        &ret,
        .ignore,
    ) catch "";
    if (ret == 0) {
        const libdir = mem.trim(u8, output, &std.ascii.whitespace);
        const library = b.pathJoin(&.{ libdir, "libwlroots-0.20.so" });
        std.Io.Dir.cwd().access(b.graph.io, library, .{}) catch return null;
        return library;
    }

    const candidates = [_][]const u8{
        "/usr/local/lib/libwlroots-0.20.so",
        "/usr/lib/libwlroots-0.20.so",
    };
    for (candidates) |library| {
        std.Io.Dir.cwd().access(b.graph.io, library, .{}) catch continue;
        return library;
    }
    return null;
}

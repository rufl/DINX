# Aqueous IPC v1

This interface is implemented in the Aqueous source tree. DMS must still discover
capabilities because installed compositor binaries may predate it. The version is independent of the retained Wayland protocol version.

### Discovery and transport

- Aqueous exports an absolute `AQUEOUS_SOCKET` path before starting session
  children. Path: `$XDG_RUNTIME_DIR/aqueous/<instance>/ipc.sock`,
  with a private, randomly named instance directory.
- Require a valid private runtime directory; do not fall back to shared
  `/tmp`. Directory mode is 0700, socket mode is 0600. Verify peer UID,
  rejecting both mismatches and credential-query failures.
- The socket is an AF_UNIX stream. Frames are one UTF-8 JSON object followed
  by LF. Embedded newlines must be JSON escapes. Reads/writes may split
  anywhere, including within a UTF-8 codepoint or across several frames.
- Use two persistent connections to the same endpoint in DMS: one for
  capabilities/queries/commands, one for capabilities/subscription/acks.
  This keeps a slow event stream from blocking command responses.
- Each connection performs `hello` before other operations. Each runtime
  request after hello carries the returned session token.
- Never guess a socket by scanning other sessions or invoking a discovery
  subprocess. Missing environment means unavailable on the socket backend.
  An inherited path is fixed for that DMS process; a new compositor instance
  requires a relaunched DMS with the new environment.
- Same-user access defines a trusted local desktop interface. It does not
  reproduce Wayland security-context filtering. Do not expose/mount the socket
  into untrusted application sandboxes; session tokens detect stale identity,
  they are not authentication secrets.

### Envelopes and handshake

Request IDs are nonempty decimal strings, at most 20 digits, strictly increasing
numerically within each connection. This enforces lifetime uniqueness without
retaining an unbounded ID history. Session tokens are 32 lowercase hex characters.
All entity IDs, sequences and delivery IDs remain strings.

Request:

```json
{"ipc":1,"id":"1","op":"hello","params":{}}
```

Successful response shape (the hello result below shows the required fields):

```json
{"ipc":1,"id":"1","ok":true,"result":{"session":"6b94a179d09456846b94a179d0945684","schema":1,"max_request_bytes":65536,"max_frame_bytes":4259840,"max_batch_bytes":4194304,"max_pending_requests":1,"capabilities":{"state":true,"commands":true,"keyboard":true,"overview":true,"shortcut_inhibition":true}}}
```

Error response:

```json
{"ipc":1,"id":"2","ok":false,"error":{"code":"locked","message":"Session is locked"}}
```

Bounds count encoded JSON bytes excluding LF. Client requests are at most
64 KiB. Server frames are at most 4 MiB + 64 KiB, allowing an envelope around
an existing batch of at most 4 MiB. Keep existing entity-state accounting
limits (currently 2 MiB) and admit at most 16 shell clients across transports.
Advertise these limits; clients must also enforce local hard limits.

An unsupported IPC or state schema version fails explicitly. Unknown optional
response fields may be ignored; unknown operations/actions and invalid command
parameters are rejected. Validate nesting depth, types, string sizes and
numeric ranges before allocating or dispatching. Malformed framing, invalid
UTF-8, reused or non-increasing IDs, invalid acks or oversized input close the
connection; emit a bounded error first only when safely possible.

### Operations

| Operation | Parameters | Successful result |
| --- | --- | --- |
| `hello` | Empty object; first request only | Handshake above |
| `snapshot` | Optional `include_unmanaged` boolean (default false) | `{"batch": <complete shell snapshot>}` |
| `subscribe` | Optional `include_unmanaged` boolean; once per event connection | `{"subscribed":true}`, then initial snapshot event |
| `ack` | `{"delivery":"N"}` | `{"acked":"N"}` |
| `display.preview.features` | Empty object; negotiate `display_preview_feature_policy_v1` | Versioned per-output capability, selection, preservation/transition support |
| `display.preview.evidence` | `{"token":"LEASE"}`; same capability | Versioned baseline/target, observed color/VRR state, presentation progress |
| `command` | `{"action":"NAME","fields":{...}}` | `{"status":"applied","sequence":"N"}` or `accepted` |

All post-hello requests additionally contain top-level `"session":"TOKEN"`.
Validate it again when a queued mutation executes. A mismatch returns
`stale_session` without applying anything.

A subscribed connection accepts only ack after subscribe. Use the separate
request connection for snapshot and command. Allow one outstanding request per
connection in v1. DMS queues rapid commands
locally with a finite bound (proposed 32); excess requests report busy.
A server receiving another request before the previous reply returns `busy`
when possible without exceeding its output budget. Unsolicited events do not
count as outstanding requests. Each ack receives a response before any next
batch is enqueued, so the event client can clear its pending ack first.

### State and subscriptions

Event envelope:

```json
{"ipc":1,"event":"state","delivery":"1","batch":{"schema":1,"session":"6b94a179d09456846b94a179d0945684","sequence":"12","base_sequence":null,"type":"snapshot","upsert":[],"removed":[]}}
```

The empty entity list above illustrates framing only. Real snapshots contain
all current entities. Reuse the existing shell schema and DMS entity validator:
output, workspace, window, seat, keyboard, keyboard_device and session.
Preserve geometry, focus, visibility, capability and lock fields. Window IDs
remain foreign-toplevel identifiers; other entity IDs remain runtime identities.
Geometry is committed global logical geometry, not per-frame animation geometry.

A snapshot has `base_sequence:null`. A delta names the previous accepted
sequence in `base_sequence`, carries full replacement entities in `upsert`,
and removes keys in `kind:id` form through `removed`. Missing optional entity
values cannot retain stale previous values. Apply the complete batch atomically.
Sequence values may jump; compare as strings for equality and use BigInt or
checked integer parsing if ordering is needed, never JavaScript Number.

Only one unacknowledged batch may exist per event connection. Acknowledge its
exact delivery ID after successfully validating and installing it. Coalesce
changes while waiting; construct the next delta against the acknowledged
baseline. Never drop a delta and continue using its old baseline.
`snapshot` responses do not require an ack and do not create subscriptions.
The subscribe response must precede its initial snapshot event.

Publish only after policy, workspace and render transactions settle, using
existing dirty notifications. There is no polling or idle heartbeat.
Bound receive buffers, retained baselines, pending output and processing work
per event-loop turn. Partial writes resume on writability; disable writable
interest when the queue is empty.

### Commands and completion

Use the existing DMS action vocabulary:

| Action | Fields |
| --- | --- |
| `window.activate` | `id`, optional `seat` |
| `window.close` | `id` |
| `window.minimized`, `window.maximized`, `window.fullscreen` | `id`, boolean `value` |
| `window.move` | `id`, exactly one of `workspace` or `output` |
| `workspace.activate` | `id`, optional `seat` |
| `workspace.rename` | `id`, UTF-8 `name` up to 1024 bytes, no CR/LF |
| `keyboard.set` | optional `seat` and `group`, zero-based integer `index` |
| `keyboard.next` | optional `seat` and `group` |
| `overview.show`, `overview.toggle` | `output` |
| `overview.hide`, `session.exit` | Empty object |

Here `output` is a runtime output ID, `workspace` a runtime workspace ID,
`group` a keyboard group ID, and `seat` a seat name. Resolve runtime IDs
inside the shared backend rather than converting IDs to connector names in DMS.
Omitting seat requires exactly one seat; omitted group uses its active group.

Resolve targets when executing at a settled transaction. Recheck session lock,
policy mode and per-object eligibility there. Command errors include `invalid`,
`not_found`, `locked`, `unsupported`, `busy`, `ambiguous_seat`,
`unavailable`, and `stale_session`; operational/resource failures must also
produce explicit failures, never false success.

`applied` means the resulting operation has committed. Its sequence is the
committed state sequence; it may arrive before DMS receives the matching event
on the other connection. Do not optimistically rewrite authoritative state.
`accepted` is reserved for close and exit: close is a client request, not proof
of destruction. Flush exit acknowledgement before orderly shutdown, with a
bounded drain deadline so an unread socket cannot prevent logout.

### Recovery and compatibility

Use 5-second handshake/query/runtime-command deadlines and an 8-second initial
subscription deadline. Established idle subscriptions have no idle timeout.
Reconnect with bounded exponential backoff and jitter, using one reconnect
owner per connection. Fail pending commands on disconnect; a command sent
without a reply has an unknown outcome and must not be replayed automatically.
Discard queued old-session mutations and stale callbacks.

Both DMS connections must agree on session token before the backend is ready.
A broken stream invalidates the state model until a fresh subscription snapshot
is installed. Never merge across sessions or continue a broken delta sequence.
Keep the existing Wayland shell protocol and `aqueousctl` behavior compatible.
The new DMS backend does not silently fall back to process calls.

## Implementation and resource budgets

`ShellManager.zig` owns state, session/sequence identity, subscriptions and settled
publication for both transports. `ShellCommands.zig` executes transport-neutral
`ShellCommand.zig` commands. `IpcServer.zig` owns only socket framing, I/O and
lifecycle; it never dispatches commands through aqueousctl or another process.

The instance name is the compositor's random session token. An existing owned
`aqueous` parent directory is tightened to 0700 for compatibility with older
outputd installations. The runtime directory must already be owned and 0700;
symlink directories are rejected. IPC setup failure is logged and clears the
inherited endpoint while allowing the compositor to continue.

There are at most 16 shared shell clients, including sockets that have not sent
hello. Each socket holds a 65537-byte input buffer, at most 4325376 queued output
bytes, and one state baseline with the existing 2 MiB state accounting bound.
Allocator capacity/hash overhead and one transient JSON serialization/parser
allocation add to those logical limits. Requests are limited to nesting depth 16.
Hello also advertises max_clients, max_state_bytes and max_depth.

Each callback accepts at most 8 sockets, reads at most 8 chunks of 8192 bytes,
processes at most 16 buffered frames per chunk/service pass and writes at most
256 KiB. Remaining buffered frames resume from an idle callback. There is no
recurring IPC timer. A one-second timer bounds draining an accepted exit reply.
Ack replies are queued before the next state event. Reading a complete response
is required before submitting another request; pipelining can return busy.

The socket is a trusted same-UID desktop interface, not a sandbox grant mechanism.
The Wayland shell global retains its separate security-context filtering.
Neither connection exposes arbitrary command execution or configuration writes.

## Validation

The schema is `aqueous-ipc-v1.schema.json`; captured protocol fixtures live in
`scripts/fixtures/ipc/`. JSON schemas describe structure; byte limits, sequence
continuity, strictly increasing request IDs and transaction timing also require
runtime checks. The existing shell schema defines the inner batch.

Build with the repository's pinned wlroots and a writable Zig cache. For isolated
Pixman tests, use a `-Dvulkan-effects=false` build and set binary overrides:

```sh
zig build test -Dvulkan-effects=false
AQUEOUS_COMPOSITOR_BIN=/path/to/aqueous python3 scripts/test-ipc-integration.py
AQUEOUS_COMPOSITOR_BIN=/path/to/aqueous AQUEOUSCTL_BIN=/path/to/aqueousctl \
  AQUEOUS_SHELL_TEST_IPC=1 python3 scripts/test-shell-integration.py
AQUEOUS_COMPOSITOR_BIN=/path/to/aqueous AQUEOUSCTL_BIN=/path/to/aqueousctl \
  python3 scripts/test-shell-integration.py
```

Run `bash packaging/tests/test-aqueous-init.sh` from the repository root to test
mocked UWSM, D-Bus and systemd endpoint propagation and nested-session isolation.
The integration fixtures launch private headless compositors and do not connect
to the user's desktop. Socket binding must be permitted in the test environment.

DMS migration is documented in `docs/dms-ipc-socket-plan.md` at the repository
root. Until that consumer work lands, DMS continues to use its existing process
adapter. Persistent settings/keybind configuration transport is a later phase.

### Per-window icons

Optional capabilities `icon_metadata` and `icon_fetch` advertise committed icon
metadata in the shared shell model and the read-only `window.icon` query.
Clients must tolerate their absence on older compositors. No IPC version bump
is required. Metadata follows the [shell state contract](aqueous-shell-v1.md).

```json
{"ipc":1,"id":"9","session":"6b94a179d09456846b94a179d0945684","op":"window.icon","params":{"id":"window-identifier","revision":"2","size":32,"scale":2}}
```

`id` is the ext-foreign-toplevel identifier from the current session's window
record. `revision` must match its committed icon revision. `size` is an integer
logical edge length (1–256); `scale` is an integer (1–8). Their product must be
at most 256. Exactly these four parameters are required. This operation uses
the request connection; it is rejected on a subscribed connection.

A successful result contains `revision`, `width`, `height`, `format: "png"`, and
`data` (base64 PNG). Width and height both equal `size * scale`. The PNG uses
straight RGBA pixels. Encoded image data is bounded to 512 KiB and remains subject
to the usual frame and output-queue limits. Do not place it in state batches.

Errors are `invalid` (parameters/connection mode), `not_found` (window removed,
unmapped, or identity changed), `stale_revision` (icon changed), `unavailable`
(no usable pixels, unsupported CPU conversion, or encoder allocation failure),
or `locked`. Existing `stale_session`, `busy`, and framing errors still apply.
Name-only icons can be resolved by the frontend's current XDG icon theme.

PNG compression runs in-process on a bounded worker job: at most one per client
and 16 admitted clients. Completion rechecks the window identity, revision, and
lock state. Disconnect cancels delivery and joins the bounded encode. The server
caches up to 32 encoded responses and invalidates a window's entries when its
icon changes or it is destroyed. No per-window subprocesses or disk cache are
used. A query response can already be obsolete by the time it reaches a client;
consumers must compare it with their latest subscribed metadata before display.


Display preview feature-policy results are defined in
[aqueous-display-v1.schema.json](aqueous-display-v1.schema.json), separately from
legacy snapshot and lease shapes. See the
[preview qualification runbook](../../docs/physical-display-preview.md#negotiated-feature-diagnostics)
for semantics and rejection codes. `display_preview_hardware` and
`production_hardware_enabled` are true in production builds and false in isolated
acceptance builds, independently of the active backend. These flags advertise
production policy, not support for every feature or output. Production DRM previews
use hardware capability checks and backend preflight; acceptance builds additionally
restrict connectors and feature selections. Use per-output/per-feature results
and candidate admission to determine whether a particular operation is supported. A successful presentation proves completion, not HDR appearance or
variable panel refresh.


### Optional unmanaged surface observation

When `hello` advertises `unmanaged_windows: true`, `snapshot` and `subscribe`
accept the optional boolean parameter `include_unmanaged`. It defaults to
false for compatibility. Opting in includes the `unmanaged_window` entities
described in [the shell contract](aqueous-shell-v1.md). Their IDs are separate
from managed window command targets. An omitted parameter on a subsequent
snapshot restores the managed-only selection.

## Workspace switcher extension

Optional hello capability `workspace_switcher_v1` advertises a compositor-owned,
immediate-focus workspace switcher. This is an additive IPC v1 extension.

| Command | Fields |
| --- | --- |
| `switcher.next` | `output`, `workspace`, optional `seat`, optional boolean `reduced_motion` |
| `switcher.previous` | Same as next |
| `switcher.dismiss` | Same scope fields; motion is ignored |

Output and workspace are opaque snapshot IDs. The workspace must still be active
on that output at execution. A missing seat is accepted only for an unambiguous
seat. Commands never move windows or activate another workspace. Empty and
single-window scopes are successful no-ops. Normal status/sequence/request-ID
receipts apply; successful replies also include `switcher_window` (nullable),
`switcher_position`, `switcher_total`, and `switcher_serial`. The state stream
publishes the same fields plus nullable `switcher_output` on the session entity.
Position is one-based while visible and zero when dismissed. Serial increments
once per accepted step through a multi-window ring. Committed state and ordinary
seat/window focus remain authoritative; request write completion is not focus.

A workspace ring retains its order across focus changes and presentation expiry.
It excludes minimized, `skip_switcher`, non-activatable and modal-blocked parent
windows; optional window metadata `switcher_eligible` publishes that eligibility.
New members append and removed/moved/excluded members leave. Three scene cards
are sufficient regardless of ring size. Actual client geometry is unchanged.

Presentation expires after 1500 ms without a step. Escape dismisses and is
consumed; other ordinary key presses dismiss and continue to the focused client.
Pointer input restores ordinary presentation before delivery except for layer
surfaces, which remain usable above the stack. Lock, output/seat destruction,
workspace change, unrelated focus change and destruction of a displayed window
also dismiss. The initiating command connection owns IPC-started presentation;
its disconnection clears the scene. Native bindings have compositor ownership.

The native actions `window_switcher_next`, `window_switcher_previous` and
`window_switcher_dismiss` are initially unbound, preserving existing shortcuts.
IPC clients can request reduced motion per step. Native bindings use the
compositor's animation build setting. This extension does not introduce new
Wayland shell command enumeration values.

The optional `window_order` hello capability and `window.layout_index` use the
scope and null semantics documented in [the shell state contract](aqueous-shell-v1.md).

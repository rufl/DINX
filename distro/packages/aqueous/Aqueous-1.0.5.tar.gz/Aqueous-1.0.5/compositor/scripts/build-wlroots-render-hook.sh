#!/usr/bin/env bash
set -euo pipefail

here=$(cd "$(dirname "$0")/.." && pwd)
version=0.20.2
archive_sha256=972c7ac44b17828f4702bfae7cd8347346a3fb5b2c1076cfa2c3fcedac5ec343
archive_url="https://gitlab.freedesktop.org/wlroots/wlroots/-/archive/$version/wlroots-$version.tar.gz"
patch_files=(
    "$here/patches/wlroots/0001-aqueous-vulkan-render-hook.patch"
    "$here/patches/wlroots/0002-fix-hdr-min-luminance.patch"
    "$here/patches/wlroots/0003-color-management-v1-srgb-compat.patch"
    "$here/patches/wlroots/0004-scene-sdr-white-level.patch"
    "$here/patches/wlroots/0005-drm-expose-edid-hdr-static-metadata.patch"
    "$here/patches/wlroots/0006-color-management-v1-windows-hdr.patch"
    "$here/patches/wlroots/0007-scene-precise-position.patch"
    "$here/patches/wlroots/0008-xwayland-native-scaling.patch"
    "$here/patches/wlroots/0009-surface-preferred-scale-override.patch"
    "$here/patches/wlroots/0010-output-layer-sync-and-test.patch"
    "$here/patches/wlroots/0011-scene-output-layer-promotion.patch"
    "$here/patches/wlroots/0012-syncobj-release-on-buffer-detach.patch"
    "$here/patches/wlroots/0013-fifo-v1.patch"
    "$here/patches/wlroots/0014-screencopy-10bit-sdr-shm.patch"
    "$here/patches/wlroots/0015-ext-capture-formats-and-color.patch"
    "$here/patches/wlroots/0016-toplevel-icon-lifetime.patch"
    "$here/patches/wlroots/0017-xdg-toplevel-drag-v1.patch"
    "$here/patches/wlroots/0018-pointer-constraint-initial-region.patch"
    "$here/patches/wlroots/0019-overlay-backend-recovery.patch"
    "$here/patches/wlroots/0020-vulkan-sync-failure-handling.patch"
    "$here/patches/wlroots/0021-drm-lease-lifetime.patch"
    "$here/patches/wlroots/0022-pointer-enter-serial-validation.patch"
    "$here/patches/wlroots/0023-commit-timing-v1.patch"
    "$here/patches/wlroots/0024-protocol-versions.patch"
    "$here/patches/wlroots/0025-drm-color-pipeline.patch"
    "$here/patches/wlroots/0026-scene-color-pipeline.patch"
    "$here/patches/wlroots/0027-xwayland-size-hints.patch"
    "$here/patches/wlroots/0028-output-color-guard.patch"
    "$here/patches/wlroots/0029-screencopy-sdr-gamma-lookup.patch"
    "$here/patches/wlroots/0030-vulkan-presentation-copy.patch"
    "$here/patches/wlroots/0031-vulkan-device-selection.patch"
    "$here/patches/wlroots/0032-scene-empty-buffer-damage.patch"
    "$here/patches/wlroots/0033-scene-effect-single-pixel.patch"
)
prefix=${1:-"$here/.deps/wlroots-render-hook"}
cache_dir=${AQUEOUS_WLROOTS_CACHE_DIR:-"$here/.deps/downloads"}
archive="$cache_dir/wlroots-$version.tar.gz"

die() { echo "FAIL: $*" >&2; exit 1; }
for tool in cc curl meson ninja patch pkg-config python3 sha256sum tar; do
    command -v "$tool" >/dev/null 2>&1 || die "$tool is required"
done
pkg-config --atleast-version=1.49 wayland-protocols ||
    die "wayland-protocols 1.49 or newer is required"
for patch_file in "${patch_files[@]}"; do
    [ -r "$patch_file" ] || die "missing wlroots patch: $patch_file"
done

mkdir -p "$cache_dir"
if [ ! -f "$archive" ]; then
    curl -L --fail --silent --show-error "$archive_url" -o "$archive.tmp"
    mv "$archive.tmp" "$archive"
fi
printf '%s  %s\n' "$archive_sha256" "$archive" | sha256sum -c - >/dev/null ||
    die "wlroots source archive checksum mismatch"

build_root=$(mktemp -d /tmp/aqueous-wlroots-render-hook.XXXXXX)
cleanup() { rm -rf "$build_root"; }
trap cleanup EXIT
source_dir="$build_root/source"
build_dir="$build_root/build"
mkdir -p "$source_dir"
tar -xzf "$archive" --strip-components=1 -C "$source_dir"
for patch_file in "${patch_files[@]}"; do
    patch -d "$source_dir" -p1 <"$patch_file"
done
cmp "$source_dir/protocol/aqueous-capture-color-v1.xml" \
    "$here/protocol/aqueous-capture-color-v1.xml" ||
    die "capture color protocol differs between compositor and wlroots patch"
grep -Fq '#define WM_BASE_VERSION 7' "$source_dir/types/xdg_shell/wlr_xdg_shell.c" ||
    die "pinned wlroots does not support the required xdg-shell version 7"
grep -Fq '#define WLR_AQUEOUS_FIFO_VERSION 1' \
    "$source_dir/include/wlr/types/wlr_fifo_v1.h" ||
    die "patched wlroots does not expose the required FIFO API"
grep -Fq '#define WLR_AQUEOUS_COMMIT_TIMING_VERSION 1' \
    "$source_dir/include/wlr/types/wlr_commit_timing_v1.h" ||
    die "patched wlroots does not expose the required commit timing API"
scene_source="$source_dir/types/scene/wlr_scene.c"
grep -Fq 'scene_output_damage_internal(scene_output, &damage, false, NULL);' \
    "$scene_source" ||
    die "patched wlroots does not separate output-only and scene damage"
grep -Fq 'render_pass, &scene_output->pending_effect_damage,' \
    "$scene_source" ||
    die "patched wlroots does not pass full scene damage to the render hook"
grep -Fq '&scene_buffer->node);' "$scene_source" ||
    die "patched wlroots does not preserve buffer damage provenance"
grep -Fq 'scene_output_damage_internal(data->output, &render_region, true,' \
    "$scene_source" ||
    die "patched wlroots does not preserve render-retry damage provenance"
grep -Fq 'scene_damage_outputs(scene, damage, node);' "$scene_source" ||
    die "patched wlroots does not preserve node-update damage provenance"
grep -Fq 'int wlr_scene_node_render_order(' "$scene_source" ||
    die "patched wlroots does not expose scene render ordering"
output_layer_header="$source_dir/include/wlr/types/wlr_output_layer.h"
grep -Fq 'struct wlr_drm_syncobj_timeline *signal_timeline;' \
    "$output_layer_header" ||
    die "patched wlroots output layers do not expose release synchronization"
grep -Fq 'bool must_scan_out;' "$output_layer_header" ||
    die "patched wlroots output layers cannot require a hardware assignment"
liftoff_source="$source_dir/backend/drm/libliftoff.c"
grep -Fq 'connector_update_layers_acceptance(&state->connectors[i])' \
    "$liftoff_source" ||
    die "patched wlroots does not enforce output-layer TEST_ONLY acceptance"
scene_header="$source_dir/include/wlr/types/wlr_scene.h"
    grep -Fq 'struct wlr_scene_output_layer_candidate' "$scene_header" &&
    grep -Fq 'WLR_AQUEOUS_OUTPUT_LAYER_PROMOTION_VERSION 3' "$scene_header" &&
    grep -Fq 'scene_entry_try_output_layer' "$scene_source" &&
    grep -Fq 'wlr_scene_output_layer_candidate_finish' "$scene_source" ||
    die "patched wlroots does not provide scene output-layer promotion"
scene_surface_source="$source_dir/types/scene/surface.c"
grep -Fq 'get_surface_effective_preferred_scale' "$scene_surface_source" &&
    grep -Fq 'wlr_surface_get_preferred_scale_override(surface)' \
    "$scene_surface_source" ||
    die "patched wlroots scene path does not preserve surface scale overrides"
color_manager_source="$source_dir/types/wlr_color_management_v1.c"
grep -Fq '#define COLOR_MANAGEMENT_V1_VERSION 3' "$color_manager_source" ||
    die "patched wlroots does not expose color-management-v1 version 3"
grep -Fq 'WP_COLOR_MANAGER_V1_FEATURE_WINDOWS_BT2100' "$color_manager_source" ||
    die "patched wlroots does not advertise Windows BT.2100"
grep -Fq 'WLR_COLOR_TRANSFER_FUNCTION_ST2084_PQ ? target_max_lum : 0' \
    "$color_manager_source" ||
    die "patched wlroots does not preserve Proton target/reference HDR headroom"
grep -Fq 'wp_color_management_output_v1_send_image_description_changed' \
    "$color_manager_source" ||
    die "patched wlroots does not notify clients about output color changes"
history_line=$(
    grep -nF 'wlr_damage_ring_add(&scene_output->damage_ring,' \
        "$scene_source" | tail -1 | cut -d: -f1
)
rotate_line=$(
    grep -nF 'wlr_damage_ring_rotate_buffer(&scene_output->damage_ring, buffer,' \
        "$scene_source" | tail -1 | cut -d: -f1
)
[ -n "$history_line" ] && [ -n "$rotate_line" ] &&
    [ "$history_line" -lt "$rotate_line" ] ||
    die "expanded effect damage is not recorded before buffer-history rotation"

# Keep wlroots optimized independently of the caller's CFLAGS and Zig build
# mode. Retain debug symbols and assertions for diagnostics.
meson setup "$build_dir" "$source_dir" \
    --prefix="$prefix" \
    --libdir=lib \
    --buildtype=debugoptimized \
    -Dexamples=false \
    -Dxwayland=enabled \
    -Drenderers=vulkan \
    -Dbackends=drm,libinput,x11 \
    -Dallocators=gbm \
    -Dsession=enabled \
    -Dlibliftoff=enabled \
    -Dcolor-management=enabled
meson compile -C "$build_dir"
meson install -C "$build_dir"

# Exercise the exact bounded enter history shipped in pointer dispatch.
cc -std=c11 -Wall -Wextra -Werror -I"$source_dir/include" \
    "$here/scripts/fixtures/pointer-enter-serial.c" -o "$build_root/pointer-enter-serial"
"$build_root/pointer-enter-serial" || die "pointer enter serial validation failed"

# Exercise the exact conversion helper shipped in the patched screencopy path.
bash "$here/scripts/test-screencopy-sdr.sh" "$source_dir" "$prefix" ||
    die "10-bit SDR screencopy conversion failed"

library="$prefix/lib/libwlroots-0.20.so"
[ -f "$library" ] || die "patched wlroots library was not installed"
for symbol in \
    wlr_vk_renderer_candidates_create \
    wlr_vk_renderer_candidates_next \
    wlr_vk_renderer_candidates_destroy \
    wlr_vk_renderer_recreate \
    wlr_output_allow_presentation_copy \
    wlr_output_try_presentation_copy \
    wlr_output_uses_presentation_copy \
    wlr_output_presentation_copy_committed \
    wlr_output_reset_presentation \
    wlr_vk_renderer_requires_copy \
    wlr_vk_renderer_get_copy_formats \
    wlr_vk_copy_allocator_create \
    wlr_buffer_has_color_pipeline \
    wlr_drm_output_supports_color_pipeline \
    wlr_seat_client_validate_pointer_enter_serial \
    wlr_xdg_toplevel_set_suspended \
    wlr_xdg_toplevel_set_constrained \
    wlr_aqueous_capture_color_manager_v1_create \
    wlr_fifo_manager_v1_create \
    wlr_commit_timing_manager_v1_create \
    wlr_commit_timing_manager_v1_get_global \
    wlr_xdg_toplevel_drag_manager_v1_create \
    wlr_xdg_toplevel_drag_v1_try_from_data_source \
    wlr_xdg_wm_dialog_v1_create \
    wlr_xdg_dialog_v1_try_from_wlr_xdg_toplevel \
    wlr_fifo_manager_v1_get_global \
    wlr_fifo_manager_v1_output_pending \
    wlr_fifo_manager_v1_prepare \
    wlr_fifo_manager_v1_finish \
    wlr_fifo_manager_v1_present \
    wlr_scene_output_set_buffer_render_hook \
    wlr_scene_output_set_buffer_needs_composition \
    wlr_scene_output_set_rect_render_hook \
    wlr_scene_output_set_render_hooks \
    wlr_scene_output_set_damage_hook \
    wlr_scene_node_render_order \
    wlr_scene_node_set_position_f64 \
    wlr_scene_node_coords_f64 \
    wlr_scene_surface_set_destination_scale \
    wlr_scene_surface_get_destination_scale \
    wlr_scene_surface_map_point_to_destination \
    wlr_surface_set_preferred_scale_override \
    wlr_surface_get_preferred_scale_override \
    wlr_output_set_client_projection_handler \
    wlr_xdg_output_manager_v1_update \
    wlr_scene_buffer_set_force_blend \
    wlr_scene_rect_set_force_blend \
    wlr_vk_renderer_enable_offscreen \
    wlr_vk_render_pass_run_offscreen \
    wlr_vk_render_pass_add_completion \
    wlr_vk_render_pass_set_texture_hook \
    wlr_vk_render_pass_get_attribs \
    wlr_output_get_edid_hdr_static_metadata \
    wlr_color_manager_v1_set_windows_hdr_features \
    wlr_color_manager_v1_encode_luminances \
    wlr_surface_has_windows_hdr_image_description \
    wlr_surface_has_windows_scrgb_image_description \
    wlr_backend_is_x11 \
    wlr_aqueous_set_color_guard \
    wlr_xwayland_create; do
    nm -D --defined-only "$library" | grep " $symbol$" >/dev/null ||
        die "patched wlroots is missing $symbol"
done

cc "$here/scripts/fixtures/wlroots-commit-timing-api.c" \
    -o "$build_root/commit-timing-api" \
    $(PKG_CONFIG_PATH="$prefix/lib/pkgconfig" pkg-config --cflags --libs wlroots-0.20 wayland-server)
LD_LIBRARY_PATH="$prefix/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}" \
    "$build_root/commit-timing-api" || die "commit timing API probe failed"

python3 "$here/scripts/test-xdg-output.py" "$prefix" ||
    die "xdg-output change detection or client isolation failed"

probe="$build_root/scene-precise-position"
cc "$here/scripts/fixtures/wlroots-precise-position.c" \
    -o "$probe" \
    $(PKG_CONFIG_PATH="$prefix/lib/pkgconfig" pkg-config --cflags --libs wlroots-0.20)
LD_LIBRARY_PATH="$prefix/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}" "$probe" ||
    die "patched wlroots did not preserve precise scene coordinates"

scene_order_probe="$build_root/wlroots-scene-order"
cc "$here/scripts/fixtures/wlroots-scene-order.c" \
    -o "$scene_order_probe" \
    $(PKG_CONFIG_PATH="$prefix/lib/pkgconfig" pkg-config \
        --cflags --libs wlroots-0.20) \
    -DWLR_USE_UNSTABLE
LD_LIBRARY_PATH="$prefix/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}" \
    "$scene_order_probe" ||
    die "patched wlroots did not preserve scene render ordering"

scene_damage_probe="$build_root/wlroots-scene-empty-damage"
cc -std=c11 -O2 -Wall -Wextra -Werror \
    "$here/scripts/fixtures/wlroots-scene-empty-damage.c" -o "$scene_damage_probe" \
    $(PKG_CONFIG_PATH="$prefix/lib/pkgconfig" pkg-config \
        --cflags --libs wlroots-0.20 pixman-1 wayland-server)
LD_LIBRARY_PATH="$prefix/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}" \
    "$scene_damage_probe" || die "scene empty-damage state updates failed"

python3 "$here/scripts/test-pointer-enter.py" "$source_dir" "$prefix"
python3 "$here/scripts/test-protocol-version-handlers.py" "$source_dir" "$prefix"

python3 "$here/scripts/test-overlay-backend.py" "$source_dir" "$prefix"
python3 "$here/scripts/test-color-pipeline.py" "$source_dir" "$prefix"
python3 "$here/scripts/test-vulkan-sync.py" "$source_dir" "$prefix"
python3 "$here/scripts/test-vulkan-selection.py" "$source_dir"
python3 "$here/scripts/test-xwayland-size-hints.py" "$source_dir"
python3 "$here/scripts/test-drm-lease-protocol.py" "$source_dir" "$prefix"
python3 "$here/scripts/test-drm-lease-backend.py" "$source_dir" "$prefix"

echo "patched wlroots $version installed at $prefix"
echo "export PKG_CONFIG_PATH=$prefix/lib/pkgconfig"
echo "export LD_LIBRARY_PATH=$prefix/lib"

# Missing Wayland and wlroots protocols

Audit of useful Wayland protocol gaps in Aqueous against the
[wayland-protocols](https://gitlab.freedesktop.org/wayland/wayland-protocols)
and [wlr-protocols](https://gitlab.freedesktop.org/wlroots/wlr-protocols)
registries. Verified against protocol manager creation in
`compositor/aqueous/Server.zig`, `InputManager.zig`, `OutputManager.zig`,
`LayerShell.zig`, `LockManager.zig`, `IdleInhibitManager.zig`,
`WorkspaceManager.zig`, and `XwaylandKeyboardGrab.zig`. Updated September 9,
2026 against the source tree, installed protocol XMLs, and the pinned patched
wlroots 0.20.2 headers. This is a source audit, not a runtime registry probe;
some globals depend on build options or hardware. Dependency support below
refers to this pinned wlroots, not an assertion about upstream development.
The staging inventory was rechecked September 10, 2026 against
[Wayland Explorer](https://wayland.app/protocols/) and compositor manager
initialization; its current classification is used below.

## Supported compatibility protocols

`org_kde_kwin_server_decoration_manager` is advertised through wlroots for
GTK 3/4 and older Qt clients. Its display-wide default follows
`[layout].force_ssd`: client-side when disabled and server-side when enabled.
The protocol is obsolete, so its wlroots binding is isolated in
`LegacyServerDecoration.zig` for straightforward removal or replacement.

`keyboard-shortcuts-inhibit-v1` is implemented in
`ShortcutInhibitManager.zig`, with focus/seat eligibility and keyboard dispatch
integration. Normal bindings are inhibited; built-in VT switching remains
reserved. See the [shell contract](../compositor/protocol/aqueous-shell-v1.md).

FIFO v1 is now implemented and advertised by Aqueous with its patched wlroots
dependency. Automated protocol, queue-ordering, lifetime, Pixman/Vulkan pacing,
and syncobj remap tests pass. Physical DRM/VRR and FIFO plane-promotion
qualification remain outstanding; see the
[implementation and validation record](fifo-v1-implementation-plan.md).

`commit-timing-v1` is implemented with ordered per-commit deadlines, synchronized
subsurface snapshots, and event-loop wakeups in the patched wlroots dependency.
Pixman/Vulkan presentation, lifecycle, sanitizer, FIFO/syncobj remap, and client
policy checks pass. Physical DRM/VRR, scanout, and plane-promotion timing remain
outstanding; see the [performance and validation record](commit-timing-v1-performance-results.md).

`xdg-toplevel-icon-v1` is implemented with committed per-window state, owned
pixel snapshots, built-in overview icons, shell metadata, and bounded socket PNG
retrieval. The native overview uses a placeholder for name-only icons; DMS can
resolve theme names and use supplied pixels. See the
[implementation and validation record](xdg-toplevel-icon-implementation-plan.md).

`xdg-toplevel-drag-v1` is implemented in the patched wlroots dependency and
Aqueous's per-seat DnD path. Both renderer builds expose version 1 under integrated
policy, including for security-context clients. Existing move restrictions apply;
legacy external-WM mode hides the global. Protocol, pointer/touch, lifecycle, and
output/seat regressions pass with Pixman. Vulkan runtime qualification remains;
see the [implementation record](xdg-toplevel-drag-v1-implementation-plan.md).

`xdg-system-bell-v1` is implemented through the pinned wlroots manager, with
configurable visual feedback, custom sound playback, shared rate limiting, and
lock/output lifecycle cleanup. Both renderers and security-context clients are
covered by headless tests; actual WAV/Ogg playback and volume pass through an
isolated PipeWire null sink. External-policy registry/lifecycle smoke checks pass.
See the [implementation and validation record](xdg-system-bell-v1-implementation-plan.md)
for behavior and remaining physical-display qualification.

`xdg-toplevel-tag-v1` is implemented with owned per-toplevel tags/descriptions,
initial and runtime tag rules, settings-editor support, versioned CLI inspection,
and socket metadata updates. Pixman/Vulkan protocol tests and legacy inspection
bindings pass. Tags remain client-provided and need not be unique. See the
[implementation and validation record](xdg-toplevel-tag-v1-implementation-plan.md).

`drm-lease-v1` is implemented for non-desktop DRM connectors. It reserves
headsets outside desktop output handling, restricts security-context clients,
and revokes/blanks leases on lock and session changes. Protocol, allocator,
lifecycle, and both renderer headless tests pass; physical DRM/VR qualification
remains outstanding. See the [implementation and validation record](drm-lease-v1-implementation-plan.md).

`pointer-warp-v1` is implemented by `PointerWarpManager.zig` and the dedicated
client cursor path. Requests validate exact recent enter serials, seat/client
ownership, focused surface coordinates, grabs, constraints, and compositor input
ownership. Pixman/Vulkan integration, external/compare policy checks, and seat
lifecycle tests pass. Rebuild the pinned wlroots dependency with patch 0022;
see the [implementation and validation record](pointer-warp-v1-implementation-plan.md).

## Not supported

### wayland-protocols staging

The remaining missing staging protocol from the audited inventory is below.
The remaining staging protocol families are implemented, with runtime
availability subject to build, renderer, hardware, and client-policy conditions.
This inventory tracks protocol presence, not conformance to every interface
version or request.

| Protocol | Global interface | Dependency support | Benefit and required integration |
|---|---|---|---|
| [ext-transient-seat-v1](https://wayland.app/protocols/ext-transient-seat-v1) | `ext_transient_seat_manager_v1` | Present: `wlr_transient_seat_v1.h`. | Temporary independent seats for remote-desktop users. Requires seat creation/destruction and virtual-input routing. `InputManager.zig` currently ignores virtual-pointer seat suggestions, so manager creation is insufficient. |

Protocol definitions are under `staging/<protocol>/<protocol>-v1.xml` in
[wayland-protocols](https://gitlab.freedesktop.org/wayland/wayland-protocols/-/tree/main/staging);
xdg-shell is under `stable/xdg-shell/xdg-shell.xml`. The installed XMLs under
`/usr/share/wayland-protocols` were used to verify interface names and semantics.
The dependency headers are under
`compositor/.deps/wlroots-render-hook/include/wlroots-0.20/wlr/types/`.

### wayland-protocols experimental (session-management correction)

Session management was previously listed above as staging
`xdg-session-management-v1`. Wayland Explorer currently lists it as experimental
`xx-session-management-v1`; it is excluded from the two staging gaps. This
section preserves that entry and is not a complete experimental inventory.

| Protocol | Global interface | Benefit and required integration |
|---|---|---|
| [xx-session-management-v1](https://wayland.app/protocols/xx-session-management-v1) | `xx_session_manager_v1` | Restore participating applications' toplevel state across executions. Needs session identity, persistent state, restoration policy, and lifecycle handling. Does not itself relaunch applications or restore their document contents. No Aqueous manager initialization found. |

### wlr-protocols compatibility

| Protocol | Global interface | Notes |
|---|---|---|
| wlr-input-inhibitor-unstable-v1 | `zwlr_input_inhibit_manager_v1` | Legacy compositor-wide input inhibition. Aqueous already implements ext-session-lock-v1. Low priority unless a concrete compatibility need is identified; would require input-policy integration, not merely global creation. |

### wayland-protocols legacy unstable

| Protocol | Global interface | Notes |
|---|---|---|
| xdg-foreign v1 | `zxdg_exporter_v1` / `zxdg_importer_v1` | Only xdg-foreign v2 is implemented. A few older clients still bind v1. |
| input-timestamps-v1 | `zwp_input_timestamps_manager_v1` | High-resolution timestamps for keyboard/pointer/touch events. Not implemented by wlroots either. |
| tablet v1 | `zwp_tablet_manager_v1` | Superseded by tablet v2 (supported). wlroots only implements v2. |
| fullscreen-shell-v1 | `zwp_fullscreen_shell_manager_v1` | Deprecated; no practical value today. |
| input-panel-v1 | `zwp_input_panel_v1` | Dead protocol; no active users. |
| input-method v1 | `zwp_input_method_v1` | Superseded by input-method v2 (supported). |
| text-input v1 | `zwp_text_input_manager_v1` | Superseded by text-input v3 (supported). |
| text-input v2 | `zwp_text_input_manager_v2` | Superseded by text-input v3 (supported). |

### Deprecated / removed upstream

| Protocol | Global interface | Notes |
|---|---|---|
| wl_shell | `wl_shell` | Removed from wayland.xml; no modern client binds it. |
| xdg-shell-unstable-v5 | `zxdg_shell_v5` | Removed from wayland-protocols. |
| xdg-shell-unstable-v6 | `zxdg_shell_v6` | Removed from wayland-protocols. |
| wl_drm | `wl_drm` | Legacy EGL buffer protocol; superseded by zwp_linux_dmabuf_v1 (supported). |

### Other compositor ecosystems

Not expected for a wlroots-based compositor; listed for completeness.

**KDE Plasma** (wl_registry globals used by Plasma-specific clients):

- `org_kde_plasma_shell` — Plasma panel/shell behavior
- `org_kde_kwin_shadow_manager` — client-drawn shadows
- `org_kde_kwin_appmenu_manager` — global menus
- `org_kde_kwin_blur_manager` — blur
- `org_kde_kwin_idle` — KDE idle tracking
- `org_kde_layer_shell_effects` — Plasma layer-shell window behavior
- `org_kde_plasma_window_management` — Plasma taskbar API

**GNOME / Mutter** — these are D-Bus APIs, not wl_registry globals:

- `org.gnome.Mutter.DisplayConfig`
- `org.gnome.Mutter.IdleMonitor`
- `org.gnome.Mutter.RemoteDesktop`
- `org.gnome.Shell.Screencast`

## Currently supported (verified)

For reference, the protocol set confirmed in the codebase:

**Core:** `wl_compositor` (v6), `wl_subcompositor`, `wl_shm` (v2),
`wl_data_device_manager`, `wl_output`, `wl_seat`.

**Desktop, rendering, and input protocols (mixed stability):** xdg-shell (v7), presentation-time (v2),
viewporter, idle-inhibit-v1, xdg-decoration-v1 (v2), relative-pointer-v1,
pointer-constraints-v1, tablet-v2 (v2), input-method-v2, text-input-v3 (v2),
xdg-activation-v1, xdg-output-v1, linux-dmabuf-v1 (v6), pointer-gestures-v1,
single-pixel-buffer-v1, fractional-scale-v1, cursor-shape-v1 (v2),
tearing-control-v1, alpha-modifier-v1, linux-drm-syncobj-v1,
color-management-v1 (v2/v3), color-representation-v1, security-context-v1, wayland-fixes,
content-type-v1, fifo-v1, commit-timing-v1, xdg-dialog-v1, xdg-system-bell-v1, drm-lease-v1
(per usable DRM backend).

The pinned wlroots patch `0024-protocol-versions.patch` provides these version
upgrades while preserving older client bindings. DMA-BUF v6 advertises sampling
tranches and accepts explicit sampling-device selection for the main renderer;
unsupported devices fail import normally. Decoration v2 supports negotiation on
mapped surfaces and retains the previous mode across destruction/recreation
without an intervening surface commit. Tablet v2 sends the bus type when libinput
provides it; Aqueous still does not expose tablet pads or dials. Text-input v2
validates and double-buffers available actions, accepts panel hints, and provides
version-gated action, language, and preedit-hint events. The existing input-method-v2
bridge cannot supply action/language events or control panel visibility, so those
capabilities remain limited by the input method. New text-input hint bits are
kept local rather than forwarded to that older bridge.

Run `python3 scripts/test-protocol-versions.py` from `compositor/` against a build
using the patched dependency to check all four advertised versions on Vulkan,
including old clients, mapped decoration recreation, new requests, and protocol
errors. `--renderer pixman` covers the same paths except DMA-BUF, which requires
a renderer with DMA-BUF support. The dependency build also runs focused handler
tests for action buffering and validation, event version gates, sampling-device
validation, and feedback flags.

xdg-shell v7 includes v6 suspension and v7 constrained-edge hints, filtered by
each client's bound version. Suspension follows workspace/output visibility,
locking, and active capture demand; visible previews and outstanding resize
buffers conservatively keep clients active. Edge hints follow client-initiated
resize eligibility, independently of modifier-driven resizing. See the
[implementation and validation record](xdg-shell-v6-v7-implementation-plan.md).

xdg-dialog-v1 (global `xdg_wm_dialog_v1`, v1) supports immediate dialog/modal
hints, lifecycle cleanup, and sandboxed clients. Integrated policy redirects
parent focus to eligible modal descendants and keeps dialogs above fullscreen
parents, while reusing ordinary transient placement. External policy receives
the global but retains its own focus/placement authority. See the
[implementation and validation record](xdg-dialog-v1-implementation-plan.md).

**wayland-protocols ext/staging:** ext-idle-notify-v1, ext-session-lock-v1,
ext-image-copy-capture-v1, ext-output-image-capture-source-v1,
ext-foreign-toplevel-list-v1, ext-foreign-toplevel-image-capture-source-v1,
ext-data-control-manager-v1, ext-workspace-v1, ext-background-effect-v1.

`ext-background-effect-v1` (v1) is available in Vulkan effects builds. Client
regions apply with surface commits and support holes, disconnected components,
popups, and subsurfaces. The global is absent in no-effects builds; capability
events reflect global blur enablement. See the
[native blur plan and implementation notes](native-background-blur-implementation-plan.md).

**wayland-protocols unstable (legacy):** zxdg_decoration_manager_v1,
zxdg_activation_v1, zxdg_foreign_v2, zwp_primary_selection_device_manager_v1,
zwp_data_control_manager_v1, zwp_xwayland_keyboard_grab_manager_v1,
zwp_input_popup_surface_v2.

**wlr-protocols:** zwlr_layer_shell_v1 (v4), zwlr_screencopy_manager_v1,
zwlr_export_dmabuf_manager_v1, zwlr_output_manager_v1,
zwlr_output_power_management_v1, zwlr_gamma_control_manager_v1,
zwlr_foreign_toplevel_manager_v1, zwlr_virtual_pointer_manager_v1,
zwlr_virtual_keyboard_manager_v1, xwayland_shell_v1.

## Recommendations

Prioritize physical **drm-lease-v1** qualification for directly connected VR
headsets; see the [validation checklist](drm-lease-v1-implementation-plan.md).
Consider experimental **xx-session-management-v1** for window-state restoration and
**ext-transient-seat-v1** for independent remote-desktop users. Session
management and transient seats require broader persistence/input work.

For gaming, prioritize physical commit-timing/FIFO presentation qualification,
including VRR, direct scanout, overlays, and tearing. Automated queue and
headless presentation tests pass; they do not establish physical display timing.

content-type-v1 was implemented in the content-type-v1 change: the protocol
global plus policy integration (visual-only `content_type` rule matcher,
auto-HDR game trigger, and aqueousctl exposure).

Missing dependency implementations can be added to Aqueous's pinned wlroots
patch series; upstream support is not a prerequisite. Legacy input inhibition
and superseded protocol versions should be driven by demonstrated client
compatibility needs rather than protocol-count completeness.

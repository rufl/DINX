# Window and layer rules (`rules.toml`)

Aqueous reads per-application placement rules from a sibling file to `wm.toml`:
`~/.config/aqueous/rules.toml`. The file is optional - if it's missing, rules
are simply disabled and Aqueous behaves identically to a release without the
feature.

See `rules.toml.example` at the repo root for a copy-pasteable template.

## Discovery order

The first hit wins:

1. `$AQUEOUS_RULES` environment variable (absolute path)
2. `[rules].path = "..."` in `wm.toml`
3. `$XDG_CONFIG_HOME/aqueous/rules.toml`
4. `~/.config/aqueous/rules.toml`

Categories 1 and 2 are returned verbatim even when the file doesn't exist (so
typos surface as a warning rather than silently disappearing). Categories 3
and 4 are only returned when the file is present on disk.

## Reload semantics

- Aqueous monitors `rules.toml` on the Wayland event loop. A changed file is
  parsed into a replacement snapshot. Every managed window and existing layer
  surface is re-evaluated without restarting the compositor.
- `Super+R` (the existing `reload_config` builtin) requests the same reload
  immediately for `wm.toml`, `layout.toml`, `input.toml`, and `rules.toml`.
- `reload_rules` is a standalone builtin verb that reloads **only** rules.toml.
  Default: unbound. Bind via:

  ```toml
  [keybinds]
  reload_rules = "Super+Shift+R"
  ```

- A parse error or missing file does not crash Aqueous. The previous rule list
  is kept and a single warn line is logged.

## Schema

### `[game_mode]`

Options for the `game-mode` layout engine. Only consulted when at least one
`[[window]]` rule below targets `layout = "game-mode"`.

| Key | Type | Default | Description |
| --- | --- | --- | --- |
| `remainder_layout` | string | `"grid"` | Layout used to tile non-anchor windows. Invoked once per non-empty side column with its own state. One of `tile`, `monocle`, `grid`, `rows`, `dwindle`, `reverse-dwindle`, `scrolling`, or `float`. |
| `gaps_inner` | int | `8` | Pixel gap between tiles inside each side column. |
| `fallback_layout` | string | `"grid"` | Layout used on outputs that have no anchor window. Accepts the same non-game-mode layouts as `remainder_layout`. |

### `[[window]]`

An array-of-tables, one entry per rule. First match wins; declaration order
matters.

| Key | Type | Required | Description |
| --- | --- | --- | --- |
| `app_id` | string (glob) | one of `app_id` / `class` / `title` / `tag` / `content_type` must be set | Match `xdg_toplevel.app_id`. |
| `class` | string (glob) | " | Match X11 `WM_CLASS` through Aqueous's native XWayland integration. |
| `title` | string (glob) | " | Match `xdg_toplevel.title`. |
| `tag` | string (glob) | " | Match the untranslated purpose supplied through `xdg-toplevel-tag-v1`. Native Wayland windows only; combine with `app_id` to scope a rule to one application. |
| `content_type` | string | " | Match the `wp_content_type_v1` state committed by the client: `none`, `photo`, `video`, or `game`. Rules with this matcher apply only visual/client-buffer settings (`blur`, `opacity`, `hdr_expand`, `buffer_scale_policy`, and `overlay_plane`); every layout and placement edit is ignored because the content type commonly arrives long after map and must never move an already-arranged window. |
| `layout` | string | no | Select a built-in layout, including `composable`; `"float"` also marks the window floating. Omitted leaves the workspace layout unchanged. Game mode requires explicit `"game-mode"` (or `"game_mode"`). |
| `floating` | bool | no | Force floating placement. |
| `scrolling_full_width` | bool | no | Set the initial scrolling column preset, equivalent to `Super+Shift+Z` when true. False starts with the preset disabled; unset leaves it alone. A rule using this field preserves the current layout when `layout` is omitted. |
| `scrolling_width` | number | no | Base scrolling column width as a finite fraction greater than `0` and at most `1` (`0.65` means 65%). Unset uses the global column fraction unless another member owns the column width. Preserves the current layout when `layout` is omitted. |
| `placement_policy` | string | no | Per-rule `cascade`, `center`, `under-pointer`, or `minimal-overlap` initial placement. |
| `stack_layer` | string | no | Place the window in the `below`, `normal`, or `above` semantic stack layer. |
| `focus` | bool | no | When false, exclude the window from compositor focus selection. |
| `fixed_position` | bool | no | Reject compositor pointer and keyboard geometry changes. |
| `skip_switcher` | bool | no | Exclude from MRU cycling and overview. |
| `skip_taskbar` | bool | no | Export a taskbar-suppression hint through the window-info state. |
| `output` | string | no | Open the window on the enabled output with this exact connector name, as reported by `aqueousctl outputs`. When `workspace` is omitted, the output's active workspace is used. |
| `workspace` | integer | no | Open the window on this 1-based workspace number. Without `output`, the window's normal admission output is used. |
| `width`, `height` | integer | no | Floating placement dimensions. |
| `x`, `y` | integer | no | Floating placement coordinates. |
| `anchor` | string | no (default `center`) | `center` / `top` / `bottom` / `left` / `right`. |
| `size` | string | no (default `"native"`) | `"native"` (use the client's requested buffer) / `"WxH"` (exact pixels) / `"FxF"` (fractions of the output's usable area, 0..1). |
| `scale` | double | no (default `1.0`) | Multiplied into the resolved size before clamping. |
| `fullscreen` | bool | no (default `false`) | Start the window fullscreen. Client fullscreen requests and manual toggles can override this property independently of output/workspace placement. |
| `buffer_scale_policy` | string | no | Override the global client-buffer policy with `"native"` or `"integer-ceil"`. Integer-ceil advertises the next integer scale before initial root/popup configures while retaining fractional logical geometry; it may improve toolkit text rasterization at the cost of larger buffers and more GPU/memory bandwidth. |
| `hdr_expand` | bool | no | Expand this window's SDR highlights toward the HDR peak when its output has `auto_hdr` enabled. When unset, fullscreen windows and windows that committed `content_type = "game"` are expanded. |
| `overlay_plane` | string | no (default `"off"`) | `"prefer"` requests promotion of this window's root buffer to the output's single DRM overlay layer. `[render].overlay_planes = true` must be enabled before startup. Promotion falls back to normal composition when TEST_ONLY rejects the complete state, when content overlaps the window, during capture/software-cursor forcing, or when scaling, transforms, effects, opacity, clipping, or buffer format constraints require composition. |

`output` and `workspace` form one initial-placement target. Either can be used
alone: output-only rules use the destination's active workspace, while
workspace-only rules retain the compositor's normal admission output. Rules do
not activate an inactive workspace. A missing or disabled output falls back to
normal admission placement and does not move the established window if the
output appears later. Manual workspace and output moves override the placement
rule until a different matcher becomes active.

While a rule owns placement, client fullscreen output hints preserve that
output and workspace, including inactive workspaces. Fullscreen entry and exit
still work normally. Once a manual move releases the placement claim, or no
available placement target is claimed, fullscreen output hints follow normal
compositor behavior.

For example, open Firefox with the full-width scrolling preset:

```toml
[[window]]
app_id = "firefox"
scrolling_full_width = true
```

The preset fills the scrolling instance's usable width, accounting for reserved
areas, outer gaps, borders, and client minimum sizes. Stacked members share the
column width. It works in nested scrolling layouts too, and has no sizing effect
in other layouts; it takes effect if the window later enters a scrolling layout.
`Super+Shift+Z`, horizontal pointer resizing, and size reset override the rule
until a different matcher becomes active. Vertical resizing preserves the preset.
Reloads update windows still owned by the rule; removing the field or matcher
restores their previous preset without undoing manual overrides. All rules
preserve the current layout when `layout` is omitted; an explicit `layout`
always takes precedence. Add the field to an existing matching rule if
one exists, since only the first matching rule applies.

To give an application a custom scrolling width:

```toml
[[window]]
app_id = "firefox"
scrolling_width = 0.65 # 65% of the scrolling viewport
```

The fraction describes the complete tile footprint, including borders, after
reserved areas and outer gaps. Inner gaps remain between columns. It affects
only width, respects client minimum sizes, and is recalculated when the usable
area changes. Nested scrolling layouts use their own region's width. Other
layouts retain their existing geometry.

An active full-width preset takes priority, followed by a manually resized
pixel width, then the custom fraction, then the global `column_fraction`.
Both rule fields may be set: toggling full width off reveals the custom base
width. Toggling a base fraction of `1.0` may make no visible difference.

Stacked members share the column width. The first eligible member supplies its
fraction until it leaves the column or its fraction is removed. Changing focus
or row order does not change that owner; merging preserves the destination
column's owner. An expelled window carries its own fraction into its new column.

Horizontal pointer resizing and size reset override fractional rules for every
current member of the column. Reset returns to the global column fraction.
Vertical resizing and full-width toggling preserve the custom base fraction.
Reloads update fractions still owned by a rule; removing a field or matcher
restores the previous fraction without undoing manual overrides. Manual overrides
survive edits to the same matcher until a different matcher becomes active.
Add `scrolling_width` to the first matching rule, or it will not take effect.

Older versions implicitly selected game mode for most rules with no `layout`.
To retain that behavior for a game, add `layout = "game-mode"` to its matching
rule. Visual-only and placement-only rules can now omit `layout`. The settings
editors' **Unset** layout option removes the field.

After an explicit game rule claims a workspace, closing the anchor or removing
its `layout` on reload leaves that workspace in game mode using `fallback_layout`.
Select a layout manually to release that existing claim. A rule without `layout`
does not create a new game-mode claim.

The global default is `[scaling].buffer_policy = "native"` in `wm.toml`.
`"integer-ceil"` is a compatibility path, not an application default. Aqueous
does not automatically enable it for Chromium, Electron, GTK, VSCodium, or
Shelly. Existing popups follow their owning window when the policy or output
scale changes, and newly created popups receive the preference before their
first configure. `scripts/aqueous-scalebench.py` measures the live-session
cost of the global policy against `native`.

### Window purpose tags

Applications supporting `xdg-toplevel-tag-v1` can identify purposes such as
`settings` independently of a changing title. Discover these with
`aqueousctl windows --json` or generate a rule using `aqueousctl inspect --rule`.
The settings rule editor exposes the same **Window tag** matcher.

```toml
[[window]]
app_id = "org.example.Editor"
tag = "settings"
floating = true
```

Tag matching is case-sensitive and combines with all other matchers in the
rule. `*` matches any sequence and `?` matches one byte; a backslash quotes the
next byte. For example, `tag = 'literal\*\?'` matches the exact tag `literal*?`.
Single-quoted TOML strings preserve backslashes; in double-quoted strings,
write `\\` for each backslash. `inspect --rule` handles both quoting layers.

An unset tag never matches, even with `tag = "*"`; `tag = ""` matches only an
explicitly empty tag. Multiple windows, including windows in different apps,
can share a tag. A tag change re-evaluates rules through the normal placement
and manual-override policy. Combining a tag with `content_type` still limits
the rule to visual settings. The translated `description` is display text and
is never a matcher. Metadata resets when a toplevel unmaps. Tags alone do not
save window geometry across application restarts, and untagged applications
continue to use the existing identity/title matchers.

### `[[layer]]`

An array-of-tables for layer-shell surfaces. First match wins and declaration
order matters.

| Key | Type | Required | Description |
| --- | --- | --- | --- |
| `namespace` | string (glob) | yes | Match the layer-shell namespace. |
| `blur` | bool | no (default `false`) | Blur the rectangular bounds of the main layer surface. |
| `blur_popups` | bool | no (default `false`) | When `blur` is also true, blur the rectangular bounds of every XDG popup and nested popup owned by the layer surface. |

Global backdrop blur must also be enabled under `[blur]` in `wm.toml`.
Rule-driven fallback blur uses rectangular bounds; pixel alpha is not a blur
mask. Clients using `ext-background-effect-v1`, including compatible DMS and
Quickshell versions, can instead supply exact regions. No matching layer rule
is required for native blur. A matching `blur = false` rule vetoes the request;
for layer popups, a matching rule must allow both `blur` and `blur_popups`.

Creating a background-effect object without setting a blur region leaves fallback
blur unchanged. An explicit, committed client mask, including an empty or null
mask, takes precedence over an enabled fallback rule. Destroying the effect
object restores fallback blur on the next surface commit. Requests are per
surface and do not automatically propagate to popups or subsurfaces. Global blur
disable always takes precedence.
The same client-mask precedence and explicit `blur = false` veto apply to
application windows. Native requests can also apply to fullscreen windows.

```toml
[[layer]]
namespace = "waybar"
blur = true
blur_popups = true
```

Run `aqueousctl scene` while the surface is mapped to discover its namespace;
layer roots are labeled `layer surface: NAMESPACE`. Layer-owned popup roots and
blur checkpoints are labeled `layer XDG popup` and
`layer popup backdrop blur marker`. Native checkpoints are labeled
`native background blur marker`.

## Game-mode layout pattern

Given a 2560x1440 monitor and a 1920x1080 game with `size = "native"`,
`anchor = "center"`:

```
+--------+--------------------------------+---------------+
|        |                                |               |
|  LEFT  |       ANCHOR (game)            |    RIGHT      |
| COLUMN |        1920 x 1080             |    COLUMN     |
|  320   |     centered at (320, 180)     |    320        |
| x1440  |                                |    x1440      |
|        |                                |               |
+--------+--------------------------------+---------------+
```

The space around the anchor is exposed as **two full-height side columns**:
the left column (from `usableArea.X` up to `anchorRect.X`) and the right
column (from `anchorRect.Right` up to `usableArea.Right`). Non-anchor windows
are partitioned across the two columns via stable round-robin over the
visible-window order (even index -> left, odd -> right), and `remainder_layout`
is invoked once per non-empty column with its own fresh instance. Top/bottom
strips above and below the anchor are intentionally unused. Column count is
fixed at 2 and is not configurable.

If the anchor is flush against an edge (e.g. `anchor = "left"`), the
corresponding side column collapses to zero width and all non-anchor windows
fall into the surviving column.

On a 7680x2160 monitor with a 3840x2160 centered anchor, top and bottom strips
have zero height (the anchor is full-height) and are unused; non-anchor windows
split round-robin between the left column `(0, 0, 1920, 2160)` and the right
column `(5760, 0, 1920, 2160)`.

## Deprecation: `[layout.options.game-mode]` in `wm.toml`

The early game-mode design put these options under `[layout.options.game-mode]`
in `wm.toml`. They have moved to `[game_mode]` in `rules.toml` so they can be
hot-reloaded independently of keybinds. The legacy location is detected at
parse time and produces a single warn log:

```
[layout.options.game-mode] in wm.toml is deprecated - game-mode options live
in rules.toml under [game_mode]. Values here are ignored. See docs/rules.md.
```

Two-release deprecation window - after which the warning becomes an error.

## Troubleshooting

- **Rule didn't apply.** Run `aqueousctl inspect --rule` for ready-to-paste
  matchers, or `aqueousctl windows --json` for the complete window snapshot.
  Wayland app IDs and XWayland classes are case-sensitive.
- **Layer rule didn't apply.** Run `aqueousctl scene` and use the namespace
  shown in the `layer surface: ...` label. Namespace globs are case-sensitive.
- **Anchor doesn't update when I edit `rules.toml`.** Check the compositor log
  for a parse warning, or press `Super+R` to request an immediate reload.
- **Game mode disappears when I close the game.** Expected - with no
  matching window on the output, `game-mode` falls through to
  `fallback_layout`.

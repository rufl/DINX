from __future__ import annotations

import logging
import os
import shlex
import time
from pathlib import Path
from typing import TYPE_CHECKING

from PyQt6.QtCore import Qt, QThread, QThreadPool, QTimer
from PyQt6.QtGui import QIcon, QKeySequence, QShortcut
from PyQt6.QtWidgets import (
    QApplication,
    QHBoxLayout,
    QMainWindow,
    QSizePolicy,
    QStackedWidget,
    QVBoxLayout,
    QWidget,
)

from .components.async_tools import BackgroundExecutor, pending_background_tasks
from .components.density import MANAGED_PROPERTY, apply_layout_density
from .components.modal_scrim import ModalScrim
from .components.sidebar import Sidebar
from .components.widgets import InfoDialog
from .console import ConsoleBeacon, ConsoleHost, ConsolePanel
from .core.alerts import SmartAlertMonitor
from .core.diagnostic_history import record_terminal_failure
from .core.gamepad import GamepadNavigationController
from .core.preferences import UiPreferences
from .core.state import state_cache_for
from .core.workflow_watch import WorkflowCompletionWatcher
from .i18n import (
    localize_top_levels,
    localize_widget_tree,
    normalize_language,
    set_language,
    tr,
    tr_format,
)
from .onboarding import (
    PERFORMANCE_VIEWS_FEATURE,
    TourGuide,
    WelcomeOverlay,
    feature_stops,
    first_run_pending,
    introduced_features,
    mark_features_introduced,
    mark_first_run_done,
    tour_stops,
)
from .theme import (
    application_stylesheet,
    apply_tooltip_palette,
    configure_theme,
    mode_of,
)

if TYPE_CHECKING:
    from .pages.settings import SettingsDialog


logger = logging.getLogger(__name__)


def _ui_perf_enabled() -> bool:
    return str(os.environ.get("BC250_UI_PERF", "")).strip().lower() in {"1", "true", "yes", "on"}


def _is_steamos_gamemode_session() -> bool:
    markers = {
        str(os.environ.get("XDG_CURRENT_DESKTOP", "")).strip().lower(),
        str(os.environ.get("XDG_SESSION_DESKTOP", "")).strip().lower(),
        str(os.environ.get("DESKTOP_SESSION", "")).strip().lower(),
    }
    if any("gamescope" in value for value in markers if value):
        return True
    if str(os.environ.get("GAMESCOPE_WAYLAND_DISPLAY", "")).strip():
        return True
    if str(os.environ.get("SteamGamepadUI", "")).strip() == "1":
        return True
    if str(os.environ.get("SteamTenfoot", "")).strip() == "1":
        return True
    return False


class ControlCenterWindow(QMainWindow):
    """Definitive BC250 interface backed by the application controller."""

    # How long a close request will wait for work it did not start itself, and
    # how long the final drain blocks once the window has decided to go.  Both
    # are generous next to a normal refresh (tens of milliseconds) and short
    # enough that a wedged backend cannot hold the window open.
    BACKGROUND_WAIT_MS = 4000
    BACKGROUND_DRAIN_MS = 3000

    def __init__(self, controller, *, settings_service=None, activity_service=None):
        super().__init__()
        self.controller = controller
        self.settings_service = settings_service
        self.activity_service = activity_service
        self.preferences = UiPreferences()
        self.settings = self.preferences.settings
        migration = self.preferences.initialize()
        self._background = BackgroundExecutor(self)
        self._state_cache = state_cache_for(
            controller,
            activity_service=activity_service,
            settings_service=settings_service,
        )
        self._gamemode_session = _is_steamos_gamemode_session()
        self._missing_backend_language = migration.missing_backend_language
        self._missing_backend_appearance = migration.missing_backend_appearance
        self._apply_language(str(self.settings.value("settings/language", "auto")), persist=False)
        self._apply_appearance(
            str(self.settings.value("settings/appearance", "system")),
            str(self.settings.value("settings/accent", "blue")),
            str(self.settings.value("settings/density", "comfortable")),
            persist=False,
        )

        self.setWindowTitle("BC250 Control Center")
        app_icon = Path(__file__).resolve().parents[2] / "assets" / "icons" / "bc250-control-center.png"
        if app_icon.exists():
            self.setWindowIcon(QIcon(str(app_icon)))
        self.resize(1460, 880)
        # 720×520 is the smallest useful shell. Below this point the pages still
        # remain intact through vertical scrolling, while the desktop window
        # manager retains a realistic resize target.
        self.setMinimumSize(720, 520)
        if self._gamemode_session:
            self.setWindowFlag(Qt.WindowType.FramelessWindowHint, True)

        root = QWidget()
        root.setObjectName("ApplicationRoot")
        layout = QHBoxLayout(root)
        self.root_layout = layout
        # Its margins already follow the density (see resizeEvent).
        layout.setProperty(MANAGED_PROPERTY, True)
        if self._gamemode_session:
            layout.setContentsMargins(8, 8, 8, 8)
            layout.setSpacing(10)
        else:
            layout.setContentsMargins(16, 16, 16, 16)
            layout.setSpacing(16)

        # The shell stacks the pages over the console, so the console spans the
        # full width the way a docked terminal does and the pages give up only
        # the height it actually occupies.
        shell = QWidget()
        shell.setObjectName("ApplicationShell")
        shell_layout = QVBoxLayout(shell)
        shell_layout.setContentsMargins(0, 0, 0, 0)
        shell_layout.setSpacing(0)
        shell_layout.addWidget(root, 1)
        self.setCentralWidget(shell)

        # Every page uses an 8 px top inset before its first visible card.
        # The sidebar and page cards share the same top alignment.
        self.sidebar_host = QWidget()
        self.sidebar_host.setObjectName("SidebarHost")
        self.sidebar_host.setMinimumWidth(0)
        self.sidebar_host.setSizePolicy(QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)
        sidebar_layout = QVBoxLayout(self.sidebar_host)
        sidebar_layout.setProperty(MANAGED_PROPERTY, True)
        sidebar_layout.setContentsMargins(0, 0 if self._gamemode_session else 8, 0, 0)
        sidebar_layout.setSpacing(0)

        self.sidebar = Sidebar()
        self.sidebar.navigation_requested.connect(self.navigate)
        collapsed = self.preferences.bool_value("sidebar_collapsed", False)
        self._sidebar_user_collapsed = collapsed
        self._sidebar_auto_collapsed = False
        self._sidebar_change_is_automatic = False
        self.sidebar.set_collapsed(collapsed)
        self.sidebar.collapsed_changed.connect(self._save_sidebar_state)
        sidebar_layout.addWidget(self.sidebar)
        layout.addWidget(self.sidebar_host)

        # Import modules only after the selected palette is configured. Their
        # existing functional widgets therefore keep the correct initial colors.
        from .pages.additional_settings import AdditionalSettingsPage
        from .pages.compute_units import ComputeUnitsPage
        from .pages.cpu_smu import CpuSmuPage
        from .pages.dashboard import DashboardPage
        from .pages.fans import FansPage
        from .pages.firmware import FirmwarePage
        from .pages.gpu_governor import GpuGovernorPage
        from .pages.performance import PerformancePage
        from .pages.processes import ProcessesPage

        self.stack = QStackedWidget()
        self.stack.setMinimumSize(0, 0)
        self.stack.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.dashboard = DashboardPage(controller)
        self.cpu_page = CpuSmuPage(
            controller,
            activity_service=activity_service,
            settings_service=settings_service,
        )
        self.gpu_page = GpuGovernorPage(controller, settings_service=settings_service)
        self.cu_page = ComputeUnitsPage(controller, activity_service=activity_service)
        self.extras_page = AdditionalSettingsPage(
            state_feed=lambda active: self.dashboard.feed_state(active)
        )
        self.fans_page = FansPage(
            controller,
            activity_service=activity_service,
            settings_service=settings_service,
        )
        self.fans_page.settings_requested.connect(self._open_settings_dialog)
        self.processes_page = ProcessesPage(
            controller,
            activity_service=activity_service,
        )
        self.performance_page = PerformancePage(controller)
        self.firmware_page = FirmwarePage(controller)
        self.settings_dialog: SettingsDialog | None = None
        self.current_page_key = "dashboard"
        self._gamepad_navigation_history: list[str] = []
        self._gamepad_suppress_history = False
        self.pages = {
            "dashboard": self.dashboard,
            "cpu": self.cpu_page,
            "gpu": self.gpu_page,
            "extras": self.extras_page,
            "cu": self.cu_page,
            "performance": self.performance_page,
            "fans": self.fans_page,
            "processes": self.processes_page,
            "firmware": self.firmware_page,
        }
        self.dashboard.module_requested.connect(self.navigate)
        self.dashboard.action_requested.connect(self._dashboard_action)
        self.dashboard.dependency_action_requested.connect(
            self._dashboard_dependency_action
        )
        self.dashboard.driver_support_requested.connect(
            self._dashboard_driver_support
        )
        self.dashboard.update_requested.connect(self.open_update_dialog)
        self.dashboard.state_applied.connect(self.extras_page.apply_state)
        self.extras_page.dependency_action_requested.connect(
            self._dashboard_dependency_action
        )
        self.extras_page.driver_support_requested.connect(
            self._dashboard_driver_support
        )
        for page in self.pages.values():
            self.stack.addWidget(page)
        layout.addWidget(self.stack, 1)

        self._build_console(shell_layout)
        # Installers and removals run in a terminal and return at once. Watch
        # for the end of each one so what they changed shows up then, not on
        # the next poll through two caches.
        self.workflow_watch = WorkflowCompletionWatcher(self)
        self.workflow_watch.finished.connect(self._workflow_finished)
        # Actions that run here (a game's files, a launch option, settings)
        # end when the page goes idle: read the tools again then.
        self.gpu_page.operation_busy_changed.connect(
            lambda busy: None if busy else self._tools_changed()
        )
        # Back from OptiScaler Client, Steam or a file manager: what they
        # changed shows at once instead of on the next poll.
        app = QApplication.instance()
        if app is not None:
            app.applicationStateChanged.connect(self._application_state_changed)
        self.workflow_watch.install()
        if getattr(self, "console", None) is not None:
            self.console.workflow_log_finished.connect(self.workflow_watch.embedded_finished)
        # Dims the window behind every modal dialog, so a white dialog over
        # white cards reads as the question it is (see modal_scrim.py).
        self.modal_scrim = ModalScrim(self)
        self._density_timer = QTimer(self)
        self._density_timer.setSingleShot(True)
        self._density_timer.setInterval(140)
        self._density_timer.timeout.connect(self._sync_current_page_layout)

        self.gamepad = GamepadNavigationController(self)
        self._follow_controller_into_the_console()
        self.alert_monitor = SmartAlertMonitor(
            controller,
            self.settings,
            activity_service=activity_service,
            parent=self,
        )
        self.alert_monitor.alert_triggered.connect(self._show_safety_alert)
        self._gamepad_navigation_enabled = self.preferences.bool_value("settings/gamepad_navigation", True)
        keypad_enabled = self.preferences.bool_value("settings/gamepad_onscreen_keypad", True)
        self.gamepad.set_onscreen_keypad_enabled(keypad_enabled)
        self.gamepad.set_onscreen_keypad_auto_show(keypad_enabled)
        self._set_detailed_diagnostics(self.preferences.bool_value("settings/detailed_diagnostics", False))
        self._set_gddr6_manual_override(
            self.preferences.bool_value("settings/gddr6_manual_override", False)
        )
        self._set_vrm_manual(self.preferences.bool_value("settings/vrm_manual", False))
        self._retranslate_interface()
        self._restore_start_page()
        self._migrate_backend_preferences_async()
        self._set_gamepad_navigation_enabled(self._gamepad_navigation_enabled)
        self.welcome: WelcomeOverlay | None = None
        self.tour: TourGuide | None = None
        self._first_run_pending = first_run_pending(self.settings)
        # Everything built after the first appearance pass (the sidebar, the
        # pages, the console) joins the chosen density here.
        apply_layout_density(self)

    def _build_console(self, shell_layout) -> None:
        """Attach the in-application terminal and offer it to the repositories.

        Every workflow keeps writing the same log and status files, so nothing
        that waits on a terminal result changes. When the console declines a
        workflow — because one is already running, or because the user turned
        it off — the repositories fall back to the desktop terminal emulators
        exactly as before.
        """
        self.console: ConsolePanel | None = None
        self.console_host: ConsoleHost | None = None
        try:
            panel = ConsolePanel(self)
        except Exception:
            logger.exception("The embedded console could not be created")
            return
        shell_layout.addWidget(panel)
        # Game Mode runs on a handheld panel where 280 px is a third of the
        # screen; the console still has to leave the page it covers usable.
        default_height = 200 if self._gamemode_session else 280
        panel.set_panel_height(self.preferences.int_value("console/height", default_height))
        # Off unless chosen: the output stays readable until the user closes it.
        panel.set_auto_hide(self.preferences.bool_value("settings/console_auto_hide", False))
        panel.external_terminal_requested.connect(self._open_workflow_in_terminal)
        panel.visibility_changed.connect(self._console_visibility_changed)
        self.console = panel

        # The way back to a console the user hid mid-workflow. It floats over
        # every page rather than living in one, so hiding the panel is no
        # longer a one-way door.
        self.console_beacon = ConsoleBeacon(self)
        self.console_beacon.clicked.connect(self._show_running_console)
        self._console_open = False
        panel.visibility_changed.connect(self._on_console_visibility)
        panel.workflow_finished.connect(lambda _code: self._sync_console_beacon())
        panel.workflow_started.connect(self._sync_console_beacon)
        panel.running_count_changed.connect(self.console_beacon.set_count)

        host = ConsoleHost(panel, self)
        host.set_enabled(self.preferences.bool_value("settings/embedded_terminal", True))
        host.install()
        self.console_host = host

        # F4 shows and hides the console the way it does Dolphin's terminal
        # panel. A window shortcut, so it works with the keyboard inside the
        # terminal grid too: the grid does not claim F4 as a shortcut
        # override, so Qt offers it to this shortcut before the key reaches
        # the shell.
        self.console_shortcut = QShortcut(QKeySequence(Qt.Key.Key_F4), self)
        self.console_shortcut.setContext(Qt.ShortcutContext.WindowShortcut)
        self.console_shortcut.activated.connect(self.toggle_console)

    def toggle_console(self) -> None:
        """F4: show or hide the embedded console."""
        console = getattr(self, "console", None)
        host = getattr(self, "console_host", None)
        if console is None or (host is not None and not host.enabled):
            return
        # The first-run panel and the tour own the screen while they are up.
        if self.is_presenting_overlay():
            return
        was_shown = console.shown
        console.toggle()
        if was_shown:
            # The grid keeps keyboard focus while it slides away; hand it back
            # to the page, the way Dolphin returns it to the file view.
            page = self.stack.currentWidget() if hasattr(self, "stack") else None
            if page is not None:
                page.setFocus(Qt.FocusReason.ShortcutFocusReason)
        self._sync_console_beacon()

    def _follow_controller_into_the_console(self) -> None:
        """Tell the console whether a controller is driving.

        The console is built before the navigation controller, because the
        pages it serves are built before both. So the connection is made here,
        after the controller exists, and primed with the current answer — a
        controller that was already plugged in when the window opened emits
        nothing to announce itself.
        """
        console = getattr(self, "console", None)
        if console is None:
            return
        self.gamepad.connection_changed.connect(
            lambda connected, _name: console.set_gamepad_present(connected)
        )
        console.set_gamepad_present(self.gamepad.connected)

    def _on_console_visibility(self, visible: bool) -> None:
        """Track the panel's intent, not its current animated height.

        ``is_open`` reads the widget's live height, and the slide is an
        animation: asking it the moment the signal fires still returns the
        height it is travelling away from, which had the beacon showing while
        the console was open and hiding the moment it closed.
        """
        self._console_open = bool(visible)
        self._sync_console_beacon()

    def _show_running_console(self) -> None:
        """Bring the hidden workflow back on screen."""
        if self.console is not None:
            self.console.slide_in()
        self._sync_console_beacon()

    def _sync_console_beacon(self) -> None:
        """Visible only while there is something to come back to."""
        beacon = getattr(self, "console_beacon", None)
        console = getattr(self, "console", None)
        if beacon is None:
            return
        if console is None:
            beacon.set_active(False)
            return
        beacon.set_active(bool(console.busy) and not self._console_open)
        beacon.set_count(console.running_count())

    def _console_visibility_changed(self, visible: bool) -> None:
        if not visible and self.console is not None:
            self.preferences.settings.setValue("console/height", self.console.panel_height())

    def set_embedded_terminal_enabled(self, enabled: bool) -> None:
        """Live switch between the docked console and a terminal window."""
        self.preferences.settings.setValue("settings/embedded_terminal", bool(enabled))
        if self.console_host is not None:
            self.console_host.set_enabled(bool(enabled))
        if not enabled and self.console is not None and not self.console.busy:
            self.console.slide_out()

    def set_console_auto_hide(self, enabled: bool) -> None:
        self.preferences.settings.setValue("settings/console_auto_hide", bool(enabled))
        if self.console is not None:
            self.console.set_auto_hide(bool(enabled))

    def _open_workflow_in_terminal(self, launch_path: str) -> None:
        """Re-open the running workflow's script in a real terminal window."""
        from bc250cc.infrastructure.terminal_plan import terminal_candidates
        from bc250cc.infrastructure.terminal_repository import TerminalRepository

        if not launch_path:
            return
        candidates = terminal_candidates(
            f"exec bash {shlex.quote(launch_path)}",
            "BC250 Control Center",
            terminal_env=os.environ.get("TERMINAL", ""),
            home=Path.home(),
        )
        terminal, _pid, _errors = TerminalRepository._launch_terminal_candidates(candidates)
        if not terminal:
            self._show_safety_alert(
                tr("Open terminal"),
                tr_format(
                    "No graphical terminal was found. Run it manually with: bash {path}",
                    path=launch_path,
                ),
                "warning",
            )

    def showEvent(self, event) -> None:  # noqa: N802 - Qt API name
        """Synchronize the active page after the window manager places it.

        KDE and some other Linux window managers can apply a restored or
        maximized geometry immediately after ``show()``.  Child scroll-area
        viewports settle one layout pass later, so perform one immediate and
        one short delayed synchronization.  The layout already starts in its
        desktop form, therefore these passes do not introduce a visible jump;
        they only prevent a stale compact mode from surviving first paint.
        """

        super().showEvent(event)
        if self._gamemode_session:
            QTimer.singleShot(0, self._apply_gamemode_window_mode)
        QTimer.singleShot(0, self._sync_current_page_layout)
        QTimer.singleShot(80, self._sync_current_page_layout)
        # getattr, because a window can be shown before this constructor has
        # run — a bare subclass in a test, or a shutdown path that only needs
        # the shell — and a missing attribute here would be an exception
        # raised inside a Qt event handler.
        if getattr(self, "_first_run_pending", False):
            # After the layout passes above, not before: the welcome screen is
            # a portrait of the window behind it, and a window that has not
            # been laid out yet has nothing to photograph.
            self._first_run_pending = False
            QTimer.singleShot(140, self.open_welcome)

    def _apply_gamemode_window_mode(self) -> None:
        if not self._gamemode_session:
            return
        screen = self.screen()
        if screen is None and self.windowHandle() is not None:
            screen = self.windowHandle().screen()
        if screen is not None:
            geometry = screen.availableGeometry()
            self.setGeometry(geometry)
        if not self.isFullScreen():
            self.showFullScreen()

    def _sync_current_page_layout(self) -> None:
        if not hasattr(self, "stack"):
            return
        page = self.stack.currentWidget()
        if page is None:
            return
        reflow = getattr(page, "_reflow", None)
        if callable(reflow):
            width = max(1, page.contentsRect().width())
            reflow(width)
        # A reflow may have set margins from code again; Compact re-tightens
        # them. In Comfortable this only undoes an earlier compact pass.
        apply_layout_density(page)
        page.updateGeometry()

    def _migrate_backend_preferences_async(self) -> None:
        if not (self._missing_backend_language or self._missing_backend_appearance):
            return

        def success(payload: object) -> None:
            local = payload if isinstance(payload, dict) else {}
            if self._missing_backend_language:
                language = normalize_language(local.get("idioma", "auto"))
                self.settings.setValue("settings/language", language)
                self._apply_language(language, persist=False)
                self._missing_backend_language = False
            if self._missing_backend_appearance:
                old_theme = str(local.get("tema", "system")).strip().lower()
                mode = old_theme if old_theme in {"light", "dark"} else "system"
                self.settings.setValue("settings/appearance", mode)
                self._apply_appearance(
                    mode,
                    str(self.settings.value("settings/accent", "blue")),
                    str(self.settings.value("settings/density", "comfortable")),
                    persist=False,
                )
                self._missing_backend_appearance = False

        self._background.start(
            "settings-migration",
            self._state_cache.config,
            success,
        )

    def _save_backend_preference(self, key: str, value: object) -> None:
        def operation() -> object:
            if self.settings_service is None:
                raise RuntimeError("Desktop requires a settings service to save preferences")
            self.settings_service.save_local_config({key: value})
            return True

        self._background.start(
            f"save-preference:{key}",
            operation,
            lambda _result: self._state_cache.invalidate("config"),
        )

    def _system_theme(self) -> str:
        app = QApplication.instance()
        if app is None:
            return "light"
        try:
            scheme = app.styleHints().colorScheme()
            if scheme == Qt.ColorScheme.Dark:
                return "dark"
            if scheme == Qt.ColorScheme.Light:
                return "light"
        except (AttributeError, RuntimeError):
            logger.debug("Qt did not expose the current platform color scheme", exc_info=True)
        try:
            return "dark" if app.palette().window().color().lightness() < 128 else "light"
        except Exception:
            return "light"

    # ------------------------------------------------------- first run

    def is_presenting_overlay(self) -> bool:
        """Whether something is covering the shell and must stay on top.

        Widgets that float themselves against a control — the update bubble —
        are children of this window too, and nothing in Qt stops them being
        drawn over a panel that is meant to be the only thing on screen. They
        ask this and wait.
        """
        welcome = getattr(self, "welcome", None)
        if welcome is not None and welcome.isVisible():
            return True
        tour = getattr(self, "tour", None)
        return tour is not None and tour.running


    def open_welcome(self) -> None:
        """Raise the first-run panel over the shell it is configuring."""
        if self.welcome is not None and self.welcome.isVisible():
            return
        shell = self.centralWidget()
        overlay = WelcomeOverlay(
            self,
            language=str(self.settings.value("settings/language", "auto")),
            mode=str(self.settings.value("settings/appearance", "system")),
            accent=str(self.settings.value("settings/accent", "blue")),
            density=str(self.settings.value("settings/density", "comfortable")),
            collapsed=self.sidebar.collapsed,
            system_mode=self._system_theme(),
            style=self.preferences.style(),
        )
        overlay.language_chosen.connect(self._welcome_language)
        overlay.appearance_chosen.connect(self._welcome_appearance)
        overlay.style_chosen.connect(self._welcome_style)
        overlay.sidebar_chosen.connect(self._welcome_sidebar)
        overlay.prepare_requested.connect(self._welcome_prepare)
        overlay.dependencies_reached.connect(self._welcome_tools_probe)
        overlay.preparation_completed.connect(self._welcome_tools_probe)
        overlay.finished.connect(self._welcome_finished)
        overlay.setGeometry(self.rect())
        overlay.set_backdrop_source(shell)
        self._clear_floating_widgets()
        self.welcome = overlay
        # The shell keeps its pixels — the glass is a photograph of it — but
        # stops taking input, so a keyboard cannot tab behind the panel into
        # controls that write to the hardware.
        if shell is not None:
            shell.setEnabled(False)
        overlay.reveal()

    def _clear_floating_widgets(self) -> None:
        """Take down anything already floating over the shell.

        The update bubble places itself against a control and stays there. It
        asks before appearing while a panel is up, but one that was already on
        screen when the panel opened has to be told.
        """
        for page in getattr(self, "pages", {}).values():
            dismiss = getattr(page, "dismiss_floating_callout", None)
            if callable(dismiss):
                dismiss()

    def _welcome_language(self, language: str) -> None:
        self._apply_language(language)
        if self.welcome is not None:
            self.welcome.retranslate()
            self.welcome.refresh_backdrop()

    def _welcome_appearance(self, mode: str, accent: str, density: str) -> None:
        self._apply_appearance(mode, accent, density)
        if self.welcome is not None:
            # The whole point of applying it live: the glass shows the choice.
            self.welcome.refresh_backdrop()

    def _welcome_style(self, style: str) -> None:
        self._apply_style(style)
        if self.welcome is not None:
            self.welcome.refresh_backdrop()

    def _apply_style(self, style: str) -> None:
        """Store the style and repaint with it, keeping theme and accent."""
        self.settings.setValue("settings/style", self.preferences.normalize_style(style))
        self._apply_appearance(
            str(self.settings.value("settings/appearance", "system")),
            str(self.settings.value("settings/accent", "blue")),
            str(self.settings.value("settings/density", "comfortable")),
            persist=False,
        )

    def _welcome_sidebar(self, collapsed: bool) -> None:
        self.sidebar.set_collapsed(bool(collapsed))
        if self.welcome is not None:
            self.welcome.refresh_backdrop()

    def _welcome_prepare(self) -> None:
        """Install the chosen components in the panel's own terminal.

        The work goes through the same call the dashboard uses; only the
        console it lands in changes. Pointing a host at the panel's terminal
        is the whole trick — there is no second way to start privileged work,
        and so no second place where the rules could drift.
        """
        overlay = self.welcome
        if overlay is None or overlay.preparing:
            return
        components = set(overlay.selected_components())
        if not components:
            return
        host = ConsoleHost(overlay.console, self)
        host.install()

        def restore() -> None:
            host.uninstall()
            if self.console_host is not None:
                self.console_host.install()

        def prepare() -> None:
            self.controller.instalar_dependencias_bc250(
                governor_preference=str(
                    self.settings.value("settings/gpu_governor", "auto")
                ),
                include_pwm="fan_pwm" in components,
                components=components,
            )

        def finished(_result) -> None:
            restore()
            if overlay is self.welcome and not overlay.preparing:
                # The call returned without a terminal ever opening. Say so
                # where the output would have been, rather than leaving a
                # button that looks like it did nothing.
                overlay.preparation_failed(tr("No workflow was started."))

        def failed(message: str) -> None:
            # A governor already running is the common one: the backend
            # refuses rather than stopping it behind the user's back, and
            # that decision belongs on the dashboard where it is explained.
            restore()
            if overlay is self.welcome:
                overlay.preparation_failed(str(message))

        overlay.preparation_starting()
        self._background.start(
            "first-run-dependencies", prepare, on_success=finished, on_error=failed
        )

    def _welcome_tools_probe(self) -> None:
        """Ask what is already installed, so the panel stops offering it."""
        overlay = self.welcome
        if overlay is None:
            return

        def read():
            return self.controller.estado_herramientas_bc250()

        def apply(result) -> None:
            if overlay is not self.welcome:
                return
            state = dict(result or {}) if isinstance(result, dict) else {}
            installed = {
                key for key, value in state.items()
                if isinstance(value, dict) and value.get("installed")
            }
            overlay.mark_installed_components(installed)

        self._background.start("first-run-tools", read, on_success=apply)

    def _welcome_finished(self, wants_tour: bool) -> None:
        overlay, self.welcome = self.welcome, None
        shell = self.centralWidget()
        if shell is not None:
            shell.setEnabled(True)
        if overlay is not None:
            if overlay.preparing and self.console is not None:
                # A package manager halfway through outlives the panel that
                # started it: the docked console adopts the session and the
                # floating button appears for it like any other workflow.
                transcript = overlay.console.view.screen.full_text()
                self.console.adopt_session(
                    overlay.console.release_session(),
                    title=tr("Prepare BC250 system"),
                    transcript=transcript,
                )
            overlay.deleteLater()
        mark_first_run_done(self.settings)
        if wants_tour:
            self.start_tour()
        else:
            self.dashboard.announce_pending_attention()

    # ------------------------------------------------------------ the tour

    def start_tour(self) -> None:
        """Walk the modules, pointing at the controls rather than describing them."""
        stops = tour_stops()
        # The whole route includes every feature's stops: none of them needs
        # introducing again afterwards.
        mark_features_introduced(self.settings, {stop.feature for stop in stops})
        self._run_tour(stops)

    def _run_tour(self, stops) -> None:
        if self.tour is not None and self.tour.running:
            return
        if self.tour is not None:
            self.tour.deleteLater()
        self._clear_floating_widgets()
        guide = TourGuide(self, stops, parent=self)
        guide.finished.connect(self._tour_finished)
        self.tour = guide
        guide.start()

    def _introduce_feature(self, feature: str, page_key: str) -> None:
        """The stops of a feature newer than this user's tour, shown once.

        Somebody who took the tour before the Performance page grew its
        per-part views and its sensor list would otherwise never learn they
        are there: nothing on the page says a tile opens a menu when pointed
        at.
        """
        if self.current_page_key != page_key or not self.isVisible():
            return
        if (self.tour is not None and self.tour.running) or self.is_presenting_overlay():
            return
        if QApplication.activeModalWidget() is not None:
            return
        if feature in introduced_features(self.settings):
            return
        stops = feature_stops(feature)
        if not stops:
            return
        mark_features_introduced(self.settings, {feature})
        self._run_tour(stops)

    def _tour_requested_from_settings(self) -> None:
        """Close the dialog first: the tour points at the window behind it."""
        dialog = getattr(self, "settings_dialog", None)
        if dialog is not None:
            dialog.close()
        QTimer.singleShot(0, self.start_tour)

    def _update_requested_from_settings(self) -> None:
        """Close the modal Settings first: the updater is a window of its own."""
        dialog = getattr(self, "settings_dialog", None)
        if dialog is not None:
            dialog.close()
        QTimer.singleShot(0, self.open_update_dialog)

    def _tour_finished(self) -> None:
        # The pages are live again the moment the spotlight is gone; nothing
        # was disabled for the tour, because the tour only ever navigated.
        self._sync_current_page_layout()
        # The notices held back while the tour pointed at the pages.
        self.dashboard.announce_pending_attention()

    def _apply_language(self, language: str, *, persist: bool = True) -> None:
        requested = normalize_language(language)
        resolved = set_language(requested)
        if persist:
            self.settings.setValue("settings/language", requested)
            self._save_backend_preference("idioma", resolved)
        if hasattr(self, "sidebar"):
            self._retranslate_interface()

    def _queue_appearance(self, mode: str, accent: str, density: str) -> None:
        """Let the chosen option paint first; of quick clicks, apply the last.

        Restyling the window takes over a second (2 500 widgets, one large
        style sheet), and doing it inside the click kept the option looking
        unselected until it finished, once per click.
        """
        self._pending_appearance = (mode, accent, density)
        timer = getattr(self, "_appearance_timer", None)
        if timer is None:
            timer = self._appearance_timer = QTimer(self)
            timer.setSingleShot(True)
            timer.setInterval(60)
            timer.timeout.connect(self._apply_pending_appearance)
        timer.start()

    def _apply_pending_appearance(self) -> None:
        pending = getattr(self, "_pending_appearance", None)
        self._pending_appearance = None
        if pending is not None:
            self._apply_appearance(*pending)

    def _persist_appearance(self, requested_mode: str, accent: str, density: str, resolved_mode: str) -> None:
        self.settings.setValue("settings/appearance", requested_mode)
        self.settings.setValue("settings/accent", accent)
        self.settings.setValue("settings/density", density)
        # The backend only knows light and dark; night blue is a dark theme.
        self._save_backend_preference("tema", mode_of(resolved_mode))

    def _apply_appearance(self, mode: str, accent: str, density: str, *, persist: bool = True) -> None:
        requested_mode = self.preferences.normalize_theme(mode)
        accent = self.preferences.normalize_accent(accent)
        density = self.preferences.normalize_density(density)
        resolved_mode = self._system_theme() if requested_mode == "system" else requested_mode
        scale = self.preferences.scale()
        style = self.preferences.style()
        # "System" that resolves to the theme already shown, or the same
        # choice picked again, changes nothing on screen: skip the restyle.
        signature = (resolved_mode, accent, density, scale, style)
        if signature == getattr(self, "_applied_appearance", None):
            if persist:
                self._persist_appearance(requested_mode, accent, density, resolved_mode)
            return
        self._applied_appearance = signature
        configure_theme(resolved_mode, accent, density, scale, style)
        apply_tooltip_palette()
        self.setStyleSheet(application_stylesheet())
        if hasattr(self, "root_layout"):
            margin = 12 if density == "compact" else 16
            self.root_layout.setContentsMargins(margin, margin, margin, margin)
            self.root_layout.setSpacing(12 if density == "compact" else 16)
        if hasattr(self, "sidebar_host"):
            sidebar_layout = self.sidebar_host.layout()
            if sidebar_layout is not None:
                sidebar_layout.setContentsMargins(0, 6 if density == "compact" else 8, 0, 0)
        if persist:
            self._persist_appearance(requested_mode, accent, density, resolved_mode)
        if hasattr(self, "sidebar"):
            self.sidebar.apply_appearance()
        if hasattr(self, "pages"):
            for page in self.pages.values():
                apply = getattr(page, "apply_appearance", None)
                if callable(apply):
                    apply()
        # Every layout of the window, visible or not: a page reached later
        # must already be in the density the user chose.
        apply_layout_density(self, density == "compact")
        settings_dialog = getattr(self, "settings_dialog", None)
        if settings_dialog is not None:
            settings_dialog.refresh_appearance()
        self._refresh_theme_aware_widgets()
        gamepad = getattr(self, "gamepad", None)
        if gamepad is not None:
            gamepad.refresh_appearance()


    def _apply_scale(self, scale: int) -> None:
        normalized = max(70, min(150, round(int(scale) / 10) * 10))
        self.settings.setValue("settings/scale", normalized)
        self._apply_appearance(
            str(self.settings.value("settings/appearance", "system")),
            str(self.settings.value("settings/accent", "blue")),
            str(self.settings.value("settings/density", "comfortable")),
            persist=False,
        )

    def _set_detailed_diagnostics(self, enabled: bool) -> None:
        enabled = bool(enabled)
        self.settings.setValue("settings/detailed_diagnostics", "true" if enabled else "false")
        for page in getattr(self, "pages", {}).values():
            setter = getattr(page, "set_detailed_diagnostics", None)
            if callable(setter):
                setter(enabled)

    def _show_safety_alert(self, title: str, message: str, level: str) -> None:
        tone = "red" if level == "critical" else "orange"
        InfoDialog(
            title,
            message,
            icon_name="warning_orange",
            parent=self,
            eyebrow="SAFETY ALERT",
            notice="This warning was recorded in local history. No hardware command was executed.",
            tone=tone,
        ).open()

    def _refresh_theme_aware_widgets(self) -> None:
        """Refresh widgets whose palette is stored in an inline stylesheet.

        The global QSS cannot override an inline background reliably.  Calling a
        small opt-in hook keeps badges, status pills, charts and value chips in
        sync after a live light/dark or accent switch without recreating pages.
        """
        root = self.centralWidget()
        if root is None:
            return
        for widget in (root, *root.findChildren(QWidget)):
            refresh = getattr(widget, "_refresh_palette", None)
            if callable(refresh):
                refresh()
        console = getattr(self, "console", None)
        if console is not None:
            # The terminal paints its own grid, so it reads the palette
            # directly instead of through the stylesheet.
            console.apply_theme()

    def _retranslate_interface(self) -> None:
        if hasattr(self, "sidebar"):
            self.sidebar.retranslate()
        localize_top_levels()
        # Most pages are made of literal labels and are covered by the shared
        # widget-tree pass.  A small number also render live formatted values
        # (for example fan duty presets and curve summaries); let those pages
        # rebuild their display-only copy after the language has changed.
        for page in getattr(self, "pages", {}).values():
            # Pages live inside the central stack and are not top-level Qt
            # widgets, so explicitly walk them on every live language change.
            localize_widget_tree(page)
            retranslate_dynamic_copy = getattr(page, "retranslate_dynamic_copy", None)
            if callable(retranslate_dynamic_copy):
                retranslate_dynamic_copy()
        gamepad = getattr(self, "gamepad", None)
        if gamepad is not None:
            gamepad.retranslate()
        console = getattr(self, "console", None)
        if console is not None:
            console.retranslate()

    def _restore_start_page(self) -> None:
        start = str(self.settings.value("settings/start_page", "dashboard"))
        if self.preferences.bool_value("settings/reopen_last_module", True):
            start = str(self.settings.value("settings/last_module", start))
        if start in self.pages:
            self.navigate(start)
        else:
            self.navigate("dashboard")
            if start == "settings":
                QTimer.singleShot(0, lambda: self._open_settings_dialog("general"))

    def _save_sidebar_state(self, collapsed: bool) -> None:
        if getattr(self, "_sidebar_change_is_automatic", False):
            return
        self._sidebar_user_collapsed = bool(collapsed)
        self.settings.setValue("sidebar_collapsed", "true" if collapsed else "false")

    def _set_sidebar_collapsed_automatically(self, collapsed: bool) -> None:
        if self.sidebar.collapsed == bool(collapsed):
            return
        self._sidebar_change_is_automatic = True
        try:
            self.sidebar.set_collapsed(bool(collapsed))
        finally:
            self._sidebar_change_is_automatic = False

    def resizeEvent(self, event) -> None:  # noqa: N802 - Qt API name
        super().resizeEvent(event)
        density_timer = getattr(self, "_density_timer", None)
        if density_timer is not None:
            # Pages reflow during the resize; tighten what they set once the
            # drag settles rather than on every intermediate size.
            density_timer.start()
        beacon = getattr(self, "console_beacon", None)
        if beacon is not None:
            beacon.reposition()
        welcome = getattr(self, "welcome", None)
        if welcome is not None:
            welcome.setGeometry(self.rect())
        tour = getattr(self, "tour", None)
        if tour is not None:
            tour.reposition()
        if not hasattr(self, "sidebar") or not hasattr(self, "root_layout"):
            return
        width = event.size().width()
        # Hysteresis avoids a visible open/close loop while the user drags near
        # the breakpoint. A manually collapsed sidebar always stays collapsed.
        if width < 900 and not self.sidebar.collapsed:
            self._sidebar_auto_collapsed = True
            self._set_sidebar_collapsed_automatically(True)
        elif width > 980 and self._sidebar_auto_collapsed:
            self._sidebar_auto_collapsed = False
            self._set_sidebar_collapsed_automatically(self._sidebar_user_collapsed)

        compact_shell = width < 820
        margin = 8 if compact_shell else 12 if self.preferences.normalize_density(
            str(self.settings.value("settings/density", "comfortable"))
        ) == "compact" else 16
        spacing = 8 if compact_shell else 12 if margin == 12 else 16
        self.root_layout.setContentsMargins(margin, margin, margin, margin)
        self.root_layout.setSpacing(spacing)

    @staticmethod
    def _set_page_updates(page: QWidget | None, active: bool) -> None:
        if page is None:
            return
        setter = getattr(page, "set_updates_active", None)
        if callable(setter):
            setter(bool(active))

    def _remember_current_module(self) -> None:
        """Persist the open module for the next launch, off the click path."""
        self.settings.setValue("settings/last_module", self.current_page_key)

    def navigate(self, key: str) -> None:
        started = time.perf_counter()
        if key in self.pages:
            page = self.pages[key]
            if key in self.sidebar.buttons:
                self.sidebar.buttons[key].setChecked(True)
            if key == self.current_page_key and self.stack.currentWidget() is page:
                self._set_page_updates(page, True)
                QTimer.singleShot(0, self._sync_current_page_layout)
                return
            previous = self.stack.currentWidget()
            previous_key = self.current_page_key
            if (
                not self._gamepad_suppress_history
                and previous_key in self.pages
                and previous_key != key
            ):
                if not self._gamepad_navigation_history or self._gamepad_navigation_history[-1] != previous_key:
                    self._gamepad_navigation_history.append(previous_key)
                    del self._gamepad_navigation_history[:-24]
            self._set_page_updates(previous, False)
            self.stack.setCurrentWidget(page)
            self.current_page_key = key
            # Remembering the module is for the *next* launch, so it has no
            # business inside the frame that has to paint the page the user
            # just clicked. Write it once the transition is on screen.
            QTimer.singleShot(0, self._remember_current_module)
            self._set_page_updates(page, True)
            if key == "performance" and not getattr(self, "_first_run_pending", False):
                QTimer.singleShot(
                    900, lambda: self._introduce_feature(PERFORMANCE_VIEWS_FEATURE, "performance")
                )
            # Hidden QStackedWidget pages may retain the geometry from their
            # construction pass.  Reflow only after the selected page owns the
            # real stack area, preserving desktop layouts on wide windows.
            QTimer.singleShot(0, self._sync_current_page_layout)
            gamepad = getattr(self, "gamepad", None)
            if gamepad is not None:
                gamepad.defer_focus_current_scope()
            if _ui_perf_enabled():
                QTimer.singleShot(
                    0,
                    lambda section=key, began=started: logger.info(
                        "UI PERF navigation %s painted in %.1f ms",
                        section,
                        (time.perf_counter() - began) * 1000.0,
                    ),
                )
            return

        if key in {"history", "settings"}:
            section = "reports" if key == "history" else "general"
            self._open_settings_dialog(section)
            return

        if key in self.sidebar.buttons:
            self.sidebar.buttons[key].setChecked(True)
        InfoDialog(
            "Module not available",
            "This module is not available in this installation.",
            icon_name="info_blue",
            parent=self,
            eyebrow="MODULE",
            button_text="Back to Dashboard",
            notice="No hardware command was executed.",
            tone="blue",
        ).exec()
        self.sidebar.buttons[self.current_page_key].setChecked(True)
        self.stack.setCurrentWidget(self.pages[self.current_page_key])

    def _open_settings_dialog(self, section: str = "general") -> None:
        previous_key = self.current_page_key if self.current_page_key in self.sidebar.buttons else "dashboard"
        previous_page = self.pages.get(previous_key)
        self._set_page_updates(previous_page, False)
        if "settings" in self.sidebar.buttons:
            self.sidebar.buttons["settings"].setChecked(True)
        if self.settings_dialog is None:
            # Settings is a large, rarely used module.  Import it on demand so
            # normal startup and page navigation do not parse/build its widget
            # graph before the user opens the dialog.
            from .pages.settings import SettingsDialog

            build_started = time.perf_counter()
            dialog = SettingsDialog(
                self.controller,
                settings_service=self.settings_service,
                activity_service=self.activity_service,
                app_settings=self.settings,
                parent=self,
            )
            if _ui_perf_enabled():
                logger.info(
                    "UI PERF settings dialog shell built in %.1f ms",
                    (time.perf_counter() - build_started) * 1000.0,
                )
            dialog.language_changed.connect(self._apply_language)
            dialog.appearance_changed.connect(self._queue_appearance)
            dialog.scale_changed.connect(self._apply_scale)
            dialog.smart_alerts_changed.connect(self.alert_monitor.set_enabled)
            dialog.diagnostics_changed.connect(self._set_detailed_diagnostics)
            dialog.sidebar_collapsed_changed.connect(self.sidebar.set_collapsed)
            dialog.gamepad_navigation_changed.connect(self._set_gamepad_navigation_enabled)
            dialog.report_glow_changed.connect(self.dashboard.footer.set_report_glow)
            dialog.gamepad_keypad_changed.connect(self.gamepad.set_onscreen_keypad_enabled)
            dialog.gamepad_keypad_auto_show_changed.connect(self.gamepad.set_onscreen_keypad_auto_show)
            dialog.embedded_terminal_changed.connect(self.set_embedded_terminal_enabled)
            dialog.console_auto_hide_changed.connect(self.set_console_auto_hide)
            dialog.gddr6_manual_changed.connect(self._set_gddr6_manual_override)
            dialog.vrm_manual_changed.connect(self._set_vrm_manual)
            dialog.tour_requested.connect(self._tour_requested_from_settings)
            dialog.update_requested.connect(self._update_requested_from_settings)
            self.settings_dialog = dialog
        dialog = self.settings_dialog
        dialog.select_section(section)
        dialog.exec()
        if previous_key in self.sidebar.buttons:
            self.sidebar.buttons[previous_key].setChecked(True)
        if previous_page is not None:
            self.stack.setCurrentWidget(previous_page)
            self._set_page_updates(previous_page, True)

    def gamepad_bottom_inset(self) -> int:
        """Height the controller legend must stay clear of at the bottom.

        The legend floats over the window at a fixed offset from its bottom
        edge. The console docks there too, so with a workflow running the
        legend sat on top of the answer row and covered the Send button — the
        one control a person needs at exactly that moment.
        """
        console = getattr(self, "console", None)
        if console is None or not console.is_open:
            return 0
        try:
            return max(0, console.height())
        except RuntimeError:
            return 0

    def gamepad_focus_scope(self) -> QWidget:
        """Return the active page as the preferred first-focus area."""
        console = getattr(self, "console", None)
        if console is not None and console.is_open:
            # A workflow on screen is the thing being waited on; entering the
            # page behind it would leave its prompt unreachable.
            scope = console.gamepad_focus_scope()
            if isinstance(scope, QWidget):
                return scope
        page = self.stack.currentWidget()
        provider = getattr(page, "gamepad_focus_scope", None)
        if callable(provider):
            scope = provider()
            if isinstance(scope, QWidget):
                return scope
        return page or self

    def gamepad_back(self) -> None:
        """Steam-style B behavior: visit history, then fall back to Dashboard."""
        console = getattr(self, "console", None)
        if console is not None and console.is_open and not console.busy:
            # In Game Mode there is no pointer, and the console's header
            # buttons are deliberately unfocusable so that typing reaches the
            # workflow instead of them. Without this, a workflow that failed —
            # which is exactly the one that stays on screen — could not be
            # dismissed with a controller at all. A workflow still running is
            # left alone: the panel is where it reports.
            console.slide_out()
            return
        page = self.stack.currentWidget()
        handler = getattr(page, "gamepad_back", None)
        if callable(handler) and bool(handler()):
            return
        target = self._gamepad_navigation_history.pop() if self._gamepad_navigation_history else "dashboard"
        if target == self.current_page_key:
            target = "dashboard"
        self._gamepad_suppress_history = True
        try:
            self.navigate(target if target in self.pages else "dashboard")
        finally:
            self._gamepad_suppress_history = False

    def gamepad_cycle_section(self, delta: int) -> None:
        """Walk the sidebar's modules with LB/RB, wrapping at either end.

        Only modules: Settings is a dialog with its own button (Menu), and a
        bumper that opened it on the way from Firmware back round to the
        Dashboard stopped the walk behind a modal. A module the sidebar is
        not showing is not a stop either.
        """
        order = [
            key for key, button in self.sidebar.buttons.items()
            if key in self.pages and not button.isHidden()
        ]
        if not order:
            return
        current = self.current_page_key if self.current_page_key in order else order[0]
        target = order[(order.index(current) + (1 if delta > 0 else -1)) % len(order)]
        self.navigate(target)

    def gamepad_toggle_sidebar(self) -> None:
        """Toggle the sidebar from the controller View/Select button."""
        if not hasattr(self, "sidebar"):
            return
        self._sidebar_auto_collapsed = False
        self.sidebar.set_collapsed(not self.sidebar.collapsed)

    def gamepad_open_settings(self) -> None:
        """Open Settings from the controller Menu/Start button."""
        self._open_settings_dialog("general")

    def gamepad_go_dashboard(self) -> None:
        """Jump directly to the Dashboard from the controller guide/home button."""
        if self.current_page_key != "dashboard":
            self.navigate("dashboard")
        else:
            gamepad = getattr(self, "gamepad", None)
            if gamepad is not None:
                gamepad.defer_focus_current_scope()

    def open_update_dialog(self) -> None:
        """What is new in the latest release, and the update to it."""
        from .components.update_dialog import UpdateDialog

        dialog = getattr(self, "update_dialog", None)
        # "Hide" during an install only hides the dialog. Opening a fresh one
        # then offered the same update again, and after a finished install
        # it would have downloaded and installed it a second time.
        resumable = getattr(dialog, "resumable", None)
        if dialog is not None and (dialog.isVisible() or (callable(resumable) and resumable())):
            dialog.show()
            dialog.raise_()
            dialog.activateWindow()
            return
        tools = dict(getattr(self.dashboard.state, "preparation_tools", {}) or {})
        dialog = UpdateDialog(
            self,
            source=getattr(self.dashboard, "_install_source", None),
            os_family=str(tools.get("os_family") or ""),
        )
        dialog.restart_requested.connect(self._restart_application)
        self.update_dialog = dialog
        dialog.show()
        dismiss = getattr(self.dashboard, "dismiss_floating_callout", None)
        if callable(dismiss):
            dismiss()

    def _restart_application(self) -> None:
        """Start the updated copy the way this one was started, then leave.

        The launcher runs ``python3 -m frontends.desktop.main`` from the
        installation folder, which is where the package manager has just put
        the new files. The new process waits a moment so this window has
        closed before the next one opens.
        """
        import sys

        from PyQt6.QtCore import QProcess

        arguments = list(getattr(sys, "orig_argv", [])[1:]) or list(sys.argv)
        started = QProcess.startDetached(
            "/bin/sh",
            ["-c", 'sleep 1; exec "$@"', "bc250-control-center-restart", sys.executable, *arguments],
            os.getcwd(),
        )
        if isinstance(started, tuple):
            started = started[0]
        if started:
            self.close()

    def _set_gddr6_manual_override(self, enabled: bool) -> None:
        """Settings › Telemetry: sample GDDR6 without the SMU channel check."""
        from .core.gddr6_monitor import gddr6_monitor_for

        gddr6_monitor_for(self.controller).set_manual_override(bool(enabled))

    def _set_vrm_manual(self, enabled: bool) -> None:
        """Settings › Telemetry: Power delivery rails shown even undetected."""
        dashboard = getattr(self, "pages", {}).get("dashboard")
        setter = getattr(dashboard, "set_vrm_manual", None)
        if callable(setter):
            setter(bool(enabled))

    def _set_gamepad_navigation_enabled(self, enabled: bool) -> None:
        self._gamepad_navigation_enabled = bool(enabled)
        if self._gamepad_navigation_enabled:
            self.gamepad.start()
        else:
            self.gamepad.stop()

    def _tools_changed(self) -> None:
        """The tools on disk changed: drop both caches and read them again."""
        invalidate = getattr(self.controller, "invalidar_estado_herramientas", None)
        if callable(invalidate):
            try:
                invalidate()
            except Exception:
                logger.debug("Could not reset the tool inventory cache", exc_info=True)
        self._state_cache.invalidate("tools")
        self.dashboard.refresh_now()

    def _application_state_changed(self, state) -> None:
        if state != Qt.ApplicationState.ApplicationActive:
            return
        # Only the pages that show the tools inventory.
        if self.stack.currentWidget() in (self.dashboard, getattr(self, "extras_page", None)):
            self._tools_changed()

    def _workflow_finished(self, result: object, code: int) -> None:
        """A terminal workflow ended: whatever it installed or removed is real now."""
        record_terminal_failure(result, code)
        invalidate = getattr(self.controller, "invalidar_estado_herramientas", None)
        if callable(invalidate):
            try:
                invalidate()
            except Exception:
                logger.debug("Could not reset the tool inventory cache", exc_info=True)
        self._state_cache.invalidate()
        self.dashboard.refresh_now()
        page = self.stack.currentWidget()
        refresh = getattr(page, "refresh", None)
        if page is not self.dashboard and callable(refresh):
            refresh()

    #: Links an accessory card opens, and its program's name in dialogs.
    _ACCESSORY_LINKS = {
        "thermalright": ("https://github.com/Lexonight1/thermalright-trcc-linux", "TRCC Linux"),
        "corsair": ("https://github.com/jurkovic-nikola/OpenLinkHub", "OpenLinkHub"),
    }

    def _dashboard_accessory(self, accessory: str, operation: str) -> None:
        """A case accessory card: install, remove, configure or read about it."""
        from .components.page_widgets import ConfirmDialog
        from .core.external_links import open_external_url

        if accessory not in self._ACCESSORY_LINKS:
            return
        upstream, program = self._ACCESSORY_LINKS[accessory]
        try:
            if operation == "upstream":
                open_external_url(upstream)
            elif operation == "configure" and accessory == "corsair":
                from bc250cc.infrastructure.accessories.openlinkhub import PANEL_URL

                open_external_url(PANEL_URL)
            elif operation == "configure":
                from PyQt6.QtCore import QProcess

                argv = self.controller.accessory_configure_argv(accessory)
                if not QProcess.startDetached(argv[0], argv[1:]):
                    raise RuntimeError(tr_format("{program} could not be started.", program=program))
            elif operation == "install":
                self.controller.manage_accessory(accessory, "install")
            elif operation == "remove":
                # Removing takes the program away; the owner's own themes and
                # profiles stay, which the dialog says.
                dialog = ConfirmDialog(
                    tr_format("Remove {program}?", program=program),
                    "The program and the service Control Center set up for it are removed. "
                    "Your own themes and profiles are kept.",
                    confirm_text="Remove",
                    tone="orange",
                    parent=self,
                )
                if dialog.exec() == dialog.DialogCode.Accepted:
                    self.controller.manage_accessory(accessory, "remove")
        except (AttributeError, OSError, RuntimeError, TypeError, ValueError) as error:
            InfoDialog(
                "Support unavailable",
                str(error),
                icon_name="warning_orange",
                parent=self,
                eyebrow="Hardware",
                notice="No changes were made.",
                tone="orange",
            ).open()

    def closeEvent(self, event) -> None:  # noqa: N802 - Qt API name
        gamepad = getattr(self, "gamepad", None)
        if gamepad is not None:
            gamepad.stop()

        console = getattr(self, "console", None)
        if console is not None and console.busy and not getattr(self, "_close_pending", False):
            # A privileged workflow is mid-flight. Closing the window would
            # kill it between two system changes, which is the worst moment.
            if not self._confirm_closing_a_running_workflow():
                event.ignore()
                return

        # A USB drive being erased or written must not be abandoned halfway:
        # it would be neither what it was nor a working update kit.
        firmware_page = getattr(self, "firmware_page", None)
        if firmware_page is not None:
            blocker = firmware_page.close_blocker()
            if blocker:
                from .pages.firmware import confirm_close_while_writing

                confirm_close_while_writing(self, blocker)
                event.ignore()
                return
            firmware_page.stop_for_close()

        # Committed to closing: a recorder that keeps sampling would keep a
        # backend read in flight and make the wait below run to its deadline.
        performance_page = getattr(self, "performance_page", None)
        if performance_page is not None:
            performance_page.stop_recording()

        outstanding = self._outstanding_background_work()
        if outstanding and not self._waited_long_enough_to_close():
            event.ignore()
            if not getattr(self, "_close_pending", False):
                self._close_pending = True
                logger.info("Waiting for %s before closing", outstanding)
                QTimer.singleShot(50, self._close_when_idle)
            return

        self._close_pending = False
        host = getattr(self, "console_host", None)
        if host is not None:
            host.uninstall()
        watch = getattr(self, "workflow_watch", None)
        if watch is not None:
            watch.uninstall()
        if console is not None:
            console.shutdown()
        # Last chance to let a pool worker leave ``operation()`` while Python is
        # still alive.  Past this point the interpreter starts finalizing, and a
        # worker that calls back into it aborts the whole process.
        QThreadPool.globalInstance().waitForDone(self.BACKGROUND_DRAIN_MS)
        super().closeEvent(event)

    def _confirm_closing_a_running_workflow(self) -> bool:
        from PyQt6.QtWidgets import QMessageBox

        answer = QMessageBox.question(
            self,
            tr("Terminal"),
            tr("A workflow is still running in the terminal. Closing now stops it."),
            QMessageBox.StandardButton.Cancel | QMessageBox.StandardButton.Close,
            QMessageBox.StandardButton.Cancel,
        )
        return answer == QMessageBox.StandardButton.Close

    def _outstanding_background_work(self) -> str:
        """Describe what is still running, or return an empty string.

        Two different mechanisms do work off the GUI thread and only one of
        them is reachable from the widget tree.  The gamepad monitor is a
        ``QThread`` child, so ``findChildren`` finds it; every page refresh is a
        ``QRunnable`` on the global pool, whose worker threads are owned by Qt
        and parented to nothing.  Looking only at ``QThread`` children — which
        is what this did — meant the window never waited for a single backend
        read, and closing during one aborted the process on the way out.
        """
        threads = [thread for thread in self.findChildren(QThread) if thread.isRunning()]
        reads = pending_background_tasks()
        parts = []
        if threads:
            parts.append(f"{len(threads)} monitor thread(s)")
        if reads:
            parts.append(f"{reads} backend read(s)")
        return " and ".join(parts)

    def _waited_long_enough_to_close(self) -> bool:
        """A wait with no deadline is a window that will not close.

        A backend read can block on hardware that never answers.  After this
        long the close proceeds and the bounded drain below absorbs whatever is
        left.
        """
        started = getattr(self, "_close_requested_at", None)
        if started is None:
            self._close_requested_at = time.monotonic()
            return False
        return (time.monotonic() - started) * 1000.0 >= self.BACKGROUND_WAIT_MS

    def _close_when_idle(self) -> None:
        if self._outstanding_background_work() and not self._waited_long_enough_to_close():
            QTimer.singleShot(50, self._close_when_idle)
            return
        self.close()

    def _dashboard_action(self, action: str) -> None:
        if action == "telemetry_settings":
            self._open_settings_dialog("telemetry")
            return
        if action in {"cpu_configuration", "cpu_overview"}:
            self.navigate("cpu")
            self.cpu_page._select_workspace(action.removeprefix("cpu_"))
            return
        if action in {"fans_manual", "fans_curve"}:
            self.navigate("fans")
            self.fans_page._set_control_mode(action.removeprefix("fans_"))
            self.fans_page.scroll.verticalScrollBar().setValue(0)
            return
        if action == "repositories":
            from .pages.settings import RepositoriesDialog

            RepositoriesDialog(self).exec()
            return
        if action == "apply_profile":
            self.navigate("cpu")
            return
        if action == "prepare_pwm":
            # Dashboard quick actions execute their workflow in place.  The
            # Fans page owns the validated confirmation and asynchronous
            # terminal launcher, but it does not need to become visible.
            self.fans_page.prepare_pwm_driver(dialog_parent=self)
            return
        if action == "open_logs":
            self._open_settings_dialog("reports")
            return
        if action != "prepare_dependencies":
            return
        # Keep the Dashboard selected while reusing the governor page's
        # conflict-aware dependency preparation dialog and terminal workflow.
        # The shared Dashboard refresh already warmed this cache; forwarding
        # it prevents a never-opened GPU page from missing conflict detection.
        try:
            cached_tools = dict(self._state_cache.tools() or {})
        except (AttributeError, OSError, RuntimeError, TypeError, ValueError):
            cached_tools = {}
        if cached_tools:
            self.gpu_page.current_state = {
                **dict(getattr(self.gpu_page, "current_state", {}) or {}),
                "tools": cached_tools,
            }
        self.gpu_page.prepare_dependencies(dialog_parent=self)

    def _dashboard_dependency_action(self, request: object) -> None:
        """Run the compact sidebar selection through the governor safety flow."""
        payload = dict(request) if isinstance(request, dict) else {}
        try:
            cached_tools = dict(self._state_cache.tools() or {})
        except (AttributeError, OSError, RuntimeError, TypeError, ValueError):
            cached_tools = {}
        if cached_tools:
            self.gpu_page.current_state = {
                **dict(getattr(self.gpu_page, "current_state", {}) or {}),
                "tools": cached_tools,
            }
        options = {
            "action": str(payload.get("action") or "prepare"),
            "preference": str(payload.get("governor") or "auto"),
            "selected_components": set(payload.get("selected_components") or ()),
            "dialog_parent": self,
        }
        if options["action"] in {"memory_swap", "memory_ttm"}:
            options.update(
                memory_policy=str(payload.get("memory_policy") or "current"),
                memory_ttm_gib=int(payload.get("memory_ttm_gib") or 0),
                memory_takeover_zram=bool(payload.get("memory_takeover_zram")),
                memory_target_mount=str(payload.get("memory_target_mount") or ""),
            )
        elif options["action"] == "vram_apply":
            options.update(vram_uma_size_mb=int(payload.get("vram_uma_size_mb") or 0))
        elif options["action"] == "kernel_options_set":
            options.update(
                kernel_options=tuple(str(item) for item in payload.get("kernel_options") or ()),
                kernel_option_changed=str(payload.get("kernel_option_changed") or ""),
            )
        elif options["action"] == "helixsr_settings":
            settings = payload.get("helixsr_settings")
            options.update(helixsr_settings=dict(settings) if isinstance(settings, dict) else {})
        self.gpu_page.execute_dependency_action(
            **options,
        )

    def _dashboard_driver_support(self, component: str) -> None:
        """Launch a reviewed distribution-native support route from Dashboard."""
        if ":" in component:
            self._dashboard_accessory(*component.split(":", 1))
            return
        if component not in {"connectivity", "printing"}:
            return
        try:
            self.controller.install_driver_support(component)
        except (AttributeError, OSError, RuntimeError, TypeError, ValueError) as error:
            InfoDialog(
                "Support unavailable",
                str(error),
                icon_name="warning_orange",
                parent=self,
                eyebrow="Hardware",
                notice="No changes were made.",
                tone="orange",
            ).open()

"""Shared option/capability mapping for embedded and legacy preparation UI."""

import os

from bc250cc.infrastructure.memory_runtime import (
    TTM_GIB_PRESETS,
    supported_ttm_gib_presets,
)
from bc250cc.shared.contract import (
    VRAM_SIZE_PRESETS_MB,  # noqa: F401 - re-exported to the dashboard
)

from ..i18n import tr, tr_format

MEMORY_OPTIONS = (
    ("Keep current configuration", "preserve"),
    ("Disk swap · 16 GiB", "swap-16"),
    ("Disk swap · 32 GiB", "swap-32"),
    ("ZRAM · up to 4 GiB", "zram"),
    ("Advanced · ZSWAP + 16 GiB swapfile", "zswap-16"),
    ("Advanced heavy loads · ZSWAP + 32 GiB swapfile", "zswap-32"),
    ("Restore BC250 memory changes", "restore"),
)

BAZZITE_MEMORY_OPTIONS = (
    ("Keep Bazzite default (ZRAM)", "current"),
    ("Recommended · ZRAM + 16 GiB emergency swap", "zram-swap-16"),
    ("Advanced · ZSWAP + 16 GiB swapfile", "zswap-16"),
    ("Advanced heavy loads · ZSWAP + 32 GiB swapfile", "zswap-32"),
)

#: SteamOS (beta). Its own half-RAM zstd ZRAM stays the default; the emergency
#: swapfile sits behind it, and ZSWAP replaces it after one reboot. The
#: swapfile goes on /home, as keyboardspecialist/bc250-steamos does.
STEAMOS_MEMORY_OPTIONS = (
    ("Keep current configuration", "preserve"),
    ("Recommended · ZRAM + 16 GiB emergency swap", "swap-16"),
    ("Advanced · ZSWAP + 16 GiB swapfile", "zswap-16"),
    ("Advanced heavy loads · ZSWAP + 32 GiB swapfile", "zswap-32"),
    ("Restore BC250 memory changes", "restore"),
)

GIB = 1024 ** 3


def ttm_state_text(ttm) -> str:
    """One line for the TTM card, from the helper's shared ``ttm`` state.

    The same state the Decky panel shows, so both say the same thing.
    """
    if not isinstance(ttm, dict) or not ttm:
        return ""
    if not ttm.get("supported"):
        return tr(str(ttm.get("reason") or ""))
    page = ttm.get("page_size") if type(ttm.get("page_size")) is int and ttm.get("page_size") > 0 else 4096
    configured = ttm.get("configured_pages")
    if type(configured) is int:
        parts = [tr_format("Next boot: {value}", value=f"{round(configured * page / GIB, 1):g} GiB")]
    else:
        parts = [tr("Kernel default (no BC250 limit set)")]
    if ttm.get("external"):
        parts.append(tr("Set outside Control Center"))
    if ttm.get("gtt_override") is not None:
        parts.append(tr("amdgpu.gttsize overrides this limit"))
    if ttm.get("reboot_required"):
        parts.append(tr("Reboot required"))
    return " · ".join(parts)


def _apply_ttm_capability(owner, ttm, *, restore_always: bool) -> None:
    """Offer only the limits the next boot has room for, and restore only ours.

    ``restore_always`` leaves the restore entry to the caller (GitHub issue
    #14 keeps it selectable on Bazzite).
    """
    if not isinstance(ttm, dict) or not ttm:
        return
    combo = owner.ttm_limit_combo
    presets = ttm.get("presets_gib")
    allowed = set(presets) if isinstance(presets, list) else None
    for index in range(combo.count()):
        value = combo.itemData(index)
        if type(value) is int and value > 0 and allowed is not None:
            combo.model().item(index).setEnabled(value in allowed)
    if not restore_always:
        combo.model().item(1).setEnabled(bool(ttm.get("managed") or ttm.get("legacy_pages") is not None))
    if hasattr(owner, "memory_ttm_state"):
        owner.memory_ttm_state.setText(ttm_state_text(ttm))


def vram_size_label(size_mb: int) -> str:
    if size_mb < 1024:
        return tr_format("{size} MiB", size=size_mb)
    return tr_format("{size} GiB", size=size_mb // 1024)


def is_bazzite_host(tools) -> bool:
    """Recognize Bazzite even when a partial inventory lacks its family key."""
    return any(
        "bazzite" in str(tools.get(key) or "").strip().lower()
        for key in ("os_family", "os_id", "os_label", "os_variant", "image_id")
    )


def is_steamos_host(tools) -> bool:
    """SteamOS, from the inventory or from the helper's own answer."""
    memory = ((tools.get("system_setup") or {}).get("memory") or {})
    return bool(memory.get("steamos")) or any(
        "steamos" in str(tools.get(key) or "").strip().lower()
        for key in ("os_family", "os_id")
    )


def bazzite_ui_preview_enabled(environ=None) -> bool:
    """Allow an inert Bazzite card preview on a development workstation."""
    source = os.environ if environ is None else environ
    return str(source.get("BC250_BAZZITE_UI_PREVIEW") or "").strip().lower() in {
        "1",
        "true",
        "yes",
        "on",
    }


def _restore_bazzite_memory_options(owner, tools) -> None:
    combo = owner.memory_policy_combo
    expected = [value for _label, value in BAZZITE_MEMORY_OPTIONS]
    if [combo.itemData(index) for index in range(combo.count())] != expected:
        previous = combo.currentData()
        combo.blockSignals(True)
        combo.clear()
        for label, value in BAZZITE_MEMORY_OPTIONS:
            combo.addItem(tr(label), value)
        combo.setCurrentIndex(max(0, combo.findData(previous)))
        combo.blockSignals(False)
    ttm_combo = owner.ttm_limit_combo
    state = tools.get("memory_runtime") or {}
    physical = state.get("physical_ram_bytes")
    supported = (
        supported_ttm_gib_presets(physical)
        if type(physical) is int and physical > 0
        else TTM_GIB_PRESETS
    )
    expected_ttm = [0, -1, *supported]
    if [ttm_combo.itemData(index) for index in range(ttm_combo.count())] != expected_ttm:
        previous = ttm_combo.currentData()
        ttm_combo.blockSignals(True)
        ttm_combo.clear()
        ttm_combo.addItem(tr("Keep current TTM limit"), 0)
        ttm_combo.addItem(tr("Kernel default (remove BC250 TTM limit)"), -1)
        for target in supported:
            ttm_combo.addItem(
                tr_format("Limit GPU allocations to {size} GiB", size=target),
                target,
            )
        selected = ttm_combo.findData(previous)
        ttm_combo.setCurrentIndex(selected if selected >= 0 else 0)
        ttm_combo.blockSignals(False)
    else:
        ttm_combo.setItemText(1, tr("Kernel default (remove BC250 TTM limit)"))
    # GitHub issue #14. The generic adapter greys this entry out until it has
    # a TTM change of its own to undo, and a refresh that ran before the
    # inventory had identified Bazzite left it greyed: the item list here is
    # the same, so it was never rebuilt, and the option stayed unavailable
    # until the application restarted. On Bazzite it is always selectable —
    # the workflow restores only the argument it recorded and otherwise
    # reports that nothing of its own exists.
    ttm_combo.model().item(1).setEnabled(True)
    _apply_ttm_capability(owner, (tools.get("system_setup") or {}).get("ttm"), restore_always=True)

    if type(physical) is int and physical > 0:
        visible_gib = physical / (1024 ** 3)
        ttm_combo.setToolTip(
            tr(
                "TTM limits managed GPU pages; it is not a guaranteed VRAM reservation."
            )
            + f"\nMemTotal: {visible_gib:.1f} GiB"
        )


def update_memory_controls(owner, tools):
    """Return False only for the existing independent Bazzite workflow."""
    # The dashboard can display Bazzite from OS_LABEL before a background
    # inventory has filled OS_FAMILY.  Treat that label as authoritative for
    # this Bazzite-only workflow, then restore its choices if an earlier
    # partial refresh had replaced them with the disabled generic list.
    if is_bazzite_host(tools):
        _restore_bazzite_memory_options(owner, tools)
        return False
    setup = tools.get("system_setup") or {}
    memory = setup.get("memory") or {}
    steamos = is_steamos_host(tools)
    options = STEAMOS_MEMORY_OPTIONS if steamos else MEMORY_OPTIONS
    combo = owner.memory_policy_combo
    existing = [combo.itemData(i) for i in range(combo.count())]
    if existing != [value for _, value in options]:
        previous = combo.currentData()
        combo.blockSignals(True)
        combo.clear()
        for label, value in options:
            combo.addItem(tr(label), value)
        combo.setCurrentIndex(max(0, combo.findData(previous)))
        combo.blockSignals(False)
    enabled = bool(setup.get("helper_available") and memory.get("supported"))
    policies = memory.get("policies") or []
    policy_reasons = dict(memory.get("policy_reasons") or {})
    takeover_available = bool(memory.get("zram_takeover_available"))
    # A ZSWAP option blocked only by a foreign ZRAM stays selectable: picking
    # it is how the user confirms disabling that ZRAM, same as Bazzite
    # already lets every option through.
    selectable = set(policies) | ({"zswap-16", "zswap-32"} if takeover_available else set())
    # With a policy in place, only what the helper can reach from it is
    # offered: restore, the same policy again, or the same swapfile with or
    # without ZSWAP in front of it. Anything else used to be selectable and
    # then refused at apply time.
    configured = str(memory.get("configured_policy") or "preserve")
    if configured not in {"preserve", "restore"} and memory.get("phase") == "configured":
        reachable = {"preserve", "restore", configured, *(memory.get("direct_switches") or [])}
        for value in selectable - reachable:
            policy_reasons[value] = "Restore the current BC250 memory policy before choosing another"
        selectable &= reachable
    for i in range(combo.count()):
        item = combo.model().item(i)
        value = combo.itemData(i)
        item.setEnabled(value in selectable)
        item.setToolTip(tr(str(policy_reasons.get(value) or "")))
    combo.setEnabled(enabled)
    owner.ttm_limit_combo.setItemText(1, tr("Restore previous TTM limit"))
    # The limit is a boot argument kept by system_setup_ttm.py, shared with the
    # Decky panel; an older helper only reports the memory module's fields.
    ttm = setup.get("ttm") if isinstance(setup.get("ttm"), dict) else {}
    ttm_enabled = bool(setup.get("helper_available")) and bool(
        ttm.get("supported") if ttm else memory.get("ttm_available")
    )
    restorable = bool(memory.get("ttm_restore_available")) or bool(ttm.get("managed"))
    owner.ttm_limit_combo.setEnabled(ttm_enabled)
    _apply_ttm_capability(owner, ttm, restore_always=True)
    owner.ttm_limit_combo.model().item(1).setEnabled(restorable)
    selected_policy = combo.currentData()
    needs_takeover = takeover_available and selected_policy in {"zswap-16", "zswap-32"} and selected_policy not in policies
    owner.memory_swap_apply_button.setEnabled(enabled and selected_policy in selectable and selected_policy != "preserve")
    if hasattr(owner, "memory_zram_warning_frame"):
        owner.memory_zram_warning.setText(
            tr("Applying this will disable the existing ZRAM to make room for ZSWAP. "
               "Takes effect after the next reboot.")
            if needs_takeover else ""
        )
        owner.memory_zram_warning_frame.setVisible(needs_takeover)
    if hasattr(owner, "memory_swap_usage_bar"):
        used = int(memory.get("swap_used_bytes") or 0)
        gib_suffix = str(memory.get("configured_policy") or "").rsplit("-", 1)
        total_gib = int(gib_suffix[-1]) if len(gib_suffix) == 2 and gib_suffix[-1].isdigit() else 0
        total = total_gib * (1024 ** 3)
        active = bool(memory.get("swap_active")) and total > 0
        owner.memory_swap_usage_bar.setVisible(active)
        owner.memory_swap_usage_label.setVisible(active)
        if active:
            percent = min(100, round(used / total * 100))
            owner.memory_swap_usage_bar.setValue(percent)
            owner.memory_swap_usage_label.setText(
                tr_format("{used} / {total} GiB used", used=round(used / (1024 ** 3), 1), total=total_gib)
            )
    if hasattr(owner, "memory_swap_target_combo"):
        target_combo = owner.memory_swap_target_combo
        targets = memory.get("swap_targets") or {}
        # The same words everywhere; SteamOS's default lives on /home, which
        # is then not offered a second time under its own name.
        default_mount = str(memory.get("default_swap_mount") or "/var/lib")
        expected = ["", *sorted(
            target for target in targets
            if target and not (steamos and target == default_mount)
        )]
        existing_targets = [target_combo.itemData(i) for i in range(target_combo.count())]
        if existing_targets != expected:
            previous_target = target_combo.currentData()
            target_combo.blockSignals(True)
            target_combo.clear()
            target_combo.addItem("", "")
            for target in expected[1:]:
                target_combo.addItem(target, target)
            index = target_combo.findData(previous_target)
            target_combo.setCurrentIndex(index if index >= 0 else 0)
            target_combo.blockSignals(False)
        target_combo.setItemText(0, tr("Default (/var/lib)").replace("/var/lib", default_mount))
        creates_swapfile = selected_policy in {"swap-16", "swap-32", "zswap-16", "zswap-32"}
        target_combo.setEnabled(enabled and creates_swapfile)
        owner.memory_swap_target_label.setVisible(creates_swapfile)
        target_combo.setVisible(creates_swapfile)
    selected_ttm = owner.ttm_limit_combo.currentData()
    selected_item = owner.ttm_limit_combo.model().item(max(0, owner.ttm_limit_combo.currentIndex()))
    owner.memory_ttm_apply_button.setEnabled(
        ttm_enabled and selected_ttm != 0 and bool(selected_item and selected_item.isEnabled())
        and (selected_ttm != -1 or restorable)
    )
    reason = setup.get("reason") or memory.get("reason") or ""
    for widget in (combo, owner.memory_swap_apply_button):
        widget.setToolTip(tr(reason) if reason else tr("Optional system setup. Review changes before applying."))
    ttm_reason = (ttm.get("reason") if ttm and not ttm.get("supported") else "") or setup.get("reason") or ""
    for widget in (owner.ttm_limit_combo, owner.memory_ttm_apply_button):
        widget.setToolTip(tr(ttm_reason) if ttm_reason else tr("Optional system setup. Review changes before applying."))
    if hasattr(owner, "memory_scope"):
        label = "SteamOS beta" if steamos else "Testing" if enabled else "Unavailable"
        if enabled and memory.get("phase") == "incomplete":
            label = "Incomplete"
        elif enabled and any(memory.get(key) for key in
                              ("restore_pending", "zram_pending", "zram_restore_pending", "zswap_pending")):
            label = "Reboot required"
        owner.memory_scope.setText(label)
        owner.memory_scope.set_tone("gray")
    return True

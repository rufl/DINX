from __future__ import annotations

import logging
from dataclasses import dataclass
from pathlib import Path

from PyQt6.QtCore import QSettings

from bc250cc.infrastructure.persistence.config_paths import (
    legacy_qt_config_dir,
    ui_settings_path,
)

from ..i18n import normalize_language

logger = logging.getLogger(__name__)

# Kept only as migration identifiers. New settings no longer use Qt's
# organization/application-derived directory because that produced a second
# ~/.config/BC250ControlCenter tree alongside the XDG application directory.
ORGANIZATION_NAME = "BC250ControlCenter"
APPLICATION_NAME = "ControlCenter"
LEGACY_QT_SETTINGS_FILES = (
    "ControlCenter.conf",
    "ModernPreview.conf",
    "BC250ControlCenter.conf",
)


@dataclass(frozen=True)
class PreferenceMigrationState:
    missing_backend_language: bool
    missing_backend_appearance: bool


def _ini_settings(path: Path) -> QSettings:
    return QSettings(str(path), QSettings.Format.IniFormat)


def _migrate_legacy_qt_settings(destination: QSettings) -> None:
    """Merge legacy Qt preferences into the canonical XDG directory.

    ``ControlCenter.conf`` is the newest legacy source, so it receives first
    priority. Older preview/safety files only fill values that are still
    missing. Legacy files are removed only after the canonical settings file
    has synchronized successfully.
    """

    legacy_dir = legacy_qt_config_dir()
    migrated_paths: list[Path] = []
    for filename in LEGACY_QT_SETTINGS_FILES:
        source_path = legacy_dir / filename
        if not source_path.exists() or not source_path.is_file():
            continue
        if source_path.is_symlink():
            logger.warning("Skipping symlinked legacy settings file: %s", source_path)
            continue

        source = _ini_settings(source_path)
        source.sync()
        if source.status() != QSettings.Status.NoError:
            logger.warning("Could not read legacy settings file: %s", source_path)
            continue

        for key in source.allKeys():
            if not destination.contains(key):
                destination.setValue(key, source.value(key))
        migrated_paths.append(source_path)

    if not migrated_paths:
        return

    destination.sync()
    if destination.status() != QSettings.Status.NoError:
        logger.warning(
            "Legacy UI settings were read but could not be synchronized to %s",
            destination.fileName(),
        )
        return

    for source_path in migrated_paths:
        try:
            source_path.unlink()
        except OSError:
            logger.warning("Could not remove migrated settings file: %s", source_path, exc_info=True)

    try:
        legacy_dir.rmdir()
    except FileNotFoundError:
        return
    except OSError:
        # Preserve the directory if an unknown file exists. The application no
        # longer writes there, so no duplicate tree will be generated again.
        logger.debug("Legacy Qt settings directory is not empty: %s", legacy_dir)


def application_settings() -> QSettings:
    path = ui_settings_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    settings = _ini_settings(path)
    _migrate_legacy_qt_settings(settings)
    return settings


class UiPreferences:
    """Own local presentation preferences and one-time legacy normalization."""

    THEME_VALUES = {"system", "light", "dark", "midnight"}
    ACCENT_VALUES = {
        "blue", "indigo", "violet", "pink", "orange",
        "amber", "green", "teal", "cyan", "graphite",
    }
    DENSITY_VALUES = {"comfortable", "compact"}
    STYLE_VALUES = {"standard", "formal"}

    def __init__(self, settings: QSettings | None = None) -> None:
        self.settings = settings or application_settings()

    def initialize(self) -> PreferenceMigrationState:
        missing_language = not self.settings.contains("settings/language")
        missing_appearance = not self.settings.contains("settings/appearance")
        if missing_language:
            self.settings.setValue("settings/language", "auto")
        if missing_appearance:
            self.settings.setValue("settings/appearance", "system")

        self._migrate_legacy_safety_preferences()
        self._normalize_stored_codes()
        self.settings.sync()
        return PreferenceMigrationState(missing_language, missing_appearance)

    def bool_value(self, key: str, default: bool) -> bool:
        value = self.settings.value(key, "true" if default else "false")
        return str(value).strip().lower() in {"1", "true", "yes", "on"}

    def int_value(self, key: str, default: int, *, minimum: int = 0, maximum: int = 10_000) -> int:
        """Read a stored integer, tolerating the strings QSettings hands back."""
        try:
            value = int(self.settings.value(key, default))
        except (TypeError, ValueError):
            value = default
        return max(minimum, min(maximum, value))

    def style(self) -> str:
        """The interface style: the standard look or the formal one."""
        return self.normalize_style(self.settings.value("settings/style", "standard"))

    @classmethod
    def normalize_style(cls, value: object) -> str:
        normalized = str(value or "").strip().lower()
        return normalized if normalized in cls.STYLE_VALUES else "standard"

    def scale(self) -> int:
        try:
            value = int(self.settings.value("settings/scale", 100))
        except (TypeError, ValueError):
            value = 100
        return max(70, min(150, round(value / 10) * 10))

    @classmethod
    def normalize_theme(cls, value: object) -> str:
        aliases = {
            "sistema": "system", "système": "system",
            "claro": "light", "hell": "light", "светлая": "light", "світла": "light",
            "oscuro": "dark", "escuro": "dark", "dunkel": "dark", "тёмная": "dark", "темна": "dark",
            "night blue": "midnight", "azul noche": "midnight",
        }
        normalized = aliases.get(str(value).strip().lower(), str(value).strip().lower())
        return normalized if normalized in cls.THEME_VALUES else "system"

    @classmethod
    def normalize_accent(cls, value: object) -> str:
        aliases = {
            "azul": "blue", "blau": "blue", "синий": "blue", "синій": "blue",
            "violeta": "violet", "violett": "violet", "фиолетовый": "violet", "фіолетовий": "violet",
            "cian": "cyan", "ciano": "cyan", "бирюзовый": "cyan", "бірюзовий": "cyan",
            "verde": "green", "grün": "green", "зелёный": "green", "зелений": "green",
            "naranja": "orange", "laranja": "orange", "оранжевый": "orange", "помаранчевий": "orange",
        }
        normalized = aliases.get(str(value).strip().lower(), str(value).strip().lower())
        return normalized if normalized in cls.ACCENT_VALUES else "blue"

    @classmethod
    def normalize_density(cls, value: object) -> str:
        aliases = {
            "cómoda": "comfortable", "comoda": "comfortable", "confortável": "comfortable",
            "komfortabel": "comfortable", "комфортная": "comfortable", "комфортна": "comfortable",
            "compacta": "compact", "kompakt": "compact", "компактная": "compact", "компактна": "compact",
        }
        normalized = aliases.get(str(value).strip().lower(), str(value).strip().lower())
        return normalized if normalized in cls.DENSITY_VALUES else "comfortable"

    def _migrate_legacy_safety_preferences(self) -> None:
        # Legacy root keys are copied into the canonical file by
        # _migrate_legacy_qt_settings(), so reading another QSettings instance
        # here would only recreate ~/.config/BC250ControlCenter.
        legacy = self.settings
        if not self.settings.contains("settings/scale"):
            try:
                scale = int(legacy.value("zoom_ui", 100))
            except (TypeError, ValueError):
                scale = 100
            self.settings.setValue("settings/scale", max(70, min(150, round(scale / 10) * 10)))
        # The notifications UI is hidden and its runtime is fail-closed.  Also
        # migrate any prior opt-in values back to disabled on startup.
        self.settings.setValue("settings/smart_alerts", "false")
        self.settings.setValue("settings/desktop_notifications", "false")
        if not self.settings.contains("settings/detailed_diagnostics"):
            discreet = str(legacy.value("modo_discreto", "true")).strip().lower() in {"1", "true", "yes", "on"}
            self.settings.setValue("settings/detailed_diagnostics", "false" if discreet else "true")
        if not self.settings.contains("settings/update_check"):
            # On by default, because a release nobody hears about helps nobody.
            # Off is a real choice: it is the one thing in this application that
            # contacts the internet on its own, and a metered or air-gapped
            # machine has every reason to decline.
            self.settings.setValue("settings/update_check", "true")
        if not self.settings.contains("settings/gamepad_navigation"):
            self.settings.setValue("settings/gamepad_navigation", "true")
        if not self.settings.contains("settings/gamepad_onscreen_keypad"):
            self.settings.setValue("settings/gamepad_onscreen_keypad", "true")
        # The keypad is now one coherent feature: when enabled for a gamepad it
        # also opens automatically on editable fields. Keep the legacy key in
        # sync so older builds can still read the same preference.
        keypad_enabled = str(
            self.settings.value("settings/gamepad_onscreen_keypad", "true")
        ).strip().lower() in {"1", "true", "yes", "on"}
        self.settings.setValue(
            "settings/gamepad_keypad_auto_show",
            "true" if keypad_enabled else "false",
        )

        for legacy_key in ("zoom_ui", "alertas_activas", "modo_discreto"):
            self.settings.remove(legacy_key)

    def _normalize_stored_codes(self) -> None:
        self.settings.setValue(
            "settings/language",
            normalize_language(self.settings.value("settings/language", "auto")),
        )
        self.settings.setValue(
            "settings/appearance",
            self.normalize_theme(self.settings.value("settings/appearance", "system")),
        )
        self.settings.setValue(
            "settings/accent",
            self.normalize_accent(self.settings.value("settings/accent", "blue")),
        )
        self.settings.setValue(
            "settings/density",
            self.normalize_density(self.settings.value("settings/density", "comfortable")),
        )


#: The dashboard's report button glows softly unless this is switched off.
REPORT_GLOW_KEY = "settings/report_glow"


def report_glow_enabled() -> bool:
    return UiPreferences().bool_value(REPORT_GLOW_KEY, True)

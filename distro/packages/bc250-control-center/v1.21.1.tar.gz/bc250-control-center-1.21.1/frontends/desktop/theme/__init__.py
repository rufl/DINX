from __future__ import annotations

import re
from copy import deepcopy
from pathlib import Path

# Light palette tuned for separation rather than whiteness. White cards sit on
# a visibly cooler canvas, nested surfaces are one clear step darker than the
# card that holds them, and every text and tone color reaches WCAG AA (4.5:1)
# on a white card: the previous "subtle" grey measured 2.6:1 and the orange,
# cyan and green tones about 3.3:1, which is why captions, eyebrows and badges
# washed out in light mode. AA holds on the nested surfaces too — the grey
# inset, the canvas and each tone's own soft fill — which is where a rendered
# audit still found captions at 4.2:1 and orange/cyan chips at 4.0:1.
LIGHT_COLORS = {
    "window": "#EDF0F4",
    "panel": "#FFFFFF",
    "panel_alt": "#F3F5F8",
    "panel_raised": "#FFFFFF",
    "control": "#FFFFFF",
    "control_hover": "#EEF1F5",
    "control_pressed": "#E2E7ED",
    "border": "#CBD3DD",
    "border_soft": "#DDE3EA",
    "border_strong": "#AEB8C6",
    "text": "#101828",
    "muted": "#4B5565",
    "subtle": "#616A7B",
    "disabled_bg": "#E6EAF0",
    "disabled_text": "#8A94A6",
    "focus": "#7AA7FF",
    "selection": "#E3EDFF",
    "scrollbar": "#B9C2CE",
    "scrollbar_hover": "#97A3B4",
    "progress_track": "#E3E8EE",
    "chart_surface": "#FAFBFD",
    "chart_grid": "#E1E7EE",
    "chart_axis": "#B8C2CF",
    "neutral_soft": "#EDF0F4",
    "neutral_border": "#D3DAE3",
    "icon_border": "#FFFFFF",
    "on_accent": "#FFFFFF",
    "console_bg": "#0E1728",
    "console_text": "#DCE6F6",
    "console_border": "#26344A",
    "tooltip_bg": "#1F2937",
    "tooltip_text": "#F9FAFB",
    "tooltip_border": "#111827",
    "scrim": "#0B1220",
    "blue": "#2563EB",
    "blue_soft": "#EAF2FF",
    "purple": "#6B4BDB",
    "purple_soft": "#F1EDFF",
    "orange": "#B14F0B",
    "orange_soft": "#FFF1E8",
    "cyan": "#06748F",
    "cyan_soft": "#E6F6FA",
    "green": "#067A57",
    "green_soft": "#E6F6EF",
    "red": "#C8281C",
    "red_soft": "#FDEDEC",
    # Categorical order for charts with several series, validated for colour
    # blindness in this fixed order (adjacent CVD ΔE >= 8.4, normal >= 19).
    # A series keeps its slot; there is no ninth.
    "series_1": "#2A78D6",
    "series_2": "#EB6834",
    "series_3": "#1BAF7A",
    "series_4": "#EDA100",
    "series_5": "#E87BA4",
    "series_6": "#008300",
    "series_7": "#4A3AA7",
    "series_8": "#E34948",
}

# Neutral graphite palette used by the desktop interface. The
# hierarchy comes from small luminance steps instead of bright borders, so the
# interface remains readable without looking like a light theme with black paint.
DARK_COLORS = {
    "window": "#0F0F0F",
    "panel": "#171717",
    "panel_alt": "#1F1F1F",
    "panel_raised": "#242424",
    "control": "#242424",
    "control_hover": "#2C2C2C",
    "control_pressed": "#333333",
    "border": "#343434",
    "border_soft": "#292929",
    "border_strong": "#4A4A4A",
    "text": "#F2F2F2",
    "muted": "#B4B4B4",
    "subtle": "#8E8E8E",
    "disabled_bg": "#292929",
    "disabled_text": "#707070",
    "focus": "#6E9FFF",
    "selection": "#24354F",
    "scrollbar": "#424242",
    "scrollbar_hover": "#5A5A5A",
    "progress_track": "#2A2A2A",
    "chart_surface": "#151515",
    "chart_grid": "#2D2D2D",
    "chart_axis": "#4A4A4A",
    "neutral_soft": "#242424",
    "neutral_border": "#363636",
    "icon_border": "#353535",
    "on_accent": "#FFFFFF",
    "console_bg": "#0A0A0A",
    "console_text": "#E6E6E6",
    "console_border": "#333333",
    "tooltip_bg": "#2B2B2B",
    "tooltip_text": "#F2F2F2",
    "tooltip_border": "#4A4A4A",
    "scrim": "#000000",
    "blue": "#5B8DEF",
    "blue_soft": "#1D2A3D",
    "purple": "#B39DFF",
    "purple_soft": "#2B2440",
    "orange": "#F0A45D",
    "orange_soft": "#38291D",
    "cyan": "#56C7D4",
    "cyan_soft": "#183137",
    "green": "#5CBF78",
    "green_soft": "#1B3224",
    "red": "#FF6B64",
    "red_soft": "#3A2020",
    "series_1": "#3987E5",
    "series_2": "#D95926",
    "series_3": "#199E70",
    "series_4": "#C98500",
    "series_5": "#D55181",
    "series_6": "#008300",
    "series_7": "#9085E9",
    "series_8": "#E66767",
}


# Two independent choices shape the look. The *theme* is the colour of the
# surfaces: light, the graphite dark, or the night blue of the application
# icon. The *style* is the register, in any theme: "formal" keeps the
# theme's surfaces but uses deeper, less saturated tones, a greyed accent,
# squarer corners and flat cards. Each (theme, style) pair has its palette;
# every text and tone colour reaches WCAG AA on its card (checked by the
# contrast tests for all six).
FORMAL_LIGHT_COLORS = {
    **LIGHT_COLORS,
    "window": "#EEF0F3",
    "panel": "#FFFFFF",
    "panel_alt": "#F4F5F7",
    "panel_raised": "#FFFFFF",
    "control": "#FFFFFF",
    "control_hover": "#EEF0F3",
    "control_pressed": "#E2E5EA",
    "border": "#C6CBD3",
    "border_soft": "#DCE0E6",
    "border_strong": "#A6ADB8",
    "text": "#0E1116",
    "muted": "#3D4552",
    "subtle": "#596170",
    "disabled_bg": "#E8EAEE",
    "disabled_text": "#8A919C",
    "focus": "#4A6A99",
    "selection": "#E2E8F1",
    "scrollbar": "#B8BEC8",
    "scrollbar_hover": "#99A0AB",
    "progress_track": "#E3E6EA",
    "chart_surface": "#FAFBFC",
    "chart_grid": "#E2E5E9",
    "chart_axis": "#B6BCC5",
    "neutral_soft": "#EDEFF2",
    "neutral_border": "#D3D7DE",
    "console_bg": "#11161D",
    "console_text": "#DDE3EA",
    "console_border": "#2A323D",
    "tooltip_bg": "#1C2229",
    "tooltip_text": "#F5F7F9",
    "tooltip_border": "#0E1116",
    "scrim": "#0B0F14",
    "blue": "#2A4A75",
    "blue_soft": "#E5EBF3",
    "purple": "#574A87",
    "purple_soft": "#EEEBF5",
    "orange": "#9A4B10",
    "orange_soft": "#F7EDE4",
    "cyan": "#1B6572",
    "cyan_soft": "#E3EFF1",
    "green": "#2C6449",
    "green_soft": "#E4EFE9",
    "red": "#A12E27",
    "red_soft": "#F6E7E5",
}

#: The night-blue theme in the formal style: the palette the formal dark
#: mode used to be, before theme and style were separate choices.
MIDNIGHT_COLORS = {
    **DARK_COLORS,
    "window": "#0B0F16",
    "panel": "#111722",
    "panel_alt": "#161D2A",
    "panel_raised": "#1B2331",
    "control": "#1B2331",
    "control_hover": "#222B3B",
    "control_pressed": "#2A3445",
    "border": "#2A3445",
    "border_soft": "#202938",
    "border_strong": "#3B4759",
    "text": "#E9EDF3",
    "muted": "#AEB7C4",
    "subtle": "#99A3B1",
    "disabled_bg": "#202938",
    "disabled_text": "#6C7686",
    "focus": "#86A8DA",
    "selection": "#22324A",
    "scrollbar": "#334052",
    "scrollbar_hover": "#445267",
    "progress_track": "#212A39",
    "chart_surface": "#0F1520",
    "chart_grid": "#222C3B",
    "chart_axis": "#3B4759",
    "neutral_soft": "#1B2331",
    "neutral_border": "#2E394A",
    "icon_border": "#2E394A",
    "console_bg": "#080B11",
    "console_text": "#E1E6EE",
    "console_border": "#283243",
    "tooltip_bg": "#1E2736",
    "tooltip_text": "#EEF1F6",
    "tooltip_border": "#3B4759",
    "blue": "#86A8DA",
    "blue_soft": "#1B2A40",
    "purple": "#AC9FE2",
    "purple_soft": "#272440",
    "orange": "#E3A673",
    "orange_soft": "#33271C",
    "cyan": "#72C4CE",
    "cyan_soft": "#16303A",
    "green": "#80C198",
    "green_soft": "#19302A",
    "red": "#F0827B",
    "red_soft": "#3A2124",
}

THEMES = ("light", "dark", "midnight")
STYLES = ("standard", "formal")
_TONES = ("blue", "purple", "orange", "cyan", "green", "red")
#: What the formal style mixes into a chosen accent: a slate that darkens the
#: light value (white text stays AA) and greys the dark one.
FORMAL_ACCENT_SLATE = {"light": ("#1B2536", 0.40), "dark": ("#8C98AA", 0.28)}
#: Corners in the formal style are this share of the standard radius.
FORMAL_RADIUS_FACTOR = 0.5


#: (light value, light soft, dark value, dark soft) for every accent. Each
#: light value carries white text at WCAG AA; each dark value reads on the
#: graphite panels. Red is left out on purpose: it is the colour of danger
#: here, and an accent would make every ordinary button look like one.
ACCENTS = {
    "blue": ("#2563EB", "#EAF2FF", "#5B8DEF", "#1D2A3D"),
    "indigo": ("#4338CA", "#EEEDFE", "#8B93FF", "#24253F"),
    "violet": ("#6B4BDB", "#F1EDFF", "#B39DFF", "#2B2440"),
    "pink": ("#BE185D", "#FDEAF3", "#F47FB5", "#3A1F2D"),
    "orange": ("#B14F0B", "#FFF1E8", "#F0A45D", "#38291D"),
    "amber": ("#A15C07", "#FEF4DF", "#EDB84E", "#35291A"),
    "green": ("#067A57", "#E6F6EF", "#5CBF78", "#1B3224"),
    "teal": ("#0F766E", "#E3F5F2", "#4FCFC0", "#16302D"),
    "cyan": ("#06748F", "#E6F6FA", "#56C7D4", "#183137"),
    "graphite": ("#475569", "#E9EDF2", "#C3CAD5", "#2A2D32"),
}

ACTIVE_MODE = "light"
#: "light", "dark" or "midnight". ACTIVE_MODE stays light/dark: everything
#: that picks an icon or a shade by brightness keeps asking that.
ACTIVE_THEME = "light"
ACTIVE_ACCENT = "blue"
ACTIVE_DENSITY = "comfortable"
ACTIVE_SCALE = 100
ACTIVE_STYLE = "standard"
COLORS = deepcopy(LIGHT_COLORS)
_STYLESHEET_CACHE: dict[tuple[str, str, str, str, int, str], str] = {}


def _blend(base: str, overlay: str, amount: float) -> str:
    """Blend two #RRGGBB colors without depending on Qt."""
    amount = max(0.0, min(1.0, float(amount)))
    try:
        left = tuple(int(base[index:index + 2], 16) for index in (1, 3, 5))
        right = tuple(int(overlay[index:index + 2], 16) for index in (1, 3, 5))
    except (TypeError, ValueError):
        return str(base)
    mixed = tuple(round(a * (1.0 - amount) + b * amount) for a, b in zip(left, right))
    return "#" + "".join(f"{channel:02X}" for channel in mixed)


def _with_tones(neutrals: dict[str, str], tones: dict[str, str], amount: float) -> dict[str, str]:
    """One theme's surfaces carrying another palette's tones.

    Each soft fill is recomputed over these surfaces: a fill mixed for
    graphite turns muddy on navy, and the other way round.
    """
    palette = dict(neutrals)
    for tone in _TONES:
        palette[tone] = tones[tone]
        palette[f"{tone}_soft"] = _blend(neutrals["panel"], tones[tone], amount)
    return palette


def _relative_luminance(color: str) -> float:
    """WCAG relative luminance for a ``#RRGGBB`` color."""
    try:
        channels = [int(color[index:index + 2], 16) / 255.0 for index in (1, 3, 5)]
    except (TypeError, ValueError):
        return 0.0
    linear = [
        channel / 12.92 if channel <= 0.04045 else ((channel + 0.055) / 1.055) ** 2.4
        for channel in channels
    ]
    return 0.2126 * linear[0] + 0.7152 * linear[1] + 0.0722 * linear[2]


def _contrast(first: str, second: str) -> float:
    """WCAG contrast ratio between two ``#RRGGBB`` colors."""
    light, dark = sorted((_relative_luminance(first), _relative_luminance(second)), reverse=True)
    return (light + 0.05) / (dark + 0.05)


def _readable_on(color: str, ground: str, ink: str) -> str:
    """``color``, drawn toward ``ink`` only as far as AA on ``ground`` needs."""
    for step in range(21):
        candidate = _blend(color, ink, step / 20)
        if _contrast(candidate, ground) >= 4.5:
            return candidate
    return ink


def _ink_for(background: str) -> str:
    """Readable text color for a solid accent fill.

    Dark-mode accents are light enough that white text washes out on them.  The
    mockup spells this out for the primary action: a ``#63D8E8`` fill carries
    ``#052227`` ink, not white.  Deriving the ink keeps every accent — and every
    user-selected accent color — consistent instead of hardcoding one pair.
    """
    if _relative_luminance(background) > 0.45:
        return _blend(background, "#000000", 0.86)
    return "#FFFFFF"


def _finish_palette(palette: dict[str, str], mode: str) -> dict[str, str]:
    for tone in ("blue", "purple", "orange", "cyan", "green", "red"):
        palette[f"{tone}_border"] = _blend(
            palette[tone], palette["panel"], 0.58 if mode == "dark" else 0.72
        )
        palette[f"on_{tone}"] = _ink_for(palette[tone])
    palette["blue_hover"] = _blend(
        palette["blue"], "#FFFFFF" if mode == "dark" else "#000000", 0.10
    )
    palette["blue_pressed"] = _blend(
        palette["blue"], "#FFFFFF" if mode == "dark" else "#000000", 0.18
    )
    palette["cyan_hover"] = _blend(
        palette["cyan"], "#FFFFFF" if mode == "dark" else "#000000", 0.10
    )
    palette["orange_hover"] = _blend(
        palette["orange"], "#FFFFFF" if mode == "dark" else "#000000", 0.10
    )
    palette["red_hover"] = _blend(
        palette["red"], "#FFFFFF" if mode == "dark" else "#000000", 0.10
    )
    # The console stays dark in every theme. Words drawn on its ground — the
    # selected tab, the terminal's menu — need colours made for it: the light
    # theme's ink and tones measured about 1:1 to 2.5:1 there.
    ground, ink = palette["console_bg"], palette["console_text"]
    palette["console_muted"] = _readable_on(_blend(ink, ground, 0.45), ground, ink)
    for tone in ("blue", "green", "orange", "red"):
        palette[f"console_{tone}"] = _readable_on(palette[tone], ground, ink)
    return palette


def semantic_color_key(value: object, preferred: str | None = None) -> str | None:
    """Resolve a previously stored palette color back to a semantic token.

    Widgets created before a live theme switch may hold the old hexadecimal
    value.  Looking through both palettes lets them refresh without rebuilding
    the page.  ``preferred`` disambiguates accent colors that intentionally
    share a value.
    """
    text = str(value or "").strip()
    if text in COLORS:
        return text
    normalized = text.upper()
    candidates: list[str] = []
    palettes = (
        COLORS, LIGHT_COLORS, DARK_COLORS, FORMAL_LIGHT_COLORS, FORMAL_DARK_COLORS,
        MIDNIGHT_COLORS, MIDNIGHT_STANDARD_COLORS,
    )
    for palette in palettes:
        for key, color in palette.items():
            if str(color).upper() == normalized and key not in candidates:
                candidates.append(key)
    for values in ACCENTS.values():
        for key, color in (("blue", values[0]), ("blue_soft", values[1]), ("blue", values[2]), ("blue_soft", values[3])):
            if color.upper() == normalized and key not in candidates:
                candidates.append(key)
    aliases = {
        "#EEF3F9": "neutral_soft", "#EEF2F7": "neutral_soft", "#F0F4F8": "neutral_soft",
        "#EFF2F6": "neutral_soft", "#F2F5F8": "neutral_soft",
    }
    alias = aliases.get(normalized)
    if alias and alias not in candidates:
        candidates.append(alias)
    if preferred and preferred in candidates:
        return preferred
    priority = (
        "neutral_soft", "blue_soft", "purple_soft", "orange_soft", "cyan_soft", "green_soft", "red_soft",
        "blue", "purple", "orange", "cyan", "green", "red", "panel_alt", "panel", "text", "muted", "subtle",
    )
    return next((key for key in priority if key in candidates), candidates[0] if candidates else None)


def palette_color(value: object, preferred: str | None = None) -> str:
    key = semantic_color_key(value, preferred)
    return COLORS.get(key, str(value or COLORS["neutral_soft"]))


#: Graphite in the formal style: the dark theme's surfaces with the quieter
#: tones of the formal register. Its greys are a step lighter than the
#: standard ones so every caption clears AA on the graphite cards.
FORMAL_DARK_COLORS = _with_tones(
    {
        **DARK_COLORS,
        "muted": "#B9B9B9",
        "subtle": "#9D9D9D",
        "focus": "#86A8DA",
        "selection": "#262F3C",
    },
    MIDNIGHT_COLORS,
    0.14,
)
#: Night blue in the standard style: the navy surfaces with the standard,
#: livelier tones.
MIDNIGHT_STANDARD_COLORS = _with_tones(MIDNIGHT_COLORS, DARK_COLORS, 0.14)

COLORS.clear()
COLORS.update(_finish_palette(deepcopy(LIGHT_COLORS), "light"))


def mode_of(theme: str) -> str:
    """Light or dark: what a theme is as far as brightness goes."""
    return "dark" if str(theme) in {"dark", "midnight"} else "light"


def palette_for(theme: str, style: str) -> dict[str, str]:
    """The base palette of one theme in one style, before the accent."""
    formal = style == "formal"
    if theme == "midnight":
        return MIDNIGHT_COLORS if formal else MIDNIGHT_STANDARD_COLORS
    if theme == "dark":
        return FORMAL_DARK_COLORS if formal else DARK_COLORS
    return FORMAL_LIGHT_COLORS if formal else LIGHT_COLORS


def formal_accent(value: str, mode: str) -> str:
    slate, amount = FORMAL_ACCENT_SLATE[mode_of(mode)]
    return _blend(value, slate, amount)


def theme_palette(theme: str, accent: str, style: str = "standard") -> dict[str, str]:
    """The finished palette a choice would install, without installing it."""
    theme = theme if theme in THEMES else "light"
    mode = mode_of(theme)
    palette = deepcopy(palette_for(theme, style))
    light_value, light_soft, dark_value, dark_soft = ACCENTS.get(accent, ACCENTS["blue"])
    palette["blue"] = dark_value if mode == "dark" else light_value
    palette["blue_soft"] = dark_soft if mode == "dark" else light_soft
    if theme == "midnight" and style != "formal":
        # The accents' soft fills were mixed for graphite; on navy the blue
        # one left accent text at 4.48:1. Mixed over these surfaces instead.
        palette["blue_soft"] = _blend(palette["panel"], palette["blue"], 0.12)
    if style == "formal":
        palette["blue"] = formal_accent(palette["blue"], mode)
        palette["blue_soft"] = _blend(palette["blue_soft"], palette["panel"], 0.25)
    return _finish_palette(palette, mode)


def configure_theme(
    mode: str = "light",
    accent: str = "blue",
    density: str = "comfortable",
    scale: int = 100,
    style: str | None = None,
) -> dict[str, str]:
    global ACTIVE_MODE, ACTIVE_THEME, ACTIVE_ACCENT, ACTIVE_DENSITY, ACTIVE_SCALE, ACTIVE_STYLE
    style = str(style if style is not None else ACTIVE_STYLE).lower()
    if style not in STYLES:
        style = "standard"
    # ``mode`` takes a theme: "midnight" is a dark mode with its own surfaces.
    theme = str(mode or "light").lower()
    if theme not in THEMES:
        theme = "light"
    mode = mode_of(theme)
    accent = str(accent or "blue").lower()
    if accent not in ACCENTS:
        accent = "blue"
    density = str(density or "comfortable").lower()
    if density not in {"comfortable", "compact"}:
        density = "comfortable"
    try:
        scale = int(round(float(scale) / 10.0) * 10)
    except (TypeError, ValueError, OverflowError):
        scale = 100
    scale = max(70, min(150, scale))
    if (theme, accent, density, scale, style) == (
        ACTIVE_THEME, ACTIVE_ACCENT, ACTIVE_DENSITY, ACTIVE_SCALE, ACTIVE_STYLE
    ):
        return COLORS
    palette = theme_palette(theme, accent, style)
    COLORS.clear()
    COLORS.update(palette)
    ACTIVE_MODE = mode
    ACTIVE_THEME = theme
    ACTIVE_ACCENT = accent
    ACTIVE_DENSITY = density
    ACTIVE_SCALE = scale
    ACTIVE_STYLE = style
    return COLORS


def apply_tooltip_palette() -> None:
    """Give tooltips outside the stylesheet the same readable pair.

    The stylesheet styles every tooltip raised from a widget inside the
    window. A few are drawn by Qt from the application palette instead — a
    combo box popup's items, a parentless helper window — and those used the
    desktop theme's colours, which need not match the palette in use here.
    """
    try:
        from PyQt6.QtGui import QColor, QPalette
        from PyQt6.QtWidgets import QToolTip
    except ImportError:  # pragma: no cover - PyQt6 is a runtime dependency.
        return
    palette = QToolTip.palette()
    for group in (QPalette.ColorGroup.Active, QPalette.ColorGroup.Inactive):
        palette.setColor(group, QPalette.ColorRole.ToolTipBase, QColor(COLORS["tooltip_bg"]))
        palette.setColor(group, QPalette.ColorRole.ToolTipText, QColor(COLORS["tooltip_text"]))
    QToolTip.setPalette(palette)


#: Compact density tightens box geometry, never type: paddings and margins
#: shrink by 30 %, minimum heights by 16 %. Fonts keep their size, which is
#: what separates "Compact" from simply choosing a smaller interface scale.
COMPACT_PADDING_FACTOR = 0.70
COMPACT_MIN_HEIGHT_FACTOR = 0.84
_COMPACT_PROPERTY_RE = re.compile(
    r"(?P<name>(?<![\w-])(?:padding(?:-top|-bottom|-left|-right)?|"
    r"margin(?:-top|-bottom|-left|-right)?|spacing|min-height))"
    r"(?P<sep>\s*:\s*)(?P<value>[^;{}]+)"
)
_PIXELS_RE = re.compile(r"(?<![A-Za-z0-9_#.-])(\d+(?:\.\d+)?)px")


def compact_stylesheet(stylesheet: str) -> str:
    """Tighten paddings, margins and minimum heights for Compact density."""

    def shrink(match: re.Match[str]) -> str:
        name = match.group("name")
        factor = COMPACT_MIN_HEIGHT_FACTOR if name == "min-height" else COMPACT_PADDING_FACTOR

        def pixels(value: re.Match[str]) -> str:
            number = float(value.group(1))
            if number <= 0:
                return value.group(0)
            return f"{max(1, round(number * factor))}px"

        return name + match.group("sep") + _PIXELS_RE.sub(pixels, match.group("value"))

    return _COMPACT_PROPERTY_RE.sub(shrink, stylesheet)


_RADIUS_RE = re.compile(
    r"(?P<name>border(?:-top|-bottom)?(?:-left|-right)?-radius\s*:\s*)(?P<value>\d+(?:\.\d+)?)px"
)


def formal_stylesheet(stylesheet: str) -> str:
    """Squarer corners for the formal style; a pill stays a pill."""

    def square(match: re.Match[str]) -> str:
        value = float(match.group("value"))
        if value >= 99:
            return match.group(0)
        return f"{match.group('name')}{max(2, round(value * FORMAL_RADIUS_FACTOR))}px"

    return _RADIUS_RE.sub(square, stylesheet)


def scale_stylesheet(stylesheet: str, scale: int | None = None) -> str:
    # Every stylesheet in the interface passes through here, so this is where
    # the formal style squares its corners — once, for all of them.
    if ACTIVE_STYLE == "formal":
        stylesheet = formal_stylesheet(stylesheet)
    if ACTIVE_DENSITY == "compact":
        stylesheet = compact_stylesheet(stylesheet)
    factor = (ACTIVE_SCALE if scale is None else max(70, min(150, int(scale)))) / 100.0

    def replace(match: re.Match[str]) -> str:
        value = float(match.group(1))
        scaled = max(1.0, value * factor)
        prefix = match.string[max(0, match.start() - 24):match.start()]
        # Improve legibility without inflating card margins or spacing. Small
        # body/caption fonts gain one logical pixel while titles retain their
        # existing hierarchy; the user scale still applies on top.
        if value <= 13 and re.search(r"font-size\s*:\s*$", prefix):
            scaled += factor
        rendered = str(round(scaled)) if scaled >= 1 else f"{scaled:.1f}"
        return rendered + "px"

    return re.sub(r"(?<![A-Za-z0-9_#.-])(\d+(?:\.\d+)?)px", replace, stylesheet)


def application_stylesheet(mode: str | None = None, accent: str | None = None, density: str | None = None, scale: int | None = None) -> str:
    if mode is not None or accent is not None or density is not None or scale is not None:
        configure_theme(mode or ACTIVE_THEME, accent or ACTIVE_ACCENT, density or ACTIVE_DENSITY, ACTIVE_SCALE if scale is None else scale)
    cache_key = (ACTIVE_MODE, ACTIVE_THEME, ACTIVE_ACCENT, ACTIVE_DENSITY, ACTIVE_SCALE, ACTIVE_STYLE)
    cached = _STYLESHEET_CACHE.get(cache_key)
    if cached is not None:
        return cached
    c = COLORS
    # Qt style sheets need a filesystem path for url(); QIcon's lookup
    # is not reachable from QSS. Kept as POSIX separators, which Qt
    # accepts on every platform it builds for.
    icon_dir = (Path(__file__).resolve().parent / "icons").as_posix()
    # This tab's cards, hairlines, fields and title bands take the greys of the
    # Compatibility tab in both themes; the title bands are a step darker.
    upscaling_card, upscaling_field = c['panel_alt'], c['control']
    upscaling_line, upscaling_line_strong = c['border_soft'], c['border']
    upscaling_head = (
        c['control_pressed'] if ACTIVE_MODE == "light"
        else _blend(c['panel_alt'], c['window'], 0.5)
    )
    # Glass, for the first-run panel: the card has to be translucent for the
    # frosted portrait behind it to mean anything, and Qt takes that as an
    # rgba() rather than as a palette entry. Light glass on a light palette,
    # dark glass on a dark one — a translucent white over a dark shell reads
    # as fog rather than as a pane.
    _glass_rgb = "255, 255, 255" if ACTIVE_MODE == "light" else "26, 30, 38"
    glass_card = f"rgba({_glass_rgb}, 0.90)"
    glass_rail = f"rgba({_glass_rgb}, 0.55)"
    glass_edge = (
        "rgba(255, 255, 255, 0.75)" if ACTIVE_MODE == "light"
        else "rgba(255, 255, 255, 0.14)"
    )
    base = f"""
    * {{
        font-family: Inter, 'Noto Sans', 'Segoe UI', sans-serif;
        color: {c['text']};
    }}
    /* A tooltip is a child window of the widget it describes, so the rule
       above reached it and painted the page's text color over the desktop
       theme's tooltip background: dark on dark in light mode, light on light
       in dark mode. It carries its own complete, high-contrast pair now. */
    QToolTip {{
        background-color: {c['tooltip_bg']};
        color: {c['tooltip_text']};
        border: 1px solid {c['tooltip_border']};
        border-radius: 6px;
        padding: 6px 9px;
        font-size: 11px;
        font-weight: 560;
    }}
    QMainWindow, QWidget#ApplicationRoot {{
        background: {c['window']};
    }}
    QScrollArea, QScrollArea > QWidget > QWidget {{
        background: transparent;
        border: none;
    }}
    QScrollBar:vertical {{
        background: transparent;
        width: 8px;
        margin: 4px 1px 4px 1px;
    }}
    QScrollBar::handle:vertical {{
        background: {c['scrollbar']};
        border-radius: 4px;
        min-height: 44px;
    }}
    QScrollBar::handle:vertical:hover {{
        background: {c['scrollbar_hover']};
    }}
    QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{
        height: 0px;
    }}
    QFrame#Sidebar {{
        background: {c['panel']};
        border: 1px solid {c['border']};
        border-radius: 16px;
    }}
    QLabel#BrandTitle {{
        font-size: 15px;
        font-weight: 860;
        color: {c['text']};
    }}
    QLabel#BrandSubtitle {{
        font-size: 10px;
        font-weight: 620;
        color: {c['muted']};
    }}
    QLabel#SidebarSection {{
        color: {c['subtle']};
        font-size: 9px;
        font-weight: 820;
        letter-spacing: 0.9px;
        padding-left: 8px;
    }}
    QFrame#SidebarDivider, QFrame#CardDivider, QFrame#ListDivider {{
        background: {c['border_soft']};
        border: none;
    }}
    QPushButton#SidebarToggle {{
        background: transparent;
        border: 0px;
        border-radius: 8px;
        padding: 0px;
    }}
    QPushButton#SidebarToggle:hover {{
        background: {c['panel_alt']};
    }}
    QPushButton[nav='true'] {{
        background: transparent;
        border: 0px;
        border-radius: 9px;
        padding: 0px 8px;
        text-align: left;
        font-size: 12px;
        font-weight: 640;
        color: {c['muted']};
    }}
    QPushButton[nav='true']:hover {{
        background: {c['panel_alt']};
        color: {c['text']};
    }}
    QPushButton[nav='true']:checked {{
        background: {c['blue_soft']};
        color: {c['text']};
        font-weight: 760;
    }}
    QPushButton[nav='true'][collapsed='true'] {{
        padding: 0px;
        text-align: center;
        min-width: 42px;
        max-width: 42px;
        min-height: 42px;
        max-height: 42px;
    }}
    QLabel#PageEyebrow {{
        color: {c['blue']};
        font-size: 9px;
        font-weight: 850;
        letter-spacing: 1.2px;
    }}
    QLabel#PageTitle {{
        font-size: 31px;
        font-weight: 830;
        color: {c['text']};
    }}
    QLabel#PageSubtitle {{
        font-size: 13px;
        color: {c['muted']};
        line-height: 1.3em;
    }}
    QFrame#HeaderStatus {{
        background: {c['panel']};
        border: 1px solid {c['border']};
        border-radius: 10px;
    }}
    QLabel#HeaderStatusText {{
        color: {c['muted']};
        font-size: 11px;
        font-weight: 750;
    }}
    QPushButton#RefreshButton {{
        background: {c['panel']};
        border: 1px solid {c['border']};
        border-radius: 12px;
        padding: 10px 15px;
        font-weight: 730;
    }}
    QPushButton#RefreshButton:hover {{
        background: {c['blue_soft']};
        border-color: {c['blue_border']};
        color: {c['blue']};
    }}
    QFrame[card='true'], QFrame[sectionCard='true'], QFrame[moduleCard='true'] {{
        background: {c['panel']};
        border: 1px solid {c['border']};
        border-radius: 20px;
    }}
    QLabel[cardTitle='true'] {{
        font-size: 15px;
        font-weight: 780;
        color: {c['text']};
    }}
    QLabel[sectionSubtitle='true'] {{
        color: {c['muted']};
        font-size: 11px;
    }}
    QLabel[metricLabel='true'] {{
        color: {c['muted']};
        font-size: 11px;
        font-weight: 600;
    }}
    QLabel[metricValue='true'] {{
        font-size: 20px;
        font-weight: 830;
        color: {c['text']};
    }}
    QLabel[pill='true'] {{
        border-radius: 8px;
        padding: 4px 9px;
        font-size: 10px;
        font-weight: 780;
    }}
    QLabel[pill='true'][prominentPill='true'] {{
        padding: 5px 10px;
        font-size: 12px;
    }}
    QPushButton[cardAction='true'] {{
        background: {c['panel_alt']};
        border: 1px solid {c['border']};
        border-radius: 12px;
        padding: 10px 13px;
        font-weight: 720;
        color: {c['text']};
    }}
    QPushButton[cardAction='true']:hover {{
        background: {c['control_hover']};
        border-color: {c['blue_border']};
        color: {c['blue']};
    }}
    QPushButton[compactAction='true'] {{
        background: {c['panel_raised']};
        border: 1px solid {c['border']};
        border-radius: 10px;
        padding: 8px 12px;
        font-size: 11px;
        font-weight: 700;
        color: {c['muted']};
    }}
    QPushButton[compactAction='true']:hover {{
        background: {c['control_hover']};
        border-color: {c['border']};
    }}
    QPushButton[compactAction='true'][powerTone='on'] {{
        background: {c['green_soft']};
        border-color: {c['green']};
        color: {c['green']};
    }}
    QPushButton[compactAction='true'][powerTone='off'] {{
        background: {c['red_soft']};
        border-color: {c['red']};
        color: {c['red']};
    }}
    QPushButton[dependencySectionTab='true'] {{
        min-height: 26px;
        padding: 7px 12px;
        background: {c['panel_alt']};
        border: 1px solid {c['border_soft']};
        border-radius: 9px;
        color: {c['muted']};
        font-size: 11px;
        font-weight: 760;
    }}
    QPushButton[dependencySectionTab='true']:hover {{
        background: {c['control_hover']};
        border-color: {c['blue_border']};
        color: {c['text']};
    }}
    QPushButton[dependencySectionTab='true']:checked {{
        background: {c['panel_raised']};
        border-color: {c['border_strong']};
        color: {c['text']};
        font-weight: 840;
    }}
    QFrame[dependencySystemBar='true'] {{
        background: {c['panel_alt']};
        border: 1px solid {c['border_soft']};
        border-radius: 10px;
    }}
    QLabel[dependencySystemText='true'] {{
        color: {c['text']};
        font-size: 12px;
        font-weight: 680;
    }}
    QFrame[quickActionRow='true'] {{
        background: {c['panel_alt']};
        border: 1px solid {c['border_soft']};
        border-radius: 11px;
    }}
    QFrame[quickActionRow='true'][hovered='true'] {{
        background: {c['blue_soft']};
        border: 1px solid {c['blue_border']};
    }}
    QLabel[actionTitle='true'] {{
        font-size: 12px;
        font-weight: 760;
        color: {c['text']};
    }}
    QLabel[actionSubtitle='true'] {{
        color: {c['muted']};
        font-size: 10px;
    }}
    QFrame#ReadinessMarker {{
        background: {c['green_soft']};
        border: 1px solid {c['green_border']};
        border-radius: 8px;
    }}
    QLabel[rowLabel='true'], QLabel[activityText='true'] {{
        color: {c['muted']};
        font-size: 11px;
    }}
    QLabel[activityTime='true'] {{
        color: {c['subtle']};
        font-size: 10px;
    }}
    QLabel#ReadinessSubtitle {{
        font-size: 11px;
    }}
    QProgressBar {{
        background: {c['progress_track']};
        border: none;
        border-radius: 4px;
        min-height: 7px;
        max-height: 7px;
        text-align: center;
    }}
    QProgressBar::chunk {{
        background: {c['orange']};
        border-radius: 4px;
    }}
    QFrame#SystemSummaryBar {{
        background: {c['panel']};
        border: 1px solid {c['border']};
        border-radius: 18px;
    }}
    QLabel#SummaryLabel {{
        color: {c['muted']};
        font-size: 10px;
        font-weight: 700;
    }}
    QLabel#SummaryValue {{
        color: {c['text']};
        font-size: 14px;
        font-weight: 830;
    }}
    QFrame[dashboardHero='true'],
    QFrame[dashboardModule='true'],
    QFrame[dashboardPreparation='true'] {{
        background: {c['panel']};
        border: 1px solid {c['border']};
        border-radius: 14px;
    }}
    QFrame[dashboardEvidence='true'] {{
        background: {c['panel']};
        border: none;
        border-left: 1px solid {c['border_soft']};
        border-top-right-radius: 13px;
        border-bottom-right-radius: 13px;
    }}
    QLabel[dashboardCardTitle='true'] {{
        color: {c['text']};
        font-size: 13px;
        font-weight: 750;
    }}
    QLabel[dashboardCardSubtitle='true'] {{
        color: {c['muted']};
        font-size: 10px;
    }}
    QFrame[dashboardMetricTile='true'] {{
        background: {c['panel_alt']};
        border: 1px solid {c['border_soft']};
        border-radius: 10px;
    }}
    QFrame[dashboardMetricTile='true'][tone='blue'] {{
        border-color: {c['blue_border']};
    }}
    QFrame[dashboardMetricTile='true'][tone='orange'] {{
        border-color: {c['orange_border']};
    }}
    QLabel[dashboardMetricLabel='true'] {{
        color: {c['muted']};
        font-size: 10px;
        font-weight: 650;
    }}
    QLabel[dashboardMetricValue='true'] {{
        color: {c['text']};
        font-size: 15px;
        font-weight: 750;
    }}
    QLabel[dashboardMetricDetail='true'] {{
        color: {c['muted']};
        font-size: 9px;
    }}
    /* One shape for every reading on the dashboard: quiet name, the number,
       its unit, and an optional word of context. */
    QFrame[sensorCell='true'] {{
        background: {c['panel_alt']};
        border: 1px solid {c['border_soft']};
        border-radius: 10px;
    }}
    QFrame[sensorCell='true'][tone='warning'] {{
        background: {c['orange_soft']};
        border-color: {c['orange_border']};
    }}
    QFrame[sensorCell='true'][tone='danger'] {{
        background: {c['red_soft']};
        border-color: {c['red_border']};
    }}
    QLabel[sensorCellLabel='true'] {{
        color: {c['muted']};
        font-size: 10px;
        font-weight: 650;
        letter-spacing: 0.3px;
    }}
    QLabel[sensorCellValue='true'] {{
        color: {c['text']};
        font-size: 17px;
        font-weight: 760;
    }}
    QLabel[sensorCellUnit='true'] {{
        color: {c['muted']};
        font-size: 10px;
        font-weight: 650;
        padding-bottom: 2px;
    }}
    QLabel[sensorCellDetail='true'] {{
        color: {c['muted']};
        font-size: 9px;
    }}
    QLabel[sensorCellValue='true'][empty='true'] {{
        color: {c['subtle']};
        font-size: 13px;
        font-weight: 650;
    }}
    QFrame[sensorCell='true'][tone='warning'] QLabel[sensorCellValue='true'] {{
        color: {c['orange']};
    }}
    QFrame[sensorCell='true'][tone='danger'] QLabel[sensorCellValue='true'] {{
        color: {c['red']};
    }}
    QFrame[dashboardBand='true'] {{
        background: {c['panel']};
        border: 1px solid {c['border_soft']};
        border-radius: 14px;
    }}
    QLabel[sensorBoardTitle='true'] {{
        color: {c['muted']};
        font-size: 10px;
        font-weight: 750;
        letter-spacing: 0.6px;
    }}
    /* The dot that opens a group of readings, and the rule and chip that
       frame the graphics card's groups. */
    QLabel[sensorBoardDot='true'] {{
        min-width: 6px;
        max-width: 6px;
        min-height: 6px;
        max-height: 6px;
        border-radius: 3px;
        background: {c['subtle']};
    }}
    QLabel[sensorBoardDot='true'][accent='purple'] {{
        background: {c['purple']};
    }}
    QLabel[sensorBoardDot='true'][accent='blue'] {{
        background: {c['blue']};
    }}
    QLabel[sensorBoardDot='true'][accent='cyan'] {{
        background: {c['cyan']};
    }}
    QLabel[sensorBoardDot='true'][accent='green'] {{
        background: {c['green']};
    }}
    QLabel[sensorBoardDot='true'][accent='orange'] {{
        background: {c['orange']};
    }}
    QLabel[sensorBoardDot='true'][accent='red'] {{
        background: {c['red']};
    }}
    QFrame[dashboardMetricTile='true'][flat='true'] {{
        background: transparent;
        border: none;
        border-radius: 0;
    }}
    QFrame[dashboardMetricTile='true'][flat='true'] QFrame[dashboardCoreCell='true'] {{
        background: transparent;
    }}
    QFrame[dashboardDivider='true'] {{
        background: {c['border_soft']};
        border: none;
    }}
    QFrame[identityChip='true'] {{
        background: {c['panel_alt']};
        border: 1px solid {c['border_soft']};
        border-radius: 9px;
    }}
    QLabel[identityChipLabel='true'] {{
        color: {c['muted']};
        font-size: 10px;
        font-weight: 700;
    }}
    QLabel[identityChipValue='true'] {{
        color: {c['text']};
        font-size: 12px;
        font-weight: 750;
    }}
    QLabel[identityChipDetail='true'] {{
        color: {c['muted']};
        font-size: 10px;
    }}
    /* Dashboard instruments (dashboard_instruments.py). Rows, not cells:
       a column of right-aligned figures is read by running down it, and the
       only colour is the domain accent and a reading the hardware flagged. */
    QFrame[boardHeader='true'] {{
        background: {c['panel']};
        border: 1px solid {c['border_soft']};
        border-radius: 16px;
    }}
    QLabel[boardName='true'] {{
        color: {c['text']};
        font-size: 17px;
        font-weight: 800;
    }}
    QLabel[boardSpec='true'] {{
        color: {c['muted']};
        font-size: 11px;
        font-weight: 600;
    }}
    QFrame[instrumentPanel='true'] {{
        background: {c['panel']};
        border: 1px solid {c['border_soft']};
        border-radius: 16px;
    }}
    QLabel[instrumentTitle='true'] {{
        color: {c['text']};
        font-size: 12px;
        font-weight: 800;
    }}
    /* One accent, and it is the one chosen in Appearance: the palette swaps
       what "blue" means, so a panel that picked its own colour ignored the
       setting. Orange and red stay semantic — they mean a reading, not a
       decoration. */
    QFrame[instrumentAccent='true'] {{
        background: {c['blue']};
        border: none;
    }}
    QFrame[instrumentHairline='true'] {{
        background: {c['border_soft']};
        border: none;
    }}
    QLabel[groupTitle='true'] {{
        color: {c['muted']};
        font-size: 9px;
        font-weight: 800;
    }}
    QLabel[bandNote='true'] {{
        color: {c['muted']};
        font-size: 10px;
        font-weight: 600;
    }}
    QLabel[headlineValue='true'] {{
        color: {c['text']};
        font-size: 32px;
        font-weight: 800;
    }}
    QLabel[headlineUnit='true'] {{
        color: {c['muted']};
        font-size: 11px;
        font-weight: 700;
        padding-bottom: 7px;
    }}
    QFrame[reading='true'] {{
        background: transparent;
        border: none;
    }}
    QFrame[reading='true'][banded='true'] {{
        border-top: 1px solid {c['border_soft']};
    }}
    QLabel[readingLabel='true'] {{
        color: {c['muted']};
        font-size: 11px;
        font-weight: 500;
    }}
    QLabel[readingValue='true'] {{
        color: {c['text']};
        font-size: 13px;
        font-weight: 700;
    }}
    QLabel[readingUnit='true'] {{
        color: {c['muted']};
        font-size: 10px;
        font-weight: 600;
    }}
    QLabel[readingDetail='true'] {{
        color: {c['muted']};
        font-size: 9px;
    }}
    QFrame[reading='true'][tone='good'] QLabel[readingValue='true'] {{
        color: {c['green']};
    }}
    QFrame[reading='true'][tone='warning'] QLabel[readingValue='true'] {{
        color: {c['orange']};
    }}
    QFrame[reading='true'][tone='danger'] QLabel[readingValue='true'] {{
        color: {c['red']};
    }}
    QPushButton[dashboardCardAction='true'][accented='true'] {{
        color: {c['blue']};
        border-color: {c['blue_border']};
    }}
    QLabel[dashboardCoreSummaryLabel='true'] {{
        color: {c['muted']};
        font-size: 9px;
        font-weight: 800;
    }}
    QLabel[dashboardCoreSummaryValue='true'] {{
        color: {c['text']};
        font-size: 13px;
        font-weight: 700;
    }}
    QLabel[dashboardCoreSummaryDetail='true'] {{
        color: {c['muted']};
        font-size: 10px;
        font-weight: 600;
    }}
    QLabel[dashboardCoreUsage='true'] {{
        color: {c['muted']};
        font-size: 11px;
        font-weight: 700;
    }}
    QFrame[dashboardCoreCell='true'] {{
        background: transparent;
        border: none;
        border-top: 1px solid {c['border_soft']};
        min-height: 26px;
    }}
    QLabel[dashboardCoreName='true'] {{
        color: {c['muted']};
        font-size: 10px;
        font-weight: 750;
    }}
    QLabel[dashboardCoreFrequency='true'] {{
        color: {c['text']};
        font-size: 12px;
        font-weight: 700;
    }}
    QLabel[dashboardCoreSeparator='true'] {{
        color: {c['muted']};
        font-size: 10px;
    }}
    QLabel[dashboardFrequencyValue='true'] {{
        color: {c['text']};
        font-size: 64px;
        font-weight: 800;
    }}
    QLabel[dashboardFrequencyUnit='true'] {{
        color: {c['muted']};
        font-size: 18px;
        font-weight: 780;
        padding-bottom: 9px;
    }}
    QLabel[dashboardFrequencyEyebrow='true'] {{
        color: {c['muted']};
        font-size: 10px;
        font-weight: 820;
    }}
    QLabel[dashboardFrequencyCopy='true'] {{
        color: {c['muted']};
        font-size: 10px;
    }}
    QLabel[dashboardEvidenceLabel='true'] {{
        color: {c['muted']};
        font-size: 10px;
    }}
    QLabel[dashboardEvidenceValue='true'] {{
        color: {c['text']};
        font-size: 10px;
        font-weight: 760;
    }}
    QPushButton[dashboardPrimaryAction='true'] {{
        min-height: 22px;
        padding: 8px 12px;
        background: {c['blue']};
        border: 1px solid {c['blue']};
        border-radius: 9px;
        color: {c['on_blue']};
        font-weight: 790;
    }}
    QPushButton[dashboardPrimaryAction='true']:hover {{
        background: {c['blue_hover']};
        border-color: {c['blue_hover']};
    }}
    QLabel[dashboardModuleHeadline='true'] {{
        color: {c['text']};
        font-size: 26px;
        font-weight: 780;
    }}
    QLabel[dashboardModuleUnit='true'] {{
        color: {c['muted']};
        font-size: 13px;
        font-weight: 730;
        padding-bottom: 4px;
    }}
    QPushButton[dashboardCardAction='true'] {{
        min-height: 20px;
        padding: 6px 10px;
        background: {c['panel_alt']};
        border: 1px solid {c['border_soft']};
        border-radius: 9px;
        color: {c['text']};
        font-size: 11px;
        font-weight: 720;
    }}
    QPushButton[dashboardCardAction='true']:hover,
    QPushButton[dashboardCardAction='true']:focus {{
        background: {c['control_hover']};
        border-color: {c['blue_border']};
        color: {c['blue']};
    }}
    /* A metric tile is already painted in panel_alt, so a card action sitting
       inside one would be the exact same colour as its own background and read
       as a flat outline. Lift it to the control surface, one step up. */
    QFrame[dashboardMetricTile='true'] QPushButton[dashboardCardAction='true'] {{
        background: {c['control']};
    }}
    QFrame[dashboardMetricTile='true'] QPushButton[dashboardCardAction='true']:hover,
    QFrame[dashboardMetricTile='true'] QPushButton[dashboardCardAction='true']:focus {{
        background: {c['control_hover']};
    }}
    /* Same problem as the metric tile above: a compatibility card is also
       painted in panel_alt, so its action buttons need lifting a step too —
       otherwise they read as barely-visible outlines against the card. */
    QFrame[dashboardPreparationInfo='true'] QPushButton[dashboardCardAction='true'] {{
        background: {c['control']};
        border-color: {c['border_strong']};
    }}
    QFrame[dashboardPreparationInfo='true'] QPushButton[dashboardCardAction='true']:hover,
    QFrame[dashboardPreparationInfo='true'] QPushButton[dashboardCardAction='true']:focus {{
        background: {c['control_hover']};
    }}
    /* The recommended action in a row that ends in a plain link (see
       PreparationInfoCard._refresh_action_styles) gets a light accent fill
       on top of the existing blue text/border, so it reads as "the" button
       instead of just another box the same weight as its neighbours. */
    QFrame[dashboardPreparationInfo='true'] QPushButton[dashboardCardAction='true'][accented='true'] {{
        background: {c['blue_soft']};
    }}
    QFrame[dashboardPreparationInfo='true'] QPushButton[dashboardCardAction='true'][accented='true']:hover,
    QFrame[dashboardPreparationInfo='true'] QPushButton[dashboardCardAction='true'][accented='true']:focus {{
        background: {c['blue_soft']};
        border-color: {c['blue']};
    }}
    /* A link action opens a browser tab, not a workflow — it should read as
       the lightest-weight choice in the row: no box, just coloured text.
       Repeated with the dashboardPreparationInfo ancestor so it outranks the
       "lift the button a step above panel_alt" rule above on specificity —
       without this scoped copy, that rule's background/border quietly won
       and every link kept its box. */
    QPushButton[dashboardCardAction='true'][linkAction='true'],
    QFrame[dashboardPreparationInfo='true'] QPushButton[dashboardCardAction='true'][linkAction='true'] {{
        background: transparent;
        border-color: transparent;
        color: {c['muted']};
    }}
    QPushButton[dashboardCardAction='true'][linkAction='true']:hover,
    QPushButton[dashboardCardAction='true'][linkAction='true']:focus,
    QFrame[dashboardPreparationInfo='true'] QPushButton[dashboardCardAction='true'][linkAction='true']:hover,
    QFrame[dashboardPreparationInfo='true'] QPushButton[dashboardCardAction='true'][linkAction='true']:focus {{
        background: transparent;
        border-color: transparent;
        color: {c['blue']};
    }}
    QPushButton[dashboardTelemetryAction='true'] {{
        min-height: 26px;
        padding: 8px 12px;
        background: {c['red']};
        border: 1px solid {c['red']};
        border-radius: 9px;
        color: {c['on_red']};
        font-size: 12px;
        font-weight: 780;
    }}
    QPushButton[dashboardTelemetryAction='true']:hover {{
        background: {c['red_hover']};
        border-color: {c['red_hover']};
    }}
    QPushButton[dashboardTelemetryAction='true']:disabled {{
        background: {c['disabled_bg']};
        border-color: {c['disabled_bg']};
        color: {c['disabled_text']};
    }}
    QFrame[fsr4LaunchOption='true'] {{
        background: {c['panel']};
        border: 1px solid {c['border_soft']};
        border-radius: 9px;
    }}
    QPushButton[fsr4LaunchCopy='true'] {{
        min-width: 30px;
        max-width: 30px;
        min-height: 30px;
        max-height: 30px;
        padding: 0;
        background: {c['purple_soft']};
        border: 1px solid {c['purple_border']};
        border-radius: 15px;
        color: {c['purple']};
        font-size: 15px;
        font-weight: 800;
    }}
    QPushButton[fsr4LaunchCopy='true']:hover,
    QPushButton[fsr4LaunchCopy='true']:focus {{
        background: {c['control_hover']};
        border-color: {c['purple']};
    }}
    QWidget[dashboardPreparationTabs='true'] {{
        background: transparent;
        border-top: 1px solid {c['border_soft']};
        border-bottom: 1px solid {c['border_soft']};
    }}
    QFrame[dashboardPreparationSystem='true'] {{
        background: {c['panel_alt']};
        border-top: 1px solid {c['border_soft']};
        border-bottom: 1px solid {c['border_soft']};
    }}
    QPushButton[dashboardPreparationTab='true'] {{
        min-height: 22px;
        padding: 5px 10px;
        background: transparent;
        border: 1px solid transparent;
        border-radius: 7px;
        color: {c['muted']};
        font-size: 12px;
        font-weight: 700;
    }}
    QPushButton[dashboardPreparationTab='true']:checked {{
        background: {c['blue_soft']};
        color: {c['blue']};
    }}
    QPushButton[dashboardPreparationTab='true']:hover,
    QPushButton[dashboardPreparationTab='true']:focus {{
        border-color: {c['border_strong']};
        color: {c['text']};
    }}
    QFrame[dashboardComponentCard='true'],
    QFrame[dashboardPreparationInfo='true'] {{
        background: {c['panel_alt']};
        border: 1px solid {c['border_soft']};
        border-radius: 11px;
    }}
    QFrame[dashboardPreparationInfo='true']:hover {{
        border-color: {c['border_strong']};
    }}
    /* In a list row the buttons sit straight on the row. A second bordered
       box around them made three nested outlines (list, panel, button). */
    QFrame[dashboardPreparationInfo='true'][listRow='true'] QFrame[dashboardCompatibilityActions='true'],
    QFrame[dashboardPreparationInfo='true'][listRow='true'] QFrame[dashboardCompatibilityState='true'] {{
        background: transparent;
        border: none;
        border-radius: 0px;
        padding: 0px;
    }}
    /* Boot options (mitigations, SMT, read-only): the card action sits on a
       panel painted in panel_alt, so it is lifted a step like the ones in the
       compatibility rows, and every state of it keeps the same shape. */
    QFrame[dashboardBootPanel='true'] QPushButton[dashboardCardAction='true'] {{
        min-height: 20px;
        padding: 6px 12px;
        border-radius: 9px;
        background: {c['control']};
        border: 1px solid {c['border_strong']};
        color: {c['text']};
        font-size: 11px;
        font-weight: 720;
    }}
    QFrame[dashboardBootPanel='true'] QPushButton[dashboardCardAction='true']:hover,
    QFrame[dashboardBootPanel='true'] QPushButton[dashboardCardAction='true']:focus {{
        background: {c['control_hover']};
        border-color: {c['blue_border']};
        color: {c['blue']};
    }}
    QFrame[dashboardBootPanel='true'] QPushButton[dashboardCardAction='true'][dangerAction='true'] {{
        background: {c['red_soft']};
        border-color: {c['red_border']};
        color: {c['red']};
    }}
    QFrame[dashboardBootPanel='true'] QPushButton[dashboardCardAction='true'][dangerAction='true']:hover,
    QFrame[dashboardBootPanel='true'] QPushButton[dashboardCardAction='true'][dangerAction='true']:focus {{
        background: {c['red_soft']};
        border-color: {c['red']};
        color: {c['red']};
    }}
    QFrame[dashboardCompatibilityGroupBox='true'] {{
        background: {c['panel_alt']};
        border: 1px solid {c['border_soft']};
        border-radius: 11px;
    }}
    QFrame[dashboardPreparationInfo='true'][listRow='true'],
    QFrame[dashboardPreparationInfo='true'][listRow='true']:hover {{
        background: transparent;
        border: none;
        border-top: 1px solid {c['border_soft']};
        border-radius: 0px;
    }}
    QFrame[dashboardPreparationInfo='true'][listRow='true'][listFirst='true'],
    QFrame[dashboardPreparationInfo='true'][listRow='true'][listFirst='true']:hover {{
        border-top: none;
    }}
    /* The component checklist row is a checkbox and a one-line label — it
       does not need the same footprint as a full compatibility card, so it
       gets a tighter radius to read as a smaller, denser control. */
    QFrame[dashboardComponentCard='true'] {{
        border-radius: 8px;
    }}
    QFrame[dashboardComponentCard='true']:hover {{
        border-color: {c['border_strong']};
    }}
    QFrame[dashboardCompatibilityFilter='true'] {{
        background: {c['blue_soft']};
        border: 1px solid {c['blue_border']};
        border-radius: 10px;
    }}
    QFrame[dashboardCompatibilityActions='true'],
    QFrame[dashboardCompatibilityState='true'] {{
        background: {c['panel']};
        border: 1px solid {c['border_soft']};
        border-radius: 9px;
        padding: 6px;
    }}
    QLabel[dashboardCompatibilityGroup='true'] {{
        color: {c['subtle']};
        font-size: 9px;
        font-weight: 820;
        letter-spacing: 0.9px;
        padding: 14px 2px 2px 2px;
    }}
    QToolButton[dashboardDisclosure='true'] {{
        background: transparent;
        border: 0px;
        color: {c['muted']};
        font-size: 13px;
        font-weight: 700;
        padding: 0px 4px;
    }}
    QToolButton[dashboardDisclosure='true']:hover,
    QToolButton[dashboardDisclosure='true']:focus {{
        color: {c['text']};
    }}
    QLabel[dashboardCompatibilityLabel='true'] {{
        color: {c['muted']};
        font-size: 10px;
        font-weight: 700;
    }}
    QLabel[dashboardComponentTitle='true'] {{
        color: {c['text']};
        font-size: 12px;
        font-weight: 650;
    }}
    QLabel[dashboardComponentDetail='true'] {{
        color: {c['muted']};
        font-size: 9px;
    }}
    QLabel[dashboardDeckyPreview='true'] {{
        background: {c['panel']};
        border: 1px solid {c['border_soft']};
        border-radius: 10px;
        padding: 8px;
    }}
    QPushButton[dashboardComponentCheck='true'] {{
        width: 26px;
        height: 26px;
        min-width: 26px;
        max-width: 26px;
        min-height: 26px;
        max-height: 26px;
        padding: 0px;
        border: 1px solid {c['border_strong']};
        border-radius: 6px;
        background: {c['control_pressed']};
        color: transparent;
        font-size: 11px;
        font-weight: 900;
    }}
    QPushButton[dashboardComponentCheck='true']:checked {{
        background: {c['panel_raised']};
        border-color: {c['border_strong']};
        color: {c['text']};
    }}
    QFrame[dashboardMemoryNote='true'],
    QFrame[dashboardMemoryPanel='true'] {{
        background: {c['panel_alt']};
        border: 1px solid {c['border_soft']};
        border-radius: 8px;
    }}
    QFrame[dashboardMemoryNote='true'][tone='orange'] {{
        background: {c['orange_soft']};
        border: 1px solid {c['orange_border']};
        border-radius: 8px;
    }}
    QLabel[dashboardMemoryDetail='true'] {{
        color: {c['muted']};
        font-size: 10px;
    }}
    QLabel[dashboardMemoryWarning='true'] {{
        color: {c['orange']};
        font-size: 10px;
        font-weight: 650;
    }}
    QLabel[gpuBusNotice='true'] {{
        color: {c['orange']};
        font-size: 11px;
        font-weight: 650;
    }}
    QLabel[dashboardMemoryControlLabel='true'] {{
        color: {c['muted']};
        font-size: 10px;
        font-weight: 720;
        letter-spacing: 0.3px;
        text-transform: uppercase;
    }}
    QProgressBar[dashboardMemoryUsage='true'] {{
        background: {c['panel_raised']};
        border: 1px solid {c['border_soft']};
        border-radius: 3px;
    }}
    QProgressBar[dashboardMemoryUsage='true']::chunk {{
        background: {c['blue']};
        border-radius: 3px;
    }}
    QComboBox[dashboardMemoryCombo='true'] {{
        min-height: 28px;
        padding: 5px 9px;
        background: {c['panel_raised']};
        border: 1px solid {c['border_soft']};
        border-radius: 7px;
        color: {c['text']};
        font-size: 11px;
        font-weight: 650;
    }}
    QComboBox[dashboardMemoryCombo='true']:disabled {{
        color: {c['subtle']};
        background: {c['panel_alt']};
    }}
    QFrame[dashboardMemoryCard='true'] {{
        background: {c['panel']};
        border: 1px solid {c['border']};
        border-radius: 16px;
    }}
    QFrame[dashboardMemoryOptionRow='true'] {{
        background: {c['panel_alt']};
        border: 1px solid {c['border_soft']};
        border-radius: 10px;
    }}
    QFrame[dashboardMemoryOptionRow='true']:hover {{
        border-color: {c['border_strong']};
    }}
    QFrame[dashboardMemoryOptionRow='true']:focus {{
        border-color: {c['blue']};
    }}
    QFrame[dashboardMemoryOptionRow='true'][selected='true'] {{
        background: {c['blue_soft']};
        border: 1.5px solid {c['blue']};
    }}
    QFrame[dashboardMemoryOptionRow='true']:disabled {{
        background: {c['panel_alt']};
        border-color: {c['border_soft']};
    }}
    QFrame[dashboardMemoryOptionIndicator='true'] {{
        border-radius: 8px;
        border: 1.5px solid {c['border_strong']};
        background: {c['panel']};
    }}
    QFrame[dashboardMemoryOptionIndicator='true'][selected='true'] {{
        border: 5px solid {c['blue']};
        background: {c['panel_alt']};
    }}
    QPushButton[dashboardMemoryChip='true'] {{
        background: {c['window']};
        border: 1px solid {c['border']};
        border-radius: 9px;
        padding: 7px 12px;
        color: {c['muted']};
        font-size: 12px;
        font-weight: 700;
    }}
    QPushButton[dashboardMemoryChip='true']:hover {{
        border-color: {c['border_strong']};
    }}
    QPushButton[dashboardMemoryChip='true']:checked {{
        background: {c['blue_soft']};
        border: 1.5px solid {c['blue']};
        color: {c['blue']};
        font-weight: 800;
    }}
    QPushButton[dashboardMemoryChip='true']:disabled {{
        color: {c['disabled_text']};
        background: {c['disabled_bg']};
        border-color: {c['border_soft']};
    }}
    QWidget[dashboardPreparationFooter='true'] {{
        border-top: 1px solid {c['border_soft']};
    }}
    QPushButton[dependencyPrepareButton='true'][dashboardPrepareAction='true'] {{
        min-height: 22px;
        padding: 7px 16px;
        font-size: 12px;
        font-weight: 700;
    }}
    QPushButton[dashboardFooterAction='true'] {{
        min-width: 34px;
        max-width: 34px;
        min-height: 34px;
        max-height: 34px;
        padding: 0;
        background: {c['panel']};
        border: 1px solid {c['border']};
        border-radius: 17px;
        color: {c['text']};
    }}
    QPushButton[dashboardFooterAction='true']:hover,
    QPushButton[dashboardFooterAction='true']:focus {{
        background: {c['blue_soft']};
        border-color: {c['blue_border']};
        color: {c['blue']};
    }}
    QPushButton[dashboardFooterAction='true'][donation='true']:hover,
    QPushButton[dashboardFooterAction='true'][donation='true']:focus {{
        background: {c['control_hover']};
        border-color: {c['border_strong']};
    }}
    /* The update badge keeps the accent even at rest: it is only on screen
       when there is something to act on, so it should not look like the
       neutral links beside it. Tinted with the active accent color rather
       than a fixed hue, so it always matches what the user picked. */
    QPushButton[dashboardFooterAction='true'][updateAvailable='true'] {{
        background: {c['blue_soft']};
        border-color: {c['blue_border']};
        color: {c['blue']};
    }}
    QPushButton[dashboardFooterAction='true'][updateAvailable='true']:hover,
    QPushButton[dashboardFooterAction='true'][updateAvailable='true']:focus {{
        background: {c['blue']};
        color: {c['on_blue']};
        border-color: {c['blue']};
    }}
    /* The callout draws its own body and tail, so the frame itself must stay
       transparent; only the text and the two buttons are styled here. */
    QFrame#updateCallout {{ background: transparent; border: none; }}
    QFrame#updateCallout QLabel[updateCalloutTitle='true'] {{
        color: {c['text']};
        font-size: 12px;
        font-weight: 800;
        background: transparent;
    }}
    QFrame#updateCallout QLabel[updateCalloutDetail='true'] {{
        color: {c['muted']};
        font-size: 11px;
        font-weight: 550;
        background: transparent;
    }}
    QPushButton#updateCalloutAction {{
        margin-top: 6px;
        min-height: 28px;
        padding: 0 12px;
        background: {c['blue']};
        border: 1px solid {c['blue']};
        border-radius: 8px;
        color: {c['on_blue']};
        font-size: 11px;
        font-weight: 750;
    }}
    QPushButton#updateCalloutAction:hover,
    QPushButton#updateCalloutAction:focus {{
        background: {c['blue_soft']};
        color: {c['blue']};
    }}
    QPushButton#updateCalloutClose {{
        background: transparent;
        border: none;
        padding: 0;
    }}
    QPushButton[dashboardFooterAction='true']:pressed {{
        background: {c['control_pressed']};
    }}
    QPushButton[dashboardGhostAction='true'] {{
        min-height: 22px;
        padding: 7px 10px;
        background: transparent;
        border: 1px solid {c['border']};
        border-radius: 9px;
        color: {c['muted']};
        font-size: 10px;
        font-weight: 720;
    }}
    QFrame#SummaryDivider {{
        background: {c['border_soft']};
        border: none;
        min-width: 1px;
        max-width: 1px;
    }}
    QDialog#InfoDialog {{
        background: transparent;
    }}
    /* The outcome of an action, from the window's corner: raised one step
       above the page so it reads as a notice, not as part of a card. */
    QFrame#AppToast {{
        background: {c['panel_raised'] if ACTIVE_MODE == 'dark' else c['panel']};
        border: 1px solid {c['border_strong']};
        border-radius: 10px;
    }}
    QLabel#AppToastTitle {{
        color: {c['text']};
        font-size: 13px;
        font-weight: 700;
        background: transparent;
    }}
    QLabel#AppToastMessage {{
        color: {c['muted']};
        font-size: 12px;
        background: transparent;
    }}
    QPushButton#AppToastClose {{
        background: transparent;
        border: none;
        border-radius: 6px;
        color: {c['subtle']};
        font-size: 11px;
        min-height: 0px;
        padding: 0px;
    }}
    QPushButton#AppToastClose:hover {{
        background: {c['control_hover']};
        color: {c['text']};
    }}
    QFrame#ControlDialogCard {{
        background: {c['panel']};
        border: 1px solid {c['border']};
        border-radius: 18px;
    }}
    QLabel#DialogEyebrow {{
        font-size: 10px;
        font-weight: 800;
        letter-spacing: 1px;
    }}
    QLabel#DialogTitle {{
        color: {c['text']};
        font-size: 19px;
        font-weight: 800;
    }}
    QLabel#DialogBody {{
        color: {c['muted']};
        font-size: 13px;
    }}
    QFrame#DialogNotice {{
        background: {c['blue_soft']};
        border: 1px solid {c['blue_border']};
        border-radius: 10px;
    }}
    QLabel#DialogNoticeText {{
        color: {c['muted']};
        font-size: 12px;
        font-weight: 600;
    }}
    QPushButton#DialogClose {{
        background: transparent;
        border: none;
        border-radius: 9px;
        padding: 5px;
    }}
    QPushButton#DialogClose:hover {{
        background: {c['control_hover']};
    }}
    QPushButton#DialogClose:pressed {{
        background: {c['control_pressed']};
    }}
    QPushButton#DialogPrimary {{
        background: {c['blue']};
        color: {c['on_blue']};
        border: 1px solid {c['blue']};
        border-radius: 9px;
        padding: 10px 18px;
        font-weight: 750;
    }}
    QPushButton#DialogPrimary:hover {{
        background: {c['blue_hover']};
        border-color: {c['blue_hover']};
    }}
    QPushButton#DialogPrimary:pressed {{
        background: {c['blue_pressed']};
        border-color: {c['blue_pressed']};
    }}
    QPushButton#DialogDanger {{
        background: {c['orange']};
        color: {c['on_orange']};
        border: 1px solid {c['orange']};
        border-radius: 9px;
        padding: 10px 18px;
        font-weight: 750;
    }}
    QPushButton#DialogDanger:hover {{
        background: {c['orange_hover']};
        border-color: {c['orange_hover']};
    }}
    QPushButton#PrimaryAction, QPushButton[primaryAction='true'] {{
        background: {c['blue']};
        color: {c['on_blue']};
        border: 1px solid {c['blue']};
        border-radius: 11px;
        padding: 10px 16px;
        font-weight: 780;
    }}
    QPushButton#PrimaryAction:hover, QPushButton[primaryAction='true']:hover {{
        background: {c['blue_hover']};
        border-color: {c['blue_hover']};
    }}
    QPushButton#PrimaryAction:disabled, QPushButton[primaryAction='true']:disabled {{
        background: {c['disabled_bg']};
        border-color: {c['disabled_bg']};
        color: {c['disabled_text']};
    }}
    QPushButton#PrimaryAction[cuApplyAction='true'] {{
        background: {c['cyan']};
        border-color: {c['cyan']};
        color: {c['on_cyan']};
    }}
    QPushButton#PrimaryAction[cuApplyAction='true']:hover {{
        background: {c['cyan_hover']};
        border-color: {c['cyan_hover']};
    }}
    QPushButton#PrimaryAction[cuApplyAction='true']:disabled {{
        background: {c['disabled_bg']};
        border-color: {c['disabled_bg']};
        color: {c['disabled_text']};
    }}
    QPushButton[dangerAction='true'] {{
        background: {c['red_soft']};
        color: {c['red']};
        border: 1px solid {c['red_border']};
        border-radius: 10px;
        padding: 8px 13px;
        font-weight: 760;
    }}
    QPushButton[dangerAction='true']:hover {{
        background: {c['red_soft']};
        border-color: {c['red_border']};
    }}
    /* The generic danger button (8px 13px, radius 10) is declared after the
       card action rule and won, so Uninstall / Remove came out taller than
       the buttons beside them. In a card it keeps the card button's shape. */
    QPushButton[dashboardCardAction='true'][dangerAction='true'] {{
        padding: 6px 10px;
        border-radius: 9px;
        font-weight: 720;
    }}
    QPushButton[successAction='true'] {{
        background: {c['green_soft']};
        color: {c['green']};
        border: 1px solid {c['green_border']};
        border-radius: 10px;
        padding: 8px 13px;
        font-weight: 760;
    }}
    QPushButton[successAction='true']:hover {{
        background: {c['green_soft']};
        border-color: {c['green']};
    }}
    QFrame[pageCard='true'] {{
        background: {c['panel']};
        border: 1px solid {c['border']};
        border-radius: 20px;
    }}
    /* Additional settings > Upscaling: the app's page cards, set tighter
       for a working tool: small radii, one button height (32 px), quiet
       secondary buttons, red text rather than a pink pill for removal,
       solid blue only for the next step, and the games as a bordered table
       with a header band. */
    QFrame[pageCard='true'][upscalerSection='true'],
    QFrame[pageCard='true'][upscalingGames='true'],
    QFrame[pageCard='true'][helixsrSettings='true'] {{
        background: {upscaling_card};
        border: 1px solid {upscaling_line};
        border-radius: 10px;
    }}
    QFrame[pageCard='true'][upscalerSection='true'] QPushButton[compactAction='true'],
    QFrame[pageCard='true'][upscalerSection='true'] QPushButton[accentAction='true'],
    QFrame[pageCard='true'][upscalerSection='true'] QPushButton[dangerAction='true'],
    QFrame[pageCard='true'][upscalingGames='true'] QPushButton[compactAction='true'] {{
        min-height: 18px;
        padding: 6px 12px;
        background: {upscaling_field};
        border: 1px solid {upscaling_line_strong};
        border-radius: 7px;
        color: {c['text']};
        font-size: 12px;
        font-weight: 600;
    }}
    QFrame[pageCard='true'][upscalerSection='true'] QPushButton[compactAction='true']:hover,
    QFrame[pageCard='true'][upscalerSection='true'] QPushButton[accentAction='true']:hover,
    QFrame[pageCard='true'][upscalingGames='true'] QPushButton[compactAction='true']:hover {{
        background: {c['control_hover']};
        border-color: {c['border_strong']};
    }}
    QFrame[pageCard='true'][upscalerSection='true'] QPushButton[dangerAction='true'] {{
        color: {c['red']};
    }}
    QFrame[pageCard='true'][upscalerSection='true'] QPushButton[dangerAction='true']:hover {{
        background: {c['red_soft']};
        border-color: {c['red']};
    }}
    QFrame[pageCard='true'][upscalerSection='true'] QPushButton#PrimaryAction {{
        min-height: 18px;
        padding: 6px 16px;
        background: {c['blue']};
        border: 1px solid {c['blue']};
        border-radius: 7px;
        color: {c['on_blue']};
        font-size: 12px;
        font-weight: 650;
    }}
    QFrame[pageCard='true'][upscalerSection='true'] QPushButton#PrimaryAction:hover {{
        background: {c['blue_hover']};
        border-color: {c['blue_hover']};
    }}
    QFrame[pageCard='true'][upscalerSection='true'] QPushButton:disabled {{
        background: {upscaling_card};
        border-color: {upscaling_line};
        color: {c['disabled_text']};
    }}
    QFrame[upscalingGames='true'] QFrame[compactPanel='true'],
    QFrame[upscalingGames='true'] QFrame[compactPanel='true']:hover {{
        background: transparent;
        border: 1px solid {upscaling_line};
        border-radius: 8px;
    }}
    QFrame[upscalingGames='true'] QFrame[compactPanel='true'] QLineEdit {{
        background: {upscaling_field};
        border: 1px solid {upscaling_line};
        min-height: 18px;
        padding: 5px 10px;
        border-radius: 7px;
        font-family: 'JetBrains Mono', 'Noto Sans Mono', monospace;
        font-size: 12px;
    }}
    QFrame[settingsGroupRow='true'] {{
        background: transparent;
        border: none;
        border-top: 1px solid {upscaling_line};
        border-radius: 0px;
    }}
    QFrame[helixsrSettings='true'] QFrame[dashboardCompatibilityGroupBox='true'] {{
        background: {upscaling_card};
        border: 1px solid {upscaling_line};
    }}
    QFrame[upscalerHead='true'] {{
        background: {upscaling_head};
        border: none;
        border-bottom: 1px solid {upscaling_line};
        border-top-left-radius: 9px;
        border-top-right-radius: 9px;
        border-bottom-left-radius: 0px;
        border-bottom-right-radius: 0px;
    }}
    QFrame[settingsGroupHead='true'] {{
        background: {upscaling_head};
        border: none;
        border-top: 1px solid {upscaling_line};
        border-radius: 0px;
    }}
    QFrame[settingsGroupHead='true'][listFirst='true'] {{
        border-top: none;
        border-top-left-radius: 10px;
        border-top-right-radius: 10px;
    }}
    QFrame[settingsGroupRow='true'][listFirst='true'] {{
        border-top: none;
    }}
    QLabel[settingsSummary='true'] {{
        color: {c['muted']};
        font-size: 12px;
    }}
    QFrame[helixsrSettings='true'] QWidget[settingRow='true'] {{
        border: none;
        border-bottom: 1px solid {upscaling_line};
    }}
    QFrame[helixsrSettings='true'] QLabel[settingHint='true'] {{
        color: {c['subtle']};
        font-size: 11px;
    }}
    QFrame[helixsrSettings='true'] QComboBox {{
        background: {upscaling_field};
        border: 1px solid {upscaling_line};
        min-height: 18px;
        padding: 4px 8px;
    }}
    /* The two upscaler cards: thinner buttons, as on the other tabs. */
    QFrame[pageCard='true'][upscalerSection='true'] QPushButton[compactAction='true'],
    QFrame[pageCard='true'][upscalerSection='true'] QPushButton[dangerAction='true'],
    QFrame[pageCard='true'][upscalerSection='true'] QPushButton#PrimaryAction {{
        min-height: 14px;
        padding: 4px 12px;
    }}
    QFrame[upscalerSection='true'] QLabel[fieldHint='true'] {{
        color: {c['muted']};
        font-size: 12px;
    }}
    QLabel[engineVersion='true'] {{
        color: {c['subtle']};
        font-family: 'JetBrains Mono', 'Noto Sans Mono', monospace;
        font-size: 12px;
        padding: 0px;
    }}
    QFrame[gameTable='true'] {{
        background: transparent;
        border: 1px solid {upscaling_line};
        border-radius: 8px;
    }}
    QFrame[gameTableHead='true'] {{
        background: {upscaling_head};
        border: none;
        border-bottom: 1px solid {upscaling_line_strong};
        border-top-left-radius: 8px;
        border-top-right-radius: 8px;
    }}
    QLabel[gameColumn='true'] {{
        color: {c['muted']};
        font-size: 10px;
        font-weight: 700;
        padding: 9px 0px;
    }}
    QLabel[gameName='true'] {{
        color: {c['text']};
        font-size: 12px;
        font-weight: 600;
    }}
    /* Formal type: names at 14 px, readings in regular weight, small
       outlined buttons in the table. */
    QFrame[pageCard='true'][upscalerSection='true'] QLabel[cardTitle='true'],
    QFrame[pageCard='true'][upscalingGames='true'] QLabel[cardTitle='true'] {{
        font-size: 14px;
        font-weight: 650;
    }}
    QFrame[upscalerSection='true'] QLabel[readingValue='true'] {{
        font-size: 12px;
        font-weight: 600;
    }}
    QFrame[upscalerSection='true'] QLabel[readingLabel='true'] {{
        font-size: 12px;
    }}
    QFrame[pageCard='true'][upscalingGames='true'] QFrame[gameTable='true'] QPushButton[compactAction='true'] {{
        min-height: 14px;
        padding: 4px 10px;
        font-size: 11px;
        font-weight: 600;
    }}
    QFrame[pageCard='true'][upscalingGames='true'] QFrame[gameTable='true'] QPushButton[dangerAction='true'] {{
        color: {c['red']};
    }}
    QLabel[gameDetail='true'] {{
        color: {c['subtle']};
        font-size: 10px;
        font-weight: 600;
    }}
    QLabel[gameState='true'] {{
        color: {c['muted']};
        font-size: 12px;
        font-weight: 500;
    }}
    QLabel[gameState='true'][tone='good'] {{ color: {c['green']}; }}
    QLabel[gameState='true'][tone='warning'] {{ color: {c['orange']}; }}
    QLabel[gameState='true'][tone='danger'] {{ color: {c['red']}; }}
    QFrame[upscalingGames='true'] QLineEdit[gameSearch='true'] {{
        min-height: 18px;
        padding: 5px 10px;
        border-radius: 7px;
    }}
    QFrame[metricTile='true'] {{
        background: {c['panel_alt']};
        border: 1px solid {c['border_soft']};
        border-radius: 12px;
    }}
    QLabel[metricTileLabel='true'] {{
        color: {c['muted']};
        font-size: 10px;
        font-weight: 700;
    }}
    QLabel[metricTileValue='true'] {{
        color: {c['text']};
        font-size: 19px;
        font-weight: 830;
    }}
    QLabel[metricTileDetail='true'] {{
        color: {c['subtle']};
        font-size: 9px;
    }}
    QFrame[profileCard='true'] {{
        background: {c['panel_alt']};
        border: 1px solid {c['border_soft']};
        border-radius: 12px;
    }}
    QFrame[profileCard='true']:hover {{
        background: {c['panel']};
        border-color: {c['border_strong']};
    }}
    QFrame[profileCard='true']:focus {{
        border: 1px solid {c['blue']};
    }}
    QLabel[profileTitle='true'] {{
        color: {c['text']};
        font-size: 13px;
        font-weight: 780;
    }}
    QLabel[profileDescription='true'] {{
        color: {c['muted']};
        font-size: 10px;
    }}
    QLabel[valueChip='true'] {{
        color: {c['muted']};
        border: 1px solid {c['border_soft']};
        border-radius: 7px;
        padding: 4px 7px;
        font-size: 9px;
        font-weight: 700;
    }}
    QLabel[fieldLabel='true'] {{
        color: {c['muted']};
        font-size: 10px;
        font-weight: 760;
    }}
    QLabel[fieldHint='true'] {{
        /* 9 px text never reaches its full colour through antialiasing; on
           light surfaces it takes the firmer grey to stay above 4.5:1. */
        color: {c['muted'] if ACTIVE_MODE == 'light' else c['subtle']};
        font-size: 9px;
    }}
    QLabel[workflowStepNumber='true'] {{
        color: {c['blue']};
        background: transparent;
        border: none;
        font-size: 15px;
        font-weight: 850;
    }}
    QLabel[workflowStepTitle='true'] {{
        color: {c['text']};
        font-size: 12px;
        font-weight: 800;
    }}
    QLabel[workflowStepDetail='true'] {{
        color: {c['muted']};
        font-size: 10px;
    }}
    QSpinBox, QComboBox, QLineEdit {{
        background: {c['control']};
        border: 1px solid {c['border']};
        border-radius: 11px;
        padding: 9px 11px;
        min-height: 20px;
        font-weight: 710;
        selection-background-color: {c['blue_soft']};
    }}
    QSpinBox:focus, QComboBox:focus, QLineEdit:focus {{
        border-color: {c['focus']};
    }}
    QPlainTextEdit#OperationConsole {{
        background: {c['console_bg']};
        color: {c['console_text']};
        border: 1px solid {c['console_border']};
        border-radius: 11px;
        padding: 10px;
        font-family: 'JetBrains Mono', 'Noto Sans Mono', monospace;
        font-size: 10px;
        selection-background-color: {c['selection']};
    }}
    /* ------------------------------------------------------------------
       The first-run panel. Glass: the card is translucent so the frosted
       portrait of the application shows through it, and it carries a light
       edge rather than a drawn border because that is what reads as a pane
       of glass lit from above. Everything inside it is the application's own
       vocabulary — the same radii, the same accent, the same type scale —
       because this is the first thing anyone sees of it.
       ------------------------------------------------------------------ */
    QWidget#onboardingOverlay {{
        background: transparent;
    }}
    QFrame#onboardingCard {{
        background: {glass_card};
        border: 1px solid {glass_edge};
        border-radius: 18px;
    }}
    QWidget#onboardingRail {{
        background: {glass_rail};
        border-right: 1px solid {c['border_soft']};
        border-top-left-radius: 18px;
        border-bottom-left-radius: 18px;
    }}
    QWidget#onboardingContent {{ background: transparent; }}
    QLabel#onboardingBrand {{
        color: {c['text']};
        font-size: 15px;
        font-weight: 800;
        letter-spacing: -0.2px;
    }}
    QLabel#onboardingBrandNote {{
        color: {c['blue']};
        font-size: 11px;
        font-weight: 760;
        text-transform: uppercase;
        letter-spacing: 0.8px;
    }}
    QPushButton#onboardingStepRow {{
        background: transparent;
        border: 1px solid transparent;
        border-radius: 9px;
        padding: 9px 10px;
        text-align: left;
        color: {c['muted']};
        font-size: 12px;
        font-weight: 640;
    }}
    QPushButton#onboardingStepRow:hover {{
        background: {c['control_hover']};
        color: {c['text']};
    }}
    QPushButton#onboardingStepRow[done='true'] {{ color: {c['text']}; }}
    QPushButton#onboardingStepRow:checked {{
        background: {c['blue_soft']};
        border-color: {c['blue']};
        color: {c['blue']};
        font-weight: 780;
    }}
    QLabel#onboardingTitle {{
        color: {c['text']};
        font-size: 25px;
        font-weight: 800;
        letter-spacing: -0.5px;
    }}
    QLabel#onboardingSubtitle {{
        color: {c['muted']};
        font-size: 13px;
    }}
    QLabel#onboardingBody {{
        color: {c['text']};
        font-size: 13px;
    }}
    QLabel#onboardingSectionLabel {{
        color: {c['muted']};
        font-size: 11px;
        font-weight: 760;
        text-transform: uppercase;
        letter-spacing: 0.7px;
    }}
    /* A quiet line of small print beside a control, not a heading for it. */
    QLabel#onboardingHint {{
        color: {c['muted']};
        font-size: 12px;
        font-weight: 480;
    }}
    QLabel#onboardingCaption {{
        color: {c['text']};
        font-size: 12px;
        font-weight: 680;
    }}
    /* The language list's own scrollbar. The global rule leaves the track
       pages unstyled, which the platform then paints solid — invisible over
       a dark panel, a black bar down the side of a pane of glass. */
    QScrollArea#onboardingScroll QScrollBar:vertical {{
        background: transparent;
        width: 8px;
        margin: 2px 0px 2px 0px;
        border: none;
    }}
    QScrollArea#onboardingScroll QScrollBar::handle:vertical {{
        background: {c['border_strong']};
        border-radius: 4px;
        min-height: 36px;
    }}
    QScrollArea#onboardingScroll QScrollBar::handle:vertical:hover {{
        background: {c['subtle']};
    }}
    QScrollArea#onboardingScroll QScrollBar::add-line:vertical,
    QScrollArea#onboardingScroll QScrollBar::sub-line:vertical {{
        height: 0px;
        background: transparent;
        border: none;
    }}
    /* The track above and below the handle. Separately, and without a height:
       giving a vertical page rule a height of zero is what left the platform
       painting it itself, solid black down the side of the glass. */
    QScrollArea#onboardingScroll QScrollBar::add-page:vertical,
    QScrollArea#onboardingScroll QScrollBar::sub-page:vertical {{
        background: transparent;
        border: none;
    }}
    QLabel#onboardingStopChip {{
        color: {c['muted']};
        background: {c['neutral_soft']};
        border: 1px solid {c['border_soft']};
        border-radius: 8px;
        padding: 7px 11px;
        font-size: 12px;
        font-weight: 620;
    }}
    QLabel#onboardingProgress {{
        color: {c['subtle']};
        font-size: 12px;
        font-weight: 680;
    }}
    QPushButton#onboardingChip {{
        background: {c['control']};
        border: 1px solid {c['border_soft']};
        border-radius: 9px;
        padding: 7px 12px;
        color: {c['text']};
        font-size: 12px;
        font-weight: 620;
    }}
    QPushButton#onboardingChip:hover {{
        border-color: {c['border_strong']};
        background: {c['control_hover']};
    }}
    QPushButton#onboardingChip:checked {{
        background: {c['blue_soft']};
        border-color: {c['blue']};
        color: {c['blue']};
        font-weight: 760;
    }}
    QPushButton#onboardingPrimary {{
        background: {c['blue']};
        color: {c['on_accent']};
        border: none;
        border-radius: 10px;
        padding: 10px 22px;
        font-size: 13px;
        font-weight: 760;
    }}
    QPushButton#onboardingPrimary:hover {{ background: {c['blue_hover']}; }}
    QPushButton#onboardingSecondary {{
        background: {c['control']};
        color: {c['text']};
        border: 1px solid {c['border']};
        border-radius: 10px;
        padding: 10px 18px;
        font-size: 13px;
        font-weight: 680;
    }}
    QPushButton#onboardingSecondary:hover {{ background: {c['control_hover']}; }}
    QPushButton#onboardingGhost {{
        background: transparent;
        color: {c['muted']};
        border: none;
        border-radius: 8px;
        padding: 8px 6px;
        text-align: left;
        font-size: 12px;
        font-weight: 640;
    }}
    QPushButton#onboardingGhost:hover {{ color: {c['text']}; }}
    /* The terminal inside the first-run panel. It sits on the console's own
       ground rather than the card's, because it is a terminal and should look
       like one wherever it appears. */
    QFrame#onboardingConsole {{
        background: {c['console_bg']};
        border: 1px solid {c['console_border']};
        border-radius: 10px;
    }}
    QWidget#onboardingConsoleHeader {{
        background: {c['panel_alt']};
        border-bottom: 1px solid {c['console_border']};
        border-top-left-radius: 10px;
        border-top-right-radius: 10px;
    }}
    QLabel#onboardingConsoleTitle {{
        color: {c['text']};
        font-size: 12px;
        font-weight: 740;
    }}
    QLabel#onboardingConsoleState {{
        color: {c['muted']};
        font-size: 12px;
        font-weight: 680;
    }}
    QLabel#onboardingConsoleState[tone='running'] {{ color: {c['blue']}; }}
    QLabel#onboardingConsoleState[tone='ok'] {{ color: {c['green']}; }}
    QLabel#onboardingConsoleState[tone='failed'] {{ color: {c['red']}; }}
    /* The guided tour. The bubble is drawn, not styled — a tail that points
       at one particular widget is not something a stylesheet can express — so
       these rules dress its contents and leave the shell to paintEvent. */
    QFrame#tourCallout {{ background: transparent; }}
    QLabel#tourStep {{
        color: {c['blue']};
        font-size: 11px;
        font-weight: 800;
        letter-spacing: 0.6px;
    }}
    QLabel#tourTitle {{
        color: {c['text']};
        font-size: 15px;
        font-weight: 800;
        letter-spacing: -0.2px;
    }}
    QLabel#tourBody {{
        color: {c['muted']};
        font-size: 12px;
    }}
    /* A stop with more to say than a sentence: a list inside the bubble, set
       off by a hairline, its markers in the accent so they read as a list. */
    QFrame#tourPoints {{
        background: transparent;
        border: none;
        border-top: 1px solid {c['border_soft']};
    }}
    QLabel#tourPointMarker {{
        color: {c['blue']};
        font-size: 12px;
        font-weight: 800;
    }}
    QLabel#tourPoint {{
        color: {c['text']};
        font-size: 12px;
    }}
    QLabel#tourFootnote {{
        color: {c['muted']};
        font-size: 11px;
    }}
    QPushButton#tourPrimary {{
        background: {c['blue']};
        color: {c['on_accent']};
        border: none;
        border-radius: 8px;
        padding: 7px 16px;
        font-size: 12px;
        font-weight: 760;
    }}
    QPushButton#tourPrimary:hover {{ background: {c['blue_hover']}; }}
    QPushButton#tourSecondary {{
        background: {c['control']};
        color: {c['text']};
        border: 1px solid {c['border']};
        border-radius: 8px;
        padding: 7px 14px;
        font-size: 12px;
        font-weight: 680;
    }}
    QPushButton#tourSecondary:hover {{ background: {c['control_hover']}; }}
    QPushButton#tourGhost {{
        background: transparent;
        color: {c['subtle']};
        border: none;
        padding: 2px 4px;
        font-size: 11px;
        font-weight: 640;
    }}
    QPushButton#tourGhost:hover {{ color: {c['text']}; }}
    /* The docked terminal. It slides up from the foot of the window, so it
       carries a top border rather than a card outline and reaches both
       edges the way a docked panel does. */
    QFrame#consolePanel {{
        background: {c['console_bg']};
        border: none;
        border-top: 1px solid {c['border_strong']};
    }}
    QWidget#consoleHeader {{
        background: {c['panel_alt']};
        border-bottom: 1px solid {c['console_border']};
    }}
    /* The left half reads as the tab strip of a docked panel: the rule under
       each tab carries its workflow state, so the colour is visible even when
       the header is too narrow to show the words. With a single workflow the
       strip is one tab and looks exactly as the header always has; a second
       concurrent workflow simply adds one beside it. */
    QWidget#consoleTab {{
        border-bottom: 2px solid {c['border_strong']};
        border-radius: 0px;
    }}
    /* Only once there is a choice to make does a tab need to look selectable:
       the one on screen carries the terminal's own ground up into the header,
       and the others step back so the eye finds the live one first. */
    QWidget#consoleTabStrip[several='true'] QWidget#consoleTab[active='true'] {{
        background: {c['console_bg']};
        border-top-left-radius: 7px;
        border-top-right-radius: 7px;
    }}
    QWidget#consoleTabStrip[several='true'] QWidget#consoleTab[active='false'] {{
        background: transparent;
        border-bottom-color: {c['border_soft']};
    }}
    QLabel#consoleTitle[dim='true'] {{
        color: {c['muted']};
        font-weight: 620;
    }}
    QPushButton#consoleTabClose {{
        background: transparent;
        border: none;
        border-radius: 9px;
    }}
    QPushButton#consoleTabClose:hover {{
        background: {c['control_hover']};
    }}
    QPushButton#consoleTabClose:pressed {{
        background: {c['control_pressed']};
    }}
    QWidget#consoleTab[tone='running'] {{ border-bottom-color: {c['blue']}; }}
    QWidget#consoleTab[tone='ok'] {{ border-bottom-color: {c['green']}; }}
    QWidget#consoleTab[tone='failed'] {{ border-bottom-color: {c['red']}; }}
    QWidget#consoleTab[tone='warning'] {{ border-bottom-color: {c['orange']}; }}
    QLabel#consoleTitle {{
        color: {c['text']};
        font-weight: 760;
        font-size: 12px;
    }}
    QLabel#consoleState {{
        color: {c['muted']};
        font-size: 12px;
    }}
    QLabel#consoleState[tone='running'] {{ color: {c['blue']}; font-weight: 700; }}
    QLabel#consoleState[tone='ok'] {{ color: {c['green']}; font-weight: 700; }}
    QLabel#consoleState[tone='failed'] {{ color: {c['red']}; font-weight: 700; }}
    QLabel#consoleState[tone='warning'] {{ color: {c['orange']}; font-weight: 700; }}
    /* The selected tab of several wears the console's ground, which is dark
       in the light themes too: its words take the console's colours, or the
       title is dark on dark. The label carries the flag, as with "dim". */
    QLabel#consoleTitle[onConsole='true'] {{ color: {c['console_text']}; }}
    QLabel#consoleState[onConsole='true'] {{ color: {c['console_muted']}; }}
    QLabel#consoleState[onConsole='true'][tone='running'] {{ color: {c['console_blue']}; }}
    QLabel#consoleState[onConsole='true'][tone='ok'] {{ color: {c['console_green']}; }}
    QLabel#consoleState[onConsole='true'][tone='failed'] {{ color: {c['console_red']}; }}
    QLabel#consoleState[onConsole='true'][tone='warning'] {{ color: {c['console_orange']}; }}
    QPushButton#consoleHeaderButton {{
        background: transparent;
        color: {c['muted']};
        border: 1px solid transparent;
        border-radius: 7px;
        padding: 3px 10px;
        font-size: 12px;
        font-weight: 640;
    }}
    QPushButton#consoleHeaderButton:hover {{
        background: {c['control_hover']};
        color: {c['text']};
        border-color: {c['border_soft']};
    }}
    QPushButton#consoleHeaderButton:pressed {{
        background: {c['control_pressed']};
    }}
    QPushButton#consoleHeaderButton:disabled {{
        color: {c['disabled_text']};
        background: transparent;
        border-color: transparent;
    }}
    /* The answer row. It sits on the console's own ground so it reads as part
       of the terminal, and turns amber while a prompt is hiding what is typed
       — the one moment where an empty-looking field is correct rather than
       broken. */
    QWidget#consoleInputRow {{
        background: {c['console_bg']};
        border-top: 1px solid {c['console_border']};
    }}
    QLabel#consoleInputLabel {{
        color: {c['muted']};
        font-size: 12px;
        font-weight: 700;
    }}
    QWidget#consoleInputRow[mode='secret'] QLabel#consoleInputLabel {{
        color: {c['orange']};
    }}
    QLineEdit#consoleInput {{
        background: {c['console_border']};
        color: {c['console_text']};
        border: 1px solid {c['console_border']};
        border-radius: 8px;
        padding: 5px 10px;
        font-family: 'JetBrains Mono', 'DejaVu Sans Mono', 'Noto Sans Mono', monospace;
        font-size: 12px;
        selection-background-color: {c['blue']};
    }}
    QLineEdit#consoleInput:focus {{
        border-color: {c['blue']};
    }}
    QWidget#consoleInputRow[mode='secret'] QLineEdit#consoleInput:focus {{
        border-color: {c['orange']};
    }}
    QPushButton#consoleSendButton {{
        background: {c['blue']};
        color: {c['on_accent']};
        border: none;
        border-radius: 8px;
        padding: 5px 16px;
        font-size: 12px;
        font-weight: 700;
    }}
    QPushButton#consoleSendButton:hover {{ background: {c['blue']}; }}
    QPushButton#consoleSendButton:disabled {{
        background: {c['disabled_bg']};
        color: {c['disabled_text']};
    }}
    QAbstractScrollArea#embeddedTerminalView {{
        background: {c['console_bg']};
        border: none;
    }}
    QAbstractScrollArea#embeddedTerminalView QWidget {{
        background: {c['console_bg']};
    }}
    /* The rule above reaches the grid's Copy/Paste menu as well, which is a
       child of the view, while its text still came from the universal rule:
       dark on dark in the light themes, so the menu looked like it never
       opened. It carries the console's complete pair now. */
    QAbstractScrollArea#embeddedTerminalView QMenu {{
        background: {c['console_bg']};
        color: {c['console_text']};
        border: 1px solid {c['console_border']};
        border-radius: 8px;
        padding: 4px;
    }}
    QAbstractScrollArea#embeddedTerminalView QMenu::item {{
        background: transparent;
        color: {c['console_text']};
        padding: 6px 22px 6px 12px;
        border-radius: 6px;
    }}
    QAbstractScrollArea#embeddedTerminalView QMenu::item:selected {{
        background: {c['console_border']};
    }}
    QAbstractScrollArea#embeddedTerminalView QMenu::item:disabled {{
        color: {c['console_muted']};
    }}
    QAbstractScrollArea#embeddedTerminalView QMenu::separator {{
        height: 1px;
        background: {c['console_border']};
        margin: 4px 6px;
    }}
    /* A thin overlay rail rather than a full scrollbar: the output is what the
       panel is for, and a chunky bar beside it competes for the eye. */
    QAbstractScrollArea#embeddedTerminalView QScrollBar:vertical {{
        background: transparent;
        width: 10px;
        margin: 0px;
        border: none;
    }}
    QAbstractScrollArea#embeddedTerminalView QScrollBar::handle:vertical {{
        background: {c['console_border']};
        border-radius: 5px;
        min-height: 28px;
        margin: 2px;
    }}
    QAbstractScrollArea#embeddedTerminalView QScrollBar::handle:vertical:hover {{
        background: {c['border_strong']};
    }}
    QAbstractScrollArea#embeddedTerminalView QScrollBar::add-line:vertical,
    QAbstractScrollArea#embeddedTerminalView QScrollBar::sub-line:vertical {{
        height: 0px;
        border: none;
        background: transparent;
    }}
    QAbstractScrollArea#embeddedTerminalView QScrollBar::add-page:vertical,
    QAbstractScrollArea#embeddedTerminalView QScrollBar::sub-page:vertical {{
        background: transparent;
    }}
    QFrame[safetyNotice='orange'] {{
        background: {c['orange_soft']};
        border: 1px solid {c['orange_border']};
        border-radius: 11px;
    }}
    QFrame[safetyNotice='blue'] {{
        background: {c['blue_soft']};
        border: 1px solid {c['blue_border']};
        border-radius: 11px;
    }}
    QFrame[safetyNotice='red'] {{
        background: {c['red_soft']};
        border: 1px solid {c['red']};
        border-radius: 11px;
    }}
    QFrame[safetyNotice='cyan'] {{
        background: {c['cyan_soft']};
        border: 1px solid {c['cyan_border']};
        border-radius: 11px;
    }}
    QFrame[safetyNotice='cyan'] QLabel[noticeTitle='true'] {{
        color: {c['cyan']};
    }}
    QFrame[safetyNotice='cyan'] QLabel[noticeBody='true'] {{
        color: {c['muted']};
    }}
    QLabel[noticeTitle='true'] {{
        color: {c['orange']};
        font-size: 11px;
        font-weight: 800;
    }}
    QLabel[noticeBody='true'] {{
        color: {c['muted']};
        font-size: 10px;
    }}
    QFrame[safetyNotice='blue'] QLabel[noticeTitle='true'] {{
        color: {c['blue']};
    }}
    QFrame[safetyNotice='blue'] QLabel[noticeBody='true'] {{
        color: {c['muted']};
    }}
    QFrame[safetyNotice='red'] QLabel[noticeTitle='true'] {{
        color: {c['red']};
    }}
    QFrame[safetyNotice='red'] QLabel[noticeBody='true'] {{
        color: {c['muted']};
    }}
    QFrame[confirmSummary='true'] {{
        background: {c['panel_alt']};
        border: 1px solid {c['border_soft']};
        border-radius: 10px;
    }}
    QLabel[confirmLabel='true'] {{
        color: {c['muted']};
        font-size: 10px;
        font-weight: 650;
    }}
    QLabel[confirmValue='true'] {{
        color: {c['text']};
        font-size: 11px;
        font-weight: 780;
    }}
    QTableWidget {{
        background: {c['panel']};
        alternate-background-color: {c['panel_alt']};
        border: 1px solid {c['border']};
        border-radius: 10px;
        gridline-color: {c['border_soft']};
        selection-background-color: {c['blue_soft']};
        selection-color: {c['text']};
    }}
    QHeaderView::section {{
        background: {c['panel_alt']};
        color: {c['muted']};
        border: none;
        border-bottom: 1px solid {c['border']};
        padding: 8px;
        font-size: 10px;
        font-weight: 750;
    }}
    QLabel[pageMode='true'] {{
        color: {c['green']};
        font-size: 9px;
        font-weight: 800;
    }}
    QFrame[heroTelemetry='true'] {{
        background: {c['panel']};
        border: 1px solid {c['border']};
        border-radius: 22px;
    }}
    QFrame[heroTelemetry='true'][tone='blue'] {{
        border-left: 4px solid {c['blue']};
    }}
    QFrame[heroTelemetry='true'][tone='purple'] {{
        border-left: 4px solid {c['purple']};
    }}
    QFrame#HeroDivider {{
        background: {c['border_soft']};
        border: none;
    }}
    QLabel[heroTitle='true'] {{
        color: {c['text']};
        font-size: 14px;
        font-weight: 800;
    }}
    QLabel[heroPrimaryLabel='true'] {{
        color: {c['muted']};
        font-size: 10px;
        font-weight: 750;
    }}
    QLabel[heroPrimaryValue='true'] {{
        color: {c['text']};
        font-size: 36px;
        font-weight: 860;
    }}
    QLabel[heroPrimaryDetail='true'] {{
        color: {c['subtle']};
        font-size: 10px;
    }}
    QLabel[heroStatLabel='true'] {{
        color: {c['muted']};
        font-size: 9px;
        font-weight: 750;
    }}
    QLabel[heroStatValue='true'] {{
        color: {c['text']};
        font-size: 17px;
        font-weight: 820;
    }}
    QLabel[heroStatDetail='true'] {{
        color: {c['subtle']};
        font-size: 9px;
    }}
    QFrame[gpuSummaryStrip='true'] {{
        background: {c['panel']};
        border: 1px solid {c['border']};
        border-radius: 18px;
    }}
    QFrame[gpuSummaryItem='true'] {{
        background: {c['panel_alt']};
        border: 1px solid {c['border_soft']};
        border-radius: 14px;
    }}
    QFrame[gpuSummaryItem='true']:hover {{
        background: {c['panel_raised']};
        border-color: {c['border_strong']};
    }}
    QLabel[gpuSummaryLabel='true'] {{
        color: {c['muted']};
        font-size: 8px;
        font-weight: 640;
    }}
    QLabel[gpuSummaryValue='true'] {{
        color: {c['text']};
        font-size: 15px;
        font-weight: 830;
    }}
    QLabel[gpuSummaryDetail='true'] {{
        color: {c['muted'] if ACTIVE_MODE == 'light' else c['subtle']};
        font-size: 8px;
    }}
    QFrame[compactVoltageSummaryItem='true'] QLabel[gpuSummaryLabel='true'] {{
        font-size: 9px;
    }}
    QFrame[compactVoltageSummaryItem='true'] QLabel[gpuSummaryValue='true'] {{
        font-size: 14px;
    }}
    QFrame[compactVoltageSummaryItem='true'] QLabel[gpuSummaryDetail='true'] {{
        font-size: 8px;
    }}
    QFrame[frequencyField='true'], QFrame[compactPanel='true'], QFrame[runtimeStatCard='true'] {{
        background: {c['panel_alt']};
        border: 1px solid {c['border_soft']};
        border-radius: 14px;
    }}
    QFrame[frequencyField='true']:hover, QFrame[compactPanel='true']:hover, QFrame[runtimeStatCard='true']:hover {{
        background: {c['panel']};
        border-color: {c['border_strong']};
    }}
    QLineEdit[frequencyInput='true'] {{
        min-height: 20px;
        padding: 7px 9px;
        font-size: 12px;
        font-weight: 800;
    }}
    QLabel[frequencyUnit='true'] {{
        color: {c['muted']};
        font-size: 10px;
        font-weight: 750;
    }}
    QLabel[runtimeStatLabel='true'] {{
        color: {c['muted']};
        font-size: 9px;
        font-weight: 760;
    }}
    QLabel[runtimeStatValue='true'] {{
        color: {c['text']};
        font-size: 13px;
        font-weight: 830;
    }}
    QLabel[runtimeStatDetail='true'] {{
        color: {c['subtle']};
        font-size: 8px;
    }}
    QFrame[frequencySelect='true'] {{
        background: {c['panel_alt']};
        border: 1px solid {c['border_soft']};
        border-radius: 11px;
    }}
    QFrame[frequencySelect='true']:hover {{
        background: {c['panel']};
        border-color: {c['border_strong']};
    }}
    QFrame[sliderControl='true'] {{
        background: {c['panel_alt']};
        border: 1px solid {c['border_soft']};
        border-radius: 12px;
    }}
    QLabel[sliderLabel='true'] {{
        color: {c['text']};
        font-size: 11px;
        font-weight: 780;
    }}
    QLabel[sliderLimit='true'] {{
        color: {c['subtle']};
        font-size: 8px;
        font-weight: 700;
    }}
    QSlider::groove:horizontal {{
        height: 6px;
        background: {c['border_soft']};
        border-radius: 3px;
    }}
    QSlider::sub-page:horizontal {{
        background: {c['blue']};
        border-radius: 3px;
    }}
    QSlider::handle:horizontal {{
        background: {c['panel']};
        border: 2px solid {c['blue']};
        width: 16px;
        height: 16px;
        margin: -6px 0;
        border-radius: 8px;
    }}
    QPushButton[presetButton='true'] {{
        background: {c['panel_alt']};
        border: 1px solid {c['border_soft']};
        border-radius: 14px;
        padding: 12px 14px;
        text-align: left;
        color: {c['muted']};
        font-size: 10px;
        font-weight: 690;
    }}
    QPushButton[presetButton='true']:hover {{
        background: {c['panel']};
        border-color: {c['border_strong']};
    }}
    QPushButton[presetButton='true']:checked {{
        background: {c['blue_soft']};
        border: 1px solid {c['blue_border']};
        color: {c['blue']};
    }}
    QPushButton[presetButton='true']:disabled {{
        color: {c['disabled_text']};
        background: {c['panel_alt']};
        border-color: {c['border_soft']};
    }}
    QWidget[cpuSmuPage='true'] QPushButton[cpuFrequencyPreset='true'] {{
        min-height: 40px;
        padding: 11px 14px;
        font-size: 11px;
        font-weight: 740;
    }}
    QWidget[cpuSmuPage='true'] QLineEdit[frequencyInput='true'] {{
        min-height: 22px;
        font-size: 13px;
        font-weight: 820;
    }}
    QFrame[cpuWorkspaceTabs='true'] {{
        background: {c['panel_alt']};
        border: 1px solid {c['border_soft']};
        border-radius: 12px;
    }}
    QStackedWidget[cpuWorkspaceStack='true'],
    QWidget[cpuWorkspacePage='true'] {{
        background: transparent;
        border: none;
    }}
    QPushButton[cpuWorkspaceTab='true'] {{
        min-height: 22px;
        padding: 7px 14px;
        background: transparent;
        border: 1px solid transparent;
        border-radius: 8px;
        color: {c['muted']};
        font-size: 11px;
        font-weight: 760;
        text-align: center;
    }}
    QPushButton[cpuWorkspaceTab='true']:hover {{
        background: {c['control_hover']};
        border-color: {c['border_soft']};
        color: {c['text']};
    }}
    QPushButton[cpuWorkspaceTab='true']:pressed {{
        background: {c['control_pressed']};
    }}
    QPushButton[cpuWorkspaceTab='true']:checked {{
        background: {c['blue_soft']};
        border-color: {c['blue_border']};
        color: {c['blue']};
        font-weight: 820;
    }}
    QPushButton[cpuWorkspaceTab='true']:checked:hover {{
        border-color: {c['blue']};
    }}
    QWidget[redesignedModule='true'] QPushButton[gpuFrequencyPreset='true'] {{
        min-height: 40px;
        padding: 11px 14px;
        font-size: 11px;
        font-weight: 740;
    }}
    QWidget[redesignedModule='true'] QPushButton[gpuFrequencyAction='true'] {{
        min-height: 20px;
        padding: 8px 12px;
        font-size: 12px;
        font-weight: 800;
    }}
    QWidget[redesignedModule='true'] QLineEdit[frequencyInput='true'] {{
        min-height: 22px;
        font-size: 13px;
        font-weight: 820;
    }}
    /* Redesigned Cyan GPU view (gpu_governor_view.py). Every control the view
       builds carries one of these properties, so nothing falls back to the
       unstyled platform button. */
    QWidget[redesignedModule='true'] QFrame[subPanel='true'] {{
        background: transparent;
        border: 1px solid {c['border_soft']};
        border-radius: 12px;
    }}
    QWidget[redesignedModule='true'] QFrame[subPanel='true'][riskPanel='true'] {{
        background: {c['red_soft']};
        border: 1px solid {c['red_border']};
    }}
    /* Qt draws a spin box's step buttons outside the rounded border by
       default, which left a grey stub hanging off every numeric field in both
       redesigned modules. Place them inside the frame and give them the same
       chevrons the rest of the interface uses. */
    QWidget[redesignedModule='true'] QSpinBox {{
        padding-right: 24px;
    }}
    QWidget[redesignedModule='true'] QSpinBox::up-button,
    QWidget[redesignedModule='true'] QSpinBox::down-button {{
        subcontrol-origin: border;
        subcontrol-position: top right;
        width: 20px;
        height: 14px;
        margin: 3px 4px 0px 0px;
        background: transparent;
        border: none;
        border-radius: 5px;
    }}
    QWidget[redesignedModule='true'] QSpinBox::down-button {{
        subcontrol-position: bottom right;
        margin: 0px 4px 3px 0px;
    }}
    QWidget[redesignedModule='true'] QSpinBox::up-button:hover,
    QWidget[redesignedModule='true'] QSpinBox::down-button:hover {{
        background: {c['panel_alt']};
    }}
    QWidget[redesignedModule='true'] QSpinBox::up-arrow {{
        image: url({icon_dir}/chevron_up_gray.svg);
        width: 11px;
        height: 11px;
    }}
    QWidget[redesignedModule='true'] QSpinBox::down-arrow {{
        image: url({icon_dir}/chevron_down_gray.svg);
        width: 11px;
        height: 11px;
    }}
    QWidget[redesignedModule='true'] QSpinBox::up-arrow:off,
    QWidget[redesignedModule='true'] QSpinBox::down-arrow:off {{
        image: none;
    }}
    /* A native check box beside a styled row reads as a stray control from
       another application. Same radius and hairline as every other field. */
    QWidget[redesignedModule='true'] QCheckBox::indicator {{
        width: 18px;
        height: 18px;
        border: 1px solid {c['border']};
        border-radius: 6px;
        background: {c['panel_alt']};
    }}
    QWidget[redesignedModule='true'] QCheckBox::indicator:hover {{
        border-color: {c['blue']};
    }}
    QWidget[redesignedModule='true'] QCheckBox::indicator:checked {{
        background: {c['blue']};
        border-color: {c['blue']};
        image: url({icon_dir}/check_white.svg);
    }}
    QWidget[redesignedModule='true'] QCheckBox::indicator:disabled {{
        background: transparent;
        border-color: {c['border_soft']};
    }}
    QWidget[redesignedModule='true'] QLabel[cardTitle='true'] {{
        color: {c['text']};
        font-size: 13px;
        font-weight: 780;
    }}
    QWidget[redesignedModule='true'] QPushButton[ghostButton='true'] {{
        background: {c['panel_alt']};
        border: 1px solid {c['border']};
        border-radius: 10px;
        padding: 9px 14px;
        font-size: 12px;
        font-weight: 720;
        color: {c['text']};
    }}
    QWidget[redesignedModule='true'] QPushButton[ghostButton='true']:hover {{
        background: {c['control_hover']};
        border-color: {c['border_strong']};
    }}
    QWidget[redesignedModule='true'] QPushButton[ghostButton='true']:disabled {{
        background: {c['disabled_bg']};
        border-color: {c['border_soft']};
        color: {c['disabled_text']};
    }}
    QWidget[redesignedModule='true'] QPushButton[linkButton='true'] {{
        background: transparent;
        border: none;
        padding: 4px 6px;
        font-size: 12px;
        font-weight: 720;
        color: {c['blue']};
    }}
    QWidget[redesignedModule='true'] QPushButton[linkButton='true']:hover {{
        color: {c['blue_hover']};
    }}
    QWidget[redesignedModule='true'] QPushButton[linkButton='true'][quiet='true'] {{
        color: {c['muted']};
    }}
    QWidget[redesignedModule='true'] QPushButton[linkButton='true'][quiet='true']:hover {{
        color: {c['text']};
    }}
    /* The button's own left padding otherwise offsets its text from the
       plain QLabel rows above and below it, which have none. */
    QWidget[redesignedModule='true'] QPushButton[linkButton='true'][flushLeft='true'] {{
        padding-left: 0px;
    }}
    /* Firmware (BIOS): notes carry their tone, and the result of a
       preparation sits in a box of the same tone. */
    QWidget[redesignedModule='true'] QLabel[firmwareNote='caution'] {{
        color: {c['orange']};
        font-size: 11px;
    }}
    QWidget[redesignedModule='true'] QLabel[firmwareNote='danger'] {{
        color: {c['red']};
        font-size: 11px;
    }}
    /* A firmware card compares images on four facts: a small upper-case name
       over a value. What an image lacks is muted rather than struck out, and
       the one fact that needs doing after the flash is in the caution tone. */
    QWidget[redesignedModule='true'] QLabel[firmwareCategory='true'] {{
        color: {c['muted']};
        font-size: 10px;
        font-weight: 800;
        padding-top: 2px;
    }}
    QWidget[redesignedModule='true'] QLabel[firmwareFactLabel='true'] {{
        color: {c['subtle']};
        font-size: 9px;
        font-weight: 800;
    }}
    QWidget[redesignedModule='true'] QLabel[firmwareFactValue='true'] {{
        color: {c['text']};
        font-size: 12px;
        font-weight: 720;
    }}
    QWidget[redesignedModule='true'] QLabel[firmwareFactValue='true'][tone='muted'] {{
        color: {c['muted']};
        font-weight: 600;
    }}
    QWidget[redesignedModule='true'] QLabel[firmwareFactValue='true'][tone='caution'] {{
        color: {c['orange']};
    }}
    /* What an image offers, under its description: short lines, each behind
       an accent bullet in the same font so the two stay on one baseline. */
    QWidget[redesignedModule='true'] QLabel[firmwareHighlight='true'] {{
        color: {c['text']};
        font-size: 11px;
    }}
    QWidget[redesignedModule='true'] QLabel[firmwareHighlightMark='true'] {{
        color: {c['blue']};
        font-size: 11px;
        font-weight: 800;
    }}
    /* The same bullets for the notes under "Before you start", in the
       quieter tone of a caption. */
    QWidget[redesignedModule='true'] QLabel[firmwareHighlight='muted'] {{
        color: {c['muted']};
        font-size: 11px;
    }}
    /* The warning read before anything else on the page: its own box, in the
       caution tone of the note it holds. */
    QWidget[redesignedModule='true'] QFrame[firmwareCallout='caution'] {{
        background: {c['orange_soft']};
        border: 1px solid {c['orange_border']};
        border-radius: 10px;
    }}
    QWidget[redesignedModule='true'] QLabel[firmwareStepTitle='pending'] {{
        color: {c['muted']};
    }}
    QWidget[redesignedModule='true'] QLabel[firmwareStepTitle='active'] {{
        color: {c['text']};
        font-weight: 760;
    }}
    QWidget[redesignedModule='true'] QLabel[firmwareStepTitle='done'] {{
        color: {c['text']};
    }}
    QWidget[redesignedModule='true'] QLabel[firmwareStepTitle='failed'] {{
        color: {c['red']};
        font-weight: 760;
    }}
    QWidget[redesignedModule='true'] QFrame[firmwareResult='success'] {{
        background: {c['green_soft']};
        border: 1px solid {c['green_border']};
        border-radius: 10px;
    }}
    QWidget[redesignedModule='true'] QFrame[firmwareResult='danger'] {{
        background: {c['red_soft']};
        border: 1px solid {c['red_border']};
        border-radius: 10px;
    }}
    QWidget[redesignedModule='true'] QFrame[firmwareResult='neutral'] {{
        background: {c['panel_alt']};
        border: 1px solid {c['border_soft']};
        border-radius: 10px;
    }}
    /* The logo's size slider does nothing until there is a picture, and
       looks it. */
    QWidget[redesignedModule='true'] QSlider[logoScale='true']::sub-page:horizontal:disabled {{
        background: {c['border']};
    }}
    QWidget[redesignedModule='true'] QSlider[logoScale='true']::handle:horizontal:disabled {{
        border-color: {c['border']};
        background: {c['panel_alt']};
    }}
    QWidget[redesignedModule='true'] QProgressBar[firmwareProgress='true']::chunk {{
        background: {c['blue']};
        border-radius: 4px;
    }}
    QWidget[redesignedModule='true'] QPushButton[iconOnlyButton='true'] {{
        background: {c['panel_raised']};
        border: 1px solid {c['border_soft']};
        border-radius: 7px;
        padding: 0px;
    }}
    QWidget[redesignedModule='true'] QPushButton[iconOnlyButton='true']:hover {{
        background: {c['control_hover']};
        border-color: {c['blue_border']};
    }}
    QWidget[redesignedModule='true'] QPushButton[toggleChip='true'] {{
        background: {c['panel_alt']};
        border: 1px solid {c['border']};
        border-radius: 9px;
        padding: 8px 13px;
        font-size: 12px;
        font-weight: 700;
        color: {c['muted']};
    }}
    QWidget[redesignedModule='true'] QPushButton[toggleChip='true']:hover {{
        border-color: {c['border_strong']};
        color: {c['text']};
    }}
    QWidget[redesignedModule='true'] QPushButton[toggleChip='true']:checked {{
        background: {c['blue_soft']};
        border-color: {c['blue_border']};
        color: {c['blue']};
    }}
    QWidget[redesignedModule='true'] QPushButton[accentAction='true'] {{
        background: {c['blue_soft']};
        border: 1px solid {c['blue_border']};
        border-radius: 10px;
        padding: 9px 14px;
        font-size: 12px;
        font-weight: 740;
        color: {c['blue']};
    }}
    QWidget[redesignedModule='true'] QPushButton[accentAction='true']:hover {{
        border-color: {c['blue']};
        color: {c['blue_hover']};
    }}
    QWidget[redesignedModule='true'] QPushButton[accentAction='true']:disabled {{
        background: {c['disabled_bg']};
        border-color: {c['border_soft']};
        color: {c['disabled_text']};
    }}
    QWidget[redesignedModule='true'] QPushButton#PrimaryAction {{
        background: {c['blue']};
        border-color: {c['blue']};
        color: {c['on_blue']};
        min-height: 22px;
    }}
    QWidget[redesignedModule='true'] QPushButton#PrimaryAction:hover {{
        background: {c['blue_hover']};
        border-color: {c['blue_hover']};
    }}
    QWidget[redesignedModule='true'] QPushButton#PrimaryAction:disabled {{
        background: {c['disabled_bg']};
        border-color: {c['disabled_bg']};
        color: {c['disabled_text']};
    }}
    QWidget[redesignedModule='true'] QFrame[profileCard='true'][selectedProfile='true'] {{
        background: {c['blue_soft']};
        border: 1px solid {c['blue_border']};
    }}
    QWidget[redesignedModule='true'] QFrame[profileCard='true'][blockedProfile='true'] {{
        border: 1px solid {c['red_border']};
    }}
    QWidget[redesignedModule='true'] QLabel[eyebrow='true'] {{
        color: {c['blue']};
        font-size: 10px;
        font-weight: 800;
        background: transparent;
    }}
    QWidget[redesignedModule='true'] QLabel[eyebrow='true'][danger='true'] {{
        color: {c['red']};
    }}
    QWidget[redesignedModule='true'] QLabel[railLegend='true'] {{
        color: {c['red']};
        font-size: 10px;
        font-weight: 800;
        background: transparent;
    }}
    QWidget[redesignedModule='true'] QLabel[bigReadout='true'] {{
        color: {c['text']};
        font-size: 21px;
        font-weight: 830;
        background: transparent;
    }}
    QWidget[redesignedModule='true'] QLabel[panelHeadline='true'] {{
        color: {c['text']};
        font-size: 15px;
        font-weight: 800;
        background: transparent;
    }}
    QWidget[redesignedModule='true'] QLabel[rangeReadout='true'] {{
        color: {c['text']};
        font-size: 16px;
        font-weight: 820;
        background: transparent;
    }}
    QWidget[redesignedModule='true'] QLabel[rangeReadout='true'][danger='true'] {{
        color: {c['red']};
    }}
    QWidget[redesignedModule='true'] QFrame[frequencyField='true'] {{
        background: transparent;
        border: none;
    }}
    QWidget[redesignedModule='true'] QLabel[frequencyFieldLabel='true'] {{
        color: {c['text']};
        font-size: 12px;
        font-weight: 700;
        background: transparent;
    }}
    QWidget[redesignedModule='true'] QLabel[frequencyChip='true'] {{
        background: {c['window']};
        border: 1px solid {c['border']};
        border-radius: 9px;
        padding: 7px 11px;
        color: {c['text']};
        font-size: 14px;
        font-weight: 800;
        min-width: 60px;
    }}
    QWidget[redesignedModule='true'] QLabel[frequencyChip='true'][chipAccent='true'] {{
        border-color: {c['blue_border']};
        color: {c['blue']};
    }}
    QWidget[redesignedModule='true'] QLabel[frequencyUnit='true'] {{
        color: {c['muted']};
        font-size: 11px;
        background: transparent;
    }}
    QWidget[redesignedModule='true'] QFrame[pickerRow='true'] {{
        background: {c['window']};
        border: 1px solid {c['border']};
        border-radius: 9px;
    }}
    QWidget[redesignedModule='true'] QFrame[pickerRow='true']:hover {{
        border-color: {c['border_strong']};
    }}
    QWidget[redesignedModule='true'] QLabel[pickerCaption='true'] {{
        color: {c['muted']};
        font-size: 12px;
        background: transparent;
    }}
    QWidget[redesignedModule='true'] QLabel[pickerValue='true'] {{
        color: {c['text']};
        font-size: 12px;
        font-weight: 700;
        background: transparent;
    }}
    QFrame[dependencyActionTile='true'] {{
        background: {c['panel_alt']};
        border: 1px solid {c['border_soft']};
        border-radius: 12px;
    }}
    QFrame[dependencyActionTile='true']:hover {{
        background: {c['panel_raised']};
        border-color: {c['border_strong']};
    }}
    QFrame[dependencyActionTile='true'][dependencyLeadTile='true'] {{
        background: {c['panel_raised']};
        border-color: {c['border']};
    }}
    QFrame[metricTile='true'][dependencyGovernorSelected='true'] {{
        background: {c['panel_raised']};
        border-color: {c['blue_border']};
    }}
    QPushButton[dependencyGovernorAction='true'] {{
        min-height: 18px;
        max-height: 18px;
        padding: 7px 11px;
        border-radius: 9px;
        font-size: 11px;
        font-weight: 720;
    }}
    QPushButton[dependencyGfxAction='true'] {{
        min-height: 20px;
        max-height: 20px;
        padding: 7px 9px;
        border-radius: 9px;
        background: {c['panel_raised']};
        border: 1px solid {c['border']};
        color: {c['muted']};
        font-size: 10px;
        font-weight: 720;
    }}
    QPushButton[dependencyGfxAction='true']:hover {{
        background: {c['control_hover']};
        border-color: {c['border_strong']};
        color: {c['text']};
    }}
    QPushButton[dependencyGfxAction='true'][dependencyGfxPrimary='true'] {{
        background: {c['blue']};
        border-color: {c['blue']};
        color: {c['on_blue']};
    }}
    QPushButton[dependencyGfxAction='true'][dependencyGfxPrimary='true']:hover {{
        background: {c['blue_hover']};
        border-color: {c['blue_hover']};
        color: {c['on_blue']};
    }}
    QPushButton[dependencyPrepareButton='true'] {{
        min-height: 26px;
        padding: 7px 14px;
        border-radius: 9px;
        background: {c['blue']};
        color: {c['on_blue']};
        border: 1px solid {c['blue']};
        font-size: 12px;
        font-weight: 800;
        text-align: center;
    }}
    QPushButton[dependencyPrepareButton='true']:hover {{
        background: {c['blue_hover']};
        border-color: {c['blue_hover']};
    }}
    QPushButton[dependencyPrepareButton='true']:disabled {{
        background: {c['disabled_bg']};
        border-color: {c['disabled_bg']};
        color: {c['disabled_text']};
    }}
    QWidget#VoltageLabDrawerOverlay {{
        background: rgba(0, 0, 0, 145);
    }}
    QFrame#VoltageLabDrawer {{
        background: {c['panel']};
        border: 1px solid {c['border']};
        border-radius: 18px;
    }}
    QScrollArea#VoltageLabDrawerScroll,
    QScrollArea#VoltageLabDrawerScroll > QWidget > QWidget,
    QWidget#VoltageLabDrawerBody {{
        background: transparent;
        border: none;
    }}
    QFrame[voltageDrawerSeparator='true'] {{
        background: {c['border_soft']};
        border: none;
        max-height: 1px;
        min-height: 1px;
    }}
    QPushButton[voltageDrawerClose='true'] {{
        background: {c['panel_alt']};
        border: 1px solid {c['border_soft']};
        border-radius: 9px;
        color: {c['muted']};
        padding: 0px;
    }}
    QPushButton[voltageDrawerClose='true']:hover {{
        background: {c['panel_raised']};
        border-color: {c['border_strong']};
        color: {c['text']};
    }}
    QLabel[voltageDrawerTitle='true'] {{
        color: {c['text']};
        font-size: 15px;
        font-weight: 800;
    }}
    QLabel[voltageDrawerSubtitle='true'] {{
        color: {c['subtle']};
        font-size: 10px;
        font-weight: 600;
    }}
    QLabel[voltageDrawerSectionTitle='true'] {{
        color: {c['muted']};
        font-size: 10px;
        font-weight: 700;
    }}
    QLabel[voltageDrawerLegend='true'] {{
        color: {c['subtle']};
        font-size: 9px;
        font-weight: 640;
    }}
    QFrame[voltageDrawerCompatibility='true'] {{
        background: {c['panel_alt']};
        border: none;
        border-bottom: 1px solid {c['border_soft']};
    }}
    QLabel[voltageDrawerCompatibilityTitle='true'] {{
        color: {c['text']};
        font-size: 11px;
        font-weight: 800;
    }}
    QLabel[voltageDrawerCompatibilityText='true'] {{
        color: {c['muted']};
        font-size: 9px;
        font-weight: 630;
    }}
    QPushButton[voltageDrawerProfile='true'] {{
        min-height: 40px;
        max-height: 46px;
        padding: 8px 11px;
        background: {c['panel_alt']};
        border: 1px solid {c['border_soft']};
        border-radius: 8px;
        color: {c['text']};
        text-align: left;
        font-size: 11px;
        font-weight: 700;
    }}
    QPushButton[voltageDrawerProfile='true']:hover {{
        background: {c['panel_raised']};
        border-color: {c['border_strong']};
    }}
    QPushButton[voltageDrawerProfile='true']:checked {{
        background: {c['blue_soft']};
        border: 1px solid {c['blue']};
        color: {c['text']};
    }}
    QPushButton[voltageDrawerProfile='true']:disabled {{
        color: {c['disabled_text']};
        border-color: {c['border_soft']};
    }}
    QLabel[voltageDrawerDetail='true'] {{
        color: {c['muted']};
        background: transparent;
        border: none;
        padding: 0px;
        font-size: 10px;
        font-weight: 600;
    }}
    QLabel[voltageDrawerColumn='true'] {{
        color: {c['subtle']};
        font-size: 9px;
        font-weight: 650;
    }}
    QFrame[voltageDrawerCurveRow='true'] {{
        background: transparent;
        border: none;
        border-top: 1px solid {c['border_soft']};
        border-radius: 0px;
    }}
    QFrame[voltageDrawerCurveRow='true'][rowFirst='true'] {{
        border-top: none;
    }}
    QFrame[voltageDrawerCurveRow='true']:hover {{
        background: {c['panel_alt']};
    }}
    QLabel[voltageDrawerFrequency='true'] {{
        color: {c['text']};
        font-size: 12px;
        font-weight: 700;
    }}
    QLabel[voltageDrawerCurrent='true'] {{
        color: {c['muted']};
        font-size: 12px;
        font-weight: 600;
    }}
    QLabel[voltageDrawerTarget='true'] {{
        color: {c['text']};
        font-size: 12px;
        font-weight: 700;
    }}
    QLabel[voltageDrawerDelta='true'] {{
        color: {c['subtle']};
        font-size: 11px;
        font-weight: 700;
    }}
    QLabel[voltageDrawerDelta='true'][deltaTone='raised'] {{ color: {c['orange']}; }}
    QLabel[voltageDrawerDelta='true'][deltaTone='lowered'] {{ color: {c['cyan']}; }}
    QLabel[voltageDrawerDelta='true'][deltaTone='default'] {{ color: {c['subtle']}; }}
    QSpinBox[voltageDrawerEditor='true'] {{
        padding: 3px 6px;
        background: {c['panel_alt']};
        border: 1px solid {c['border']};
        border-radius: 7px;
        color: {c['text']};
        font-size: 12px;
        font-weight: 700;
    }}
    QSpinBox[voltageDrawerEditor='true']:focus {{
        border-color: {c['blue']};
    }}
    QLabel[voltageDrawerSummary='true'] {{
        color: {c['subtle']};
        font-size: 10px;
        font-weight: 620;
    }}
    QLabel[voltageDrawerStatCaption='true'] {{
        color: {c['muted']};
        font-size: 10px;
        font-weight: 600;
    }}
    QLabel[voltageDrawerStatValue='true'] {{
        color: {c['text']};
        font-size: 16px;
        font-weight: 800;
    }}
    QPushButton[voltageDrawerSecondary='true'] {{
        min-height: 38px;
        padding: 0px 15px;
        background: {c['panel_alt']};
        border: 1px solid {c['border_soft']};
        border-radius: 10px;
        color: {c['text']};
        font-size: 10px;
        font-weight: 700;
    }}
    QPushButton[voltageDrawerSecondary='true']:hover {{
        background: {c['panel_raised']};
        border-color: {c['border_strong']};
    }}
    QPushButton[voltageDrawerApply='true'] {{
        min-height: 38px;
        padding: 0px 20px;
        background: {c['blue']};
        border: 1px solid {c['blue']};
        border-radius: 10px;
        color: {c['on_blue']};
        font-size: 11px;
        font-weight: 800;
    }}
    QPushButton[voltageDrawerApply='true']:hover {{
        background: {c['blue_hover']};
        border-color: {c['blue_hover']};
    }}
    QPushButton[voltageDrawerApply='true']:disabled {{
        background: {c['disabled_bg']};
        border-color: {c['disabled_bg']};
        color: {c['disabled_text']};
    }}
    QPushButton[voltageLabLauncher='true'] {{
        background: {c['blue_soft']};
        border: 1px solid {c['blue_border']};
        color: {c['blue']};
        font-weight: 820;
    }}
    QPushButton[voltageLabLauncher='true']:hover {{
        background: {c['blue']};
        border-color: {c['blue']};
        color: {c['on_blue']};
    }}
    QFrame[voltageLabToolbar='true'] {{
        background: {c['panel']};
        border: 1px solid {c['border']};
        border-radius: 16px;
    }}
    QLabel[voltageToolbarTitle='true'] {{
        color: {c['text']};
        font-size: 16px;
        font-weight: 850;
    }}
    QPushButton[voltageToolbarButton='true'] {{
        padding: 6px 13px;
        font-size: 11px;
        font-weight: 790;
    }}
    QLabel[voltageToolbarSubtitle='true'] {{
        color: {c['muted']};
        font-size: 9px;
        font-weight: 620;
    }}
    QWidget[voltageLabPage='true'] QFrame[pageCard='true'] {{
        border-radius: 14px;
    }}
    QWidget[voltageLabPage='true'] QFrame[compactPageCard='true'] QLabel[cardTitle='true'] {{
        font-size: 14px;
        font-weight: 830;
    }}
    QWidget[voltageLabPage='true'] QFrame[compactPageCard='true'] QLabel[sectionSubtitle='true'] {{
        font-size: 9px;
        font-weight: 620;
    }}
    QFrame[compactPageCard='true'] QFrame#CardDivider {{
        margin-top: 0px;
        margin-bottom: 0px;
    }}
    QPushButton[voltageProfileButton='true'] {{
        background: {c['panel_alt']};
        border: 1px solid {c['border_soft']};
        border-radius: 10px;
        padding: 8px 11px;
        text-align: left;
        color: {c['text']};
        font-size: 11px;
        font-weight: 760;
    }}
    QPushButton[voltageProfileButton='true']:hover {{
        background: {c['panel_raised']};
        border-color: {c['border_strong']};
    }}
    QPushButton[voltageProfileButton='true']:checked {{
        background: {c['blue_soft']};
        border: 2px solid {c['blue']};
        color: {c['blue']};
    }}
    QPushButton[voltageProfileButton='true'][profileTone='green']:checked {{
        background: {c['green_soft']};
        border-color: {c['green_border']};
        color: {c['green']};
    }}
    QPushButton[voltageProfileButton='true'][profileTone='orange']:checked {{
        background: {c['orange_soft']};
        border-color: {c['orange_border']};
        color: {c['orange']};
    }}
    QPushButton[voltageProfileButton='true'][profileTone='purple']:checked {{
        background: {c['purple_soft']};
        border-color: {c['purple_border']};
        color: {c['purple']};
    }}
    QLabel[voltageProfileDetail='true'] {{
        color: {c['muted']};
        background: {c['panel_alt']};
        border: 1px solid {c['border_soft']};
        border-radius: 9px;
        padding: 7px 10px;
        font-size: 10px;
        font-weight: 640;
    }}
    QFrame[voltageCurveGrid='true'] {{
        background: {c['panel_alt']};
        border: 1px solid {c['border_soft']};
        border-radius: 11px;
    }}
    QFrame[voltageGridHeader='true'] {{
        background: {c['neutral_soft']};
        border: 1px solid {c['border_soft']};
        border-radius: 7px;
    }}
    QLabel[voltageGridHeaderTitle='true'] {{
        color: {c['text']};
        background: transparent;
        border: none;
        font-size: 11px;
        font-weight: 830;
    }}
    QLabel[voltageGridHeaderDetail='true'] {{
        color: {c['subtle']};
        background: transparent;
        border: none;
        font-size: 9px;
        font-weight: 680;
    }}
    QFrame[voltageGridCell='true'] {{
        background: {c['panel_alt']};
        border: 1px solid {c['border_soft']};
        border-radius: 7px;
    }}
    QFrame[voltageGridCell='true'][cellRole='frequency'] {{
        background: {c['blue_soft']};
        border-color: {c['blue_border']};
    }}
    QFrame[voltageGridCell='true'][cellRole='proposed'] {{
        background: {c['cyan_soft']};
        border-color: {c['cyan_border']};
    }}
    QFrame[voltageGridCell='true'][cellRole='safe'] {{
        background: {c['green_soft']};
        border-color: {c['green_border']};
    }}
    QFrame[voltageGridCell='true'][cellRole='positive'] {{
        background: {c['green_soft']};
        border-color: {c['green_border']};
    }}
    QFrame[voltageGridCell='true'][cellRole='warning'] {{
        background: {c['orange_soft']};
        border-color: {c['orange_border']};
    }}
    QFrame[voltageGridCell='true'][cellRole='custom'] {{
        background: {c['purple_soft']};
        border-color: {c['purple_border']};
    }}
    QFrame[voltageGridCell='true'][cellRole='muted'] {{
        background: {c['neutral_soft']};
        border-color: {c['border_soft']};
    }}
    QLabel[voltageGridValue='true'] {{
        color: {c['text']};
        background: transparent;
        border: none;
        font-size: 12px;
        font-weight: 830;
    }}
    QLabel[voltageGridDetail='true'] {{
        color: {c['subtle']};
        background: transparent;
        border: none;
        font-size: 9px;
        font-weight: 650;
    }}
    QSpinBox[voltageEditor='true'] {{
        min-width: 116px;
        padding: 4px 8px;
        border: 1px solid {c['purple_border']};
        border-radius: 8px;
        background: {c['panel_raised']};
        color: {c['purple']};
        font-size: 11px;
        font-weight: 820;
    }}
    QSpinBox[voltageEditor='true']:disabled {{
        background: {c['purple_soft']};
        color: {c['disabled_text']};
        border-color: {c['purple_border']};
    }}
    QFrame[voltageWorkflowPanel='true'] {{
        background: {c['panel_alt']};
        border: 1px solid {c['border_soft']};
        border-radius: 10px;
    }}
    QFrame[voltageStepItem='true'] {{
        background: {c['panel_raised']};
        border: 1px solid {c['border_soft']};
        border-radius: 8px;
    }}
    QLabel[voltageStepBadge='true'] {{
        color: {c['blue']};
        background: {c['blue_soft']};
        border: 1px solid {c['blue_border']};
        border-radius: 10px;
        font-size: 8px;
        font-weight: 850;
    }}
    QLabel[voltageStepText='true'] {{
        color: {c['text']};
        font-size: 10px;
        font-weight: 700;
    }}
    QPushButton[voltageApplyButton='true'] {{
        padding: 7px 14px;
        font-size: 11px;
        font-weight: 820;
    }}
    QFrame[compactStatusLine='true'] QLabel[statusLineLabel='true'] {{
        font-size: 9px;
    }}
    QFrame[compactStatusLine='true'] QLabel[statusLineDetail='true'] {{
        font-size: 8px;
    }}
    QFrame[compactStatusLine='true'] QLabel[statusLineValue='true'] {{
        font-size: 9px;
    }}
    QFrame[compactSafetyNotice='true'] QLabel[noticeTitle='true'] {{
        font-size: 10px;
    }}
    QFrame[compactSafetyNotice='true'] QLabel[noticeTitle='true'][prominentNoticeTitle='true'] {{
        font-size: 12px;
        font-weight: 800;
    }}
    QFrame[compactSafetyNotice='true'] QLabel[noticeBody='true'][prominentNoticeBody='true'] {{
        font-size: 11px;
    }}
    QFrame[compactSafetyNotice='true'] QLabel[noticeBody='true'] {{
        font-size: 8px;
    }}
    QFrame[statusLine='true'] {{
        background: {c['panel_alt']};
        border: 1px solid {c['border_soft']};
        border-radius: 10px;
    }}
    QLabel[statusLineLabel='true'] {{
        color: {c['text']};
        font-size: 10px;
        font-weight: 760;
    }}
    QLabel[statusLineDetail='true'] {{
        color: {c['subtle']};
        font-size: 9px;
    }}
    QLabel[statusLineValue='true'] {{
        color: {c['blue']};
        font-size: 11px;
        font-weight: 800;
    }}

    QProgressBar[cuProgress='true'] {{
        min-height: 6px;
        max-height: 6px;
        margin-top: 4px;
    }}
    QFrame[cuTopologyTable='true'] {{
        background: {c['panel_alt']};
        border: 1px solid {c['border_soft']};
        border-radius: 15px;
    }}
    QFrame[cuTableHeaderCell='true'] {{
        background: {c['neutral_soft']};
        border: 1px solid {c['border_soft']};
        border-radius: 9px;
    }}
    QLabel[cuTableHeaderTitle='true'] {{
        color: {c['text']};
        background: transparent;
        border: none;
        font-size: 11px;
        font-weight: 830;
    }}
    QLabel[cuTableHeaderDetail='true'] {{
        color: {c['subtle']};
        background: transparent;
        border: none;
        font-size: 9px;
        font-weight: 680;
    }}
    QLabel[cuTableRowLabel='true'] {{
        color: {c['text']};
        background: {c['panel_alt']};
        border: 1px solid {c['border_soft']};
        border-radius: 10px;
        padding: 0 8px;
        font-size: 12px;
        font-weight: 830;
    }}
    QPushButton[wgpToggle='true'] {{
        background: {c['panel_alt']};
        color: {c['subtle']};
        border: 1px solid {c['border']};
        border-radius: 10px;
        padding: 6px 5px;
        font-size: 11px;
        font-weight: 830;
    }}
    QPushButton[wgpToggle='true']:hover {{
        border-color: {c['border_strong']};
        background: {c['panel_raised']};
    }}
    QPushButton[wgpToggle='true'][routeState='driver_on'] {{
        background: {c['green_soft']};
        color: {c['green']};
        border: 1px solid {c['green_border']};
    }}
    QPushButton[wgpToggle='true'][routeState='driver_on']:hover {{
        background: {c['green_soft']};
        border-color: {c['green_border']};
    }}
    QPushButton[wgpToggle='true'][routeState='extra_on'] {{
        background: {c['cyan_soft']};
        color: {c['cyan']};
        border: 1px solid {c['cyan_border']};
    }}
    QPushButton[wgpToggle='true'][routeState='extra_on']:hover {{
        background: {c['cyan_soft']};
        border-color: {c['cyan_border']};
    }}
    QPushButton[wgpToggle='true'][routeState='driver_off'] {{
        background: {c['red_soft']};
        color: {c['red']};
        border: 1px solid {c['red_border']};
    }}
    QPushButton[wgpToggle='true'][routeState='driver_off']:hover {{
        background: {c['red_soft']};
        border-color: {c['red_border']};
    }}
    QPushButton[wgpToggle='true'][routeState='off'] {{
        background: {c['panel_alt']};
        color: {c['disabled_text']};
        border: 1px solid {c['border_soft']};
    }}
    QPushButton[wgpToggle='true']:disabled {{
        background: {c['neutral_soft']};
        color: {c['disabled_text']};
        border-color: {c['border_soft']};
    }}
    QLabel[cuCountValue='true'] {{
        color: {c['blue']};
        background: {c['blue_soft']};
        border: 1px solid {c['blue_border']};
        border-radius: 10px;
        padding: 0 7px;
        font-size: 12px;
        font-weight: 850;
    }}
    QFrame[cuLegendBar='true'] {{
        background: {c['panel_alt']};
        border: 1px solid {c['border_soft']};
        border-radius: 11px;
    }}
    QWidget[cuLegendItem='true'] {{
        background: transparent;
        border: none;
    }}
    QLabel[cuLegendToken='true'] {{
        border-radius: 7px;
        padding: 4px 7px;
        font-size: 10px;
        font-weight: 850;
    }}
    QLabel[cuLegendToken='true'][routeState='driver_on'] {{
        background: {c['green_soft']};
        color: {c['green']};
        border: 1px solid {c['green_border']};
    }}
    QLabel[cuLegendToken='true'][routeState='extra_on'] {{
        background: {c['cyan_soft']};
        color: {c['cyan']};
        border: 1px solid {c['cyan_border']};
    }}
    QLabel[cuLegendToken='true'][routeState='driver_off'] {{
        background: {c['red_soft']};
        color: {c['red']};
        border: 1px solid {c['red_border']};
    }}
    QLabel[cuLegendToken='true'][routeState='off'] {{
        background: {c['neutral_soft']};
        color: {c['subtle']};
        border: 1px solid {c['border_soft']};
    }}
    QLabel[cuLegendText='true'] {{
        color: {c['muted']};
        font-size: 10px;
        font-weight: 690;
    }}
    QPushButton[registerToggle='true'] {{
        min-height: 20px;
        max-height: 30px;
        padding: 2px 9px;
        border-radius: 8px;
        font-size: 10px;
    }}
    QFrame[cuAdvancedRegisters='true'] {{
        background: {c['panel_alt']};
        border: 1px solid {c['border_soft']};
        border-radius: 12px;
    }}
    QLabel[cuAdvancedTitle='true'] {{
        color: {c['text']};
        font-size: 10px;
        font-weight: 820;
    }}
    QLabel[cuAdvancedSubtitle='true'] {{
        color: {c['subtle']};
        font-size: 8px;
    }}
    QLabel[cuAdvancedHeader='true'] {{
        color: {c['muted']};
        background: {c['neutral_soft']};
        border: 1px solid {c['border_soft']};
        border-radius: 7px;
        padding: 0 6px;
        font-size: 8px;
        font-weight: 790;
    }}
    QLabel[cuAdvancedRow='true'] {{
        color: {c['text']};
        background: {c['panel_alt']};
        border: 1px solid {c['border_soft']};
        border-radius: 7px;
        padding: 0 6px;
        font-size: 9px;
        font-weight: 800;
    }}
    QLabel[cuAdvancedValue='true'] {{
        color: {c['muted']};
        background: {c['panel_raised']};
        border: 1px solid {c['border_soft']};
        border-radius: 7px;
        padding: 0 6px;
        font-family: 'JetBrains Mono', 'Noto Sans Mono', monospace;
        font-size: 9px;
        font-weight: 720;
    }}
    QLabel[cuAdvancedValue='true'][pending='true'] {{
        color: {c['orange']};
        background: {c['orange_soft']};
        border-color: {c['orange_border']};
    }}
    QFrame[cuSelectionPanel='true'] {{
        background: {c['panel_alt']};
        border: 1px solid {c['border_soft']};
        border-radius: 12px;
    }}
    QLabel[cuSelectionTitle='true'] {{
        color: {c['text']};
        font-size: 12px;
        font-weight: 820;
    }}
    QLabel[cuSelectionDetail='true'] {{
        color: {c['muted']};
        font-size: 9px;
    }}
    QLabel[cuSelectionDetail='true'][tone='warning'] {{
        color: {c['orange']};
    }}
    QLabel[cuProfileNote='true'] {{
        color: {c['muted']};
        background: {c['blue_soft']};
        border: 1px solid {c['blue_border']};
        border-radius: 9px;
        padding: 8px 10px;
        font-size: 9px;
        font-weight: 760;
    }}
    QFrame[cuActivityDot='true'] {{
        background: {c['green']};
        border: none;
        border-radius: 4px;
    }}
    QFrame[cuActivityDot='true'][tone='blue'] {{ background: {c['blue']}; }}
    QFrame[cuActivityDot='true'][tone='purple'] {{ background: {c['purple']}; }}
    QFrame[cuActivityDot='true'][tone='red'] {{ background: {c['red']}; }}
    QFrame[cuActivityDot='true'][tone='gray'] {{ background: {c['subtle']}; }}
    QLabel[cuActivityTitle='true'] {{
        color: {c['text']};
        font-size: 10px;
        font-weight: 760;
    }}
    QLabel[cuActivityDetail='true'] {{
        color: {c['muted']};
        font-size: 9px;
    }}
    QWidget[computeUnitsPage='true'] QPushButton[compactAction='true']:disabled, QWidget[computeUnitsPage='true'] QPushButton[dangerAction='true']:disabled {{
        background: {c['neutral_soft']};
        color: {c['disabled_text']};
        border-color: {c['border_soft']};
    }}

    QFrame[curvePoint='true'] {{
        background: {c['panel_alt']};
        border: 1px solid {c['border_soft']};
        border-radius: 14px;
    }}
    QFrame[curvePoint='true']:hover {{
        background: {c['panel_raised']};
        border-color: {c['border_strong']};
    }}
    QLabel[curvePointTitle='true'] {{
        color: {c['text']};
        font-size: 11px;
        font-weight: 800;
    }}
    QLabel[curvePointBadge='true'] {{
        color: {c['purple']};
        background: {c['purple_soft']};
        border: 1px solid {c['purple_border']};
        border-radius: 7px;
        padding: 3px 7px;
        font-size: 8px;
        font-weight: 800;
    }}
    QFrame[fanChannelRow='true'] {{
        background: {c['panel_alt']};
        border: 1px solid {c['border_soft']};
        border-radius: 12px;
    }}
    QFrame[fanChannelRow='true']:hover {{
        background: {c['panel_raised']};
        border-color: {c['border_strong']};
    }}
    QLabel[fanChannelTitle='true'] {{
        color: {c['text']};
        font-size: 11px;
        font-weight: 800;
    }}
    QLabel[fanChannelDetail='true'] {{
        color: {c['subtle']};
        font-size: 9px;
    }}
    QLabel[fanChannelValue='true'] {{
        color: {c['text']};
        font-size: 10px;
        font-weight: 780;
    }}
    QLabel[fanChannelHeader='true'] {{
        color: {c['muted']};
        font-size: 8px;
        font-weight: 800;
        padding: 0 8px;
    }}
    QLabel[fanAccess='write'] {{
        color: {c['green']};
        background: {c['green_soft']};
        border: 1px solid {c['green_border']};
        border-radius: 8px;
        padding: 5px 7px;
        font-size: 8px;
        font-weight: 800;
    }}
    QLabel[fanAccess='admin'] {{
        color: {c['blue']};
        background: {c['blue_soft']};
        border: 1px solid {c['blue_border']};
        border-radius: 8px;
        padding: 5px 7px;
        font-size: 8px;
        font-weight: 800;
    }}
    QLabel[fanAccess='read'] {{
        color: {c['orange']};
        background: {c['orange_soft']};
        border: 1px solid {c['orange_border']};
        border-radius: 8px;
        padding: 5px 7px;
        font-size: 8px;
        font-weight: 800;
    }}
    QLabel[fanAccess='off'] {{
        color: {c['muted']};
        background: {c['neutral_soft']};
        border: 1px solid {c['border_soft']};
        border-radius: 8px;
        padding: 5px 7px;
        font-size: 8px;
        font-weight: 800;
    }}
    QFrame[pathsNavigation='true'] {{
        background: {c['panel_alt']};
        border: 1px solid {c['border_soft']};
        border-radius: 13px;
    }}
    QPushButton[pathsNavButton='true'] {{
        background: transparent;
        border: 1px solid transparent;
        border-radius: 9px;
        padding: 10px 11px;
        text-align: left;
        color: {c['muted']};
        font-size: 10px;
        font-weight: 720;
    }}
    QPushButton[pathsNavButton='true']:hover {{
        background: {c['panel']};
        color: {c['text']};
    }}
    QPushButton[pathsNavButton='true']:checked {{
        background: {c['blue_soft']};
        border-color: {c['blue']};
        color: {c['blue']};
        font-weight: 800;
    }}
    QFrame[pathsSection='true'] {{
        background: {c['panel_alt']};
        border: 1px solid {c['border_soft']};
        border-radius: 13px;
    }}
    QLabel[pathsSectionTitle='true'] {{
        color: {c['text']};
        font-size: 12px;
        font-weight: 820;
    }}
    QLabel[pathsSectionDescription='true'] {{
        color: {c['muted']};
        font-size: 9px;
    }}
    QFrame[pathEntry='true'] {{
        background: {c['panel']};
        border: 1px solid {c['border_soft']};
        border-radius: 9px;
    }}
    QLabel[pathEntryLabel='true'] {{
        color: {c['muted']};
        font-size: 9px;
        font-weight: 780;
    }}
    QLabel[pathEntryValue='true'] {{
        color: {c['text']};
        font-family: 'JetBrains Mono', 'Noto Sans Mono', monospace;
        font-size: 9px;
    }}
    """
    if ACTIVE_DENSITY == "compact":
        base += """
        QFrame[pageCard='true'] { border-radius:16px; }
        QTableWidget::item { padding-top:2px; padding-bottom:2px; }
        """
    base = scale_stylesheet(base)
    _STYLESHEET_CACHE[cache_key] = base
    return base

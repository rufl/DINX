"""GPU use cases."""

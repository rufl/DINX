"""Cross-domain value objects."""

"""Memory domain package."""

"""CPU infrastructure adapters."""

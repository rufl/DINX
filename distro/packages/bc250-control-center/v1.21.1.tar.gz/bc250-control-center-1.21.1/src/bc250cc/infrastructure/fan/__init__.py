"""Fan infrastructure adapters."""

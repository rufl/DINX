"""GPU infrastructure adapters."""

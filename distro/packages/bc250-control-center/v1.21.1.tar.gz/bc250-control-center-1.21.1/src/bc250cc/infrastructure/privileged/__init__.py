"""Typed privileged-operation adapters."""

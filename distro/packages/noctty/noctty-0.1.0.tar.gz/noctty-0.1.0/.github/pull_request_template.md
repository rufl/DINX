## What changed

-

## Why

-

## Tested

- [ ] `zig fmt --check build.zig src`
- [ ] `zig build check -j1 --summary all`
- [ ] `./scripts/check_docs_truth.sh` for docs/truth changes
- [ ] `./scripts/check_no_surprise_network.sh` for launch/network-adjacent changes
- [ ] `./scripts/check_public_source_hygiene.sh` for publication/community/workflow changes
- [ ] Other:

## Licensing and provenance

- [ ] I have the right to submit this contribution under the MIT License.
- [ ] New third-party code/assets include compatible provenance and notices, or none were added.

## Not claimed

-

# NOCTTY Changelog

This changelog starts from the live repository state refreshed on 2026-07-18. Earlier granular history should be reconstructed from git history when repository metadata is available.

## Unreleased
- Added a persisted optional `OpenGL (GPU presentation)` renderer setting
  (settings snapshot v17). The GTK `GtkGLArea` path uploads the authoritative
  Cairo image as a texture; context, shader, surface, texture, and draw
  failures replace the pane with Cairo on the main loop. GPU glyph rasterization
  and end-to-end GPU terminal rendering remain out of scope.
- Added renderer A/B benchmark selection through
  `NOCTTY_BENCH_RENDERER=cairo|opengl`; the native benchmark receipt records
  requested/effective backend, successful GPU presentations, texture uploads,
  and fallback count so software or Cairo fallback runs cannot be reported as
  GPU results.
- Fixed restored hot-session page rebuilding to retain the root pane widget
  and resolve root contexts in page/pane helpers, preventing GTK object
  use-after-free during native startup and benchmark setup.
- Started the primary native-grid context's PTY and event sources during host
  startup so output workloads continue draining beyond the PTY buffer.
- Fixed the OpenGL benchmark receipt validator to accept a zero-fallback
  receipt at end of line.
- Updated benchmark auditing to accept the documented native-Wayland visual
  metric omission.
- Migrated the native build and compatibility layer to Zig 0.17.0, including
  translated C modules for the Tree-sitter and networking adapters.
- Batched VT damage generations per PTY feed, restored the bounded 2 MiB native
  pump budget, and skipped empty pending-write flushes on read-only PTY pumps,
  reducing avoidable terminal main-loop overhead during multi-pane output
  without changing the renderer contract.
- Replaced per-row native-grid callbacks with one borrowed packed-frame
  snapshot per paint (ABI v7). The host owns and reuses the packed buffer;
  renderer qualification retains pixel parity and zero warm-frame allocations
  while reducing the C/Zig callback crossings.
- Added a lazy per-row Zig packed-frame cache keyed by row damage generations
  and viewport state, avoiding repeated cell-to-u64 packing on warm paints
  while preserving the ABI v7 host-owned frame buffer.
- Moved command-palette dispatch, split orientation/rendered-event selection,
  tab-rename boundary validation, and restored-session dimension minimums behind
  focused Zig policy plans; GTK retains activation, layout, editor, and session
  allocation effects.
- Moved ATK granularity normalization, keyboard-scroll action mapping, shortcut
  chord redraw/reopen side effects, and terminal renderer fallback colors into
  tested Zig policy; C retains GTK/ATK/Cairo/Pango effects.
- Polished the command palette, terminal find, quick-note, keyboard-shortcuts,
  theme-library, and project-workspace dialogs with shared theme-aware utility
  surfaces, bounded editor/search regions, visible focus and selection states,
  and focused visual smoke assertions.
- Polished the Settings and session-sharing dialogs with theme-aware grouped
  surfaces, readable label/control spacing, explicit action focus and tooltip
  affordances, and semantic preview/status styling; extended isolated smoke
  coverage for the visual classes.
- Refined Settings category selection with a theme-aware accent and stronger
  selected-label hierarchy; session-sharing controls now distinguish primary
  and destructive actions while retaining native focus, disabled, and
  accessible states.

- Moved sharing-preview key-event classification and terminal sequence encoding
  into a tested Zig policy entry; C retains clipboard requests, input
  transport, and transient feedback effects.
- Polished the compact native tab and Settings surfaces: tab event targets now
  expose the full title plus current-state assistive description, action
  controls retain keyboard focusability, Settings category rows retain pointer
  focus, and the tab/sidebar states distinguish hover, active, disabled,
  selected, and keyboard focus.
- Extended the compact UX smoke to require the rendered tab's assistive name
  and description alongside its existing geometry, icon, tooltip, and close
  checks.
- Moved D-Bus `RequestName` ownership-result classification and shortcut
  conflict/failure event identities into tested Zig policy; C retains protocol
  calls, callback dispatch, and native effects.
- Centralized D-Bus call, notification, drain, and polling timing in the tested
  Zig lifecycle plan; C retains GLib scheduling and D-Bus transport effects.
- Moved persisted compact-setting field/schema selection, defaults, font
  normalization, background-opacity clamping, and panel-metric bounds into a
  tested Zig settings plan; C retains callback acquisition and state effects.
- Moved compact-setting target mapping, font-rendering combo bounds, terminal
  context-menu action/selection geometry, theme display labels, and profile
  preset validity into tested Zig grid policy; C retains native state and GTK
  effects.
- Moved windowed-dimension percentage/floor selection and launch-profile kind
  normalization plus command/SSH sensitivity policy into tested Zig plans; C
  retains monitor queries, GTK size effects, and widget sensitivity.
- Moved workspace event routing classification, tray-menu item kinds/actions,
  and bounded native lifecycle timing constants into tested Zig plans; C retains
  GTK/GVariant/GLib effects and callback dispatch.
- Moved native host geometry bounds, scrollbar/copy limits, UI color role
  ordinals, status event IDs, persistence result codes, and remaining GTK
  lifecycle intervals into tested Zig plans; C retains native object access,
  GTK effects, and callback dispatch.
- Routed layer-surface hide commit, quick-note debounce, sharing refresh,
  resize-overlay hide/commit/arm intervals through the tested Zig lifecycle
  plan; C retains GLib source registration and callback effects.
- Centralized settings-control event IDs for appearance, scrolling, layout, and
  font-rendering callbacks in the tested Zig grid policy; GTK retains signal
  wiring, widget state, and native effect dispatch.
- Centralized native host protocol event identities, workspace routing codes,
  restore markers, layout-preset events, and GTK smoke callbacks in a tested
  Zig host-event map; C retains callback dispatch and native effects.
- Windows terminal right-click now opens the native Terminal context menu for
  Copy, Paste, and Clear Screen instead of disappearing through mouse
  tracking.
- Windows startup now surfaces persisted workspace, theme, and launch-profile
  restoration failures instead of silently falling back; the current session
  remains usable and points operators to Settings for recovery.
- Moved shared terminal-status color-role and fallback selection into the Zig
  grid-logic adapter; C retains markup construction and GTK color application.
- Moved compact-tab extent and close/action sizing arithmetic into the Zig
  grid-logic adapter; GTK retains allocation queries and native eligibility
  checks.
- Moved dirty-row/span capacity normalization and selection-copy buffer growth
  bounds into the Zig grid-logic adapter; C retains allocation and clipboard
  ownership.
- Moved Smart Tab visibility, first-visible/focused-pane tracking, focus-first,
  and empty-filter decisions into Zig; GTK retains widget visibility, focus,
  and empty-state construction.
- Moved GTK accessibility range clamping, character-offset validity, and
  word/line/sentence/paragraph range expansion into the Zig grid-logic adapter;
  C retains UTF-8 pointer conversion, returned-text allocation, and ATK effects.
- Moved startup visibility, activation-application, and native-smoke scheduling
  policy into Zig; C retains GTK effects, callback dispatch, and lifecycle.
- Moved accessible text capacity, cell-length filtering, and whitespace
  trimming into Zig; C retains GString construction and ATK effects.
- Moved panel gap splitting, multi-pane auto-fit bound aggregation, and
  allocation resize change detection into Zig layout plans; C retains GTK
  allocation queries, font propagation, overlays, and deferred resize effects.
- Moved session-sharing control enablement, contextual action-label selection,
  and status-message/error classification into the Zig grid-logic adapter; C
  retains widget sensitivity, native labels, discovery-field updates, and GTK
  effects.
- Moved compact-tab markup, tooltip, close-name, escaping, truncation, and
  suffix policy into the Zig grid-logic adapter; C retains title acquisition,
  GTK label/tooltip/accessibility effects, and tab-color styling.
- Moved native terminal feedback labels into the Zig grid-logic adapter; C
  retains status-feedback timing, GTK redraw, and presentation effects.
- Moved pane-status tooltip composition and startup recovery-notice message
  precedence into the Zig grid-logic adapter; C retains tag acquisition,
  InfoBar construction, GTK presentation, and response wiring.
- Moved output-presentation tick-versus-timeout selection into the Zig
  grid-logic adapter; C retains GTK source registration and terminal pump
  effects.
- Moved Smart Tab text, cycle-feedback labels, tab-title fallback precedence,
  notification body composition, and pane-zoom feedback into the Zig
  grid-logic adapter; C retains native acquisition and presentation effects.
- Moved zoom enter/unzoom selection into a tested Zig state plan; C retains
  pane visibility, notebook, focus, and resize effects.
- Moved settings shortcut button label and transport-specific tooltip composition
  into the Zig grid-logic adapter; C retains shortcut-key acquisition and GTK
  widget application.
- Moved note-overlay labels, window-title prefixes, close confirmations,
  layout-preset prompts, find-status text, keyboard-shortcuts text, and sharing
  peer/tab/pane labels into the Zig grid-logic adapter; C retains GTK and
  terminal-model effects.
- Moved layout-preset event validation and rows/columns/target-count selection
  into a tested Zig state plan; C retains pane enumeration, confirmations,
  session movement, and GTK layout effects.
- Moved settings-panel/background field normalization and layout-effect
  classification into a tested Zig state plan; C retains per-context state
  application, widget invalidation, window redraw, and event emission.
- Moved launch-profile payload serialization, profile-name validation, launch
  save-status messages, and Noctalia theme persistence-status composition into
  the Zig grid-logic adapter; C retains GTK acquisition and native effects.
- Moved restore-mode text, sharing selection IDs, pane drag identifiers, and
  terminal accessibility names into bounded Zig formatting helpers; C retains
  process, GTK selection/drag, and ATK effects.
- Fixed native Cairo ASCII glyph-cache reuse across repeated renderer frames;
  cache validity now follows the explicit native font-policy invalidation path
  instead of unstable scaled-font pointer identity, restoring zero warm-frame
  renderer allocations.
- Moved GTK window visibility toggle classification into the Zig grid-logic
  adapter; C retains activation, focus, overlay, and hide/show effects.
- Moved overlay dialog monitor-margin arithmetic into the Zig grid-logic
  adapter; C retains monitor lookup, layer anchors, and native margin effects.
- Routed dropdown window sizing and centering through the existing Zig
  adaptive-geometry planner; C retains monitor discovery and native resize/move.
- Moved fullscreen target selection for GTK and Wayland into the Zig
  grid-logic adapter; C retains monitor enumeration and native fullscreen calls.
- Hardened nullable GVariant ownership adapters so failed D-Bus calls cannot
  unref null replies during native-grid smoke and shutdown paths.
- Moved layer-shell dropdown, zen, and window sizing decisions into the Zig
  grid-logic adapter; C retains namespace, anchors, margins, and native effects.
- Moved the monitor fallback precedence for window, primary, pointer, and
  first-monitor selection into the Zig grid-logic adapter; C retains native
  monitor queries and returned handles.
- Moved monitor scale clamping and topology-change detection into the Zig
  grid-logic adapter; C retains native monitor queries and adaptation effects.
- Moved compact-tab sizing and settings-dialog geometry plans into the Zig
  grid-logic adapter; C retains GTK allocation, widget, and window effects.
- Added current-build mapped GTK evidence: Debug presentation and ReleaseSafe
  full-stack qualification pass under isolated X11 and Wayland sessions;
  physical Windows acceptance remains external.
- Routed residual GTK combo population, color chooser, allocated-size, and
  check-menu reads through the Zig adapter; C retains theme, sharing, and menu
  policy.
- Routed GTK object lifetime, metadata, clear operations, and GLib main-loop
  source scheduling through shared Zig adapters; C retains callback and UI
  policy.
- Routed GLib heap frees and clear-to-null ownership transitions through Zig
  memory adapters; C retains destruction ordering and policy.
- Routed GVariant reference/clear operations and GError cleanup through Zig
  adapters; C retains D-Bus protocol and failure policy.
- Moved GTK wheel route/accumulator planning, double-click word-boundary
  selection, and hyperlink-buffer validation into the Zig grid-logic adapter;
  C retains event extraction and native effects.
- Moved GTK keyboard chord classification into the Zig grid-logic adapter;
  C retains shortcut effects, terminal dispatch, and widget interaction.
- Moved GTK pointer-event classification for double-click zoom/selection,
  hyperlink menus, workspace menus, selection drag, and terminal mouse
  dispatch into the Zig grid-logic adapter; C retains native effects.
- Moved GTK resize-handle event classification for dragger double-clicks,
  click-to-drag promotion, drag updates, and release completion into the Zig
  grid-logic adapter; C retains native resize, dropdown, and focus effects.
- Moved GTK presentation-mode transition classification for dropdown surface
  recreation, layer-shell geometry, fullscreen, windowed, and dropdown updates
  into the Zig grid-logic adapter; C retains GTK lifecycle and geometry effects.
- Moved GTK overlay stacking classification for basic dialogs, existing
  overlays, layer-shell overlays, and parent-layer lowering into the Zig
  grid-logic adapter; C retains GTK stacking, monitor, and lifecycle effects.
- Routed remaining GTK tick cleanup, spin-button values, list selection,
  dialog response widgets, sensitivity/label reads, drag selection text,
  IM client windows, initialization, and main-loop entry through the Zig adapter.
- Routed the final direct GTK calls in the C adapter—accessible-class setup,
  input-context construction, recursive container traversal, and popup-window
  type reads—through Zig ABI adapters.
- Routed all GTK widget type predicates in the native grid host through a
  shared Zig GType adapter; C retains UI policy and GTK casts.
- Routed GTK combo active IDs/text, file chooser filenames, list-box row
  lookup/selection, event-box stacking, and entry icon operations through the
  Zig adapter; C retains workspace and dialog policy.
- Routed GTK text-buffer reads/writes, combo model row counts, and button/image
  icon reads through the Zig adapter; C retains note, suggestion, and icon
  presentation policy.
- Routed remaining GTK text-view editable state, style-background rendering,
  scroll-delta reads, synthetic button events, device attachment, and event
  cleanup through the Zig adapter; C retains popup and smoke-test policy.
- Routed GDK window origins, monitor lookup, enumeration, geometry, workarea,
  scale, pointer positioning, fullscreen dispatch, and cursor
  creation/application through the Zig adapter; C retains monitor and pointer
  policy.
- Routed remaining GDK paint scheduling, keyval conversion, screen visual and
  compositing reads, Wayland display detection, and synthetic event pointer
  attachment through the Zig adapter; C retains input and presentation policy.
- Routed GTK dialog content, run/response/default-response, window
  transient/icon reads, screen/app-paintable reads, URI opening, and main-loop
  exit operations through the Zig adapter; C retains modal and presentation
  policy.
- Routed GTK accessibility objects and style contexts, including class
  mutations, accessible names/descriptions/roles, and state reads through the
  Zig adapter; C retains UI policy and qualification assertions.
- Routed GTK clipboard retrieval/publication, IM focus and key filtering,
  and editable selection through the Zig adapter; C retains paste, sharing,
  and focus policy.
- Routed GTK label, markup, entry, button, combo, spin, toggle, and range
  mutations through the Zig adapter; C retains validation, settings, and
  action policy.
- Routed GTK label, tooltip, entry, spin, toggle, combo, range, and scale
  factor reads through the Zig adapter; C retains validation and settings
  policy.
- Routed GTK pane topology, orientation, container-child, bin-child, and
  widget-toplevel reads through the Zig adapter; C retains layout decisions
  and topology traversal policy.
- Routed remaining GTK focus, display, ancestor, grab, revealer, menu-state,
  size-request, frame-clock, and toplevel-list operations through the Zig
  adapter; C retains interaction and compositor decisions.
- Routed GTK widget destruction, including callback-bound destroy handlers, through the Zig adapter; C retains dialog, menu, and window lifecycle decisions.
- Routed direct GTK signal registrations through the Zig adapter; C retains signal names, callbacks, data ownership, and lifecycle decisions.
- Routed GTK swapped and object-bound signal registrations through dedicated Zig adapters; C retains callback semantics and lifetime decisions.
- Routed GTK drag source and destination setup through the Zig adapter; C retains pane drag targets, modifiers, actions, and event orchestration.
- Routed GTK recursive show, app-paintable, and visual state mutations through the Zig adapter; C retains surface visibility and compositor policy.
- Routed GTK window focus, geometry, activity, decoration, and resizeability reads through the Zig adapter; C retains sizing policy and smoke assertions.
- Routed GTK widget parent, visibility, mapped, destruction-state, and allocation reads through the Zig adapter; C retains layout and readiness decisions.
- Routed GTK coordinate translation and widget surface-window reads through the Zig adapter; C retains popup placement, focus, and event synthesis policy.
- Routed GTK tick callbacks, drag completion, resize-drag initiation, and main-loop polling through the Zig adapter; C retains event scheduling and interaction policy.
- Routed GTK notebook page, tab, action-widget, visibility, selection, reorder, and removal operations through the Zig adapter; C retains tab and workspace orchestration.
- Routed GTK menu popdown, item lookup/activation, shell selection/activation, attachment lookup, and popup placement through the Zig adapter; C retains menu orchestration and qualification assertions.
- Moved GTK grid window, notebook, and IM-context construction into the Zig native adapter; the C host retains lifecycle and event orchestration.
- Moved native grid window configuration policy into the Zig GTK adapter; C retains monitor capability detection, lifecycle signals, and smoke qualification.
- Moved GTK notebook action widgets and lifecycle signal wiring into the Zig native adapter; C retains callback implementations and workspace orchestration.
- Moved GTK grid-window lifecycle signal registration into the Zig native adapter; C retains lifecycle callback implementations and monitor signal wiring.
- Centralized GTK notebook page insertion and reorder/detach policy in the Zig native adapter; C retains tab identity and layout orchestration.
- Added native Windows launch-profile management with eight custom entries,
  Unicode names, executable/arguments/directory/environment/scrollback controls,
  rename/delete/selection, and transactional local persistence. Built-in
  PowerShell and Command Prompt remain available; changes affect new sessions.
  The launch planner resolves explicit executables, preserves inherited Unicode
  environment entries without mutating the parent, and never substitutes a
  built-in shell when a custom launch fails. `NWS3` layouts remain unchanged.
- Moved GTK notebook tab-position, toolbar orientation, visibility, and border policy into the Zig adapter; C retains profile state and event notification.
- Centralized GTK notebook page selection through the Zig native adapter across navigation, restore, reorder, split, and close paths.
- Moved GTK grid-window mode setters and title application into the Zig adapter; C retains mode transitions, title composition, and geometry policy.
- Moved GTK window presentation, fullscreen toggling, and XDG startup-ID application into the Zig adapter; C retains lifecycle timing and compositor-specific geometry.
- Centralized GTK focus ownership and terminal-area margin policy in the Zig adapter; C retains pane targeting and layout-state decisions.
- Routed remaining GTK focus requests through the Zig adapter across filters, tabs, dialogs, panes, scrollbars, palette flows, and startup restoration.
- Routed GTK draw-area, draw, and resize requests through the Zig adapter across terminal rendering, damage tracking, pane transitions, and resize settling.
- Routed GTK widget visibility, focusability, and zoom-tab hiding through the Zig adapter; C retains pane/filter state and notebook policy decisions.
- Routed GTK sensitivity updates through the Zig adapter across pane activation, launch-profile controls, workspace dialogs, and sharing actions; C retains enablement decisions.
- Routed GTK size requests and tooltip application through the Zig adapter across tabs, panes, dialogs, and resize affordances; C retains geometry and text decisions.
- Routed GTK window decorated, keep-above, and resizable mutations through the Zig adapter across settings, overlays, sharing, and resize affordances; C retains lifecycle and geometry decisions.
- Routed GTK dialog default-size, modality, positioning, type-hint, and parent-destroy policy through the Zig adapter; C retains surface lifecycle and geometry calculations.
- Routed GTK event-mask registration and dialog transient-parent binding through the Zig adapter; C retains event routing and overlay ownership decisions.
- Routed GTK window resize and move operations through the Zig adapter across dropdown, fullscreen, settings, pane-close, and native-resize paths; C retains geometry calculations.
- Routed GTK no-show-all and settings geometry-hint application through the Zig adapter; C retains dialog bounds and tab-rename state decisions.
- Routed GTK paned packing and divider-position mutations through the Zig adapter across split, restore, close, and resize paths; C retains workspace topology decisions.
- Routed GTK container and box packing, removal, border, and reorder mutations through the Zig adapter across dialogs, tabs, restored layouts, and window roots; C retains topology decisions.

- Fixed GTK settings qualification to select high contrast by stable theme ID
  rather than a palette-list position, and to own its maintenance autosave path.

- Added native Windows theme-library import/export with Unicode file pickers,
  up to 64 custom themes, persistent selection, terminal palette/cursor colors,
  and transactional failure handling. Portable files reuse the Linux codec;
  the separate Windows theme envelope leaves `NWS3` workspaces unchanged.
- Added guarded native Windows broadcast input. `Ctrl+Shift+B` and the
  Workspace menu require explicit confirmation before enabling, show the active
  state, fan input to live local panes, and remain unavailable to remote
  viewers; disabling is immediate.
- Broadcast input is intentionally session-scoped and is not restored from
  workspace state, preventing a saved layout from unexpectedly fanning input
  into every local pane after restart.
- Added native Windows Smart Tab controls for tag 1: `Ctrl+Shift+Y` toggles
  the focused pane tag and `Ctrl+Shift+G` toggles the volatile filtered view.

- Added captured native tab drag reordering with insertion feedback, stable
  identity checks, cancellation, and remote-viewer guards.

- Fixed shared theme decoding leaking the rejected duplicate name and
  overflowing arithmetic on a malicious name length. Regression tests now
  reject both cases without leaking or crashing.

- Gave the GTK layout-preset smoke real maintenance I/O and an owned autosave
  path, eliminating missing-I/O errors without disabling maintenance.

- Added native Windows proportional split dividers with drag preview,
  release-to-commit, cancellation, focused-axis menu resizing, and reset.
  Saved layouts now use `NWS3`; `NWS1`/`NWS2` migrate with equal ratios.
  Pane/session identity survives resizing and tab reordering.

- Added shared NOCTTY Dark, High Contrast, and Paseo Black Zinc terminal
  palettes to Windows, including ANSI colors. Native font controls now accept
  exact 8–32-point sizes with increase/decrease/reset and persisted preferences.

- Shared overflow-safe divider conversions between GTK and Windows, removing
  duplicated GTK C arithmetic and its signed multiplication overflow.

- Added a native Windows tab strip with selection, Unicode rename, and
  left/right ordering commands. Reordering preserves pane/session identity;
  remote tab names and order remain host-owned. Terminal geometry now reserves
  the strip across rendering, resize, and pointer input.

- Extracted the bounded Windows workspace and snapshot codec for display-free
  tests. Saved layouts retain tab names/order in `NWS2`; existing `NWS1` layouts
  remain readable at the same state-file path.

- Added native Windows Workspace and Terminal menus for tab/split creation,
  pane/tab navigation, guarded close, copy/paste, and focused Ctrl+L. Remote
  viewers disable local mutations and retain dispatch guards; failed paste or
  clear input delivery shows a native error.

- Shared terminal key encoding between GTK and Win32 without changing platform
  key mappings, cursor modes, or bounded-write contracts. Fixed Windows local
  Ctrl+Shift+Tab being swallowed by Ctrl+Shift letter-command handling.

- Changed Clear Screen to send Ctrl+L (`0x0c`) through the active PTY, leaving
  the shell responsible for redraw and ready for the next command instead of
  injecting a private terminal-screen escape sequence.

- Moved terminal scroll, font-size, panel-metric, and background-opacity
  clamping from the GTK host into tested native-grid Zig policy.

- Reused the native-grid settings policy for context initialization, removing
  duplicate GTK-side clamps from restored terminal and panel state.

- Moved repeated fullscreen and dialog workarea sizing clamps into tested
  native-grid Zig geometry policy.

- Moved bounded scroll deltas, tab title widths, search ordinals, selection
  spans, and restored grid partition sizing into tested native-grid Zig policy.

- Moved terminal damage clipping and cursor redraw rectangle bounds from the
  GTK host into tested native-grid rendering policy.

- Made dropdown and fullscreen geometry follow live monitor changes. Manual
  dropdown resizes now persist as monitor-relative percentages, legacy pixel
  sizes migrate on use, hidden windows adapt before reveal, and fullscreen
  remains compositor-resizable while being reaffirmed on the current monitor.
  A private-KWin smoke switches 1440×900 → 1024×640 → 1440×900 and validates
  compositor screenshots for both modes.

- Moved bounded UTF-8 and control-byte validation for GTK tab names and Wayland
  activation tokens into tested, allocation-free Zig native-grid logic.
  Hyperlink validation now shares the same policy.

- Moved native scrollbar thumb hit testing, saturated page targets, and
  continuous drag-to-history mapping from GTK C into tested Zig policy.

- Moved terminal font point-to-pixel conversion and bounded cell dimensions
  from GTK C into tested Zig policy. Rendering, damage, pointer mapping, and
  PTY resize now share one computed metric set per operation.

- Moved dirty row and cell-span invalidation geometry from GTK C into tested
  Zig policy. GTK now clamps the returned rectangles to the live allocation
  before queuing redraws.

- Added the `Paseo Black Zinc` built-in theme: pure-black terminal/workspace
  surfaces, zinc-950 through zinc-50 chrome, zinc selection and scrollbar
  states, and a high-contrast ANSI palette. It is available alongside the
  existing NOCTTY Dark and High Contrast themes and persists through the theme
  library.

- Moved GTK modifier-mask translation and Alt/Meta key detection into tested
  Zig input policy. GTK now forwards raw event state and key values through
  the native logic ABI.

- Moved tray-menu ID validation and resize-cursor orientation selection into
  tested Zig policy. GTK retains D-Bus menu construction and cursor creation.

- Moved tray-menu labels and icon-name selection into tested Zig policy. GTK
  retains only D-Bus variant construction and dynamic presented-state input.

- Moved resize-handle edge ordinal selection into tested Zig policy. GTK now
  receives the bounded edge value through the native logic ABI.

- Moved resize-handle storage-index normalization into tested Zig policy.
  GTK object data remains the transport for the 1-based handle identifier.

- Moved active-pane identity selection for dimmed rendering into tested Zig
  policy. GTK focus remains the fallback only when no model-selected pane exists.

- Moved terminal status-label selection (`running`, `done`, `error`, pending
  input, and idle fallback) into tested Zig policy.

- Moved profile preset label selection and custom fallback into tested Zig
  policy. GTK retains radio-menu construction and activation.

- Moved broadcast menu label selection into tested Zig policy. GTK retains
  only the live broadcast-state query and menu construction.

- Moved global shortcut component, action, display, description, and object-path
  naming into tested Zig policy for both normal and smoke identities.

- Moved resize-handle grid coordinates and size policy into tested Zig. GTK
  retains widget creation and attachment.

- Moved pane divider snap-point selection and threshold policy into tested Zig.
  GTK retains the paned-widget position query and update.

- Moved the command-palette action table into tested Zig. GTK retains
  palette widget construction and action activation.

- Moved workspace color-editor labels and roles into tested Zig. GTK retains
  settings-page widget creation.

- Restricted pane double-click zoom to empty background cells and added
  contiguous word selection for rendered text.

- Moved sharing-preview Enter, Tab, Escape, arrow, and editing-key sequence
  selection into tested Zig policy. GTK retains event-state extraction,
  clipboard retrieval, and sharing transport.

- Moved bracketed-paste begin/end marker selection into tested Zig. GTK retains
  clipboard retrieval, chunking, and sharing transport.

- Moved sharing-preview Home, End, Insert, Delete, Page Up, Page Down, and
  F1–F12 sequence formatting into tested Zig policy. GTK retains key-event
  routing and sharing transport.

- Moved sharing-preview printable and Alt-prefixed text buffering into tested
  Zig policy. GTK retains event-state extraction and sharing transport.

- Moved sharing-preview normal and application-cursor arrow formatting,
  including modifier variants, into tested Zig policy. GTK retains key routing
  and sharing transport.

- Moved sharing paste-size validation and 16 KiB chunk sizing into tested Zig
  policy. GTK retains clipboard retrieval, chunk transport, and feedback.

- Moved sharing-preview wheel direction and smooth-delta mapping into tested
  Zig policy. GTK retains event extraction and redraw scheduling.

- Moved sharing peer and stream selection-ID decimal parsing into tested Zig
  policy. GTK retains combo-box state and selection side effects.

- Moved normalized sharing-preview pane hit testing into tested Zig policy. GTK
  retains widget dimensions, event dispatch, and selection side effects.

- Moved sharing-preview pane selection-ID formatting into tested Zig policy.
  GTK retains combo-box updates and selection side effects.

- Moved theme color-editor channel clamping, rounding, and CSS-hex formatting
  into tested Zig policy. GTK retains color chooser interaction and settings
  dispatch; RGB-channel extraction now shares the same Zig boundary.

- Kept Windows NoctEd `--self-test` failures non-interactive: session-path and
  document failures now report their error names to stderr and exit nonzero
  instead of opening a modal dialog.
- Fixed NoctEd save/restore data-loss paths: Save checks the original file's
  identity before atomic replacement, dirty restored buffers with unknown disk
  versions require Save As, and newer edits cannot be discarded by a close-time
  save or delayed reload. Worker admission failures no longer double-free jobs.
- Bound language-service edits to request-time document snapshots instead of
  the active tab. Closed, changed, or unsnapshotted targets reject the response;
  workspace rename validates every target before mutating any buffer.
- Fixed maintenance failure paths that stranded autosave work or consumed a
  closed-tab snapshot on allocation failure. Recovery cleanup now executes the
  storage cleanup operation rather than reporting an invented empty receipt.
- Hardened sharing frame ownership, hostile workspace-layout traversal,
  request-scoped control consent, and host trust invalidation. Handshakes and
  encrypted-frame transfers now share an absolute five-second transaction
  deadline, so trickled input cannot renew a worker's wait indefinitely.
- Corrected terminal RIS mode/buffer reset and UTF-8 OSC parsing. Printable
  ASCII batching now preserves a preceding Unicode grapheme cluster and remains
  bytewise-equivalent. Windows shell profiles preserve complete
  sentinel-terminated command lines; wide-glyph backgrounds paint before
  leading glyphs, and oversized NoctEd previews cannot leave the previous file
  editable under the newly selected name.
- Added non-interactive Linux CLI help and unknown-option rejection before GUI
  activation. Help/version queries bypass dogfood receipts. Source-package
  inputs and installed third-party license texts are now complete, contributor
  instructions distinguish ordinary builds from maintainer qualification, and
  the source-hygiene gate rejects a failed Git inventory instead of passing.
- Made Linux release verification reproducible on clean runners: CI now
  provisions a repository-owned, serialized, pressure-gated bubblewrap/Xvfb
  boundary and virtual KWin, then runs the bounded source-alpha gate instead of
  invoking the maintainer matrix without its graphical prerequisites.
- Refreshed alpha captures through that private display boundary. Active-window
  framing removes desktop leakage; the current set covers Unicode and 24-bit
  terminal output, tabs and recursive splits, native settings, NoctEd project
  editing, and project-wide search. Capture failures or signals clean the
  application process tree, and assets publish only after every capture passes.

- Fixed pane zoom inside nested split trees: double-click now hides every
  sibling branch up to the page root, giving lower panes the full available
  width and height, then restores all branches without changing split ratios.
  Smart Tab filtering now uses the same empty-branch collapse and is reapplied
  after split, move, close, and preset rebuild operations. Tab creation, split,
  move, close, and preset mutations restore zoom first, keeping GTK visibility
  synchronized with the Zig workspace model.
- Moved nested split-branch visibility traversal, pane divider/gap styling,
  balanced split positioning, terminal key encoding, shortcut labels, hyperlink
  validation, command-palette fuzzy matching, dropdown size clamping, and
  sharing-status action policy from GTK C into tested Zig. Failed
  alternate-screen key or mouse-wheel delivery now produces visible feedback
  rather than becoming a silent no-op.
- Moved compact-tab, new-tab, and window-toolbar widget construction into
  `NativeGtk.zig`, including GTK ownership, callback wiring, accessibility
  names, and live close-button visibility. Tab/pane cycling, directional focus
  scoring, and the first keyboard-command routing layer now use exhaustive
  planners in `NativeGridLogic.zig`; GTK focus, IME, workspace, and terminal
  effects remain in the C adapter.

- Hardened isolated X11 and virtual-Wayland scratch teardown against the
  short GVfs directory-creation race seen after private D-Bus shutdown. Cleanup
  retries once after 100 ms, then still fails closed if the private tree remains.

- Fixed a live layout qualification race: the newly materialized 4×4 page now
  retries bounded geometry, auto-fit, terminal-readiness, and TUI checks before
  teardown instead of treating provisional allocations as a permanent failure.
  Hardened terminal-session ABI entry points against null handles and invalid
  resize dimensions.

- Added configurable inactive-pane brightness, disabled/transparent/theme-colored
  pane gaps, monitor-resolution adaptation in every presentation mode, safe
  default-browser hyperlink actions and link menus, TUI-aware theme palettes,
  and independently persisted per-tab themes.
- Fixed wheel behavior across alternate-screen TUIs: requested DEC mouse mode
  receives wheel reports, emitted full-screen scroll rows enter bounded local
  history, and applications with neither receive xterm-compatible cursor-key
  wheel fallback. Codex no longer requires `--no-alt-screen` for scrolling.

- Crossed the enforced 80% Zig core-ownership threshold by moving the native
  sharing-preview Cairo renderer to Zig, separating smoke-only C from the
  production GTK host, and relocating stable public adapter headers under
  `include/noctty`.

- Reordered the Split Pane menu by daily-use frequency: Split Right, Split Down,
  Split Up, then Split Left. The compact UI smoke now verifies this order.

- Fixed optimized Linux builds against fortified glibc headers by disabling
  `_FORTIFY_SOURCE` inside the bounded socket C import; native C compilation
  keeps the repository's normal hardening flags.

- Fixed the remaining Linux dogfood popup-stack warning by dismissing stale
  process-local GTK popup windows before opening terminal or tab menus. The
  logging launcher now counts Wayland's exact non-topmost-parent warning and
  makes it fail the multi-OMP clean-log contract instead of silently recording
  zero warnings.

- Made repeat dogfood installation survive later removal of the host GTK Layer
  Shell package without accepting an arbitrary library: the installer
  preflights and reuses only the private runtime whose SHA-256 matches the
  previous `0600` build receipt, and otherwise fails before replacing installed
  files. Both NOCTTY and NoctEd `--version` calls now bypass session receipts as
  documented. An isolated fake-prefix smoke proves both retained-runtime
  admission and rejection-before-mutation.

- Added a checksum-bound Windows dogfood delivery ZIP containing the existing
  per-user NSIS installer and a PowerShell verifier/installer. Successful
  physical installs verify both installed self-tests and retain an atomic local
  install receipt. The artifact is discovered by PI WEB QOL's existing
  token-scoped Builds service; unsigned and physical-qualification boundaries
  remain explicit. The Wine installer lifecycle smoke now bounds and identifies
  each external step plus cleanup instead of hanging until its outer display
  timeout.

- Hardened the shared isolated-X11 launcher against an inherited Wayland GTK
  preference by forcing `XDG_SESSION_TYPE=x11` and `GDK_BACKEND=x11`; its smoke
  now injects the conflicting parent environment and proves the override.

- Fixed Codex inline-mode scrollback retention by treating explicit zero
  DECSTBM parameters as terminal defaults. Codex emits `CSI 1;0 r`; NOCTTY now
  resets the full-screen scroll region and cursor like xterm instead of ignoring
  the sequence, allowing subsequent line feeds to enter bounded history.

- Completed the experimental Win32 terminal-host source migration. Zig now owns
  the main HWND, timers, hit testing, focus/capture, input, workspace-session
  orchestration, command/message dispatch, ConPTY, GDI rendering, menus,
  clipboard, fonts, diagnostics, and bounded mouse policy. The retired
  `native_host.c` translation unit is no longer compiled; physical Windows
  qualification remains a separate acceptance boundary.

- Continued extracting platform-neutral GTK native-grid policy: Zig now decides
  scrollbar, local selection, application-mouse, terminal-scroll, tab-cycle,
  pane-cycle, and font-zoom routing while C retains GTK events, widget/capture
  lifetimes, callbacks, and rendering. Existing Zig ownership also covers
  scrollbar/thumb geometry, wheel accumulation, keyboard scroll targets, grid
  dimensions, auto-fit, resize bounds, pointer mapping, selection hit testing,
  and pixel-snapped spans.

- Ported the complete experimental Windows NoctEd controls adapter from C to
  Zig and removed its private C ABI header. Zig now owns RichEdit/tree/tab
  HWNDs, GDI fonts, menus, accelerators, settings/find dialogs, DPI layout,
  document-close confirmation, UTF conversion, and the Win32 message loop. A
  dedicated mock-callback qualification found and fixed Zig's stricter
  pseudo-HMENU alignment at Win32 control creation. Post-fix mapped runs pass
  under isolated Wine in Debug and `ReleaseSafe`; physical Windows behavior
  remains a separate acceptance boundary.

- Replaced the Python Unicode table generator with a bounded, hash-verifying
  Zig tool and added its parser/merge/hash tests to `zig build check`. The
  generated table now records the Zig regeneration command while retaining its
  pinned Unicode 17 input/output contract. Windows NoctEd startup also moved
  session-path creation, command-line handling, UTF-16/WTF-8 conversion, and
  bootstrap error dialogs from its C host into Zig.

- Ported the first-party session-sharing socket implementation and Windows
  DPAPI/state persistence from C to Zig. The transport now uses typed slices
  and explicit socket ownership while retaining bounded connect/I/O timeouts,
  loopback pairing, multicast discovery, atomic Windows writes, current-user
  encryption, and Linux/Windows build coverage. The obsolete C translation
  units and private headers were removed; native GTK/Win32 UI adapters remain
  explicit platform boundaries.

- Prepared the tracked source for GitHub review with pinned read-only Linux and
  Windows source CI, a deterministic publication-hygiene guard,
  feature-request/community templates, contributor licensing terms,
  conduct/support policies, private vulnerability-reporting instructions, an
  operator-owned GitHub publication runbook, and removal of unreferenced
  placeholder screenshot SVGs. Source publication remains separate from the blocked
  public-alpha announcement and binary-release evidence.

- Removed the repository's prebuilt LGPL GTK Layer Shell fallback and unused
  GIR/header payload. Runtime, dogfood, and bundle paths now require the system
  `libgtk-layer-shell.so.0`; private bundle staging remains fail-closed on host
  package ownership and retained license notices instead of redistributing an
  inadequately sourced binary in the MIT repository.

- Repaired native renderer qualification: X11 and Wayland now run in separate
  private display/session namespaces, ABI assertions use current ABI v6, and
  the Wayland wrapper clears inherited Qt/GTK plugin variables that could crash
  its virtual compositor before the test. The bounded public-source gate now
  passes both backends instead of printing an X11 receipt before failing.

- Restored vertical-only Settings scrolling and made the category rail, label
  columns, page padding, and geometry bounds fit a 1440×900 display at 2× GTK
  scale. The HiDPI smoke now checks stable behavior fields instead of one stale
  full-line receipt and proves `geometry=sane horizontal_scroll=false`.

- Documented ownership boundaries at the largest native, model, terminal, and
  editor entry points. The bounded pane-equalization timeout now cancels when
  its GTK layout is destroyed, preventing an early tab/window teardown from
  retaining the layout until a later main-loop iteration.

- Removed the redundant **New 1×1** split-tab action; **New Tab** remains the
  single-terminal path. Newly materialized preset grids now receive a bounded
  post-map equalization pass in addition to resize-ratio tracking, and the 2×2
  geometry gate requires pane dimensions to remain within eight pixels after
  GTK spacing and divider rounding.

- Removed fractional-row seams from terminal/TUI background fills by snapping
  colored spans outward to device-pixel boundaries. Drag selection now follows
  linear terminal text: the first and final rows honor their endpoints and all
  intervening rows select completely in either drag direction. Clipboard copy
  uses the same range semantics and grows safely to a bounded 4 MiB instead of
  silently failing beyond the former 16 KiB stack buffer.

- Preserved terminal history for NOCTTY-generated Codex resume sessions by
  launching Codex with `--no-alt-screen`; documented Codex's persistent
  `tui.alternate_screen = "never"` control and the equivalent explicit
  fullscreen limitation in Pi.

- Removed tracked `dist/` archives, binaries, install trees, and build logs;
  generated distribution output is now ignored and recreated by package gates.

- Hardened session-sharing recovery and fail-closed UX across the shared core,
  native Linux dialog, and experimental Windows command surface. Stopped or
  failed host/viewer objects can now be explicitly cleared; invalid concurrent
  actions are disabled; revoked peers disappear from actionable selectors and
  require confirmation; paired-device save failures remain visible and
  retryable; full stores reclaim revoked capacity; dialog close stops pairing,
  discovery, hosting, and receiving; and listening pairing workers poll bounded
  cancellation instead of depending on cross-thread blocking-accept teardown.
  Remote input/paste failures remain visible for three seconds, bracketed-paste
  cleanup is best-effort after a failed chunk, and remote paste is capped at
  64 KiB. The focused paired-device tests pass 3/3, native Linux smoke and
  experimental Windows Debug binaries compile, and the native source contract
  passes. The mapped flow remains unclaimed because the isolated runner could
  not create its private lock/socket namespace in this sandbox.

- Closed another low-risk native UI/accessibility tranche. Workspace restore,
  encrypted-history password, agent-resume, and sharing controls now expose
  explicit assistive names, as do terminal-tab rename, workspace-tag,
  Noctalia-import, and NoctEd language-service controls. Tag input is trimmed
  without modifying GTK's borrowed entry buffer. Sharing and NoctEd
  search/status changes publish native status or alert events. The sharing
  preview request is bounded by the dialog work area instead of forcing its
  former 480x260 minimum on compact screens. Unchanged timer-driven status is
  de-duplicated so screen readers are not notified every 200 ms, and the
  focused sharing smoke now checks those contracts.

- Fixed `Open NoctEd Here` to launch the standalone editor with the selected
  pane directory as its real process cwd while retaining explicit `.npr`
  project activation. Failed agent-resume clearing now reports a native error
  instead of silently doing nothing.

- Made compact transient surfaces responsive to the active monitor work area.
  Terminal find and command rows stack at narrow widths, Quick Note and the
  command/shortcut surfaces use bounded scroll geometry, failed Quick Note
  reads become read-only instead of overwriting prior state, and dynamic
  note/theme results publish native accessibility status or alert events.

- Hardened durable native settings: theme reads recheck their size after file
  loading, installed Noctalia imports share the bounded reader, profile and
  active-theme actions distinguish config-write failure, and theme controls
  retain visible success/failure feedback.

- Hardened recoverable native actions without turning ordinary user or I/O
  errors into a hard workspace synchronization failure. Workspace save/open
  failures now remain visible and retryable, hot-session write-through reports
  its real result, and theme imports are bounded to regular nonempty files,
  report success/failure in the owning dialog, refresh live selectors, and
  redraw the applied theme immediately.

- Improved compact native UI behavior at low width and for assistive
  technology. Settings can scroll on both axes when its controls exceed the
  work area, terminal and NoctEd close buttons identify the tab/file they will
  close, and new split layout no longer queues the same parent resize twice.
  The reviewed legacy isolated-X11 fallback now also owns a private
  `XDG_RUNTIME_DIR` instead of inheriting desktop-session sockets.

- Fixed Codex and other mouse-reporting TUIs shadowing NOCTTY's visible pane
  scrollbar. Wheel events inside the native rail now move Zig-owned history
  before terminal mouse reporting is considered; wheel events over terminal
  content still reach the TUI. The focused scrollbar smoke now proves both
  halves instead of placing its TUI event inside the scrollbar hit target.

- Hardened the dogfood lifecycle paths implicated by retained failures.
  Terminal-only sessions no longer run git status/log subprocesses every ten
  seconds; project data refreshes when Project / NoctEd is opened. Sharing
  refresh sources are explicitly owned and cancelled, menu teardown validates
  pane contexts before dereferencing them, real pointer menus anchor to the
  top-level surface, and recoverable config/autosave failures are logged
  without being misreported as `NativeGridStateSyncFailed` on normal exit.
  NoctEd window destruction is now idempotent and calls `gtk_main_quit` only
  while a GTK main loop exists. Current-build multi-hour recapture remains an
  explicit backlog boundary.

- Opening or closing a split pane now redistributes the resulting split tree by
  descendant pane count. Split ratios remain proportional while nested 2×2
  allocations and fullscreen window geometry settle, while subsequent manual
  divider resizing remains unconstrained and becomes the new resize ratio.

- TUI applications such as Pi and OMP now receive a visible blinking caret
  drawn above field backgrounds and text, with input and cursor movement
  restarting the visible blink phase. The caret color is theme-configurable.

- Double-clicking a pane in a multi-pane tab focuses it at full available width
  and height, shows the active session name, and restores the exact split
  geometry on the next double-click. Disabling broadcast input through
  `Ctrl+Alt+B`, `Ctrl+Shift+B`, the pane menu, or the command palette now shows
  an explicit `Broadcast mode disabled.` confirmation.

- Fixed background translucency disappearing when Settings closes under Niri.
  The managed dropdown rule now disables Niri's opaque focus-ring backing
  rectangle with `draw-border-with-background false`, while preserving the
  focused ring and all NOCTTY layout/input behavior.

- Every application-close origin—including window controls, toolbar, tray, and
  natural last-session exit—now requires explicit **Close Anyway** confirmation,
  even when no foreground process is detected.

- Terminal history now has a hard 10,000-line default across current, pooled,
  split, restored, and profile-launched sessions. Persisted or imported zero
  values migrate to 10,000 instead of disabling scrollback.

- The pane-information footer now uses an opaque black background. The old
  default side/bottom resize targets migrate from 3px/18px to 2px/2px;
  customized thickness values remain unchanged.

- The dropdown bottom dragger now toggles exactly once between full and
  half-screen height on double-click. The terminal context menu now offers
  Split Down, Up, Left, and Right under **Split Pane**, and labels new preset
  tabs as **New Split Tab**.

- Theme Library now discovers installed Noctalia colorschemes under the user
  configuration directory, lists them alphabetically, and applies either the
  Dark or Light variant with explicit status and safe empty/error states.

- Added Noctalia JSON theme import for active `colors.json` material colors and
  complete dark/light colorscheme variants, including terminal foreground,
  background, cursor, selection, all 16 ANSI colors, and NOCTTY chrome/status
  role mapping. Dark and light imports retain distinct names.

- Settings now shows the currently mapped open/retract shortcut directly on
  the change button and refreshes the label after recording a replacement.

- Added persisted Appearance controls for workspace tint, compositor-aware
  background translucency and opacity, pane borders, scrollbars, overlays,
  selection, search, and status colors. Focused, selected, and unselected pane
  borders, status and overlay outlines, split handles, window resize borders,
  and the bottom dragger now have independent persisted thickness controls.
  Unsupported compositor alpha falls back to opaque rendering with an explicit
  Settings notice.

- Added persisted wheel-step and smooth-scrolling controls, raised normal
  session scrollback defaults to 10,000 lines, and synchronized live, restored,
  split, profile, context-menu layout, and legacy two-pane session limits.
  Scrolled viewports preserve their logical rows as output arrives; keyboard
  and paste input return them to the live bottom. Wheel events over terminal
  content reach mouse-reporting applications with bounded coordinates, while
  the visible native scrollbar rail always retains history-navigation priority.

- Uncolored tab titles now inherit GTK's theme text color instead of forcing
  white text, restoring readable titles with light desktop themes while
  retaining contrast-aware text for explicitly colored tabs.

- Disabled KDE startup notification for NOCTTY's layer-shell desktop entry.
  KWin cannot resolve a layer surface as an activatable xdg-toplevel; its
  activation timeout was followed by a compositor main-thread stall.

- Shortcut-enabled dropdown startup now keeps the toplevel unmapped until it
  is explicitly shown, avoiding a rapid layer-surface create/configure/destroy
  cycle. Layer surfaces also skip inapplicable xdg activation requests.

- Fixed NoctEd's About dialog close affordance by explicitly revealing and
  sizing the GTK response button, giving it a high-contrast native style, and
  covering both visibility and the close response in native smoke.

- Fixed the NOCTTY terminal context menu's **Command Palette…** item routing
  to the actual command palette instead of action 17, which is tab rename.
  Palette opening now waits for menu teardown so focus lands in command search,
  and compact native smoke rejects any resulting inline tab rename.

- Improved Linux NoctEd project navigation with an always-visible file-tree
  toggle, a matching sidebar-header hide control, and an Up button that
  reopens the parent directory and disables at the filesystem root. Native
  smoke covers parent navigation and sidebar hide/restore behavior.

- Fixed native GTK dogfood window lifecycle regressions: presentation-mode
  changes now recreate the toplevel without losing Settings, tray Show recovers
  a hidden surface even if cached presentation state drifted, shortcut recording
  temporarily releases the active Plasma accelerator and hides Settings while
  the overlay recorder owns compositor keyboard focus so keys such as F10 can
  be captured, and layer-shell dialogs are initialized on the overlay layer
  above the dropdown.

- Added native NoctEd font controls on Windows. The editor exposes
  View-menu zoom commands and accelerators, `Ctrl+wheel` document zoom, and a
  DPI-aware Settings dialog for exact 8–32 point sizes. The selected size is
  atomically persisted in NoctEd's GUI-owned settings and reported in the
  status bar.

- Added persistent 8–32 point native interface font sizing to Linux NoctEd.
  **Settings > Interface Font Size...** adjusts menus, tabs, the sidebar,
  dialogs, and status text without changing document text. View-menu actions,
  `Ctrl++`, `Ctrl+-`, `Ctrl+0`, and `Ctrl+wheel` retain independent bounded
  60–240% code-text zoom. Interface-font CSS excludes the GtkSourceMap, and
  native smoke now bounds minimap geometry so it cannot expand into a second
  full-size editor. The interface value is stored atomically in NoctEd's
  GUI-owned `settings.conf`.

- Completed the next native Windows source tranche. The Win32 terminal now has
  Unicode-aware drag selection, bounded clipboard extraction, and DEC
  1000/1002/1003 mouse reporting with legacy and SGR encoding. The package now
  includes the separate native `nocted.exe` editor, a reproducible per-user
  NSIS installer with reversible shortcuts and Open-With registration, and a
  fail-closed operator signing-hook contract with per-artifact verification
  receipts. Cross-build, Wine-hosted self-tests, and installer lifecycle smoke
  pass; physical Windows 10/11 qualification and real release signatures remain
  external release boundaries.

- Improved native GTK usability after a full dogfood audit: windowed mode now
  uses native movable/resizable decorations, the active pane has a persistent
  focus ring, sharing and settings surfaces stay above the dropdown and remain
  scrollable, terminal history supports keyboard navigation, and terminal
  content is exposed through ATK text semantics. Launch-profile actions now
  report validation and save status, shortcut help reflects the configured
  accelerator, and compact tab controls use reliable 24-pixel targets.

- Added native Windows settings and workspace continuity controls. The Win32
  menu now selects dark or system high-contrast colors, terminal font size,
  and the launch profile used by new ConPTY sessions. Users can explicitly
  save and restore bounded tab/split layouts and choose startup restoration;
  state is atomically persisted with version and checksum validation under
  `%LOCALAPPDATA%\NOCTTY`. Restoring starts replacement shells and deliberately
  does not claim to preserve shell contents.

- Added Konsole-style per-pane scrollbars to the native terminal surface. Each
  visible pane now renders its own bounded scrollback thumb; wheel scrolling,
  track clicks, and thumb dragging navigate the Zig-owned viewport without
  taking keyboard focus from another pane.

- Added telemetry-free automatic multi-OMP dogfood extraction. Installed
  launchers pin the local `omp/X.Y.Z` version and a private log path; the native
  host recognizes foreground `omp` processes and records bounded local events
  for hashed worktrees/workspaces, concurrency, concurrent output, isolated
  input/paste/focus, resize, hide/show, protected close paths, normal exit,
  restored-layout relaunch, and PTY delivery. The launcher appends a fail-closed
  clean-log result after exit. `dogfood_status.sh` correlates only matching
  restored workspace identities, requires every event and clean contributing
  log, and cannot qualify independently keyed complementary partial runs.

- Hardened installed-host dogfood evidence. Every `noctty` and `nocted`
  launcher writes a private atomic running receipt before process start, then
  replaces it with host/boot identity, wall and monotonic timestamps, elapsed
  seconds, backend/session context, log path, and zero or nonzero exit status.
  Abruptly killed launchers leave an explicitly incomplete receipt rather than
  inventing elapsed acceptance. The runtime counter imports both version-1
  receipts and retained legacy logs, reports NOCTTY and NoctEd hours separately
  to avoid overlapping-time inflation, and identifies two-hour runtime
  candidates. `dogfood_status.sh` now counts only unique two-hour NOCTTY
  receipts linked from real-work log entries; missing, duplicate, incomplete,
  short, or runtime-only evidence stays uncounted. On this host the retained
  legacy logs contain 8.777 NOCTTY process-hours and 3.056 NoctEd process-hours;
  one 4.466-hour NOCTTY candidate remains uncounted because its work context was
  not recorded and it ended with a retained file-descriptor/display failure.

- Added explicit paired session sharing between Linux and Windows NOCTTY hosts.
  Devices establish and pin X25519 identities through a Noise XX
  ChaCha20-Poly1305/BLAKE2s handshake, require the same six-digit confirmation
  on both sides, and then exchange bounded, versioned, authenticated terminal
  presentation frames over direct TCP. Linux hosts can pin a share to one pane,
  follow one tab, or follow the entire workspace. Tab order, active state,
  titles, pane membership, and pane lifecycle synchronize without reconnecting;
  independently sequenced remote grids preserve unaffected panes during
  resynchronization. Linux receivers expose shared-tab and shared-pane
  selectors. Windows receivers identify the share scope and selected hierarchy
  in the native title, use `Ctrl+Tab` to cycle shared tabs, and use
  `Ctrl+Shift+Tab` to cycle panes inside the selected tab. Both sides require
  matching workspace, dynamic-pane, tab-hierarchy, share-scope,
  resynchronization, keepalive, and per-pane-control capabilities before
  accepting presentation state. Sequence gaps trigger a fresh bounded
  structured checkpoint, idle host links require authenticated keepalive
  replies, and explicit stop paths send a bounded disconnect reason. The
  active shells remain on the host; receivers start view-only, remote input
  requires a separate host grant for the selected pane and current connection,
  and pane closure, pane selection, resynchronization, revoke, disconnect, or
  reconnect ends that grant. Receivers retain and navigate the latest 64
  scrollback rows per pane, accept explicit bracketed clipboard paste and
  comprehensive terminal special-key routing, and preserve a scrolled view as
  new history arrives. A reconnect action repeats paired-key authentication,
  rebuilds the bounded workspace checkpoint, and always returns to view-only.
  Device revocation closes matching live links.
  Linux provides a native Session Sharing dialog, opt-in LAN listener
  discovery, scope controls, revision-aware hierarchy selectors, and a Cairo
  receiver that reconstructs every pane in the selected tab from the host
  split tree and ratios; the experimental Windows host provides DPAPI-protected
  identity storage, command-line LAN discovery and pair/share/receive modes,
  hierarchy cycling, split-layout reconstruction, direct pane selection, and
  rendering through its existing GDI surface.
  Manual hostname, IPv4/IPv6, LAN, tailnet, and routed-VPN endpoints remain
  supported without a relay, account service, NAT traversal, subnet scan,
  telemetry, or background discovery.
  Focused protocol/security/loopback tests pass; the Windows host cross-build
  passes, while physical cross-machine Windows/Linux and VPN qualification
  remain open.

- Added bounded local tabs and recursive splits to the experimental Windows
  host. Up to 16 tabs and 32 panes own independent ConPTY processes, output
  rings, Zig VT grids, replies, resize state, lifecycle, and clean teardown.
  `Ctrl+Shift+T` opens a tab, `Ctrl+Shift+S` splits down, `Ctrl+Shift+L` splits
  left, `Ctrl+Tab` cycles panes, `Ctrl+Shift+Tab` cycles tabs, `Ctrl+D` closes a
  pane, and `Ctrl+Shift+W` closes a tab while protecting the final session.
  Clicking a pane focuses its exact session; the native title reports current
  tab/pane counts. A pane share remains pinned to the ConPTY selected when
  sharing starts, so an existing remote-control grant cannot migrate when local
  focus changes. Debug and `ReleaseSafe` Windows cross-builds pass, and the
  Wine-hosted no-window test now covers VT plus nested workspace layout,
  cycling, collapse, and close protection. Physical Windows ConPTY/GDI/input
  qualification remains open.
- Added the first experimental native Windows terminal tranche: an x86_64 Win32/GDI GUI, ConPTY shell transport, shared Zig VT/parser, Unicode and control-key input, live resize, ANSI/true-color rendering, scrollback, visible-surface copy, clipboard paste, bounded local lifecycle/error logs, and local crash minidumps with no upload path. Windows builds no longer require GTK target libraries; `scripts/package_windows.sh` emits a checksummed `ReleaseFast` ZIP and manifest. The cross-build passes Debug/`ReleaseSafe`/`ReleaseFast` compilation and a Wine-hosted no-window VT fixture; physical Windows behavior, settings/restore, selection/mouse reporting, NoctEd, ARM64, signing, and installer packaging remain open.
- Added lightweight NoctEd word wrap: `Alt+Z` toggles word wrapping across open documents, the View menu exposes the same checkable setting, and the choice persists in the GUI-owned settings file.
- Reduced native NOCTTY and NoctEd tab/action chrome height again: controls now target 18 logical pixels while preserving 28-pixel horizontal hit widths; tab labels retain 90% typography and compact padding.
- Hardened the native Cairo row-buffer path against an undersized callback buffer. The renderer now falls back to per-cell reads instead of indexing past the owned row storage.
- Fixed live presentation-mode changes from Drop-down to Windowed or Zen fullscreen. NOCTTY now rebuilds the native top-level surface around the existing terminal workspace so a Wayland layer-shell drop-down becomes a real movable window/fullscreen surface instead of retaining drop-down anchoring.
- Hardened NoctEd hot-exit recovery against multi-launch data loss. Desktop and file-association launches now route through one primary `GApplication`; a filesystem lock protects the same configuration when D-Bus registration is unavailable, explicit file opens preserve the existing restored session, and isolated native smoke runs bypass the production singleton.
- Prevented blank prompt lines during tab, split, and preset-layout creation. Terminal PTYs now ignore transient allocations while their GTK surface is unmapped, apply the real allocation on map with the existing debounce, retain the two-cell PTY floor, and defer focus until the activating key event has finished instead of letting an Enter activation reach the new terminal.
- Removed the drop-down's first-launch input-grab flash on Plasma Wayland. Automatic KGlobalAccel startup now keeps the exclusive layer-shell surface hidden while shortcut registration is pending, and registration completion no longer hides a window that the user explicitly showed during that interval.
- Refined native window chrome to match Yakuake: three-pixel side resize borders, the full pane-information bar as the horizontal resize dragger, text cursors over terminals, cardinal resize cursors only, and no diagonal corner cursors. Native windows now expose the installed NOCTTY icon, settings remain work-area bounded with explicit layer-shell geometry instead of collapsing to their natural minimum, and all owned dialogs use compositor-safe stacking above the dropdown.
- Fixed native terminal Enter delivery for raw-mode TUIs such as Pi: Return and keypad Enter now emit the standard carriage return (`CR`, `0x0d`) instead of line feed. The cross-backend terminal-chord smoke records the exact PTY bytes and rejects the former mapping.
- Added the NCT-112 native stability runner and retained its Debug/`ReleaseSafe` Plasma Wayland/X11 harness shakedown plus a separate short authenticated `ReleaseSafe` matrix with two exact Codex responses. Smoke-only mode 40 alternates the production PTY/VT/GTK/Cairo host between mapped-visible and fully unmapped-hidden phases while output continues, recording phase draws/presents, root-coalesced cursor and maintenance wakeups, zero fallback PTY ticks, duration, controlled exit, external root/tree memory, scheduler counters, and initial/final compositor pixels. The default authenticated acceptance command is 24 hours per backend, 48 hours total; that elapsed run remains open and the shakedown does not close NCT-112.
- Improved first-run NoctEd UX: when no session or file supplies a document, the editor now opens one clean Untitled buffer and shows `New file. Press Ctrl+S to save` instead of presenting an empty editor surface.
- Closed NCT-110 at the accepted one-host boundary with four authenticated Codex 0.144.6 requests through NOCTTY's production command profile, PTY, VT, GTK, and Cairo path. Debug and `ReleaseSafe` passed on live Plasma Wayland/X11 with exact 29-byte responses, mapped compositor screenshots, root/process-tree memory, controlled zero exits, ephemeral sessions, and read-only sandboxes. No credential is retained; Claude Code, Antigravity, HID, universal compatibility, and multi-day stability are not claimed.
- Closed NCT-111 with locally installed tmux 3.7b and Zellij 0.44.3. Every Debug/`ReleaseSafe` Wayland/X11 lane now retains first attach, a detach chord routed through NOCTTY's PTY write path, first-process exit with the multiplexer session alive, a second NOCTTY launch, reattach with prior content visible, compositor screenshots, and controlled cleanup. The tools came from signature-verified Arch packages under the user prefix and remain external runtime dependencies only for qualification.
- Polished shared terminal/editor chrome: NOCTTY New Tab, Settings, application Close, per-tab Close, and NoctEd file-tab Close now use 28-logical-pixel targets with explicit hover, active, and keyboard-focus states while retaining compact native GTK geometry.
- Closed the sustained NCT-106/NCT-121/NCT-122 native NoctEd tranche. A new isolated endurance wrapper runs 32 complete mapped workflows in each Debug/`ReleaseSafe` Wayland/X11 lane, retaining 256 cycles per phase per lane, 4,096 combined resource/search/monitor/lifecycle phase cycles, 3,072 deterministic Quick Open ranking evaluations, process-tree memory, warning-fatal GTK execution, worker/project drain, and first/final rendered images over 630 seconds. The same pass replaced Wayland's potentially nonempty all-black GDK window copy with Cairo widget rendering plus sampled nonblack RGB validation, and polished the product title, window accessibility name, search placeholders, 28-logical-pixel transient icon controls, and visible keyboard focus. Multi-day stability, varied-project coverage, broader agent products, physical input, and final compositor acceptance remain separate boundaries.
- Stabilized the direct native qualification path without changing production input behavior: tab rename now drives its actual focus-out cancellation callback after the synthetic outside click, and the synthetic `Ctrl+Tab` lane synchronizes the same focus activation that a real GDK focus event supplies. The clipboard matrix now fails closed after 30 seconds per backend instead of hanging indefinitely. The native host now waits for KGlobalAccel to acknowledge shortcut removal before dropping the D-Bus connection; the physical X11 shortcut lane refuses to disturb a running NOCTTY, removes only its stale `noctty/toggle-window` qualification registration before and after the run, forces the guaranteed `C` locale, and passes consecutively instead of leaving KGlobalAccel routed to an exited process.
- Closed NCT-119 with retained Debug/`ReleaseSafe` live Plasma Wayland/X11 idle and fullscreen evidence through the production PTY/VT/GTK/Cairo path. The matrix archives OCR-validated compositor captures, external root/process-tree memory and scheduler snapshots, zero fallback PTY timer ticks, bounded cursor/maintenance wakeups, real fullscreen state, and checksums. Physical HID, final compositor acceptance, broader agent products, and multi-day behavior remain separate boundaries; authenticated Codex now has its own mapped receipt. The same UI tranche adds explicit assistive names for command search/results, terminal search/status, and Quick Note/status, enforced by the compact UX smoke.
- Advanced NCT-119 with a live mapped Plasma presentation qualification. Debug and `ReleaseSafe` each retain 64 production PTY/VT/GTK key-handler-to-draw and key-handler-to-`after-paint` samples on Wayland and X11, plus frame intervals and GDK predicted presentation. Wayland returned completed presentation feedback in both modes; this host's X11 backend returned none, so the receipt does not invent X11 presentation timestamps. The synthetic event calls the production key handler directly and is explicitly not GDK-queue, HID, or physical-key evidence: `native_grid_presentation_matrix debug=true release_safe=true wayland=true x11=true samples_per_run=64 production_pty=true production_vt=true production_gtk=true mapped_surface=true key_to_draw=true key_to_frame=true frame_intervals=true wayland_presentation_feedback=true x11_presentation_feedback_optional=true synthetic_gtk_keys=true gdk_event_queue=false hid=false scratch_clean=true`.
- Hardened broadcast-input UX across the context menu, command palette, and `Ctrl+Shift+B`: enabling now uses an explicit warning with `Keep Off` as the default and explains selected-versus-all-tab targeting; disabling is immediate; menu and shortcut copy name the current action instead of saying only “Toggle Broadcast.” The cross-backend workspace smoke requires the shortcut path, confirmation, cancel default, immediate disable, and state-aware label.
- Made the physical tab-reorder gate deterministic from a Wayland desktop by running its X11 pointer drag inside a disposable Xvfb + `kwin_x11` session when those existing host tools are available, instead of relying on Xwayland focus automation. The Noctalia IPC smoke also reuses the documented dogfood-private GTK Layer Shell runtime when present, and the aggregate native driver gives the existing timing-sensitive renderer/layout/navigation/overlay lanes one bounded retry on a loaded host. Native builds and product runtime are unchanged.

- Closed two release-evidence gaps on the live Plasma session: NoctEd now retains matching Wayland Debug/`ReleaseSafe` search/load, project lifecycle, monitor-burst, deterministic-ranking, and process-tree-memory receipts; installed desktop/MIME and Recent Workspaces child activation now pass on both Wayland and X11. The activation harness uses a guaranteed locale under fatal-warning mode and correctly allows an unpainted hidden restored tab while still requiring mapped/rendered active content and zero child exit. The Project Workspace dialog now uses an adaptive scrollable summary with explicit assistive names instead of a fixed 620-pixel content width.
- Added a production-session GLib fairness qualification with one continuously flooding PTY and 29 marker PTYs, plus 8 MiB queued-paste drain and pending-paste teardown coverage. Debug and `ReleaseSafe` retain all markers, zero allocator/process residue, and scoped cleanup; `ReleaseSafe` marker max was 2.409 ms in the retained run, so the 2 MiB pump ceiling and equal source priority remain unchanged. Settings pages now permit horizontal access on narrow work areas, and category tooltips name their destination.
- Hardened the Settings navigation surface end to end: Window/Behavior/Appearance rows now have explicit ATK names, 48-logical-pixel targets, tooltips, theme-aware selected/focus contrast, and a predictable Window keyboard entry point. The native settings smoke and HiDPI/theme lane retain `category_navigation=true`; compact UX and host docs now describe the interaction boundary.
- Polished NoctEd's bounded recovery UX: file-tab close controls now retain 28-logical-pixel targets, and the no-file status names the New/Open recovery actions. X11 Debug and `ReleaseSafe` search/load qualification now retain first-result, completion, first-draw, deterministic-ranking, monitor-burst, project-lifecycle, and process-tree memory evidence. The PTY foreground-process checks share the maintained bounded poll ceiling, removing a cold-host one-second false failure.

- Deep-audited coding CLI/TUI behavior after reproducing Pi's duplicated rows. Shared VT fixes now include delayed right-margin autowrap; collision-safe private CSI handling for Kitty/xterm negotiation; correct origin mode, scroll-margin movement, line feed, reverse index, and line editing; immediate-only `CSI b` repeat; DEC G0/G1 box drawing with save/restore; independent alternate-screen cursor/wrap/margin state; ED 3 scrollback clearing; and physical clearing of vacated rows instead of stale lazy-recycle cells. Raw Pi 0.83.0 and Codex CLI 0.144.6 traces covered startup/edit/resize/exit. A VTE 0.84.1 differential produced 31 exact plus one equivalent pending-wrap result across 32 curated streams, then 48 exact plus two equivalent results across 50 deterministic no-tab streams, with zero material mismatches. The direct Pi probe retains cursor row 9, zero history, typed/arrow editing, resize, and no duplicate rows. ReleaseFast guards retained 111.649 MiB/s at eight output panes and 134.808 MiB/s at 32; Debug/`ReleaseSafe` checks pass 343/343 tests. The installed-tool matrix now runs its two modes sequentially under `TMPDIR`, and the PTY session matrix also serializes modes; EOF/reap and 8 MiB queue-drain tests use bounded 60-second ceilings, avoiding false failures under cold-cache host contention without weakening marker, exit, or drain assertions.
- Applied a source-pinned review of fourteen high-performance and agent-focused terminal projects. Width-changing primary-screen reflow now discards only provably blank rows below the cursor, preventing real content from being displaced into fake scrollback. Bounded OSC 9/99/777 requests now drive native pending-input attention without persisting terminal text. PTY input no longer sleeps on GTK's main thread: each session owns a capped ordered nonblocking queue, pending writes flush through a temporary 4 ms source plus existing pump/maintenance paths, and large storage is released after drain. An 8 MiB sleeping-child probe reduced caller blocking from 921.618 to 1.450 ms (635.8x); focused real-PTY tests and the native attention smoke cover the new boundaries. Dedicated adapter event IDs now keep idle-history receipts, pane-font changes, settings updates, and status attention separate, restoring the compact font-wheel smoke. Added Herdr-inspired continuity badges, opt-in bounded Claude Code/Codex resume references, a GUI restore-mode chooser, explicit user-confirmed OSC focus/project actions, and password-protected `.nocttyhs` screen-history export using stdlib PBKDF2/XChaCha20-Poly1305 with atomic mode-0600 storage.
- Added bounded idle-history release for dense agent workspaces. Unfocused panes wait 30 seconds after PTY output and the focused pane waits five minutes; root maintenance cold-packs at most sixteen 64-row batches per second, preserves content, and regrows on resumed output. Libc-backed eager virtual history slabs avoid active growth copies, and one completion-wave trim returns released pages to the OS. A 30-grid 120×40 qualification reduced history storage from 52,770,240 to 10,067,400 bytes (−40.72 MiB) with a 0.191 ms maximum step; seven active A/B pairs retained or improved eight/32-pane throughput, while a delayed native 32-pane sample reduced USS from 62,772 to 55,688 KiB. The benchmark now records USS, supports post-output settle windows, and can require an idle-compaction receipt.
- Optimized native 20/30-agent scale after detached-worktree comparisons of 16/32/64/96/128 KiB read arrays, early history compression, Pango/Cairo reuse, shared pump storage, and terminal-cell alignment. GTK-serialized panes now share one guarded 128 KiB PTY scratch while standalone sessions retain private ownership; `TerminalSession` shrank from 141,344 to 10,280 bytes, structurally removing about 3.88 MiB at 32 sessions. Terminal cells also shrank from 16 to 14 bytes without narrowing values. A nine-pair shared-scratch stress run observed 4.1% lower output PSS, 2.4% lower output RSS, and neutral throughput; a second seven-pair cell run lowered output RSS in every pair with a 1,616 KiB paired median and no median throughput regression. Compact raw/process/metadata/checksum evidence is retained. Reentrant pump use fails closed, tests cover shared ownership and cell size, and the production benchmark now accepts 16 and 32 panes plus an exact binary override for detached A/B runs.
- Fixed a contention-sensitive PTY inherited-descriptor regression check: PTY EOF can precede `waitpid(WNOHANG)` readiness, so the bounded test now sleeps on EOF instead of exhausting 5,000 polls in a tight loop before the child is observable. Three focused Debug repetitions and the complete `ReleaseSafe` check pass.
- Continued the Jeremy Huang optimization pass with `jofi` and `jtop`: NoctEd direct Tree-sitter updates now coalesce for 100 ms, admit at most 32 KiB and 4,096 complete captures on GTK's main thread, reject partial highlighting, and visibly fall back to GtkSourceView for larger or capture-dense files. A focused repetitive-Zig ReleaseFast probe measured parse-plus-capture p50 at about 5.9 ms for 32 KiB versus 43.5 ms at the former 256 KiB ceiling. NOCTTY's compact New Tab, per-tab Close, Settings, and application Close controls now use theme-aware GTK symbolic icons and 28-logical-pixel minimum targets instead of font-dependent Unicode glyphs. The production runtime contract retains the capture-limit and byte-ceiling checks.
- Optimized NoctEd Quick Open after reviewing Jeremy Huang's `jcode`, `handterm`, `agentgrep`, `ffp`, `jengine`, `mermaid-rs-renderer`, and `niri-workspaces-rs` performance patterns. The bounded fuzzy scorer now normalizes query metadata once, initializes only active DP states, and swaps slice headers instead of copying a 2,056-byte score row for every path byte. A 100,000-file ReleaseFast fixture improved from about 939 ms to 6.8-7.3 ms p50 for `file` and from about 918 ms to 15.8-16.2 ms for `modulefilezig`, with identical ranking fingerprints. The maintained Debug/`ReleaseSafe` scale lane now covers Quick Open and gives the 100,000-entry `ReleaseSafe` path a 500 ms regression budget.
- Added Sublime-style NoctEd editor zoom: `Ctrl+wheel` adjusts the shared document font from 60% through 240% in 10% steps, handles discrete and smooth scrolling, consumes the modified event without disturbing ordinary scrolling, updates every open document through one GTK CSS provider, and leaves the minimap scale independent.
- Fixed decorated dogfood drop-down windows on Wayland hosts without a system GTK Layer Shell install. The dogfood installer now stages the existing pinned runtime library beside the binaries and the launcher exposes only that trusted private directory, restoring the undecorated `noctty-dropdown` layer surface instead of falling back to an ordinary titled toplevel.
- Fixed NOCTTY reopening as an unusably short strip after a legacy or accidental 32 px drop-down resize. Stored pixel overrides below the 480×240 interactive floor now fall back to the configured percentage, future drag resizing respects that floor, and ordinary window mode reapplies a bounded 80%×75% work-area size instead of inheriting collapsed drop-down geometry.
- Fixed NOCTTY closing before its GTK window appeared when a legacy hot-session snapshot contained a relative pane working directory. Pane construction now enforces the existing absolute-cwd invariant, so invalid autosaves take the maintained fresh-workspace fallback instead of reaching PTY startup.
- Added Sublime-style NoctEd hot exit. Version-2 atomic session snapshots retain ordered clean tabs plus dirty saved and untitled UTF-8 buffers, restore the active dirty tab, preserve version-1 saved-tab sessions, debounce edit-pause snapshots, and use private `0600` storage. Quitting or closing the application now preserves dirty buffers without prompting; closing an individual dirty tab still uses Save/Discard/Cancel, and a failed recovery write blocks application exit.
- Continued the bounded C-to-Zig migration by moving native settings headings, grids, groups, pages, category rows, and generic settings callbacks into `src/gui/NativeGtk.zig`; settings labels now explicitly name their associated controls for assistive technology. Native-grid launch sites now use one named Zig options struct instead of repeating a 30-argument callback list, and the paste ABI correctly models length-delimited, non-NUL-terminated input.
- Hardened native save UX: Quick Note reports persistence failures and refuses dialog close when its final save fails, while scrollback export shows a recoverable error instead of silently discarding a failed write.
- Replaced 1,600 lines of implementation-string guard scripts with compact architecture and documentation checks. The docs gate now validates real local Markdown targets, backlog partitioning, bounded claims, stale surfaces, and dogfood status instead of restating hundreds of already-covered feature details.

- Removed the obsolete embedded compatibility editor now that standalone NoctEd owns the complete editor workflow. This deletes the duplicate text-buffer/syntax/document state, legacy editor CLI/build options, GTK compatibility dialog, editor-specific application-shutdown transaction, and its shutdown-only smoke lane. The focused NOCTTY gate now proves cwd resolution plus separate `nocted` process handoff; NoctEd's own native matrix remains the edit/save/search/dirty-prompt authority. The resulting clean-source gate passes `19/19` steps and `311/311` tests.
- Hardened local trust boundaries after the security scan: release CI now uses read-only permissions, non-persistent checkout credentials, and no release cache; GTK Layer Shell no longer loads from environment-selected or current-directory paths; PTY children reject relative launch paths, resolve fixed tools before profile environment changes, and close inherited descriptors before exec; package and release-evidence writes use private temporary files plus atomic replacement; a repository-owned Semgrep policy guards those regressions; and unused vendored upstream workflows, lockfiles, and container metadata were removed from the shipped source tree.
- Hardened the migrated native boundaries: PTY master/slave descriptors are now close-on-exec, the native-grid C seam is warning-clean in smoke builds under strict Clang conversion/shadow checks, release actions are pinned to full commit SHAs, shell backend-list formatting no longer mutates `IFS`, and the release workflow contract rejects mutable action tags. A fresh single-job `./scripts/verify.sh` run completed the full maintained matrix and final scratch/cache/install cleanup.
- Moved native GTK action-button affordances, tooltip fallback handling, compact-tab CSS ownership, tab child lookup, contrast selection, and per-tab color styling from `native_grid_host.c` into `src/gui/NativeGtk.zig`. Repeated tab label/close lookups now reuse object-cached pointers instead of allocating GTK child lists on every refresh; CSS formatting remains stack-backed and style updates retain the existing RGB/active-state dedupe.
- Replaced the optional 817-line GTK/VTE host C implementation with `src/gui/VteHost.zig`. The fallback keeps the same Wayland layer-shell/X11 placement, dual VTE sessions, Plasma global shortcut registration/conflict handling, recorder dialog, smoke scheduling, cleanup, and callback receipts while removing another product-owned C translation unit and the C-to-Zig host entry boundary. Qt-compatible shortcut conversion is now shared from Zig by both native hosts, including letter, digit, navigation, editing, and modifier parity; the standalone native-control D-Bus client also moved out of C.
- Removed the remaining PTY C shim. `Pty.zig` now owns validated fixed-argv fork/exec for shell, command, SSH, tmux, and Zellij profiles; environment setup; nonblocking descriptor I/O; resize; exit polling; foreground metadata; bounded process-group teardown; and `/proc` resource sampling. App and selected-pane resources share one process-tree traversal and one machine sample; a focused 2,000-iteration ReleaseSafe microcheck improved from a 0.062 s median to 0.040 s median (35.5%) on this host. Debug/`ReleaseSafe` PTY lifecycle, forced-group shutdown, exact tmux/Zellij argv, compact pane-resource, and resource-churn gates remain green.
- Moved the active-pane/resource information strip below the notebook so a bottom-positioned tab row remains immediately above it. The compact native smoke now verifies notebook-first/strip-last root ordering, while dropdown mode reduces the full-width resize grip from 12 to 4 pixels.
- Added live CPU and resident-memory usage to the active-pane information bar. `App` samples the complete NOCTTY process tree; `Pane` samples the selected terminal shell tree. Both reuse the existing one-second root maintenance cadence, rapid refreshes reuse the cached sample, `/proc` traversal is fixed-capacity, formatting remains caller-buffered, and hover shows process counts and detailed MiB/CPU values. Focused unit/build and native compact-UX proof cover resource parsing, deltas, labels/tooltips, and setter dedupe. The compact smoke's stale hard-coded 11 pt expectation was also corrected to follow the configured default font. A repeatedly observed cold/contention launch-profile test timeout now uses the same bounded 20-second exit budget already used by heavier qualification paths. A focused five-process-tree microcheck measured 200 sampler calls at a host-local 39.8 µs average. The dogfood installer now atomically replaces binaries so an already-running NOCTTY does not block installation; the running process still requires a normal restart to load the new inode.
- Added and exercised `./scripts/install_dogfood.sh`. It installs unstripped `ReleaseFast` `noctty`/`nocted` binaries by default under `~/.local/libexec/noctty-dogfood`, logging launchers under `~/.local/bin`, and absolute installed desktop-entry commands. Each invocation retains local arguments, session/backend, stdout/stderr, GTK/GLib debug output, exit status, best-effort core dumps, and an atomic duration receipt; the bounded stores keep 100 verbose logs and 500 compact receipts per app, and no evidence is uploaded. **Open NoctEd Here** resolves the sibling logging launcher, so the editor receives independent evidence.
- Refreshed `docs/PUBLIC_ALPHA_CODE_REVIEW.md` to match the current public-alpha state: screenshots, code map, clean source-copy fast gate, bounded source-alpha gate, issue templates, release notes, local Git baseline, and the minimum counted-session baseline are closed; NCT-125's clean current-build workflow remains the honest P1 blocker.
- Updated `docs/PUBLIC_ALPHA_GO_NO_GO.md` to keep the project no-go for public announcement on NCT-125 rather than the now-satisfied elapsed-session count.
- Reconciled seven unique installed NOCTTY receipts with operator-confirmed real work: 601,585 seconds / 167.107 hours now count, while historical exit-139, GTK-critical, popup, and clipboard-consumer observations remain explicit.
- Hardened `dogfood_status.sh` evidence parsing so missing work context and negative or unavailable Agent/NoctEd/close fields cannot produce positive coverage, and recognize the installed OMP CLI as agent evidence.
- Corrected the native OMP dogfood emitter to use the documented `dogfood_event session=ID` wire format. `dogfood_status.sh` normalizes retained pre-fix `noctty_dogfood_event session_id=ID` records so existing local evidence remains analyzable, and the logging smoke now exercises both formats.
- Added `docs/DOGFOOD_RUNBOOK.md`, a short counted-session protocol for public-alpha dogfood work. It defines what counts, the four-pane target, foreground-job close-confirmation target, NoctEd edit/search/save coverage, and what not to count.
- Added `./scripts/public_alpha_verify.sh`, a bounded source-alpha gate that runs the fast build/check, no-surprise network guard, docs truth guard, native-grid X11/Wayland smoke, and NoctEd native smoke. It reports `full_verify=false` so it cannot be mistaken for the full maintainer `./scripts/verify.sh` matrix.
- Hardened the native-grid smoke synchronized-output fixture for dogfood preflight. The smoke now leaves the first DECSET 2026 synchronized-output window long enough for mapped X11/Wayland hosts to observe a normal release, and leaves the second window long enough to deterministically exercise the deadman release path under current compositor timing. `./scripts/native_grid_smoke.sh` now passes again on both backends.
- Added bounded draft public source-alpha release notes in `docs/PUBLIC_ALPHA_RELEASE_NOTES.md`, including what is claimed, what is not claimed, retained fast-gate proof, and the fresh full-verifier receipt.
- Created the first local public source baseline commit after replacing the broken empty Git marker with a real Git boundary. Vendored Tree-sitter sources are embedded as ordinary files rather than unusable nested Git links.
- Added public-alpha GitHub hygiene templates: reproducible bug report form, real dogfood-session form, issue routing config, and a small PR template that asks for tested commands and non-claims.
- Verified the fast build/check path from a clean source copy: `zig build check -j1 --summary all` passed with `21/21` steps and `336/336` tests after copying the tree without `.git`, `.zig-cache`, `zig-out`, or `.noctty-*` state.
- Retried the full maintainer gate with `NOCTTY_ZIG_SINGLE_JOB=1 ./scripts/verify.sh`; the fresh 2026-07-29 run completed the maintained matrix and ended with `verify_cleanup scratch=true cache=true install=true artifacts=true`.
- Prepared the source-alpha release-hygiene note: current limitations, license, contributing/security docs, incomplete package/signing status, and the changelog alpha wording are reflected in the public roadmap. Remaining public-alpha blockers are NCT-125's clean current-build workflow and external release operations.
- Added a retained public-alpha no-surprise network guard. `./scripts/check_no_surprise_network.sh` scans production source/build resources for telemetry vendors, update/crash-upload/remote-flag tokens, and hidden network APIs, and `docs/NO_SURPRISE_NETWORK.md` records the current static proof boundary. Roadmap/release docs now mark the alpha telemetry/network surprise check complete.
- Improved public-alpha presentation and fixed a NoctEd launch blocker. NOCTTY now defaults to JetBrains Mono 12 pt, applies subpixel/slight-hinted Cairo options, routes non-ASCII/grapheme fallback through Pango/Cairo, opens a larger default native-grid window, and uses rounded native tabs. NoctEd now has matching rounded editor tabs. Both apps now share the same modern NOCTTY dark palette across terminal defaults, editor chrome, GtkSourceView styling, and SVG app icons. The screenshot helper captures current-monitor PNGs for both apps with isolated app state. NoctEd also resolves relative `--project`/`--open` CLI paths to absolute real paths before worker admission, fixing the relative-path assertion found during screenshot/dogfood prep. Focused checks passed: `zig build check -j1 --summary all`, `./scripts/native_grid_smoke.sh`, `./scripts/nocted_native_smoke.sh`, `./scripts/check_docs_truth.sh`, and `./scripts/capture_alpha_screenshots.sh`.
- Advanced NCT-106/NCT-121/NCT-122 through the first retained native search/load tranche. Two consecutive warning-fatal Debug runs on the live Wayland session each completed eight production GTK cycles for first result, completion, cancellation retirement, first result-tree draw, open under search, save under refresh, three-query coalesced Quick Open, the exact two-batch cap, deterministic ranking, worker/project drain, rendered screenshot validation, real-project model/tree draws, actual GIO bursts, overflow recovery, and clean scratch (`nocted_search_load_wayland_evidence backend=wayland optimize=Debug runs=2 cycles_per_run=8 first_result_latency=true completion_latency=true cancellation_latency=true ui_draw_latency=true open_under_search=true save_under_refresh=true deterministic_ranking=true gtk_batch_peak=2 gtk_batch_cap=2 worker_drained=true warning_fatal=true rendered=true scratch_clean=true`). Later managed commands lost compositor access, including `wayland-info` with `Operation not permitted`, so matching `ReleaseSafe`, X11, peak process-tree memory, and long-duration cross-backend evidence remain open.
- Closed the NCT-077 dependency-bundle redistribution-payload follow-through. A new fail-closed license collector maps every copied shared library to exactly one installed Arch/pacman or Debian/dpkg package, or to the pinned vendored GTK Layer Shell payload; it embeds package-installed notices and available canonical SPDX texts with SHA-256 inventory, records package/version/expression/source per library, normalizes loader aliases, and sets `redistribution_ready=true` only when ownership and the full payload are accounted for. A synthetic Debian backend lane passes with `package_bundle_licenses_backend_smoke debian=true version=true copyright=true library_inventory=true package_inventory=true fail_closed=true scratch_clean=true`, and the Ubuntu x86_64/aarch64 workflow now validates the ready fields and embedded payload before upload. Release receipt intake/status additionally require manifest readiness and payload-completeness attestations. The terminal-history qualifier now uses verifier-owned or scratch-local Zig caches instead of recreating a 321 MiB workspace cache after the full verifier's cleanup receipt. Focused acceptance is `package_bundle_manifest manifest=true archive=true checksum=true installed_files=true library_inventory=true package_inventory=true license_payload=true all_libraries_accounted=true gtk_layer_shell_license=LGPL-3.0-or-later redistribution_ready=true fail_closed=true scratch_clean=true`; independent review, signing, architecture artifacts, retained redistribution receipt, and publication remain external operations.
- Expanded the retained NCT-110/NCT-112 installed system-TUI lane from seven to ten applications. Debug and `ReleaseSafe` now add Bash 5.3.15's isolated interactive Readline shell with bracketed-paste state, man-db 2.13.1's styled nested less pager chain, and OpenSSH SFTP 10.4p1 attached directly to the installed local `sftp-server`. All three cross the production launch-profile, PTY, `TerminalSession`, and `Vt.Grid` path, retain foreground identity and controlled zero exit, and return allocator/process ownership to zero. The SFTP case binds no socket, uses no credential or remote transport, and does not broaden the existing local credentialed-SSH receipt into network proof. The lane remains headless and version-bounded rather than authenticated-agent, mapped-compositor, or multi-day evidence.
- Expanded the retained NCT-110/NCT-112 installed system-TUI lane from four to seven applications. Debug and `ReleaseSafe` now add fzf 0.74.0's styled Unicode fuzzy filter with alternate-screen/bracketed-paste/mouse state, SQLite 3.53.3's deterministic plaintext in-memory REPL, and Glances 4.5.5's styled alternate-screen CPU/memory/load monitor to the existing top/watch/info/whiptail cases. Every case crosses the production launch-profile, PTY, `TerminalSession`, and `Vt.Grid` path, retains foreground identity and controlled zero exit, samples root/tree memory, and returns allocator/process ownership to zero. Glances update checks and public-information display are disabled, and its IP plugin is disabled for the managed sandbox. This remains headless, version-bounded evidence rather than authenticated-agent, mapped-compositor, or multi-day proof.
- Completed the remaining headless NoctEd worker transaction seam for NCT-106/NCT-122. `Worker.Pools` now owns the exact lazy two-lane GLib pool lifecycle used by production, while transactional enqueue appends only after pool creation, removes exactly the appended pointer on push failure, preserves prior ordering, and shares identity-safe retirement with `App`. The Debug/`ReleaseSafe` runner injects append and push failures, proves rollback and idempotent ordered retirement, then uses the same pool/enqueue path for the real scan/search/save workload. GTK publication, compositor presentation, and long-duration GUI acceptance remain open.
- Completed the shared NoctEd worker-admission qualification seam for NCT-106/NCT-122 without moving GUI ownership. Lane mapping, newer-generation cancellation, the 64 attached-job cap, 32-live-job per-lane caps, cancelled-job exclusion from lane pressure, kind cancellation, and pending-kind lookup now live beside `Worker`; production `App.submitWorkerJob`, `cancelWorkerJobs`, and `hasWorkerJob` delegate to those exact functions. Debug and `ReleaseSafe` qualify boundary/full/cancelled/independent-lane cases before running the existing real two-pool GLib workload: `nocted_worker_matrix debug=true release_safe=true shared_admission_policy=true generation_supersession=true shared_queue_cap=64 lane_queue_cap=32 cancelled_lane_excluded=true kind_cancel=true pending_lookup=true lazy_pool_creation=true transactional_enqueue=true append_failure_safe=true push_failure_rollback=true ordered_retirement=true glib_thread_pools=true worker_lanes=2 project_scan=true search_streaming=true snapshot_first=true cooperative_cancellation=true search_batch_size=24 search_batch_cap=2 backpressure_exercised=true foreground_save_under_backpressure=true worker_drained=true allocator_leak_free=true process_memory=true scratch_clean=true`. The transaction slice above subsequently closes list append, lazy pool creation, push-error rollback, and ordered retirement; GTK publication, compositor, and long-duration acceptance remain outside the headless boundary.
- Advanced NCT-106/NCT-122 with a retained production `Worker`/GLib concurrency tranche. A new maintained Debug/`ReleaseSafe` runner creates two real single-thread `GThreadPool` lanes, scans a 193-file fixture, fills both outstanding 24-result batch slots, proves the foreground lane commits an atomic save while the scan lane is blocked, retires a cooperatively cancelled generation, drains a snapshot-first replacement search, samples root PSS/RSS, and exits with zero allocator residue: `nocted_worker_matrix debug=true release_safe=true shared_admission_policy=true generation_supersession=true shared_queue_cap=64 lane_queue_cap=32 cancelled_lane_excluded=true kind_cancel=true pending_lookup=true lazy_pool_creation=true transactional_enqueue=true append_failure_safe=true push_failure_rollback=true ordered_retirement=true glib_thread_pools=true worker_lanes=2 project_scan=true search_streaming=true snapshot_first=true cooperative_cancellation=true search_batch_size=24 search_batch_cap=2 backpressure_exercised=true foreground_save_under_backpressure=true worker_drained=true allocator_leak_free=true process_memory=true scratch_clean=true`. Together with the later shared-policy and transaction extraction, this closes the real headless admission/queue/worker/backpressure seam, not GTK widget publication, compositor/key-to-pixel latency, varied-project, or long-duration native-GUI acceptance.
- Advanced NCT-106/NCT-122 with an opt-in bounded core-endurance lane. The production NoctEd core runner now accepts a validated 1–512 cycle count while the maintained verifier keeps its 128-cycle baseline; the endurance wrapper selects 512 cycles in both Debug and `ReleaseSafe`, validates positive root-memory samples and the exact ranking fingerprint, records duration, and trap-cleans one project-local scratch tree. The retained 459-second run covers 1,024 total atomic save/load, edit/fold, scan/search, Quick Open, grammar, and allocator cycles plus 3,072 ranking evaluations with zero allocator residue: `nocted_core_endurance_matrix debug=true release_safe=true cycles_per_mode=512 total_cycles=1024 fixture_files=128 document_round_trip=true edit_fold=true project_scan=true project_search=true quick_open=true deterministic_ranking=true ranking_queries=3 ranking_evaluations=3072 grammar_conversion=true allocator_leak_free=true latency_percentiles=true process_memory=true duration_recorded=true scratch_clean=true`. This is headless core evidence, not GTK worker/compositor, varied-project, or multi-day native-GUI proof.
- Hardened the installed `top` qualification after the full verifier exposed a high-process-count viewport race. The interactive monitor now filters its process table to its own retained PID, keeping the header and live row inside the 120x40 VT while preserving production PTY/VT parsing, foreground identity, routed `q`, zero exit, allocator/process teardown, and independent root/tree resource assertions.
- Advanced NCT-110/NCT-112 with a third retained real installed-application production-path tranche. Debug and `ReleaseSafe` initially start procps top 4.0.6-dirty, procps watch 4.0.6-dirty, GNU info 7.3, and newt whiptail 0.52.25; the current ten-case runner also starts fzf 0.74.0, SQLite 3.53.3, Glances 4.5.5, Bash 5.3.15, man-db 2.13.1, and OpenSSH SFTP 10.4p1 through production launch profiles, C PTYs, `TerminalSession`, and `Vt.Grid`. The runner retains monitor, refresh, browser, widget, filter, REPL, Readline shell, nested pager, and direct local SFTP behavior; foreground identity; routed zero exits; rich styles where emitted; separate root/tree memory; zero allocator/process residue; and trap-cleaned scratch: `terminal_system_tui_matrix debug=true release_safe=true applications=top,watch,info,whiptail,fzf,sqlite3,glances,bash,man,sftp top_monitor=true watch_refresh=true watch_plain_surface=true info_browser=true whiptail_widget=true fzf_filter=true sqlite_repl=true glances_monitor=true bash_shell=true bash_readline=true man_pager=true pager_chain=true sftp_client=true sftp_local_server=true network_bind=false rich_style=true plain_repl=true input_routed=true foreground_identity=true controlled_exit=true allocator_leak_free=true root_memory_separate=true process_tree_memory=true installed_tools=true scratch_clean=true`. The lane is headless evidence for ten installed versions; authenticated agents, additional terminal applications, mapped Plasma Wayland/X11 pixels/interactions, and multi-day evidence remain open.
- Hardened qualification under cold-cache verifier contention without weakening assertions. The pre-existing NCT-112 session qualifier and immediately following NCT-111 continuity qualifier expand only their child marker/exit budgets from 5,000 to 20,000 bounded 1 ms would-block polls; the new ncurses cases add a qualification-only 1,000-poll observation dwell so the independent process-tree sampler cannot outlast the entire short app sequence. Markers, exact continuity argv, positive root/tree samples, zero exits, allocator baselines, process residue, and forced-group assertions remain mandatory.
- Advanced NCT-110/NCT-112 with a second retained real installed-application production-path tranche. Debug and `ReleaseSafe` each start nano 9.1 on a disposable read-only fixture with mouse support, less 704 on a 201-line pager fixture, and dialog 1.3-20260107 on a titled message widget through production launch profiles, C PTYs, `TerminalSession`, and `Vt.Grid`. The runner retains foreground identity, styled cells, routed controlled exits, nano/less alternate screens, nano/dialog mouse modes, dialog's honestly asserted primary-screen behavior, separate root/tree memory, zero allocator/process residue, and trap-cleaned scratch: `terminal_ncurses_matrix debug=true release_safe=true applications=nano,less,dialog nano_editor=true nano_mouse=true less_pager=true dialog_widget=true editor_pager_alternate_screen=true dialog_primary_screen=true rich_style=true input_routed=true foreground_identity=true controlled_exit=true allocator_leak_free=true root_memory_separate=true process_tree_memory=true installed_tools=true scratch_clean=true`. The lane is headless evidence for three installed versions; authenticated agents, additional terminal applications, mapped Plasma Wayland/X11 pixels/interactions, and multi-day evidence remain open.
- Advanced NCT-111 with native Persistent tmux and Persistent Zellij launch profiles. Settings version 9 preserves the version-8 binary layout/recent-workspace MRU while admitting the two new kinds; the GUI owns the session target and named-profile workflow. A conservative session-name grammar reaches fixed direct argv (`tmux new-session -A -s SESSION` or `zellij attach --create SESSION`) without shell-string construction. Debug and `ReleaseSafe` cross the production profile, `TerminalSession`, C PTY, cwd/environment/history, VT marker, controlled exit, and allocator boundary: `launch_continuity_matrix debug=true release_safe=true kinds=tmux,zellij direct_argv=true create_or_attach=true production_pty=true cwd=true environment=true controlled_exit=true allocator_leak_free=true tool_shims=true installed_tools=false live_reattach=false scratch_clean=true`. The host lacks both tools, so installed detach/relaunch/reattach and mapped Plasma Wayland/X11 proof remain open.
- Advanced NCT-112/NCT-119 with a retained real-PTY-to-production-Cairo pipeline tranche. Debug and `ReleaseSafe` each run two 64-sample sequences through `/bin/sh`, the production PTY, bounded `TerminalSession` pump, VT grid, ABI-v2 packed rows, and exact `draw_grid_contents` path. The first retained run in each mode ingests 191,646 bytes, records input-write-to-draw, PTY-read-start-to-draw, and draw-CPU p50/p95/p99, keeps root memory separate from the live shell tree, produces byte-identical repeat/cross-mode pixels with SHA-256 `6ffcf3f95517772167cb41074a4af7afdc82aa2ec9edd621ff85fd90500c55fc`, and reports zero warm-frame renderer allocations: `native_grid_pipeline_matrix debug=true release_safe=true samples_per_run=64 runs_per_mode=2 production_pty=true production_vt=true production_cairo=true input_write_to_draw=true pty_read_to_draw=true latency_percentiles=true artifact_repeat_exact=true cross_mode_artifacts_identical=true warm_frame_owned_allocations=0 root_memory_separate=true process_tree_memory=true compositor_presented=false scratch_clean=true`. This is display-independent completion of a Cairo image-surface draw, not GTK-key, frame-clock, compositor-presentation, or photon latency.
- Hardened the NCT-111 installed activation acceptance harness so its build prefix, TMPDIR, XDG cache, and Zig local/global caches all live below one exact trap-cleaned project-local scratch root. This fixed read-only shared-cache failures and let both full backend attempts reach the native GTK host. Wayland and X11 still returned `native_grid_gtk_init_failed` in the managed execution boundary despite visible socket paths, so no mapped/drawn child receipt is claimed and the compositor matrix stays open.
- Advanced NCT-110/NCT-112 with a retained real installed-TUI production-path tranche. Debug and `ReleaseSafe` each start Codex 0.144.5 with a disposable unauthenticated home, Vim 9.2 on a disposable fixture, and btop 1.4.7 with disposable XDG roots through the real launch-profile, PTY, `TerminalSession`, and `Vt.Grid` seam. The runner retains Codex synchronized output and login markers, Vim alternate-screen/bracketed-paste/focus state, btop alternate-screen/mouse/SGR-mouse/truecolor/Unicode state, foreground identity, routed controlled exits, separate root/tree memory, zero allocator/process residue, and trap-cleaned scratch: `terminal_real_tui_matrix debug=true release_safe=true applications=codex,vim,btop codex_login_surface=true codex_sync_output=true vim_alternate_screen=true vim_bracketed_paste=true btop_alternate_screen=true btop_mouse=true btop_truecolor=true unicode=true rich_style=true input_routed=true foreground_identity=true controlled_exit=true allocator_leak_free=true root_memory_separate=true process_tree_memory=true scratch_clean=true`. The Codex case never authenticates or submits a model request, and the lane does not map GTK or a compositor; authenticated Codex plus Claude Code/Antigravity/broader ncurses cross-backend receipts and multi-day evidence remain open.
- Advanced NCT-119 with a retained display-independent production-Cairo renderer tranche. Debug and `ReleaseSafe` each draw 128 measured idle, full-screen, and rich-style 160×50 fixtures through the exact production function; repeated surfaces have zero changed pixels, all three PNGs are byte-identical across build modes, and their SHA-256 fingerprints are retained. Renderer-owned row/glyph/cache accounting reports 15 combined first-frame allocations, zero warm allocations across 384 measured frames, one bounded grow allocation, zero shrink allocations, and 4352 peak counted scratch bytes; process-CPU percentiles and root memory are recorded in `docs/NATIVE_GRID_RENDERER_QUALIFICATION.md`: `native_grid_renderer_qualification_matrix debug=true release_safe=true frames_per_scenario=128 scenarios=3 pixel_repeat_exact=true cross_mode_artifacts_identical=true idle_draw_cpu=true fullscreen_draw_cpu=true rich_style_draw_cpu=true owned_allocation_counts=true warm_frame_owned_allocations=0 resize_growth_bounded=true resize_shrink_allocations=0 process_memory=true scratch_clean=true`. That tranche was partial until the later mapped presentation and full-stack compositor receipts closed NCT-119.
- Advanced NCT-112 with a retained allocator-accounted real-PTY lifecycle and forced-process-group tranche. Debug and `ReleaseSafe` each run 64 ordinary spawn/two-resize/output/title/exit/idempotent-close cycles plus eight foreground loops that ignore `SIGHUP` and `SIGTERM`; every cycle returns requested bytes to baseline, both modes exit at zero, all 16 stubborn groups exhaust the bounded grace path and are force-removed, and root versus child-tree PSS/RSS plus lifecycle percentiles are retained. Production teardown now keeps tracking the foreground and shell groups independently when the interactive shell exits first: `terminal_session_qualification_matrix debug=true release_safe=true normal_cycles=64 forced_cycles=8 sessions_per_mode=72 total_sessions=144 allocator_leak_free=true forced_group_shutdown=true latency_percentiles=true root_memory_separate=true process_tree_memory=true scratch_clean=true`. The newer installed-TUI tranche adds one controlled real application sequence per mode; NCT-112 remains partial for multi-day hidden/visible Plasma Wayland/X11 soaks, sustained authenticated-agent output, and rendered keystroke/frame latency.
- Hardened `scripts/verify.sh` cache ownership for restricted native-build environments: its self-deleting workspace-local verification root owns `TMPDIR`, `XDG_CACHE_HOME`, Zig-cache, install, and generated-artifact state. Keeping the root on the worktree filesystem avoids Zig local-C cache-manifest failures seen with a cross-filesystem `/tmp` cache; `NOCTTY_VERIFY_PARENT` remains an explicit override, and `NOCTTY_ZIG_SINGLE_JOB=1` provides an opt-in serialized build without slowing normal hosts. The full gate retains `verify_cleanup scratch=true cache=true install=true artifacts=true`.
- Advanced NCT-121 with a retained native project-lifecycle matrix on the production NoctEd path. X11 and Wayland each repeat the current NOCTTY checkout eight times from scan admission through immutable-model commit and first subsequent GTK tree draw, then drive eight actual twelve-file GIO bursts through debounce, delta worker, GTK publication, and draw. A deterministic 257-event admission case selects exactly one bounded full-scan recovery, and the exact monitor callback invoked after window destruction exits through the shutdown guard without scheduling work. The stable receipt is `nocted_native_matrix x11=true wayland=true ... real_project=true lifecycle_cycles=8 gtk_tree_draw=true model_latency=true draw_latency=true monitor_burst=true burst_cycles=8 files_per_burst=12 publication_latency=true overflow_recovery=true late_callback_guard=true worker_drained=true warning_fatal=true scratch_clean=true`; host-local distributions are retained in `docs/NOCTED_PROJECT_LIFECYCLE_QUALIFICATION.md`. NCT-121 remains partial only for sustained long-duration cross-backend lifecycle evidence; eight one-host cycles are not a multi-hour/multi-day claim.
- Advanced NCT-121 with precise immutable project-index deltas and a retained scale qualification. Capped/coalesced create, delete, move, and rename batches now run on NoctEd's existing scan worker, refresh only exact paths or directory subtrees, and transactionally publish a replacement snapshot; Save As uses this route instead of forcing a full scan. Ignore-control changes, malformed/unknown events, and batches beyond 256 fall back conservatively. Warning-fatal X11 retains `project_delta_updates=1 project_delta_fallbacks=0`, while real disposable 4K/25K/100K Debug/`ReleaseSafe` fixtures retain scan/delta time, compact/two-snapshot bytes, directory rename, replacement conflict, fallback, root memory, and zero-residual allocator evidence: `nocted_project_index_matrix debug=true release_safe=true scales=4000,25000,100000 immutable_delta=true directory_rename=true replacement_conflict=true ignore_fallback=true overflow_fallback=true scan_time=true delta_time=true index_memory=true two_snapshot_peak=true process_memory=true allocator_leak_free=true scratch_clean=true`. The later native lifecycle tranche supersedes this entry's former first-paint/real-project, monitor-burst, and teardown follow-ups.
- Hardened the Zig-owned PTY smoke against load-induced false timeouts by matching the terminal-session smoke's bounded polling budget. The original one-second-scale loop timed out once immediately after the 100K Debug/`ReleaseSafe` qualification even though the isolated PTY lane passed; the expanded bound preserves the same marker, resize, clean-exit, and zero-exit-code assertions.
- Added the maintained NCT-111 installed-desktop and Recent Workspaces acceptance harness without changing the production activation route. A disposable install now validates the real desktop file, `x-scheme-handler/noctty` registration, exact `Exec=noctty --open-uri %u` dispatch, production/smoke separation, and a two-tab native fixture (`native_grid_installed_activation_contract installed_desktop=true mime_registered=true exec_open_uri=true fixture_tabs=2 production_binary=true smoke_isolated=true scratch_scoped=true`). On an accessible Plasma session the full lane uses `gio open`, clicks the real **Open Recent** button, and requires the separately spawned child to be mapped and drawn with both tabs on Wayland and X11 before controlled exit. The managed sandbox cannot connect to its advertised compositor socket, so only the contract is retained here; the full compositor receipts and deliberate live-process continuity remain open.
- Retained the NCT-111 credentialed SSH acceptance lane through NOCTTY's actual validated launch-profile and PTY path. A self-cleaning fixture creates disposable Ed25519 client/host keys, pins the host key, resolves the real OpenSSH client/server, authenticates public-key credentials, executes a remote-shell marker, and observes exit without writing the user's SSH home: `native_grid_credentialed_ssh_smoke profile=true system_client=true system_server=true credential=publickey identity_isolated=true host_key=pinned transport=stdio_proxy network_bind=false remote_marker=true exited=true`. The server uses local stdin/stdout transport because the managed gate cannot bind a socket; this is credential/authentication proof (`credentialed_ssh=true`), not remote-network, password/agent/hardware-key, compositor, or live-process-continuity proof. NCT-111 remains partial for the now-scripted Wayland/X11 installed-activation receipts and deliberate live-process continuity.
- Advanced NCT-111 with bounded local workspace activation and recent workspaces. `noctty:///…nocttyws` and `file:///…nocttyws` inputs now pass through a fixed-capacity decoder and absolute snapshot-path validation before startup restore; remote authorities, query/fragment suffixes, controls, malformed escapes, wrong extensions, and oversized input are rejected. The desktop registers the `noctty` scheme. Settings version 8 appends a deduplicating eight-entry MRU while retaining version-7 named profiles, and Project Workspace exposes the list through native GTK. Open/recent activation starts a separate native process so current PTYs remain alive. Local proof is `native_grid_workspace_activation_smoke native_uri=true file_uri=true percent_decode=true authority_rejected=true validated_snapshot=true startup_restore_seam=true recent_mru=true fixed_capacity=8 config_v8=true atomic=true separate_process_policy=true exited=true`; installed-desktop and rendered child-window acceptance still remain before this portion is promoted to compositor proof.
- Advanced NCT-111 with the bounded native named-profile library. Settings now owns one active launch profile plus up to eight bounded, case-insensitively unique names; save/replace, selection, and deletion are atomic, and deleting a selected name keeps its current values active as custom state. Settings snapshot version 7 introduced the library and selected identity; version 8 retains them and adds recent workspaces, version 6 migrates its active profile into an empty library, and versions 1–5 retain the default-shell migration. The rendered lane applies a custom profile, saves two names, deletes one, reselects the survivor, reloads it, and launches a real PTY with the selected cwd/environment/history: `launch_profile=true launch_kind=command launch_shell=/bin/sh launch_cwd=/tmp launch_env=2 launch_scrollback=2048 launch_atomic=true launch_persisted=true launch_runtime=true launch_library=true launch_profiles=1 launch_named=true launch_saved=true launch_selected=true launch_deleted=true`. The later OpenSSH lane supplies the credentialed acceptance case; installed-desktop activation and deliberate live-process continuity remain.
- Advanced NCT-110 with a retained deterministic terminal compatibility lane. Debug and `ReleaseSafe` each run 23 SHA-256-pinned DA/DSR/DECRQM/XTGETTCAP/OSC/C1 protocol cases through six whole-input, bytewise, and chunk schedules, diff observable parser/grid/reply/title/mode/hyperlink state, assert SGR/truecolor/OSC 8/blocked OSC 52/fixed string bounds, feed 128 malformed 4096-byte cases through resize churn, mutate 256 Unicode/control inputs, and replay all 766 Unicode 17 grapheme-break cases. Allocator requested bytes return to baseline after each fixture and zero at exit: `terminal_compatibility_matrix debug=true release_safe=true protocol_cases=23 schedules=6 malformed_cases=128 unicode_mutations=256 grapheme_cases=766 allocator_leak_free=true scratch_clean=true`. The newer real installed-TUI tranche advances beyond fixtures; NCT-110 remains partial for authenticated Codex, Claude Code, Antigravity, and broader ncurses protocol/visual/interaction/exit receipts on Plasma Wayland and X11.
- Advanced NCT-122 with a retained deterministic-ranking and core allocator tranche plus production GTK search/load instrumentation. Debug and `ReleaseSafe` each run 128 atomic save/load, selection/fold, project scan/search, Quick Open, and TextMate conversion cycles over a disposable 128-file project; three full-order Quick Open queries per cycle retain the same fingerprint, active requested bytes return to baseline and zero at exit, and exact p50/p95/p99 plus root PSS/RSS are archived in `docs/NOCTED_SEARCH_LOAD_QUALIFICATION.md` (`nocted_core_stability_matrix debug=true release_safe=true cycles=128 fixture_files=128 document_round_trip=true edit_fold=true project_scan=true project_search=true quick_open=true deterministic_ranking=true ranking_queries=3 ranking_cycles=128 grammar_conversion=true allocator_leak_free=true latency_percentiles=true process_memory=true scratch_clean=true`). The native fixture and real GTK callbacks measure first result, completion, cancellation retirement, first result-tree draw, open under search, save under refresh, coalesced Quick Open, batch high water, and worker drain. This tranche originally stopped at `GtkUnavailable`; the newer Wayland Debug evidence above supersedes that boundary for one backend/mode only, while native `ReleaseSafe`, X11, process-tree memory, and the complete matrix remain open.
- Advanced NCT-106 with deterministic invalid-file/grammar robustness and identity-stable external reads. The loader now compares device, inode, size, and nanosecond mtime before and after every read, retries a one-time rewrite to the current generation, and returns `DocumentChangedDuringRead` after three continuously changing attempts rather than pairing stale bytes with a newer identity. Debug/`ReleaseSafe` run 256 actual-file cases and 256 TextMate mutations: `nocted_fuzz_race_matrix debug=true release_safe=true document_cases=256 grammar_cases=256 external_read_race=true stable_retry=true retry_cap=3 perpetual_churn_rejected=true scratch_clean=true`. The later core-stability tranche supplies bounded allocator/leak and operation-distribution evidence; long native-GUI and worker/lifecycle proof remains open.
- Advanced NCT-106 with crash-safe NoctEd settings/session recovery and a real `ReleaseSafe` legacy-parser fix. Versioned state now rejects unsupported, duplicate, unknown, invalid-UTF-8, NUL-bearing, and oversized inputs to safe defaults while preserving allocation errors; interrupted atomic replacements leave the prior complete file intact. The vendored Bash scanner callback now uses the exact declared `create(void)` C prototype instead of the optimized indirect-call mismatch. Repeated Debug/`ReleaseSafe` qualification passes: `nocted_state_recovery_matrix debug=true release_safe=true legacy_shell_parser=true malformed_state_corpus=13 oversized_fallback=true interrupted_replace=true settings_atomic=true session_atomic=true scratch_clean=true`. The later fuzz/race and allocator-accounted core-stability tranches supersede this entry's former follow-ups; long native-GUI and cross-backend lifecycle distributions remain.
- Closed NCT-104 with native bounded multi-selection editing, recent projects, and atomic session/tab restoration. `Ctrl+Shift+L`/`Edit > Select All Occurrences` keeps GTK's primary selection for clipboard/IME ownership, renders paired-mark secondary ranges, normalizes overlaps, and applies Unicode replacements back-to-front inside one undo transaction. `File > Open Recent` retains eight deduplicated projects; a versioned 64 KiB `session.conf` atomically retains up to 32 ordered file tabs plus the active tab and safely falls back after corruption. Unit/build checks and warning-fatal X11/Wayland restore/render proof pass: `nocted_native_matrix x11=true wayland=true folding=true find_in_files=true multi_file=true untitled=true save_as=true quick_open=true quick_open_capture=true multi_selection=true multi_selection_undo=true multi_selection_rendered=true session_persist=true session_restore=true recent_project=true textmate_import=true textmate_language=true textmate_precedence=true malformed_rejected=true warning_fatal=true scratch_clean=true`.
- Closed NCT-105 with bounded TextMate/VS Code JSON grammar import. NoctEd converts capped match/range/repository rules into application-owned GtkSourceView XML, rejects malformed/oversized/cyclic/path-unsafe inputs, atomically replaces normalized duplicate IDs, gives generated definitions explicit precedence, and reloads syntax by replacing the GtkSource language manager while re-detecting open buffers before old-language teardown. Unit/build checks and warning-fatal X11/Wayland activation pass with 171 definitions: `nocted_native_matrix x11=true wayland=true folding=true find_in_files=true multi_file=true untitled=true save_as=true quick_open=true quick_open_capture=true textmate_import=true textmate_language=true textmate_precedence=true malformed_rejected=true warning_fatal=true scratch_clean=true`.
- Closed NCT-120 with stable logical-line identity, grapheme-relative anchors, primary-screen reflow, compact UTF-8/style-run cold history, deterministic stale-anchor behavior, and memory-only storage. Explicit history shrink now forces cold-arena compaction even below the routine dead-storage threshold. Debug and `ReleaseSafe` qualification pass at 100000 lines with repeated grow/shrink cycles (`terminal_history_matrix debug=true release_safe=true lines=100000 compact=true reflow=true grow_shrink=true scratch_clean=true`).
- Promoted NCT-110, NCT-119, NCT-121, and NCT-122 from open to partial. The implemented slices include a bounded table-driven VT parser with rich styles, graphemes, hyperlinks, replies, and synchronized output; native-grid ABI v2 dirty spans with frame-clock presentation, glyph caching, and resize coalescing (`render_abi=packed_rows render_abi_version=2 damage_tracking=dirty_spans glyph_batching=true glyph_cache=true frame_clock_present=true`); an immutable arena-backed NoctEd worktree index with ignore and external-change handling; and two lazy worker lanes with streaming search, backpressure, and top-K Quick Open (`nocted_worker=bounded nocted_worker_lanes=2`). Focused X11/Wayland smoke passes. NCT-121's later scale and native-lifecycle tranches are retained; real-agent compatibility, remaining terminal performance, sustained project lifecycle, search/UI-load, and long-run qualification stay explicit acceptance work.
- Hardened the consolidated native matrix against verified transient input-delivery misses by allowing only the PID-owned tab-reorder, cross-backend tab-navigation, and physical Plasma shortcut lanes one bounded retry. Ownership, active-window validation, exact GTK/Zig/snapshot order, navigation/shortcut invariants, and final failure after the second attempt remain mandatory. The focused project/editor gate now installs both production and smoke artifacts before testing `Open NoctEd Here`, so its sibling-binary lookup proves the real `nocted` name instead of depending on a pre-existing install.

- Added a source-backed terminal/editor algorithm audit and measurement contract. NCT-119 through NCT-122 now cover GTK frame-clock presentation, bounded Cairo glyph delivery and resize coalescing, stable logical terminal lines and compact scrollback, a shared immutable NoctEd worktree index with coalesced external-change handling, and latency-prioritized streaming project search/quick-open. NCT-110 now includes a bounded table-driven VT parser and DECSET 2026 synchronized output. GPU rendering, per-pane thread sets, a custom editor rope/piece tree, and default Tree-sitter highlighting remain explicitly deferred. This is research and backlog truth only, not a shipped performance or compatibility claim (`performance_algorithm_research=true`).

## 0.1.0 — 2026-07-14 product behavior complete; release hardening and publication pending

The native product-behavior scope and local release-source evidence scope are complete for the current release slice. NCT-075 through NCT-085 plus the current NCT-077 follow-through closed release-source, retained-evidence, and fail-closed dependency-license payload contracts; NCT-086 through NCT-102 plus NCT-109 and NCT-116 through NCT-118 closed native performance, memory, benchmark, agent-session lifecycle, source ownership, renderer damage, bounded editor I/O, and production-build hardening; NCT-113 closes pointer-driven tab-reorder consistency and proof; NoctEd work through NCT-118 plus NCT-104/NCT-105 provides the standalone foundation, defined daily-editing workflows, syntax compatibility, bounded background filesystem ownership, and short resource qualification; and NCT-115 adds bounded local active-pane information plus stripped dependency-bundle binaries. Modern VT and process-continuity parity, long-duration resource qualification, and broader mature-editor parity remain active follow-on work; signing/publication, retained architecture artifacts/signatures, independent dependency-bundle redistribution review/receipt, unavailable-compositor acceptance, and consented Wayland HID capture remain external release operations.

- Closed NCT-118: terminal scrollback is now GUI-configurable from 0 through 100000 lines with live session application, lazy growth, immediate bounded shrink, and logical history preservation across column resize. The Zig VT owns dirty-row state, replacing per-presentation row hashing; native-grid calls now cross a size/version-checked ABI v1, and Cairo coalesces equal-background fills plus batches eligible ASCII glyph runs (`render_abi=packed_rows render_abi_version=1 damage_tracking=dirty_rows glyph_batching=true`). NoctEd now routes project scan/search and document load/save/path resolution through one exclusive GLib worker with a 64-job cap, generation cancellation, main-thread-only GTK commit, and join/drain shutdown. Canonical document lookup is hashed, notebook pages retain direct document identity, tree models use compact entry IDs, search results borrow indexed paths, and per-document search/minimap objects are lazy (`nocted_worker=bounded`). Debug and `ReleaseSafe` resource lanes prove eight NoctEd workflow cycles and 32 terminal session create/close operations with separate root/process-tree samples; deterministic malformed terminal input is covered during resize/history churn. The observations are one-host engineering receipts, not universal performance claims.
- Closed NCT-117: NoctEd project loading now scans and builds a staging tree in bounded idle slices, Find in Files advances through a cancellation-owned cursor, Quick Open coalesces edits, and the old project remains usable until transactional commit. Native pane creation uses explicit root and borrowed-state initialization instead of shallow context copies. GTK/Cairo rendering fetches packed rows once, hashes rows for contiguous damage, redraws cursor cells selectively, and initializes damage when panes map. Production `noctty` no longer links VTE or Tree-sitter and rejects smoke and legacy-editor commands; optional VTE and smoke binaries are separate, non-default artifacts, and package manifests no longer require VTE. Warning-fatal X11/Wayland NoctEd, package and release contracts, packed-row damage proof, and the complete native release matrix pass. Acceptance receipt: `render_abi=packed_rows damage_tracking=row_hash production_vte=false production_noctty_tree_sitter=false production_nocted_tree_sitter=true production_smoke_surface=false production_legacy_editor=false`.
- Closed NCT-116: descriptor-backed panes no longer own one-second exit timers. PTY reads remain GLib descriptor-driven, the existing root maintenance pass owns bounded exit safety, and only descriptor-registration failure creates a 16 ms pane timer. I/O and context source shutdown now share centralized idempotent helpers across natural exit, close, retirement, and final teardown. Layout-preset proof distinguishes visual mapping from descriptor/fallback readiness. The eight-pane static schedule is 3 callbacks per second instead of the NCT-109 intermediate 11; this is a scheduling calculation, not a CPU benchmark. Full-matrix validation also hardened the real-pointer tab-reorder harness to raise, synchronously activate, verify, and pointer-sync only its PID-owned test window before dragging. Acceptance receipt: `descriptor_fallback=root_coalesced pane_exit_timers=0 periodic_callbacks_per_second=3 source_cleanup=centralized`.
- Closed NCT-115: each tab page now owns one configurable 18-pixel active-pane strip with Yakuake/Konsole-shaped `short cwd : foreground process` text and a detailed pane/PID/process/directory tooltip. A bounded PTY metadata ABI owns `tcgetpgrp` plus `/proc` reads, a pure Zig formatter owns safe allocation-free presentation, and a dedicated GTK component owns visibility/cache revisions. Focus/tab changes refresh immediately, command changes reuse root maintenance, unchanged setters are skipped, config v4 persists the GUI toggle, and explicit terminal-content lookup protects restore/preset/move paths. Pointer presses and GTK focus signals now share one idempotent pane-activation path. Native gate lifecycle is deterministic: workspace actions cancel stale focus-loss hides, mapped-menu setup is shared and bounded, click-focus interactions are sequenced behind bounded readiness and controlled PTY release, foreground-close fixtures are controlled, hidden rename pages are explicitly drawn, natural editor cancellation is origin-bound, and release stages allow 200 ms for GTK teardown. Dependency bundles now request stripped `ReleaseSafe` binaries. Acceptance receipt: `pane_info=true pane_source=pty_proc pane_refresh=coalesced pane_info_dedup=true`.
- Closed NCT-114: NoctEd now provides clean `Ctrl+N` untitled buffers, `Ctrl+Shift+S` native Save As with overwrite confirmation, atomic first-file creation, canonical target identity, duplicate-open rejection, syntax re-detection, and a `Ctrl+P` fuzzy project quick-open panel capped at 100 results over the existing pruned 4096-entry index. Focused tests cover first-save target resolution, fuzzy ordering, malformed/oversized queries, and result caps. X11 and Wayland warning-fatal runs prove clean/dirty untitled transitions, exact first-save content, target-collision refusal, Zig reclassification, quick-open activation, and a captured native panel. Acceptance receipt: `nocted_native_gate rendered=true folding=true minimap_overlay_translucent=true find_in_files=true project_search_activation=true multi_file_tabs=true tab_navigation=true close_other=true close_all=true untitled=true save_as=true quick_open=true quick_open_capture=true warning_fatal=true backend=x11 scratch_clean=true`.
- Closed NCT-113: GTK tab dragging now preserves the pre-drag active page for background moves, rolls native order back if Zig rejects the stable-ID reorder, coalesces hot-session persistence during motion, suppresses startup reorder writeback, and keeps every initial/dynamic/restored page reorderable but nondetachable. The release matrix now drives a real PID-owned pointer drag across three tabs instead of calling the reorder API directly. Acceptance receipt: `pointer_drag=true pointer_press=true pointer_drop=true tabs=3 active_identity=true model_order=true snapshot_order=true persistence_coalesced=true tab_reorder_pointer_drag=true tab_reorder_active_identity=true tab_reorder_rollback=true tab_reorder_persistence_coalesced=true`.
- Closed NCT-109: destructive terminal closes now detect foreground process groups and require a native confirmation; bounded PTY teardown cannot wait forever on a stuck shell; complete retired session grids and dynamic session objects are released immediately; a pre-teardown retirement barrier rejects late GTK, IM, PTY, input, draw, resize, drag, and clipboard callbacks; cursor blink and maintenance are root-coalesced; descriptor-backed exit fallback was reduced to one second in that slice; and hidden panes use 100 ms presentation with mapped-only redraw. NCT-116 later folded that exit fallback into root maintenance. An outstanding clipboard read retains only its small C context until delivery. Added explicit-PID process-tree PSS/RSS reporting plus the daily-driver/agent-resource audit. Acceptance receipt: `foreground_guard=true close_confirmed=true primary_pty_closed=true session_storage_released=true late_callback_guard=true root_timer_coalesced=true hidden_present_throttled=true mapped_redraw_only=true`.
- Ordered owned-menu and process-local GTK popup dismissal before parent-window hide/destroy. The hot-session Wayland/X11 lane is now warning-fatal and proves `popup_teardown=true`, closing an intermittent GDK parent-unmap warning found by the aggregate native matrix.
- Closed NCT-108: NoctEd now provides bounded literal Find in Files through `Ctrl+Shift+F`, path/line/column previews, click-to-open line activation, `Ctrl+PageUp`/`Ctrl+PageDown` file cycling, `Ctrl+W`, and Save/Discard/Cancel-aware close-other/close-all actions. The search core caps queries, files, per-file bytes, total bytes, results, and previews and skips binary/invalid UTF-8 data; document load/save now rejects NUL-bearing text at the GTK/C boundary. Acceptance receipt: `nocted_native_gate rendered=true folding=true minimap_overlay_translucent=true find_in_files=true project_search_activation=true multi_file_tabs=true tab_navigation=true close_other=true close_all=true warning_fatal=true backend=x11 scratch_clean=true`.
- Closed NCT-107: NoctEd now has persisted indentation-based folding with current/all fold and unfold actions, zero-copy compact text tags that preserve the full buffer and native undo history, exact folded save, and bounded region analysis. The minimap viewport is translucent so source glyphs remain visible, and shutdown now guards late GTK callbacks before widget teardown.
- Closed NCT-103: `nocted` is now a separate native Zig binary and process with compact tabs, a left project tree, right minimap, GtkSourceView syntax definitions, find, undo/redo, bounded UTF-8 editing, symlink-safe canonical paths, permission-preserving atomic save, GUI-owned settings, existing-syntax discovery/import prompts, desktop/AppStream/icon resources, and complete package/bundle integration. NOCTTY's `Open NoctEd Here` starts the sibling binary at the selected pane cwd and does not own its lifetime; the former embedded compatibility editor has since been removed. Acceptance receipt: `nocted_standalone=true process_separate=true project_tree=true project_activation=true minimap=true gtksourceview_lang=true syntax_import_prompt=true atomic_save=true permissions_preserved=true rendered=true`.
- Isolated the pane-close warning-fatal gate from an unavailable host AT-SPI bridge with `NO_AT_BRIDGE=1`; GLib/GDK application warnings remain fatal, while missing desktop accessibility-bus infrastructure no longer aborts the smoke before pane behavior runs.
- Closed NCT-102: native panes now register their PTY descriptor with a teardown-owned GLib Unix-FD source, retain the 16 KiB reusable buffer and 128 KiB per-dispatch fairness cap, coalesce output presentation onto one-shot 16 ms sources, and use a 500 ms timer only for exit/fallback work. Native two-pane and pane-close smokes assert the event source at runtime; pane-context close pops down its menu before destroying the parent hierarchy and is exercised with GLib/GDK warnings fatal. The benchmark now rotates terminal order, waits one second after each clean teardown, and verifies each WezTerm split workload before continuing. In the final Yakuake-guarded matrix, NOCTTY recorded the fastest startup median and lowest PSS at 1/2/4/8 panes plus a 66 ms four-pane writer median, tied with Ghostty and 2 ms behind Kitty. Acceptance receipt: `pty_event_source=true timer_read_polling=false output_present_coalesced=true event_source_cleanup=true pane_close_menu_popdown=true benchmark_order_isolated=true wezterm_split_ready=true writer_median_ms=66`.
- Closed NCT-101: full-screen visible-grid scroll now rotates logical rows instead of moving the slab; viewport blending, alternate-screen history isolation, resize, partial margins, and editing operations are regression-covered; printable ASCII is consumed in equivalent runs; and productive PTY reads use one active-only, teardown-owned high-idle continuation with a 16 KiB reusable buffer while every pump remains capped at 128 KiB. The NCT-101 matrix recorded an 80 ms four-pane writer median, down from 318 ms, with lowest PSS at every pane count. Acceptance receipt: `native_output_throughput=true visible_grid_ring=true vt_ascii_run=true pty_active_continuation=true continuation_cleanup=true read_buffer=16384 writer_median_ms=80`.
- Closed NCT-100: added an isolated six-terminal split-pane benchmark with explicit Yakuake exclusion, PID-scoped controls, fixed geometry, process-tree PSS/RSS and idle CPU accounting, and retained raw/summary/environment artifacts. The benchmark exposed one 4 KiB PTY read per 16 ms tick; a bounded drain-to-`EAGAIN` loop reduced NOCTTY's four-pane 20,000-line writer median from 7129 ms to 318 ms while retaining a 128 KiB per-pane UI-tick cap. Acceptance receipt: `split_terminal_benchmark=true yakuake_excluded=true process_tree_pss=true pty_pump_bounded_drain=true output_metric=writer_completion`.
- Closed NCT-099: VT history now starts with 32 lines and grows geometrically to the existing 1000-line cap, row-only resize keeps history storage, alternate-screen resize is memory-safe, the render loop uses one packed cell/style callback and skips blank glyphs, idle ticks avoid metadata probes and throttle exit polling, legacy native-host callback/source ownership is cleaned up, Tree-sitter/editor scratch allocation is bounded, and literal paste uses one session-owned buffer. Acceptance receipt: `native_deep_memory_hardening=true scrollback_lazy_growth=true alternate_resize_safe=true packed_cell_render=true blank_cell_draw_skipped=true idle_metadata_probe_suppressed=true idle_exit_poll_throttled=true native_host_callback_cleanup=true tree_sitter_capture_stack=true editor_find_lazy_reserve=true literal_paste_single_pass=true paste_session_allocator=true`.
- Closed NCT-098: syntax-theme JSON import now uses an allocator-aware parse path with parser deinit; git status/graph parsing checks caps before cloning overflow records; native editor find pre-reserves bounded match storage; and Smart Tab filter plus terminal-find status labels use stack formatting instead of temporary heap strings. Acceptance receipt: `native_allocation_polish=true syntax_theme_parse_deinit=true git_parse_cap_before_alloc=true smart_filter_label_stack=true terminal_find_status_stack=true editor_find_prereserved=true`.
- Closed NCT-097: heap-created native grid contexts are now removed and freed when retired; VT scrollback uses a fixed history slab; common editor single edits avoid whole-buffer rebuilds; terminal find caches normal result sets from one pass; and open editor documents reuse Tree-sitter parser documents by revision. Acceptance receipt: `native_memory_leak_hardening=true retired_context_free=true scrollback_slab=true editor_single_edit_fastpath=true terminal_find_cached=true tree_sitter_document_reuse=true`.
- Closed NCT-096: native draw now caches cursor state once per frame and dedupes same-weight font selection; terminal status events are throttled to actual PTY work/status transitions with a slower tick for long-running status; close teardown removes all tracked source families; editor undo/redo history is bounded; editor search advances line/column in one pass; project scans prune generated/vendor trees and avoid pre-cap path duplication. Acceptance receipt: `native_perf_memory_polish=true draw_cursor_cached=true draw_font_switch_dedup=true tick_event_throttled=true teardown_sources_complete=true editor_undo_bounded=true editor_search_linear=true project_scan_pruned=true`.
- Closed NCT-095: compact-tab refreshes now use stack or literal suffixes for pane counts, selection counts, broadcast markers, and tab-color tooltip text, and append the title ellipsis without an extra heap string. Visible markup and tooltips are unchanged. Acceptance receipt: `tab_suffix_stack=true empty_suffix_no_alloc=true ellipsis_no_concat=true tooltip_suffix_stack=true native_layout=true`.
- Closed NCT-094: tab-color refreshes now cache the applied RGB plus active-state style key on each GTK tab widget, skipping CSS provider removal/rebuild when the style is unchanged while preserving rebuilds for real color/reset/active-state changes. Acceptance receipt: `tab_color_style_dedup=true provider_rebuild_bounded=true active_state_key=true native_layout=true`.
- Closed NCT-093: pane status tooltip refreshes now use bounded stack formatting and an object-owned tooltip cache on the drawing area, skipping repeated GTK tooltip setter calls when status/tag text is unchanged. Acceptance receipt: `pane_tooltip_dedup=true stack_format=true tooltip_cache=true object_owned_cleanup=true native_layout=true`.
- Closed NCT-092: compact-tab refreshes now cache the last applied tab markup and tooltip strings on the GTK tab label object, skipping repeated `gtk_label_set_markup` and tooltip setter calls when computed strings are unchanged. Cached strings are object-owned and replaced/freed by GTK. Acceptance receipt: `tab_setter_dedup=true markup_cache=true tooltip_cache=true object_owned_cleanup=true native_layout=true`.
- Closed NCT-091: hold-Alt quick-note overlays now request an explicit bounded preview from the Zig text-action ABI and allocate 4 KiB instead of a 1 MiB full-note buffer. The full Quick Note editor still uses the strict full-note read path, while overlay text remains UTF-8 validated and display-truncated. Acceptance receipt: `note_overlay_preview_bounded=true preview_buffer=4096 full_editor_read_unchanged=true utf8_validated=true native_layout=true`.
- Closed NCT-090: the quick-note overlay now reuses a root-owned `Sans 9` Pango font description across overlay paints instead of allocating it for every visible pane draw. Layouts remain draw-local to the Cairo context, and shutdown cleanup releases the cached font. Acceptance receipt: `note_overlay_font_cached=true pango_font_reused=true draw_context_safe=true cleanup=true native_layout=true`.
- Closed NCT-089: the native 16 ms terminal tick now uses the Zig pump result to redraw only when PTY bytes arrive or pane status changes; idle would-block ticks no longer queue full terminal redraws after title/status no-op work is skipped. Exit and cursor blink redraw paths remain intact. Acceptance receipt: `idle_redraw_suppressed=true pump_driven_draw=true status_transition_draw=true native_layout=true`.
- Closed NCT-088: the native 16 ms terminal tick now skips no-op top-level title updates when GTK already holds the same title, and only refreshes the running status tooltip when a pane first enters the running state. Exit/done/error and tag-refresh paths still update tooltips. Acceptance receipt: `tick_noop_dedup=true title_dedup=true status_tooltip_dedup=true native_layout=true`.
- Closed NCT-087: the native quick-note overlay now caches its formatted `Note · ...` label for the Alt-preview lifetime instead of allocating the same draw label for every pane paint. Hide/release and shutdown cleanup now clear both overlay-owned strings, and the native layout proof requires that hidden state before accepting `note_overlay=true`. Acceptance receipt: `note_overlay_cached=true draw_allocations=bounded hidden_cleanup=true native_layout=true`.
- Closed NCT-086: the Zig VT grid now keeps its 1000-line scrollback cap through ring-retention instead of repeated front removal, so long terminal output preserves logical oldest-to-newest scrollback without shifting the retained history slice on every new line. Grid initialization now pre-reserves the bounded pointer storage and cleans up partially allocated cells/tab stops on failure, and resize setup has the same allocator cleanup guard. Acceptance receipt: `scrollback_ring=true bounded=1000 no_front_shift=true init_cleanup=true resize_cleanup=true order_preserved=true`.
- Closed NCT-085: `scripts/release_operations_acceptance_intake.sh` now copies compositor acceptance receipts and Wayland HID consent receipts into the release evidence directory only after semantic fields validate and placeholder text is absent. The smoke proves all six compositor receipts plus Wayland HID consent can complete a retained-evidence fixture through `--require-complete`, proves `tagged_artifacts=true signatures=true publication=true dependency_bundle_redistribution=true compositor_acceptance=true wayland_hid_consent=true complete=true external_blockers=0`, and rejects placeholder, compositor-mismatched, or no-consent receipts. Acceptance receipt: `release_operations_acceptance_intake_smoke compositors=6 wayland_hid=true semantic=true placeholder_blocked=true compositor_mismatch_blocked=true consent_required=true complete_status=true scratch_clean=true`.
- Closed NCT-084: `scripts/release_operations_receipt_intake.sh` now copies publication receipts and dependency-bundle redistribution notices into the release evidence directory only after semantic fields validate and placeholder text is absent. `scripts/release_operations_status.sh` now keeps publication blocked unless retained tagged artifacts and signatures are already true, emitting `publication_prerequisites_missing` for standalone receipts. The smoke proves `tagged_artifacts=true signatures=true publication=true dependency_bundle_redistribution=true compositor_acceptance=false wayland_hid_consent=false complete=false external_blockers=2` after receipt intake and rejects placeholder or incomplete receipts. Acceptance receipt: `release_operations_receipt_intake_smoke publication=true redistribution=true semantic=true placeholder_blocked=true incomplete_blocked=true manifest_attestation=true publication_prerequisites=true retained_status=true scratch_clean=true`.
- Closed NCT-083: `scripts/release_operations_signature_intake.sh` now copies a retained archive/checksum/manifest signature into the release evidence directory only after the matching canonical artifact, checksum, or manifest target already exists. The smoke proves all six signature lanes after sidecar-verified artifact intake, proves `tagged_artifacts=true signatures=true publication=false dependency_bundle_redistribution=false compositor_acceptance=false wayland_hid_consent=false complete=false external_blockers=4`, and rejects placeholder or targetless signatures. Acceptance receipt: `release_operations_signature_intake_smoke archive=true checksum=true manifest=true x86_64=true aarch64=true placeholder_blocked=true target_required=true retained_status=true scratch_clean=true`.
- Closed NCT-082: `scripts/release_operations_artifact_intake.sh` now copies a retained `x86_64` or `aarch64` archive into the release evidence directory only after its checksum and manifest sidecars verify. The smoke proves both architecture lanes, proves `tagged_artifacts=true signatures=false publication=false dependency_bundle_redistribution=false compositor_acceptance=false wayland_hid_consent=false complete=false external_blockers=5` after sidecar-verified intake, and rejects an architecture mismatch. Acceptance receipt: `release_operations_artifact_intake_smoke x86_64=true aarch64=true sidecars_verified=true retained_status=true mismatch_blocked=true scratch_clean=true`.
- Closed NCT-081: `scripts/release_operations_scaffold.sh` now creates TODO-bearing release-operation receipt templates without creating fake artifacts, manifests, checksums, or signatures. The scaffold stays blocked by the semantic validator until real retained evidence replaces it. Acceptance receipt: `release_operations_scaffold_smoke templates=true fake_artifacts=false placeholder_blocked=true require_complete_blocks=true scratch_clean=true`.
- Closed NCT-080: retained release evidence now requires semantic fields instead of arbitrary nonempty files. Architecture manifests must match checksum digests, publication/compositor/HID receipts must carry exact release-operation fields, placeholder text keeps rows blocked, and the focused smoke now reports `release_operations_status_smoke missing_diagnostics=true require_complete_blocks=true complete_fixture=true checksum_verified=true semantic_receipts=true bundle_manifest_attestation=true scratch_clean=true`.
- Closed NCT-079: `scripts/release_operations_status.sh --list-missing` now emits deterministic `release_operations_issue` rows for absent or placeholder retained evidence, and `scripts/release_operations_status_smoke.sh` proves the incomplete 21-issue local boundary. NCT-080 supersedes the original complete-fixture receipt with semantic retained-evidence validation.
- Closed NCT-078: `scripts/release_operations_status.sh` now reports the retained-evidence state for tagged x86_64/aarch64 artifacts, signatures, publication, dependency-bundle redistribution notices, compositor acceptance receipts, and consented Wayland HID evidence. The current local receipt is `release_operations_status version=0.1.0 tagged_artifacts=false signatures=false publication=false dependency_bundle_redistribution=false compositor_acceptance=false wayland_hid_consent=false complete=false external_blockers=6`, and `docs/RELEASE_OPERATIONS.md` defines the evidence layout plus `NOCTTY_RELEASE_EVIDENCE_DIR` override.
- Closed NCT-077: package manifest receipts now report RPM/Arch parser availability instead of unconditional success, dependency bundles emit `.manifest` sidecars with version, architecture, compiler, source revision when available, archive digest, installed files, bundled-library inventory, and conservative library provenance, and `gtk-layer-shell` is reconciled to `LGPL-3.0-or-later` at the project/package boundary. Its original `redistribution_ready=false` boundary is retained as history and superseded by the current fail-closed embedded license-payload follow-through; no signing, independent review, retained receipt, or publication claim is inferred.
- Closed NCT-076: the release workflow now uses Zig `0.16.0`, provisions `libgtk-layer-shell0` on both architecture jobs, asserts the runner architecture matches the artifact label, validates each generated archive plus SHA-256 sidecar before upload, and has a local `release_workflow_contract` guard wired into `./scripts/verify.sh`. This is workflow source proof only; retained tagged x86_64/aarch64 artifacts remain an external release operation.
- Closed NCT-075: the install-tarball lane now runs two isolated `ReleaseSafe` builds with separate stages and Zig caches, normalizes both archives, requires byte-identical output and matching SHA-256 values, verifies the published sidecar, guards the 0.1.0 version/date/revision contract across runtime, packaging manifests, AppStream, and docs, and removes verification scratch/cache residue without deleting the requested archive.
- Hardened the headless terminal-session smoke timeout to match the unit-test boundary, avoiding false `TerminalSessionExitMissing` failures after the marker/title have already reached the Zig VT grid.
- Added an exact-pane native `Profile` submenu with five Zig-owned presets: Global default, Compact, Readable, High contrast, and Mono no ligatures. The live adapter synchronizes the selected pane's family, point size, high-contrast state, ligature preference, and current preset without mutating its neighbor; Settings exposes the same selector as `Active pane profile`. The rendered two-pane lane drives Readable, High contrast, and Mono no ligatures, verifies current-item routing and exact-target isolation, marks workspace recovery dirty, and proves snapshot/autosave restoration. The hardened Wayland/X11 matrix passes twice and the release aggregate now reports `profile_presets=true`. The fixed-cell Cairo renderer records the ligature preference but does not claim font-feature shaping or visual ligature suppression.
- Made graceful whole-application shutdown editor-aware. The tab-row and tray `Close NOCTTY` actions, main-window manager delete, and natural last-PTY exit now scan every native grid context for dirty former embedded-editor buffers and require Save, Discard, or Cancel before teardown. A close requested during a direct editor modal is deferred and resumed at one-modal depth without replacing the editor-owned prompt. The strengthened rendered lane proves window-manager Cancel survival, deterministic toolbar save-failure survival, natural last-PTY Cancel/retry after an 80 ms dwell with distinct nonzero exit codes 7 and 9 plus active validation preserved, then final toolbar Save/Discard teardown across two editors. Dirty Cancel is not separately driven from the tray entry; forced signals and desktop-session termination remain outside this interactive guarantee.
- Hardened display-backed release-proof determinism after aggregate runs exposed scheduling-sensitive prerequisite lanes. Synthetic pane menus now wait for a mapped surface and use an allocated GDK pointer trigger, navigation uses handshake PTYs plus the `GtkWindow` focus child as its exact routing truth, note overlays release only after both Cairo surfaces draw, terminal-chord shells distinguish trapped `SIGINT` from real PTY EOF, and Noctalia IPC exits after the second status receipt with bounded CLI calls. The two-tab smoke still serializes close validation, fresh-tab reopen, and cleanup; tab rename now waits for both mapped terminal surfaces to draw before releasing its handshake PTYs. Receipts and user-facing behavior are unchanged.
- Made the former embedded editor's direct document transitions data-loss safe. Clean files keep Save disabled; edits expose an explicit unsaved state and enable Save; `Ctrl+S` writes through the existing Zig atomic-save path and returns the buffer to clean state. Switching files or directly closing the editor now requires a native Save/Discard/Cancel decision, where Cancel preserves the current buffer and a failed save cannot permit the transition.
- Normalized the source-truth ledger after the 0.1.0 completion tranche: completed rows now live in `BACKLOG_ARCHIVE.md`, the active queue is explicitly empty, three colliding historical IDs were reassigned, and the documentation gate now rejects finished rows under Active, unfinished rows in the archive, and duplicate canonical task IDs.
- Made terminal control chords pane-local. Plain `Ctrl+C` now sends exactly one interrupt to the focused PTY even while broadcast mode is enabled, while `Ctrl+Shift+C` remains copy. Plain `Ctrl+D` closes the focused pane through the same model-first PTY/timer/GTK teardown as `Close Terminal`, sends no EOT into the shell, restores surviving focus, and preserves final-pane protection. A dedicated two-pane Wayland/X11 matrix proves the complete contract.
- Added Ctrl+Alt+wheel tab cycling. Scroll down advances and scroll up reverses through ordinary and Smart Tab-filtered views with wraparound, preserving the active filter and handing terminal focus through the established GTK/Zig path. Each step shows an 800 ms native purple frame with a `Tab n / total` chip; the navigation smoke proves both directions, wraparound, focus synchronization, and rendered feedback on Wayland and X11.
- Added Alt+wheel pane cycling. Scroll down advances and scroll up reverses through visible panes on the current tab, skipping Smart Tab- and zoom-hidden surfaces while preserving multi-pane tag selection. Each step shows an 800 ms native blue focus frame with a `Pane n / total` chip, and smooth scrolling accumulates into controlled steps. The navigation smoke now proves the interaction on Wayland and X11.
- Added Sublime-style hot-session recovery. Workspace changes write through to an atomic XDG-state snapshot, and startup rebuilds customized tabs, live pane counts, recursive split geometry and divider ratios, active focus, titles/colors, tags/Smart Tabs, profiles, notes, broadcast state, and saved working directories before showing the window. Settings retain immediate atomic config persistence; corrupt snapshots safely fall back to a clean workspace, and shells restart rather than claiming impossible process-memory resurrection.
- Added multi-pane tags and a native Smart Tab filter. Selected panes can be tagged from the terminal context menu, and the filter keeps only matching panes visible in the active live split without duplicating PTY sessions.
- Added tag removal for selected panes and made Smart Tab filters replaceable and clearable without losing the current filter on cancel.
- Added Yakuake-order Settings and Close controls to the far edge of the native tab row. They use system-theme icons, follow horizontal or vertical tab placement, open the existing Settings surface, and stop all live terminal sessions through the same clean lifecycle as tray Close.
- Standardized native button hover feedback across persistent and transient controls. Action buttons now show the desktop's standard arrow pointer, preserve or derive concise GTK tooltips, and restore the inherited cursor on leave; the rendered Settings receipt proves the contract on New Tab, Settings, Close NOCTTY, and per-tab Close.
- Compressed the native tab strip to Yakuake density. Scoped GTK notebook styling keeps the row within 22–24 logical pixels, uses 22-pixel app actions and an 18-pixel tab-close control, trims visible titles at 18 characters, and represents multi-pane tabs as `×N` while full detail remains in tooltips. Dynamically created tabs now map their close child instead of collapsing it to one pixel; the rendered two-tab receipt includes `compact_tabs=true` and bounds both vertical and horizontal chrome with a nonzero close-control floor.
- Added Peacock-style per-tab accents without a browser/editor runtime dependency. Each tab's native context menu offers Default plus eight color presets; contrast-aware GTK styling colors the exact tab, `Ctrl+Alt+=` and `Ctrl+Alt+-` adjust a reversible bounded shade, and the same actions appear in the command palette and shortcut card. Accent state is Zig-owned, marks the workspace dirty, and persists through backward-compatible version-5 snapshots.
- Added direct keyboard navigation at the rendered native boundary. `Ctrl+Tab` wraps through visible panes on the current tab and moves real GTK/Zig focus while skipping Smart Tab- or zoom-hidden panes; `Ctrl+Shift+Tab` advances ordinary and Smart Tab-filtered tab views without clearing the active tag. Existing `Ctrl+PageUp`/`Ctrl+PageDown` aliases remain intact, and the expanded navigation smoke covers both new routes plus close/reopen focus restoration.
- Fixed Settings being obscured by the always-on-top dropdown. Settings now has explicit transient/keep-above ownership; on Plasma Wayland it receives a dedicated overlay-layer surface while the parent dropdown is temporarily lowered and restored on close. A rendered Wayland/X11 stacking matrix proves both windows remain visible, the compositor ordering contract is applied, and the parent layer is restored.
- Added hold-Alt workspace-note previews. Pressing either Alt key paints the existing persisted quick note as a compact wrapped UTF-8 tooltip in every visible pane; releasing Alt, hiding NOCTTY, or losing window focus clears all copies. The Wayland/X11 rendered matrix proves two-pane coverage, bounded geometry, release-to-hide, and clean session exit without adding pane chrome or a second note model.
- Hardened the consolidated native workspace receipt exposed by this full-matrix rerun: dynamic sessions now retain enough render/exit dwell, and selection-marker proof inspects pane 3's actual tab instead of stale tab-1 chrome.
- Extended the native workspace smoke with a runtime tag/filter receipt: selected-pane tagging, tagged/untagged matching, filter clearing, and post-run Zig state are now checked together.
- Added tag discoverability to live pane tooltips and refreshes those tooltips immediately after tagging or removing tags.
- Added a compact Smart Tab indicator and tooltip state so the active tag remains visible while navigating notebook pages.
- Added Smart Tab filter access through the command palette and `Ctrl+Shift+G`, reusing the existing native dialog and clear-on-blank behavior.
- Added palette actions for tagging or removing tags from selected panes, plus `Ctrl+Shift+Y` for the non-destructive tag action.
- Added compact selection-count and broadcast markers, with explicit tab-tooltip state for active selection groups and broadcast input.
- Smart Tab filtering now hands focus to the first matching pane when the focused pane is hidden, preventing keyboard input from targeting an invisible terminal.
- Smart Tab filters with no matches now show an explicit native empty-state message and recover cleanly when a matching filter is selected.
- Smart Tab no-match feedback now includes a native `Clear filter` action that restores all panes and terminal focus in one click.
- Smart Tab no-match feedback now identifies the active tag in the empty state and its tooltip, making unexpected empty results easier to diagnose.
- Pressing `Escape` now clears a no-match Smart Tab and restores terminal focus without intercepting ordinary terminal Escape input.
- Tag, remove-tag, and Smart Tab dialogs now offer an editable native list of unique tags already used by workspace panes.

- Fixed context-menu `Layout 2×2` and `Layout 3×3` changing only workspace metadata. They now materialize four/nine live native PTYs in balanced equal-cell GTK grids, while `Layout 1×1` tears surplus sessions down through the normal pane-close lifecycle and focuses the survivor.
- Added pane-targeted `Close Terminal` to the native right-click menu. Zig accepts and removes the exact pane before GTK collapses its split, the PTY and pane timers stop, nested topology is preserved, focus moves to a surviving terminal, root controller services survive closing pane 1, and the final terminal remains protected.
- Added a leading accessible `+` New Tab button to the compact tab row. The control stays available with one tab, follows the current notebook page, survives closing the original host tab, and creates a fresh Zig session rather than reusing a retired peer; pane zoom still hides and restores the whole row.
- Added `Close Tab` when right-clicking a compact tab title. It closes the clicked tab rather than whichever tab is active, rejects the final-tab close, stops that page's PTYs and pane timers, preserves the surviving session, and keeps tray/show/settings focus safe after closing the original host tab.
- Added the original `Open Editor Here` embedded-editor route to every terminal context menu and the native command palette. NCT-103 later replaced this product path with standalone `Open NoctEd Here`.
- Fixed right-clicking a drop-down terminal hiding the main window before a context-menu item could be chosen. Focus-loss hiding now waits while the GTK menu/grab is active, respects editor/project transients, and cannot reverse an explicit hide during reveal animation teardown.
- Added `Ctrl+mouse-wheel up/down` terminal font scaling. One-point changes now apply only to the pane under the pointer, use font-derived cell geometry so glyphs never overlap fixed cells, resize that pane's Zig PTY/grid, clamp to configured limits, and persist in its workspace profile without intercepting ordinary unmodified wheel behavior. Settings remains the global font-default control.
- Added unobtrusive free resizing and a Yakuake-style tray presence. Borderless windowed mode now exposes all eight compositor resize edges/corners; dropdown mode exposes side, bottom, and bottom-corner drags that update persisted dimensions. A native StatusNotifierItem registers with Plasma, stays Active while hidden, uses the packaged icon plus a pixmap fallback, toggles on primary activation, opens Settings on secondary activation, and re-registers after watcher restarts. Its standard right-click menu now provides dynamic Show/Hide, `Settings…`, and `Close NOCTTY`; Close stops every active PTY and timer before clean tray/menu unregistration.
- Reworked the native Settings dialog around Yakuake's compact list-style configuration pattern. Window, Behavior, and Appearance categories now show one grouped page at a time with system-theme icons and keyboard navigation; the rendered settings gate proves all three categories, live page switching, and unchanged persistence on Wayland and X11.
- Added Yakuake/Ghostty-style live terminal resize dimensions. Split dividers, the dropdown grip, and window resizing now produce a centered transient `columns × rows` Cairo OSD after initial layout, update it continuously, and hide it 750 ms after resizing settles.
- Fixed unintended terminal text selection after double-click pane zoom or restore. The native handler now clears the gesture's selection state and consumes its geometry-shifted trailing release, while the rendered gate separately confirms normal drag selection remains available.
- Added Yakuake-style tab renaming: double-clicking a compact tab title replaces that label with a borderless native entry in the tab row, with no dialog or popup. Enter commits, Esc cancels, and clicking any other control or terminal surface cancels without mutating the title; committed names route through Zig, override changing shell titles, mark autosave/recovery dirty, and survive version-4 workspace snapshot export/import with older snapshot compatibility retained.
- Added a dedicated rendered tab-rename regression and consolidated `tab_rename=true` release receipt covering the double-click route, embedded editor, explicit popup absence, outside-click cancellation, Enter commit, visible label, durable model/snapshot, focus restoration, and independent tab PTYs.
- Added a compositor-backed tab-title polish receipt covering working-directory fallback when the shell has no title, compact ellipsis rendering, full-title tooltips, and manual rename precedence.
- Added a compositor-backed tab-indicator receipt covering attention and unsaved-workspace markers, attention clearing on exit, dirty clearing after save, and title preservation.
- Fixed background-tab drag reorder activating the moved tab. The native notebook now preserves the pre-drag active tab, while the stable tab IDs and saved workspace order remain synchronized; a compositor-backed reorder receipt covers the full path.
- Added a compositor-backed command-palette rename receipt covering fuzzy action selection, invalid-name validation, commit, cancel, focus restoration, and durable title preservation.
- Completed first-class Noctalia Shell support without a shell-plugin dependency: native detection covers Niri, Hyprland, Sway, Scroll, Labwc, and MangoWC, with v4-compatible and current v5 compositor-owned binding plans.
- Added `com.noctty.NOCTTY` D-Bus activation plus `--status`, `--show`, `--hide`, `--toggle`, and ready-before-hidden autostart; normal launch remains visible and duplicate launcher activation targets the running instance.
- Promoted the default Zig-grid dropdown to the `noctty-dropdown` GTK layer-shell namespace and added a live Wayland gate for hidden/status/show/hide/toggle, single-instance routing, and clean exit.
- Added a rendered cross-desktop shortcut recorder to the default grid Settings surface. Plasma re-registers before save; Noctalia plans consume the same persisted shortcut, with F11 capture/reload now in the settings gate.
- Installed compositor fragments for all six Noctalia targets plus an optional v5 compact bar button, updated desktop/AppStream identity, and made `gtk-layer-shell` explicit in Debian/RPM/Arch and dependency-bundle contracts.
- Wired the Zig-native dropdown renderer to Plasma GlobalAccel: configured shortcuts are availability-checked, accepted-key verified, hidden-start is allowed only after registration, conflict/transport failure keeps the window visible, teardown unregisters the action, and a physical X11 F10 gate proves hidden-window activation.
- Promoted the Zig-native PTY/VT grid to the default renderer. The established VTE/workspace host remains available explicitly through `--native-host` or `NOCTTY_RENDERER=vte`.
- Routed native-grid tab/split commands through the Zig workspace model and completed on-demand creation/rendering of independent sessions in GTK notebook and recursive split surfaces.
- Fixed Split Down incorrectly rendering as a left/right split and removed the two-terminal ceiling. Every pane can now split recursively; the live regression proves four independent sessions with vertical Split Down and horizontal Split Left.
- Fixed pane clicks leaving keyboard focus pinned to the most recently created terminal. Mouse press now focuses and activates the clicked pane before input; a live two-pane gate delivers distinct commands to both PTYs.
- Removed the apparent four-pane ceiling by midpoint-positioning every new divider and added a balanced eight-session live gate.
- Fixed selection trails by separating completed selection ranges from active Button-1 dragging; click, release, focus loss, and hover-without-button behavior now have explicit regression coverage.
- Hardened the physical F10 gate against Plasma metadata/subscription readiness races with process-specific main-loop-ready and activation-receipt markers plus bounded key retries, and made child failures print their captured diagnostics.
- Gave mode smokes a short rendered-frame dwell so fast shell exit cannot race the required GTK draw evidence.
- Fixed Move Pane to Other Tab updating only Zig state: context-menu and drag moves now collapse/rebuild GTK split trees, reparent the live terminal, focus it in the destination, and close an emptied source tab.
- Fixed tab-position settings updating persistence but not the window: top/bottom/left/right changes now apply immediately and loaded placement is restored at host startup.
- Hardened pane reparent/resize drawing against a stale GTK allocation frame: out-of-range C-ABI grid reads now return a blank default cell instead of panicking after a rapid layout change.
- Added the compact power-UX pass: transient fuzzy palette, scrollback find/save, workspace quick notes, pane zoom, geometry-aware navigation, shortcut card, theme/tab cycling, bell attention dots, IM composition, a compact tab row with zoom-only hiding, animated configurable drop-down behavior, inherited cwd, and a four-pixel resize grip.
- Added versioned persistence for pointer-focus settings and workspace quick notes while retaining version-1 config and older workspace import compatibility.
- Dismissed active GTK menus before F10 reveal animation hides the parent, removing the popup-parent unmap warning during rapid drop-down use.
- Added `--native-grid-workspace-smoke`, proving GTK adapter workspace events route through Zig and leave the workspace with two tabs.
- Added native-grid Ctrl+Shift+L split-left routing and expanded workspace smoke proof to two tabs plus three active-tab panes.
- Added native-grid Ctrl+Shift+B broadcast-mode routing and included the enabled state in workspace smoke proof.
- Added native-grid Ctrl+Alt+1..9 pane-selection routing and selected-pane proof to the workspace smoke.
- Added the first syntax-theme foundation for the former embedded editor: existing bounded spans expose canonical TextMate scopes, and VS Code/TextMate `tokenColors` themes import into an owned native resolver with editor globals and font styles.
- Added the native Tree-sitter C adapter and MIT-licensed JSON, C, and Bash parser sources. JSON, C/C++, and Shell editor highlighting now use incremental parser/query captures first and fall back to the existing bounded highlighter when unsupported; grammar revisions and staged Zig sources are recorded in `vendor/tree-sitter/LICENSES.md`.
- Added the generated MIT Markdown parser sources and native GTK tag application: opened editor files now receive resolved scope colors and font styles from the syntax-theme layer, with a compositor-backed `syntax_highlighting=true` editor receipt.
- Generated and compiled the MIT Zig Tree-sitter parser from the vendored grammar using a temporary build-time CLI only; NOCTTY runtime remains native C/Zig with no Node dependency. Large-file editor policy receipts continue to prove editable, read-only preview, and metadata-only fallback modes.
- Persisted syntax-theme selection in config version 3 with older snapshot defaults preserved; the native editor smoke now proves a high-contrast syntax theme survives fresh-App reload and affects the rendered editor tag path.
- Added a compositor-backed tab navigation receipt covering real `Ctrl+PageUp`, `Ctrl+PageDown`, `Ctrl+Shift+W`, and `Ctrl+Shift+T` handling with reopened-tab focus restoration.
- Added the maintained `native_grid_tab_navigation_smoke` wrapper and closed NCT-027 after repeated compositor-backed passes; repository Zig caches and NOCTTY temporary artifacts were cleaned after verification.
- Fixed broadcast mode ignoring terminal input: keyboard, IME, and clipboard delivery now reaches selected panes only when a selection group is tagged, or all panes in the active tab when no panes are tagged; ordinary focused-pane routing remains unchanged when broadcast is off.
- Added native-grid Ctrl+Alt+[ / ] active-pane focus cycling and focus-cycle proof to the workspace smoke.
- Added a thin native-grid right-click menu for New Tab, Split Down, Split Left, and Toggle Broadcast.
- Added a real two-session native-grid split: `--native-grid-two-pane` runs two independent Zig PTY/VT sessions in one GTK paned window, and `--native-grid-two-pane-smoke` proves both grids plus pane-2 lifecycle routing.
- Connected live Split Down/Left events to reveal and start the dormant second native session only after the Zig workspace command succeeds; the maintained two-pane gate now reports `dynamic_split=true`.
- Connected New Tab to reparent/start the dormant second session in a real GTK notebook page after Zig acceptance; `--native-grid-two-tab-smoke` proves dynamic tab creation and lifecycle.
- Completed and archived NCT-007: native GTK clipboard copy/paste now has Wayland and X11 runtime proof through Zig paste safety, bracketed-paste semantics, rendered PTY output, and clean exit.
- Completed and archived NCT-004: the native grid renders pane status borders/tooltips and delivers configured KDE-compatible exit notifications through the freedesktop DBus API.
- Completed and archived NCT-005: the native grid now has rendered GUI controls for mode, tabs, font, theme, status, panel metrics, notifications, and pane presets with atomic persistence/reload.
- Completed and archived NCT-006: the native Theme Library supports GTK file selection, Zig parsing for Ghostty/Xresources/Alacritty, install/select, and persistent reload.
- Completed and archived NCT-008 and NCT-009: rendered project/workspace and editor flows now execute Zig snapshot, project-row, document, edit/save, autosave, refresh, and cleanup paths.
- Completed and archived NCT-003: native tabs/splits, layout presets, selection/focus, confirmed broadcast, and drag/context pane movement now route through the live workspace boundary.
- Completed NCT-011, NCT-012, and NCT-014 and closed NCT-002 through the supported native replacement: Zig PTY/VT plus GTK/Cairo is now the fully proven default, with physical GlobalAccel activation and no private Ghostty ABI or maintained fork.
- Completed and archived NCT-010's product and initial packaging boundary: the consolidated native release matrix passes, while a normalized local archive/bundle, Debian/RPM/Arch manifests, and x86_64/aarch64 workflow wiring are present. NCT-075–077 supersede the earlier broad release-proof wording.
- Refreshed README, architecture, native-host, pitch-audit, install, release-checklist, backlog, and archive truth for the product-complete 0.1.0 boundary with release-source hardening still open.
- Hardened focused smoke wrappers to print captured child output on failure, so display or runtime preflight errors remain diagnosable from the consolidated release gate.

### Added

The granular entries below preserve chronological development history. Any “open”, “pending”, or “provisional” wording records the boundary at that intermediate slice and is superseded by the completion summary above.

- Added the first NCT-011 Zig-native PTY slice: a Zig-owned session now creates the master PTY, spawns the shell, performs nonblocking read/write, applies terminal resize, observes child exit, and passes `--pty-smoke`; the GTK/VTE host remains unchanged until public VT state and NOCTTY rendering are connected.
- Added the NCT-012 renderer-neutral VT slice: Zig now owns a bounded terminal grid with ANSI cursor/scroll/clear handling and OSC title capture, while the public `libghostty-vt` paste utility is dispatched through a small dynamic ABI shim and verified by `--vt-smoke`; the GTK/VTE widget remains provisional because the public package exposes no Linux renderer or screen-state API.
- Added the NCT-013 PTY-to-VT session seam: `TerminalSession` now pumps a real Zig PTY into the Zig grid and proves title capture and child exit with `--terminal-session-smoke`; this slice is archived as complete.
- Added the NCT-014 native grid adapter behind `--native-grid-smoke`: GTK now has a drawing/input surface connected to the real Zig session callbacks, with live dropdown/windowed/zen proof; default VTE remains pending product integration.
- Extended the NCT-014 adapter with allocation-driven PTY/grid resize and arrow-key escape encoding; the default host remains unchanged pending live display proof.
- Added the opt-in `--native-grid` launcher and `NOCTTY_RENDERER=grid` selector for exercising the real Zig PTY/VT session through the GTK drawing surface.
- Extended the native grid renderer with UTF-8 codepoint drawing and Zig-preserved bold/inverse style bits.
- Added ANSI 8-color and bright-color palette state to the Zig grid and GTK native renderer.
- Completed native painting for ANSI backgrounds and inverse foreground/background swapping; bold now selects the bold monospace face.
- Added native GTK mouse button routing as SGR mouse sequences through the Zig PTY boundary.
- Added native GTK clipboard request routing through the Zig paste-safety and bracketed-paste pipeline.
- Added native grid clipboard copy serialization and wheel-event SGR mouse routing.
- Added bounded Zig scrollback storage and local wheel viewport navigation to the native grid path.
- Added Zig-sourced cursor painting to the GTK native grid surface.
- Added native control/Alt chord handling and editing/navigation key encoding.
- Added OSC title propagation and cursor blink behavior to the GTK native grid surface.
- Corrected OSC title parsing to expose title text without its command prefix and made cursor blinking focus-aware.
- Corrected CSI row/column cursor addressing in the Zig VT grid.
- Added UTF-8 decoding from PTY bytes into Unicode grid cells.
- Added ANSI erase-line modes and absolute horizontal/vertical cursor movement coverage.
- Added ANSI display erase modes for cursor-relative and full-screen clearing.
- Added CSI scrolling-margin support for region-limited terminal scrolling.
- Added alternate-screen preservation for `CSI ?1049h/l` terminal applications.
- Added cursor save/restore and `CSI ?25h/l` visibility controls.
- Added bracketed-paste mode tracking so native clipboard delivery wraps only when requested by the terminal.
- Added application cursor-key mode tracking and SS3 arrow encoding for native input.
- Made native mouse delivery respect terminal mouse-reporting mode; wheel input remains local scrollback when reporting is disabled.
- Added negotiated legacy X10 versus SGR mouse sequence encoding at the Zig PTY boundary.
- Added terminal focus-reporting mode and GTK focus-in/focus-out sequence routing.
- Added native-grid windowed and zen-fullscreen launcher modes alongside dropdown mode.
- Added separate native-grid smoke commands for dropdown, windowed, and zen modes.
- Captured live GTK runtime proof for all three native-grid modes and fixed post-loop window cleanup assertions.
- Connected native-grid session start/output/exit callbacks to the Zig pane status model.
- Added drag selection and selected-grid clipboard serialization to the native grid surface.
- Added UTF-8 encoding for non-ASCII native keyboard input.
- Added insert mode and CSI insert/delete/erase-character operations to the Zig VT grid.
- Added CSI line insert/delete and region scroll-up/scroll-down operations.
- Added DEC autowrap mode tracking for last-column output behavior.
- Added configurable tab stops with `ESC H` and `CSI g` handling.
- Hardened the libghostty boundary: the ABI smoke now audits public `libghostty-vt` versus GUI headers/private libraries, and the probe refuses to report a complete or safe GUI ABI until a supported Linux platform-surface contract exists.
- Downloaded upstream Ghostty at commit `53bd14f`, built its internal library with Zig 0.15.2, and added `scripts/ghostty_upstream_surface_probe.sh`; the matching Linux probe creates config/app state but rejects the `invalid` platform surface, preserving the upstream Linux ABI blocker without using another package's private library.
- Completed the host-specific NCT-001 mode boundary: the GTK adapter now honors dropdown, centered borderless windowed, and native zen-fullscreen modes; local shortcut activation uses the configured key instead of a hardcoded F10; and windowed/fullscreen smoke commands exercise the same lifecycle and GlobalAccel path.
- Connected the native GTK/GLib event loop to the existing Zig maintenance contract with a periodic timer callback; display-bound smoke now requires at least one delivered maintenance tick while keeping autosave, refresh, and cleanup execution receipt-driven.
- First live native terminal vertical slice: default launch now opens a GTK window, starts the user's shell in a VTE PTY, and provides rendered terminal output, keyboard input, focus, resize behavior, scrollback, and child-exit handling on Wayland/X11-capable GTK environments.
- Native-host architecture and Ghostty replacement criteria in `docs/NATIVE_HOST.md`.
- Stable-pane lifecycle synchronization from native terminal spawn, output, and exit callbacks into `App` status state.
- Deterministic `--native-host-smoke` command and dual-backend `scripts/native_host_smoke.sh` graphical gate.
- Graphical smoke assertions for terminal input delivery, rendered marker correlation, and resize propagation.
- Live borderless always-above dropdown show/hide, terminal focus restoration, F10 focused-window handling, and GTK-to-Zig visibility synchronization.
- Plasma GlobalAccel F10 registration, hidden-window activation signal handling, safe visible fallback, model receipt synchronization, and shutdown cleanup.
- Exact X11/XWayland top-edge dropdown placement with compositor readback, plus optional GTK3 layer-shell loading and explicit Wayland constrained-placement reporting.
- Pinned repo-local GTK3 layer-shell 0.10.1 x86_64 fallback with package provenance, checksums, and live Plasma `wayland_layer_shell` proof. The extracted `.PKGINFO` says `LGPL-3.0-or-later` while the included `LICENSE_MIT.txt` and earlier vendor note say MIT; NCT-077 keeps the resolved redistribution-license claim open pending authoritative reconciliation.
- Config-driven Qt shortcut encoding, Plasma availability/accepted-key validation, registered/conflict/failed Zig receipts, visible fallback, and a non-destructive occupied-F12 conflict smoke.
- Native right-click shortcut-recorder dialog with live Zig config updates, safe GlobalAccel re-registration, Esc cancellation, success closure, and rendered conflict/failure guidance.
- Recorder navigation/editing-key capture plus atomic save after confirmed registration and fresh-App F11 reload proof.
- X11 physical `Ctrl+Home` recorder capture and bounded desktop screenshot smoke.
- Cropped X11 recorder-window screenshot assertion using `xdotool` geometry and ImageMagick, closing the dialog-region pixel-proof gap on X11.
- Read-only Wayland EIS/RemoteDesktop capability probe, documenting the explicit user-consent boundary for keyboard injection.
- Attempted an explicit RemoteDesktop portal session; Plasma returned a request handle but no consent response/UI, so no EIS keyboard injection claim was added.
- Monitored a complete `CreateSession` retry; no portal `Request.Response` signal was emitted, confirming the block occurs before device selection or consented EIS connection.
- Verified the workspace file-flow development command round-trips a two-pane binary snapshot with matching byte counts (`saved_bytes=372 loaded_bytes=372 panes=2`); rendered save/load controls remain open.
- Ran the project-panel/editor proof group: bounded panel views and actions, editable/large/metadata-only loading, atomic save plus read-only rejection, syntax highlighting spans, and wrapped/non-wrapped find navigation all pass; rendered editor/panel UI remains open.
- Clipboard safety tests pass multiline shell repair, bracketed-paste wrapping, heredoc literal preservation, unsafe-control stripping, marker normalization, and unbracketed literal configuration; live OS clipboard transport remains open.
- Theme compatibility tests pass Ghostty palette and Xresources imports, name validation, preview formatting, binary library round-trip, malformed/duplicate rejection, and atomic save/load; rendered theme selection remains open.
- Status-signal tests pass running/pending/completed/long-running detection, agent-state colors, KDE notification request/receipt handling, and tooltip summary/receipt handling; live KDE delivery and rendered tooltip chrome remain open.
- Configuration tests pass defaults/validation, typed setting dispatch, shortcut and profile handling, invalid-setting non-mutation, and atomic config snapshot save/load; `--dump-default-config` confirms the current dropdown/F10, Fira Code 11pt, top-tab, border-status defaults. Rendered settings UI remains open.
- The native shortcut dialog now renders a compact settings summary for shortcut, mode, font, profile, preset list, tab position, and status indicator; editable settings controls and broader rendered UI remain open.
- Added a selectable five-item profile preset control to the native settings dialog; dispatch and persistence wiring remain open.
- Wired the preset selector's GTK change signal; Zig profile dispatch and persistence remain open.
- Preset selection now dispatches into the existing Zig pane-profile command; persistence remains open.
- Preset selection now persists the updated settings snapshot through the existing atomic config writer.
- The native host now renders the live terminal inside a GTK notebook with a real `Terminal 1` tab surface; multi-tab actions and splits remain open.
- Added a real horizontal GTK split container with an explicitly unbound secondary-pane placeholder; second-PTY lifecycle wiring remains open.
- Added a dedicated secondary VTE context and shell spawn with pane ID `2`; secondary event routing and lifecycle receipts remain open.
- Added a native-layout structural smoke check for notebook, split, and unbound-secondary-pane wiring.
- Extended native-layout smoke coverage to secondary context allocation, pane ID 2, spawn, output, resize, and exit handlers; live two-pane smoke remains open.
- Extended native smoke reporting with separate pane-2 started/output/exit fields and callback acceptance.
- Workspace UX tests pass pane splitting, 1x1/2x2/3x3 grids, pane selection modes, broadcast targeting, stable status routing, and snapshot/export restoration of workspace metadata; rendered tabs, splits, drag/drop, and context menus remain open.
- Maintenance/project-workspace checks report autosave, project refresh, and recovery cleanup due with pending receipts; project scan inventories 52 files in 17 directories without truncation and preserves the unavailable-Git boundary for this checkout.
- Host planning confirms the Plasma Wayland dropdown/layer-shell, GlobalAccel, KDE notification, drag/drop, and HiDPI capability model; the Ghostty probe reports no supported library and incomplete lifecycle, preserving VTE as provisional.
- Release verification passes with `zig build -Doptimize=ReleaseSafe` followed by `./scripts/verify.sh`; install packaging and multi-architecture artifacts remain open.
- The explicit AArch64 ReleaseSafe build remains blocked before linking because GTK3/VTE target system libraries are unavailable; this is documented as a provisioning gap, not cross-build proof.
- Added a native `resources/com.noctty.NOCTTY.desktop` launcher descriptor for KDE/portal app identity; installer integration, icons, dependency bundling, and multi-architecture packaging remain open.
- Added matching AppStream `resources/com.noctty.NOCTTY.metainfo.xml` metadata; installation and release artifact wiring remain open.
- Wired the desktop and AppStream descriptors into the Zig install tree under `share/applications/` and `share/metainfo/`; icons, dependency bundling, and package-manager artifacts remain open.
- Verified the install tree with isolated Zig caches; the default cache's read-only `compiler_rt` failure is recorded as an environment boundary.
- Added scalable SVG plus 48px and 128px native application icons under the hicolor icon tree; package-manager integration remains open.
- Added `scripts/package_smoke.sh` to verify the release install tree contains the executable, desktop entry, AppStream metadata, and icon.
- Promoted the packaging smoke into `scripts/verify.sh`, so the standard verification gate checks install-tree metadata automatically.
- Extended the packaging smoke to validate desktop-entry and AppStream syntax when `desktop-file-validate` and `xmllint` are available.
- Verified an isolated-prefix install produces the executable, desktop entry, AppStream metadata, and scalable icon at the documented paths.
- Added `scripts/package_tarball.sh` to create a local tarball from the verified install tree; distro manifests, dependency bundling, signing, and multi-architecture artifacts remain open.
- Promoted tarball-content checks into `scripts/verify.sh` alongside the install-tree packaging smoke.
- Normalized tarball ordering, timestamps, ownership, and gzip metadata as determinism prerequisites; byte-identical isolated rebuild proof remains NCT-075.
- Added SHA-256 sidecar generation and verification for local release bundles; signing and publishing remain open.
- Bundle output now reports the archive and checksum sidecar paths explicitly.
- Added a docs-truth checker for required handoff files and README links, wired into `scripts/verify.sh`.
- Added `docs/INSTALL.md` with the verified local install command, artifact locations, runtime dependency boundary, and remaining distribution gaps.
- Added `docs/RELEASE_CHECKLIST.md` summarizing verified local gates and remaining release-infrastructure work.
- Added `scripts/ci_verify.sh` as a headless-safe CI wrapper that reports whether display-bound smoke lanes are available.
- Added opt-in `NOCTTY_RUN_NATIVE_SMOKE=1` execution for compositor-backed CI jobs while retaining headless-safe defaults.
- Hardened the CI wrapper to require a live Wayland/X11 socket instead of trusting stale display environment variables.
- Clarified CI output so socket presence is not reported as compositor proof; only a successful opt-in native smoke is `passed`.
- Recorded the current compositor opt-in failure: the advertised display socket was not usable, so no CI native-smoke pass is claimed.
- Reproduced the same failure for two-pane smoke: Wayland socket presence is reported, but native launch exits `NativeHostUnavailable` before pane-2 evidence.
- Elevated host access resolved the earlier sandbox boundary; full Wayland and X11 graphical smoke now proves pane-2 lifecycle.
- X11 native smoke now proves complete pane-2 lifecycle (`secondary_started=true secondary_output=true secondary_exited=true`) while retaining all primary assertions.
- Added `scripts/ghostty_abi_smoke.sh` to guard the unsupported-public-ABI boundary and provisional VTE host decision.
- Promoted the Ghostty ABI guard into `scripts/verify.sh`.
- Native Zig state-model foundation for config, workspace, terminal pane state, themes, paste policy, project workspaces, project panels, and editor buffers.
- Plasma/Wayland/X11 host capability and placement state for dropdown, windowed, and zen fullscreen modes.
- Native host launch/readiness plan for default hidden-dropdown startup, first visible dropdown activation, degraded non-Plasma behavior, and headless unavailability.
- Native host presentation-action plans for startup and shortcut activation across Wayland layer shell, Wayland toplevel fallback, and X11 EWMH fallback.
- Native global-shortcut registration request/receipt tracking with KDE GlobalAccel and X11 grab-key transport selection.
- Native window lifecycle request/receipt tracking for startup and shortcut activation without claiming live OS window creation.
- Native notification delivery request/receipt tracking with KDE DBus transport selection without claiming live notification delivery.
- Native status-tooltip request/receipt tracking around tab status summaries without claiming rendered tooltip display.
- Compact terminal workspace model with split/grid presets, pane selection, broadcast targeting, status summaries, and context-menu command dispatch.
- GUI-facing configuration commands for mode, shortcut capture, tab/status options, KDE notification toggles, long-running thresholds, font settings, default theme, panel metrics, and per-terminal profile presets.
- Native binary GUI settings persistence with export/import, default config path generation, and file-backed save/load helpers.
- Native profile preset menu request/receipt tracking for future right-click per-terminal preset menus, plus app-level selection from the active menu request.
- Theme import primitives for Ghostty, Xresources, and simple Alacritty color lines, plus app-level preview/install/select state.
- Native binary installed-theme library persistence with export/import, default theme-library path generation, and file-backed save/load helpers.
- Clipboard paste preparation with unsafe-control stripping, heredoc literal preservation, shell one-line repair, bracketed-paste wrapping, and bracket-marker normalization.
- Native clipboard transfer request/receipt tracking plus prepared paste delivery request/receipt tracking without claiming live OS clipboard or terminal injection.
- Isolated dynamic `libghostty` API and lifecycle boundary with fake-symbol coverage for config/app/surface creation, drawing, ticking, resize, focus, text, key, and mouse routing.
- Workspace snapshot, binary export/import, file-backed save/load, atomic writes, default XDG-style paths, recovery dirty/autosave state, and retention cleanup planning/pruning.
- Native project-panel state for git status entries, git graph nodes, and file-list entries.
- Native project-panel scan helpers for Git porcelain status, decorated Git log records, bounded file-list walking, app-level scan application, and the `--project-scan` development command.
- Native maintenance tick planning for autosave, project-panel refresh, and recovery cleanup, plus receipts and the `--maintenance-plan` development command.
- Native workspace save/open file-dialog request and receipt modeling with KDE file-dialog transport selection visible in `--host-plan`.
- Selected workspace file-dialog path bridging to native manual workspace save/load helpers, visible in `--workspace-file-flow`.
- Native project-panel presentation request/receipt tracking, visible in `--host-plan` and exercised with seeded panel data by `--project-panel-plan`.
- Bounded render-ready project-panel views for git status, git graph, and files, with filter/selection/truncation state visible in `--project-panel-view`.
- Native project-panel row activation intents for git diff, file, directory, and commit targets, visible in `--project-panel-action`.
- Native project-panel action execution plans for future git diff, git commit, file open, and directory open executors.
- Native project-panel action execution specs for future Git argv, editor-document, and directory-view dispatch.
- Native project-panel action execution result receipts with stale/mismatched receipt rejection.
- Native project-panel action result views for future GUI panels, with static title/detail strings, tone, output, attention, and process/editor/directory display flags.
- Native project-panel action request/receipt tracking for future file, directory, diff, and commit action execution.
- Native project-panel file-open to editor-open planning bridge with large-file policy application before file reads or rendered UI work.
- Lightweight editor core with multiple selections, per-selection replacement, transactional multi-edits, language detection, worktree-aware document metadata, dirty/revision tracking, undo/redo, literal search, bounded find navigation summaries, large-file open planning, and bounded syntax highlight spans.
- Native app-level editor document load/store state for supplied bytes, including editable loads, large read-only loads, metadata-only no-buffer handling, and same-path reload replacement.
- Native dir-backed editor file loading for project-panel file rows, including stat-before-read hard-limit handling.
- Native app-level editor edit/save writeback for stored editable documents, including dirty/revision updates, atomic file writes, and large read-only rejection.
- `BACKLOG_ARCHIVE.md` to preserve completed slice history separately from active epics.

### Changed

- Promoted the executable from planning-command-only behavior to a real default native terminal launch while keeping development commands available.
- Recorded VTE as a provisional feasibility backend rather than claiming the unresolved public Ghostty Linux surface integration is complete.
- Verified the provisional host lifecycle under explicitly selected Wayland and X11 GDK backends, with pane `1` reaching `done` after exit code 0.
- Expanded both graphical lanes to require injected input, the expected marker in terminal contents, and an observed terminal allocation change.
- Expanded both graphical lanes to require mapped, hidden, remapped, and focus-restored dropdown transitions.
- Expanded both graphical lanes to require actual Plasma shortcut registration, component invocation/signal delivery, and clean unregistration without stale actions.
- Promoted Wayland placement evidence from constrained to `wayland_layer_shell` after providing the matching GTK3 runtime; X11 remains verified as `x11_top`.
- Replaced hardcoded GlobalAccel key assignment with the validated Zig shortcut and added maintained successful/conflict graphical lanes.
- Refreshed `README.md`, `BACKLOG.md`, and `docs/ARCHITECTURE.md` so they describe the native model boundary instead of implying a rendered terminal app exists.
- Marked verification and packaging as `partial` because the local model/build gates exist while GUI smoke tests and packaging remain open.
- Rechecked the public Ghostty C header on 2026-07-09 and kept the Linux/Plasma surface contract as an open integration boundary.
- Expanded `--host-plan` so native launch readiness and feature usage are visible from the development CLI.
- Refreshed README, backlog, archive, changelog, and architecture notes after the host launch/readiness slice so the docs distinguish CLI-visible model proof from missing GUI runtime proof.
- Expanded `--host-plan` again to include startup and shortcut presentation-action lists for future backend transport work.
- Expanded `--host-plan` to include the global-shortcut registration transport request and current registration state.
- Expanded `--host-plan` to include startup and shortcut window lifecycle requests and current lifecycle state.
- Expanded `--host-plan` to include notification delivery transport state.
- Expanded `--host-plan` to include status-tooltip request state.
- Expanded `--host-plan` to include profile preset menu request state.
- Expanded `--host-plan` to include workspace save/open file-dialog transport state.
- Expanded `--host-plan` to include clipboard transfer transport state and paste delivery request state.
- Added `--project-scan` so the development launcher reports project-panel scan availability; in this checkout it proves file scanning while Git status/log are unavailable because usable Git metadata is not present.
- Added `--maintenance-plan` so the development launcher reports autosave, project refresh, and recovery cleanup tick decisions without claiming a live GUI timer exists.
- Added `--workspace-file-flow` so the development launcher exercises selected file-dialog paths through native workspace save/load without claiming rendered save/open controls exist.
- Expanded `--host-plan` to include project-panel presentation request state and added `--project-panel-plan` for a seeded show/receipt/hide project-panel flow.
- Added `--project-panel-view` so the development launcher reports bounded project-panel rows without claiming rendered panel UI exists.
- Added `--project-panel-action` so the development launcher reports project-panel row activation intents without executing file, diff, or commit actions.
- Expanded `--project-panel-action` to report pending native action handoffs and completed receipts without executing live file, diff, or commit actions.
- Expanded `--project-panel-action` to report native action execution plans and their path/commit/Git requirements before handoff receipts.
- Expanded `--project-panel-action` to report non-executed action specs, including Git argv and native editor/directory targets.
- Expanded `--project-panel-action` to report seeded action result receipts after the native action handoff receipts.
- Expanded `--project-panel-action` to report render-ready action result views after each seeded result receipt.
- Added `--editor-plan` so the development launcher reports editable, large read-only, and metadata-only editor open decisions without reading files or opening rendered UI.
- Added `--editor-open-flow` so the development launcher reports project-panel file action targets planned as editor-document opens without reading files or opening rendered UI.
- Added `--editor-load-flow` so the development launcher reports native editor document load/store behavior without rendered editor tabs.
- Added `--editor-file-load-flow` so the development launcher reports native dir-backed editor file loading without rendered editor tabs.
- Added `--editor-save-flow` so the development launcher reports native editor edit/writeback behavior without rendered editor tabs.
- Added `--editor-highlight` so the development launcher reports bounded syntax spans for Zig, JSON, and Markdown without painting an editor.
- Added `--editor-find` so the development launcher reports bounded find matches, truncation, current selection, backward wrap, and no-wrap state without rendered controls.

### Release Operations

- Run and retain the tagged x86_64 and aarch64 artifacts/checksums on their architecture-local release runners.
- Sign and publish the tag, artifacts, checksums, signatures, and release notes using project credentials.
- Optionally capture physical Wayland HID evidence through an explicitly consented RemoteDesktop/EIS portal session; normal Plasma GlobalAccel support does not depend on synthetic input.
- The public Ghostty Linux GUI surface remains unavailable. NOCTTY ships its supported Zig PTY/VT renderer, keeps the optional adapter isolated, and makes no Ghostty-rendering claim.

<!-- OVERZEER:DOCS_CHANGELOG_BEGIN -->
## Unreleased (NOCTTY)
- fix(windows): restore menu qualification helper (2026-09-15; commit `696db5d72574`)
- fix(windows): guard filtered pane tree indices (2026-09-15; commit `8de1c5e516f5`)
- test(windows): cover filtered split ratio preservation (2026-09-15; commit `58ce9b59a2d8`)
- feat(windows): reflow filtered Smart Tab panes (2026-09-15; commit `7584c58ba61d`)
- fix(windows): inspect menu hints with item metadata (2026-09-15; commit `2e4d2f476fa9`)
- test(windows): cover Smart Tab callbacks in smoke (2026-09-15; commit `66b7388006ea`)
- test(windows): compare menu hint lookup modes (2026-09-15; commit `d37ca6a03498`)
- test(windows): report smoke remote mode (2026-09-15; commit `2538e6b20034`)
- test(windows): normalize menu smoke local mode (2026-09-15; commit `4f9cb99b6231`)
- test(windows): include shortcut lengths in smoke receipt (2026-09-15; commit `e49aa75c2607`)
- test(windows): report shortcut hint lengths (2026-09-15; commit `165cc20b9bf3`)
- Update files (2026-09-14; commit `d3375336bec7`)
- test(windows): stage theme smoke continuation (2026-09-14; commit `47550b63381e`)
- fix(noctty): harden source theme imports (2026-09-14; commit `be66f94978a5`)
- test(windows): refresh imported theme before checking colors (2026-09-14; commit `de3b30ffbc27`)
- feat(noctty): import Alacritty TOML themes (2026-09-14; commit `8322e688e84f`)
- fix(windows): write source theme smoke fixture (2026-09-14; commit `cafa5db8fc2f`)
- test(windows): expose source theme import errors (2026-09-14; commit `15a569d2dcbc`)
- test(windows): report theme smoke stages (2026-09-14; commit `05e759651fbd`)
- test(windows): report menu smoke stages (2026-09-14; commit `bf31b6c8a663`)
- test(windows): expose menu qualification diagnostics (2026-09-14; commit `231c0b33c330`)
- fix(windows): restore terminal menu qualification (2026-09-14; commit `7d7098ed491f`)
- fix(windows): correct Smart Tab menu qualification count (2026-09-14; commit `5f42ab30e19d`)
- docs(windows): document Smart Tab controls (2026-09-14; commit `921df11e2c9e`)
- feat(windows): add native Smart Tab controls (2026-09-14; commit `f3da5f8f89f3`)
- feat(windows): add volatile Smart Tab filtering (2026-09-13; commit `c1676f5ac619`)
- feat(windows): persist pane tags for Smart Tabs (2026-09-13; commit `f2c1deecced9`)
- test(windows): add Smart Tab matching policy (2026-09-13; commit `299fb51e9952`)
- docs(windows): align parity capability boundary (2026-09-13; commit `02ffd1e23e01`)
- test(windows): qualify broadcast routing policy (2026-09-13; commit `718a10c5a6f5`)
- feat(windows): add guarded broadcast input (2026-09-13; commit `684c0e70b028`)
- feat(windows): import native theme source formats (2026-09-13; commit `845a5826854c`)
- feat(windows): add persistent native launch profile management (2026-09-13; commit `92fce13b074f`)
- feat(windows): add portable theme libraries and tab drag reordering (2026-09-13; commit `537b058deb72`)
- feat(windows): add proportional dividers and shared appearance controls (2026-09-13; commit `ef9bc13e7bb3`)
- feat: add native Windows tab strip and persistent tab names (2026-09-13; commit `39ec26ccc5c1`)
- feat: share terminal keys and expose Windows workspace menus (2026-09-13; commit `1985162d0bab`)
- refactor: move damage bounds to Zig (2026-09-11; commit `91904da04af5`)
- refactor: move bounded host policies to Zig (2026-09-11; commit `7da80298b9db`)
- refactor: move dialog geometry clamps to Zig (2026-09-11; commit `debcc02cb158`)
- refactor: reuse Zig settings policies on init (2026-09-11; commit `eb60d34a3013`)
- refactor: move settings clamps to Zig (2026-09-11; commit `75092f41b3a5`)
- fix: make clear screen send Ctrl-L (2026-09-10; commit `3f8370521b06`)
- refactor: move theme RGB channels to Zig (2026-09-10; commit `641077858087`)
- refactor: move theme color formatting to Zig (2026-09-09; commit `db28ad272bc6`)
- refactor: move sharing index formatting to Zig (2026-09-09; commit `d4f4c0530578`)
- refactor: move sharing pane hit testing to Zig (2026-09-09; commit `6a22d2ef894f`)
- refactor: move sharing selection parsing to Zig (2026-09-09; commit `b237a1c88c58`)
- refactor: move sharing preview scroll policy to Zig (2026-09-09; commit `32e1d9d37fc3`)
- refactor: move sharing paste chunk policy to Zig (2026-09-09; commit `ec7af72a3ad8`)
- refactor: move sharing arrow formatting to Zig (2026-09-09; commit `8795da737625`)
- refactor: move sharing text buffering to Zig (2026-09-09; commit `ad5b85bb1066`)
- refactor: move extended sharing keys to Zig (2026-09-09; commit `9860895a6ec6`)
- refactor: move sharing key sequences to Zig (2026-09-09; commit `0a103188d6a8`)
- refactor: move bracketed paste markers to Zig (2026-09-09; commit `c58864ec5fd6`)
- fix: reserve pane zoom for background cells (2026-09-08; commit `ccd400e344f6`)
- refactor: move workspace color policy to Zig (2026-09-08; commit `6edd27d7c986`)
- refactor: move palette actions to Zig (2026-09-08; commit `2e9d5f96df46`)
- refactor: move pane snap policy to Zig (2026-09-08; commit `5426ac30353d`)
- refactor: move resize layout policy to Zig (2026-09-08; commit `cbef9d6485ca`)
- refactor: move shortcut labels to Zig (2026-09-08; commit `1602109c9710`)
- refactor: move broadcast labels to Zig (2026-09-08; commit `8f80a6defbff`)
- refactor: move profile labels to Zig (2026-09-08; commit `4cf541a3cef9`)
- refactor: move status labels to Zig (2026-09-08; commit `805dece679b1`)
- refactor: move active pane render policy to Zig (2026-09-08; commit `e04cee22b88f`)
- refactor: move resize handle index to Zig (2026-09-08; commit `abf145ba5618`)
- refactor: move resize edge policy to Zig (2026-09-08; commit `894cfbeea092`)
- refactor: move tray labels to Zig (2026-09-08; commit `b0c8f52cb45f`)
- refactor: move tray cursor policy to Zig (2026-09-08; commit `6691f22dc2ad`)
- refactor: move GTK input utilities to Zig (2026-09-08; commit `c03ecea76763`)
- feat: add Paseo black zinc theme (2026-09-08; commit `607ae6887648`)
- refactor: move grid damage spans to Zig (2026-09-08; commit `a751725dc600`)
- refactor: move grid font metrics to Zig (2026-09-08; commit `39a906146f1e`)
- refactor: move scrollbar policy to Zig (2026-09-08; commit `52596ac8d2e6`)
- refactor: move native text validation to Zig (2026-09-08; commit `2cfc2135a8c3`)
- fix: harden public alpha source baseline (2026-09-08; commit `2dc3060417fa`)
- fix(windows): keep VT fallback buildable (2026-09-08; commit `4b48913b779c`)
<!-- OVERZEER:DOCS_CHANGELOG_END -->

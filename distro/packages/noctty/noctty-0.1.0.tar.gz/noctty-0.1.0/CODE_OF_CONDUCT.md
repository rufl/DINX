# Code of Conduct

## Our standard

NOCTTY welcomes contributors and users regardless of experience, identity, or
background. Be respectful, discuss the work rather than the person, assume good
faith, accept correction, and keep criticism specific and actionable.

Unacceptable behavior includes harassment, threats, discriminatory language,
sexualized attention, deliberate intimidation, publishing another person's
private information, sustained disruption, and retaliation against a reporter.

## Scope

This policy applies to project repositories, issues, pull requests, reviews,
discussions, and project-representative communication.

## Reporting and enforcement

Do not litigate sensitive conduct reports in a public issue. Use GitHub's
private reporting form:

<https://github.com/lichforge/noctty/security/advisories/new>

Maintainers will limit report access, gather relevant context, avoid conflicts
of interest, and respond proportionally. Actions may include a private warning,
content removal, temporary participation limits, or a permanent ban. Immediate
threats or illegal conduct should also be reported to the appropriate local
service; project maintainers cannot provide emergency response.

Good-faith reports and appeals will not result in retaliation. Confidentiality
will be preserved as far as investigation and legal obligations allow.

# Support

NOCTTY is an early source alpha maintained on a best-effort basis. There is no
paid support, response-time guarantee, or stable-version compatibility promise.

## Before asking

1. Read [Known limitations](docs/KNOWN_LIMITATIONS.md).
2. Search existing issues.
3. Reproduce with the current `main` branch when practical.
4. Collect the commit, distribution, desktop/compositor, GPU/driver when
   relevant, launch command, exact steps, and non-sensitive logs.

Use a GitHub bug-report template for reproducible defects. Use a feature request
for bounded product proposals; discuss broad architecture changes before
implementing them. General terminal, shell, compositor, or distribution support
questions belong in those upstream communities unless NOCTTY-specific behavior
is demonstrated.

Never post credentials, private terminal output, pairing keys, encrypted-history
passwords, crash dumps containing private data, or vulnerability details.
Security reports use the private process in [SECURITY.md](SECURITY.md).

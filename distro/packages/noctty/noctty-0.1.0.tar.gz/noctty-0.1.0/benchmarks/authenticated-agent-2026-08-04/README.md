# Authenticated Codex evidence, 2026-08-04

This archive retains four authenticated Codex CLI 0.144.6 model requests through NOCTTY's production command profile, PTY, VT, GTK, and Cairo path: Debug/`ReleaseSafe` on live Plasma Wayland/X11.

Each `*-response.txt` is exactly `NOCTTY_AUTHENTICATED_CODEX_OK`. Matching logs require an ephemeral read-only request and controlled zero exit; PNGs retain the mapped response. `summary.csv` records root/process-tree memory and image dimensions. KWin activation and Spectacle capture are compositor automation, not HID proof.

See `docs/AUTHENTICATED_AGENT_QUALIFICATION.md` for the protocol and claim boundary.

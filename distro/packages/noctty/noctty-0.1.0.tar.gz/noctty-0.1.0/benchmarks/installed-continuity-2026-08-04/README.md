# Installed continuity evidence, 2026-08-04

This archive retains tmux 3.7b and Zellij 0.44.3 create/attach, detach, NOCTTY relaunch, and reattach through the production launch-profile, PTY, VT, GTK, and Cairo path in Debug/`ReleaseSafe` on live Plasma Wayland/X11.

Each lane has a first-attach and reattach log/screenshot. The prior session marker remains rendered after relaunch. `summary.csv` records all 16 screenshots and dimensions. Synthetic detach chords and KWin/Spectacle automation are not HID proof.

See `docs/INSTALLED_CONTINUITY_QUALIFICATION.md` for the protocol and claim boundary.

# Terminal Agent-Scale Evidence

Compact retained evidence for `docs/TERMINAL_AGENT_SCALE_RESEARCH.md`.

- `trials.csv`, `processes.tsv`, `summary.csv`, `metadata.txt`: nine alternating 32-pane pairs comparing inline per-session pump storage with shared scratch.
- `cell14-*`: seven alternating 32-pane pairs comparing 16-byte and 14-byte terminal cells.
- `cell14-renderer*`: seven simultaneous ReleaseSafe exact-renderer pairs with CPU assignment alternated.
- `eight-pane-*`: seven direct baseline/final pairs guarding the established eight-pane path.
- `idle-history-*`: bounded idle cold-packing, seven-pair active-path checks, delayed native USS confirmation, and exact core memory receipts.
- `pump-budget-rejection.txt`: retained 128 KiB–2 MiB pump-budget sweep and rejection decision.
- `SHA256SUMS`: artifact integrity.

These are noisy-host engineering receipts, not universal terminal rankings or authenticated-agent proof.

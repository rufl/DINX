# Terminal Peer Research Evidence

Pinned public-source revisions and focused local receipts for
`docs/TERMINAL_PEER_RESEARCH.md`.

- `sources.tsv`: exact peer revisions reviewed.
- `write-queue-probe.txt`: sleeping-child main-thread enqueue comparison. This
  measures caller blocking time, not time until every queued byte reaches the child.
- `active-scale-smoke-*`: one current ReleaseFast Xvfb regression sample at 8
  and 32 panes; it is a guard, not an A/B or cross-terminal ranking.
- `reflow-blank-tail.txt`: deterministic before/after correctness receipt.
- `SHA256SUMS`: artifact integrity.

The source review transfers bounded ideas, not peer benchmark rankings.

# Compact Power UX

Last verified: 2026-09-27.

NOCTTY adapts the strongest low-chrome interactions from [Wave Terminal](https://docs.waveterm.dev/releasenotes), [PrettyMux](https://prettymux.com/), and [Yakuake](https://apps.kde.org/yakuake/) without copying their implementation or turning the terminal into a dashboard.

## Adopted Interactions

| Inspiration | NOCTTY adaptation | Screen-estate rule |
| --- | --- | --- |
| Wave pane magnification, terminal search, BEL/OSC attention badges, focus-follows-pointer, scrollback save, font scaling, and IME fixes | Reversible keyboard or double-click pane zoom, scrollback-wide find overlay, compact attention dots, optional hover focus, atomic UTF-8 scrollback save, persistent pane-local Ctrl+wheel font scaling, and GTK IM composition | No per-pane header or permanent search bar; zoom gestures cannot leave text selected |
| PrettyMux command search, quick notes, directional pane navigation, theme cycling, broadcast, and agent attention | Fuzzy command palette, workspace-persisted quick note with hold-Alt overlays on every visible pane, geometry-aware Alt+Arrow focus, palette theme cycling, broadcast with compact state markers, tab-rollup attention color, selected-pane tags with editable existing-tag suggestions, and Smart Tab filtering with a compact active-tag indicator, matching-pane focus handoff, tag-named empty-state feedback, and button/Escape recovery | Palette, note, tag dialogs, and shortcut card exist only while invoked; note overlays exist only while Alt is held; no sidebar |
| VS Code Peacock's fast visual workspace identity | Exact-tab native color accents with eight initial presets, contrast-aware text, and reversible keyboard shade steps | Color is limited to the existing compact tab; no editor-wide chrome, extension runtime, or permanent picker panel |
| Yakuake drop-down sizing, reveal motion, focus-loss hiding, active-session title information, direct tab creation/drag reorder/rename/close, pane/session close, layout presets, resize dimensions, list-style settings, system-tray access, same-directory tools, and global access | Undecorated Wayland layer-surface presentation, horizontally centered percentage/pixel width changes, settings-backed width/height/reveal duration with a 480×240 usable floor and legacy collapsed-state recovery, popup-aware focus-loss hide, a configurable 18-pixel bottom `short cwd : foreground process` strip for the active pane, native attached-tab pointer reordering with insertion feedback and active-identity preservation, a leading themed `+` New Tab action, right-edge Settings then Close app controls, no-popup inline double-click tab rename, right-click exact-tab close, pane-targeted `Close Terminal`, live balanced 1×1/2×2/4×2/3×3/4×4 grids with cancel-first overflow-tab protection, a centered `columns × rows` OSD, three category pages with guaranteed above-parent Wayland/X11 stacking, thin resize targets, a native StatusNotifier item with Show/Hide, Settings, and clean Close actions, cwd-rooted `Open NoctEd Here`, inherited pane cwd, Plasma GlobalAccel, Noctalia compositor-to-D-Bus F10, and tag-aware pane tooltips | Menus and project/tag surfaces are transient; NoctEd is a separate process rather than permanent terminal chrome; the pane strip is one page-level row rather than a header on every split; dragged tabs stay in the current window; pane close and presets reuse existing split chrome; rename edits the label itself and resize feedback is an overlay; settings show one grouped category at a time; resize targets consume at most six edge pixels |

## Default Shortcuts

- `Ctrl+Shift+P`: command palette
- `Ctrl+Shift+F`: find across the active terminal grid and scrollback
- `Ctrl+Shift+N`: workspace quick note
- `Ctrl+Shift+G`: set or clear the Smart Tab filter
- `Ctrl+Tab`: cycle forward through visible panes on the current tab
- `Ctrl+Shift+Tab`: cycle forward through ordinary and Smart Tab-filtered tab views
- `Ctrl+Shift+Y`: tag selected panes
- `Ctrl+Shift+Z`: zoom or restore the active pane
- `Ctrl+Shift+R`: rename the active tab
- `Ctrl+Alt+=`: lighten the active tab color
- `Ctrl+Alt+-`: darken the active tab color
- Hold `Alt`: show the workspace note in every visible pane
- `Alt+Arrow`: focus the nearest pane in that direction
- `Alt+wheel up/down`: previous or next visible pane on this tab
- `Ctrl+Alt+wheel up/down`: previous or next tab / Smart Tab view
- `Ctrl+Shift+K`: compact shortcut card
- `Ctrl+wheel up/down`: increase or decrease the pointed pane's font size
- `Ctrl+C`: interrupt only the active terminal pane
- `Ctrl+D`: close the active terminal pane; protect the final pane
- `Ctrl+S`: save the current NoctEd document
- `F10`: show or hide NOCTTY

Inside the separate NoctEd window:

- `Ctrl+N`: create a clean untitled buffer
- `Ctrl+S`, `Ctrl+Shift+S`: save or open native Save As
- `Ctrl+P`: fuzzy-filter the bounded project file index and open the selected path
- `Ctrl+F`, `F3`, `Shift+F3`: find in the current file and move between matches
- `Ctrl+Shift+F`: open Find in Files; Enter starts the bounded asynchronous project search
- `Ctrl+PageUp`, `Ctrl+PageDown`: previous or next file tab
- `Ctrl+W`: close the current file through Save/Discard/Cancel
- `Ctrl+Shift+[`, `Ctrl+Shift+]`: fold or unfold the current indentation region

`Ctrl+Tab` wraps within the current GTK page and skips panes hidden by a Smart Tab filter or pane zoom before synchronizing the stable pane ID in Zig. Alt+wheel uses the same visible current-page order: down advances, up reverses, and smooth deltas accumulate into whole steps. Each pane target receives an 800 ms blue focus frame and `Pane n / total` chip without changing the tag-selection group or consuming layout space. `Ctrl+Shift+Tab` advances the notebook without clearing the active tag, so filtered tab views remain in the same navigation loop. Ctrl+Alt+wheel uses that tab loop with down for next and up for previous, wraparound, separately accumulated smooth steps, and an 800 ms purple `Tab n / total` overlay over the focused terminal. `Ctrl+Shift+B`, the command palette, and the pane menu share one explicit broadcast-input path: enabling explains selected-versus-all-tab targeting and defaults to `Keep Off`; disabling is immediate. Existing `Ctrl+PageUp`/`Ctrl+PageDown`, split, copy/paste, and pane-selection shortcuts remain unchanged. F10 uses GlobalAccel on Plasma and `noctty --toggle` from the compositor on Noctalia; both target the same compact reveal behavior.

Plain `Ctrl+C` is terminal-local even when broadcast is on: one ETX is written directly to the active pane and never duplicated to selected or neighboring panes. `Ctrl+Shift+C` remains copy. Plain `Ctrl+D` is a workspace close chord rather than terminal EOF; it reuses `Close Terminal` foreground-process confirmation plus model/session/GTK teardown and focus handoff without forwarding EOT. The final pane is protected and receives neither close nor EOT.

Holding either Alt key reads the existing persisted workspace quick note and paints it in the upper-right corner of every mapped terminal pane. UTF-8 and multiline text wraps to at most three lines inside a 320×92-logical-pixel translucent tooltip; releasing Alt, hiding NOCTTY, or moving focus outside the window removes every copy. Smart Tab- and zoom-hidden panes are not drawn. `Alt+Arrow` keeps its directional-focus behavior while the note remains visible for the duration of the chord.

Double-clicking an empty background cell in a multi-pane terminal zooms or
restores that pane. Double-clicking rendered text selects its contiguous
non-space word instead; the gesture never zooms through text.

Right-click and choose `Open NoctEd Here` to launch the standalone editor at that pane's live cwd. The terminal context menu remains focus-safe through activation, then NOCTTY releases the popup and retains no editor child handle. NoctEd presents the compact left project tree, tabs, translucent right minimap, and source view in its own native window. At most two lazy bounded lanes separate foreground document load/save/path resolution from project scan/search and capped structural index deltas; precise create/delete/move/rename paths refresh on the scan lane, conservative fallbacks use the full scanner, and GTK builds the replacement staging tree in bounded main-thread slices while the prior tree stays usable. Find in Files appears only while invoked, publishes completed bounded results on the main thread, and opens a selected result at its line. `Ctrl+P` uses the already-pruned project index for a capped fuzzy file list and coalesces query edits before filtering. Folding compacts hidden lines with zero-copy tags, leaves the full buffer and undo history intact, and unfolds before edits or search. `Ctrl+N` creates an untitled buffer; `Ctrl+S` uses permission-preserving atomic replacement or routes its first save through the native chooser, while `Ctrl+Shift+S` always opens Save As. Closing a dirty NoctEd document or window, including close-other/close-all, requires Save, Discard, or Cancel. Closing NOCTTY does not close NoctEd or discard its buffers.

Right-click a terminal pane and choose `Close Terminal` to stop and remove that exact session. A foreground command or agent produces a native `Keep Open` / `Close Anyway` warning before the workspace changes; accepted close has a bounded process-group shutdown and releases the complete PTY, grid, and dynamic session storage. The context is marked callback-retired before IM or GTK hierarchy changes, preventing a late focus, draw, input, resize, PTY, drag, or clipboard callback from reaching released session state (`late_callback_guard=true`). The sibling expands into the vacated split without flattening the saved split topology, focus moves to the model-selected survivor, and closing pane 1 does not retire the root window controller. A sole-pane tab closes only when another tab can survive; the application's final terminal remains protected.

Before the dropdown hides or shuts down, tracked menus, active menu grabs, and visible process-local GTK popup windows are dismissed ahead of the parent window (`popup_teardown=true`).

Choose `New 2×2`, `New 4×2`, or `New 3×3` from **New Split Tab** to materialize four, eight, or nine real native sessions. New PTYs are allocated on demand, existing sessions are preserved, and balanced horizontal/vertical dividers create equal cells. The redundant user-facing 1×1 preset is removed; use **New Tab** for a single terminal.

Dragging a split divider, the full pane-information bar, or a three-pixel cardinal window edge shows each affected terminal's live grid as `columns × rows`. Terminal content keeps the text cursor, the information bar uses the north/south resize cursor, side targets use east/west resize, and no diagonal corner cursors are exposed. Pages with at least four panes automatically reduce their effective font to target the conventional 80×24 TUI floor, without overwriting the pane's requested/persisted font; growth restores it. If the bounded 3 pt minimum still cannot fit 80×24, the same OSD says `Min 3pt · columns × rows`; otherwise it briefly shows `Zoom N% · columns × rows`. Ordinary initial layout remains suppressed, and the OSD disappears 750 ms after the last accepted resize.

Tab, pane, and divider customization is also a hot-session transaction. Accepted workspace actions write through to the atomic recovery snapshot; continuous divider movement updates the matching Zig split node and coalesces the disk flush. On the next launch—even after an unclean exit—the native notebook, recursive ratios, active focus, titles/colors, tags and Smart Tab, pane profiles, notes, broadcast state, and cwd are reconstructed before the window appears. Settings use their own immediate atomic config path. Shells restart in the saved directories rather than claiming process-memory resurrection.

Holding Ctrl while scrolling changes only the pane under the pointer by one point per wheel notch. Smooth events accumulate independently per pane; the configured minimum/maximum are respected, neighboring panes retain their sizes, and only the targeted PTY/grid is resized to its new font-derived cell geometry. The pane profile persists through workspace save/load. Without Ctrl, wheel input keeps its existing scrollback or application mouse-reporting route; Settings remains the global default control.

Right-clicking a terminal exposes `Profile` without adding permanent pane chrome. Its five radio choices—Global default, Compact, Readable, High contrast, and Mono no ligatures—are resolved and applied by Zig for that exact pane; another focused or neighboring terminal is not a fallback target. Family, point size, high-contrast state, ligature preference, and the current preset synchronize into the live pane, and Settings presents the same selector as `Active pane profile`. Preset changes dirty and persist the workspace and restore with the hot session. Mono no ligatures records and restores the preference, but the current fixed-cell Cairo codepoint renderer does not claim font-feature shaping or visible ligature suppression.

Tabs use numbered defaults (`Tab 1`, `Tab 2`, `Tab 3`, …), live shell titles when available, and the working-directory basename when no shell title exists. Long titles use an ellipsis in the compact row while the full title remains in the tooltip. Double-click a visible tab title and its label becomes a selected borderless entry in the same tab. Enter commits through the Zig workspace model; Esc or clicking any other element cancels and restores the prior label. No rename popup or confirmation button is used. Manual names persist in workspace snapshots and take precedence over changing shell titles.

The workspace owns one compact information strip below the notebook, keeping bottom-positioned tabs immediately above the Yakuake-style information bar. For local sessions it keeps Konsole's default `%d : %n` shape, the final cwd component and foreground process, then adds `App` and `Pane` CPU/RSS summaries. `App` is the NOCTTY process tree; `Pane` is the selected terminal shell tree. NOCTTY obtains the process-group leader with `tcgetpgrp`, reads bounded `/proc` metadata, and samples descendant CPU ticks/RSS once per existing one-second root maintenance cadence. Rapid focus/draw refreshes reuse the last sample, so the bar adds no pane-local timer and unchanged GTK setters remain suppressed. Hover exposes pane ID, foreground PID, full directory, process, both process counts, CPU, and MiB values. Appearance > Client chrome can hide the strip and config snapshot v4 preserves that choice. CPU is a local Linux process-tree observation, not telemetry or a benchmark claim. A focused host-local microcheck over a five-process tree measured 200 sampler calls at 39.8 µs average; the UI samples two trees once per second, but that one-host observation is not a universal budget. SSH username/host expansion remains launch-profile work.

Right-click a tab title and open `Tab Color` to choose Default, Red, Orange, Yellow, Green, Cyan, Blue, Purple, or Pink for that exact page. The compact tab receives the resolved RGB while its label and close glyph automatically choose dark or light contrast; terminal palettes remain untouched. Choosing a preset resets its shade. `Ctrl+Alt+=` and `Ctrl+Alt+-` then move the active tab through four reversible lighter/darker steps, and start an uncolored tab from Blue. The same actions are searchable in the command palette. Preset and shade mark the workspace dirty and persist in version-5 snapshots with older-file compatibility.


`Rename active tab` is also available in the command palette and via `Ctrl+Shift+R`.

The persistent `+` New Tab button exposes `Ctrl+Shift+T` in its tooltip and accessibility name.

Settings and Close occupy the tab row's far edge in Yakuake's order, with Settings immediately before Close. The compact strip keeps visible titles to 18 characters and uses `×N` instead of wider multi-pane text while tooltips retain full detail. New Tab, Settings, application Close, and per-tab Close use GTK symbolic icons with 28-logical-pixel width and 18-logical-pixel height targets; tab labels render at 90% of the surrounding UI font. The tab event target now exposes the full title as its assistive name and the current tab summary as its assistive description. The controls follow horizontal or vertical tab placement, expose accessible names and tooltips, and share explicit hover, active, disabled, and keyboard-focus states.

Attention and unsaved-workspace markers appear beside the title without replacing it. Attention clears when the pane receives focus or its session exits; the unsaved marker follows workspace save state.

Click the leading `+` icon before the first tab to create and focus a new native tab. The row remains visible in a one-tab workspace, and the action resolves the current notebook page; after the original host tab is closed it allocates a fresh Zig session instead of reusing the retired PTY.

Click a tab's close button or right-click its title and choose `Close Tab` to close that exact page, even when another tab is active. The last tab remains available; an accepted close stops the page's PTYs and pane timers, keeps the compact one-tab row and `+` action available, and sends focus back to the surviving session.

The native Settings window follows Yakuake's compact list pattern: Window, Behavior, and Appearance remain keyboard-selectable in a narrow system-icon sidebar while only the active page is shown. Category rows have explicit accessible names, 48-logical-pixel targets, destination-specific tooltips, pointer-focus retention, selected/hover/pressed contrast, visible keyboard focus, and opening Settings places focus on Window so keyboard users can navigate immediately. Both axes remain scroll-accessible on narrow work areas instead of clipping launch-profile controls. Existing settings continue to apply live and persist through the Zig configuration boundary.

Transient power surfaces are named at their actual controls: command search and results, terminal search and result status, Quick Note text plus save status, and the keyboard-shortcut card. Find switches to a vertical layout on narrow work areas, command rows stack their hint below the action, and the command, note, and shortcut surfaces derive bounded scroll geometry from the current monitor work area. Dynamic note and theme status uses native status/alert roles; a failed Quick Note read leaves the editor read-only and closes without overwriting the prior note. The compact smoke reads the established ATK names before accepting the interaction path; current narrow-layout mapped recapture remains subject to the isolated-display gate.

Restore mode, encrypted-history password, registered-agent fields, and the
session-sharing form also expose explicit assistive names. Sharing state and
action failures emit status/alert events, while the remote preview's requested
width and height are capped by the already workarea-bounded dialog. The sharing
status publisher compares text, role, and description before emitting so its
200 ms refresh timer does not repeat an unchanged screen-reader announcement.
Action sensitivity follows the pairing/host/viewer state, including explicit
clear actions for stopped and failed roles. Revocation has a cancel-default
confirmation and removes the peer from the actionable selector; save failure
retains a three-second alert plus an explicit retry. Closing the dialog stops
every network role because there is no separate persistent sharing indicator.
Remote paste is limited to 64 KiB and reports partial or denied delivery instead
of silently returning.
The sharing smoke rejects missing names, a non-status initial role, or a
preview request outside its 480x260 upper bound; mapped compact proof still
requires an admitted private display session.
These contracts cover form/action/status accessibility, not an ATK text model
for the Cairo-rendered remote terminal canvas; screen-reader access to remote
cell content remains unqualified.

Inline tab rename, workspace-tag input, Noctalia import variants, and NoctEd
completion/rename controls carry explicit names too. Tag input is copied and
trimmed before validation rather than mutating GTK's borrowed entry text.

## Chrome Budget

- One or more tabs use one compact row with a leading `+` New Tab action, short double-click-renamable/right-click-colorable/closable titles, one status/attention dot, and trailing Settings then Close app actions.
- Terminal close reuses the transient pane menu and existing split; it adds no per-pane close button or title bar.
- Pane status remains a one-pixel border plus tooltip. At most one optional 18-pixel information row exists per tab page; split panes do not each gain a title bar.
- Search, command, note, shortcut, settings, theme, and project surfaces are transient.
- Hold-Alt note previews are painted into visible terminal surfaces, reserve no layout space, and disappear on release or window focus loss.
- Resize dimensions are painted over the terminal only while resizing and reserve no layout space.
- Font scaling reuses the terminal surface and transient resize dimensions; it adds no toolbar or status row.
- Borderless resize targets use only the outer six pixels and add no title bar; the tray icon preserves one-click access while hidden and keeps Show/Hide, Settings, and foreground-process-aware `Close NOCTTY` in a transient desktop-rendered menu.
- Zoom temporarily hides sibling panes and the tab row, including `+`, then restores the exact live sessions and creation action.

Wave web widgets, embedded AI services, and browser blocks are intentionally not imported because NOCTTY has no browser runtime or remote service. PrettyMux's persistent project sidebar is represented by transient palette/project surfaces instead. Ghostty remains behind the isolated public-ABI boundary.

## Proof

The active-pane portion of `scripts/native_grid_compact_ux_smoke.sh` requires the focused second pane to render `sleep` from PTY `/proc` metadata, verifies `App`/`Pane` resource text and detailed tree tooltips, verifies notebook-first/strip-last root ordering so the tab row remains above the information bar, and proves rapid unchanged refreshes retain one revision (`tab_bar_above_info=true pane_info=true pane_source=pty_proc pane_resources=true pane_refresh=coalesced pane_info_dedup=true`). The settings smoke toggles the real Appearance control and reloads the persisted config.

`scripts/native_grid_hot_session_smoke.sh` performs a fresh-process Wayland/X11 reconstruction of two customized tabs and five live panes, including recursive ratios, titles/colors/tags/Smart Tab/profile/settings/cwd, then proves malformed-file fallback.

`scripts/native_grid_profile_preset_smoke.sh` opens pane 2's real five-item `Profile` submenu while pane 1 owns keyboard focus, confirms the current item, then drives Readable, High contrast, and Mono no ligatures. It requires 14 pt geometry, rendered high contrast, live ligature-preference delivery, exact-target isolation, dirty state, and snapshot/autosave restoration; its repeated matrix reports `native_grid_profile_preset_matrix wayland=true x11=true exact_target=true isolated=true persisted=true restored=true`.

`scripts/native_grid_terminal_chords_smoke.sh` runs two live panes with broadcast enabled on Wayland and X11. It drives the real GTK key path, requires exactly one ETX on the focused pane and zero on its neighbor, then requires exact-pane `Ctrl+D` model/PTY/GTK teardown, zero forwarded EOT bytes, surviving focus, and final-pane protection.

`scripts/native_grid_tab_reorder_smoke.sh` launches an owned X11/Xwayland NOCTTY window, validates its PID, and uses real pointer press/move/drop input to move background tab 1 after tabs 2 and 3. It fails closed unless `NOCTTY_DEDICATED_DISPLAY=1` names a disposable compositor session with X11/Xwayland available. It requires GTK order, Zig stable-ID order, preserved tab-3 activity, coalesced persistence, snapshot/reload order plus active identity, and clean exit. Wayland uses the same GTK notebook path; consent-free synthetic Wayland pointer injection is not claimed by this X11 gate.

`scripts/native_grid_compact_ux_smoke.sh` renders and exercises the palette, scrollback search/save, quick-note writeback, transient assistive names, dynamic tab accessible name/description, pane zoom/restore including tab-row hide/restore, directional focus, pane-local Ctrl+wheel increase/decrease, neighboring-pane isolation, ordinary wheel preservation, workspace font-profile reload, standard OSC notification attention, IM context, same-directory split, and transient chrome. `scripts/native_grid_note_overlay_smoke.sh` renders a multiline UTF-8 workspace note over two mapped panes on Wayland and X11, requires compact bounds on every pane, then proves Alt release hides all copies. `scripts/native_grid_tab_navigation_smoke.sh` creates two tabs and a split on Wayland and X11, drives `Ctrl+Tab`, drives Alt+wheel down/up with rendered pane feedback, proves the other tab and a Smart Tab-hidden pane are never selected, drives Ctrl+Alt+wheel down/up with last-to-first wraparound and rendered tab feedback, drives `Ctrl+Shift+Tab` without losing the filter, and then rechecks PageUp/PageDown plus close/reopen focus restoration. The remaining focused native scripts retain tab color/reorder/rename, exact pane close, dense layout, workspace activation, tray, settings, profile, and resize-overlay proof; display-backed aggregate lanes remain in `scripts/native_release_smoke.sh` while longer resource lanes stay opt-in.

The complementary `scripts/terminal_session_qualification.sh` is headless and display-independent: Debug and `ReleaseSafe` each run 64 ordinary plus eight HUP/TERM-resistant real-PTY lifecycles through production `TerminalSession`, require zero allocator/process residue, and sample root/tree memory separately (`terminal_session_qualification_matrix debug=true release_safe=true normal_cycles=64 forced_cycles=8 sessions_per_mode=72 total_sessions=144 allocator_leak_free=true forced_group_shutdown=true latency_percentiles=true root_memory_separate=true process_tree_memory=true scratch_clean=true`). It proves bounded session ownership and forced group teardown, not compact GTK rendering or multi-day compositor stability.

`scripts/native_grid_renderer_qualification.sh` separately calls the exact compact native-grid Cairo draw function without mapping GTK. In each build mode it measures 128 idle, full-screen, and rich-style 160×50 frames, requires exact repeat pixels and byte-identical cross-mode PNGs, and proves zero renderer-owned warm-frame allocations plus scratch reuse on shrink (`native_grid_renderer_qualification_matrix debug=true release_safe=true frames_per_scenario=128 scenarios=3 pixel_repeat_exact=true cross_mode_artifacts_identical=true idle_draw_cpu=true fullscreen_draw_cpu=true rich_style_draw_cpu=true owned_allocation_counts=true warm_frame_owned_allocations=0 resize_growth_bounded=true resize_shrink_allocations=0 process_memory=true scratch_clean=true`). That receipt exercises the production terminal paint, including the rich grapheme/style path, but does not prove mapped compact chrome, a compositor frame clock, library-internal allocations, or end-to-end latency.

`scripts/native_grid_pipeline_qualification.sh` feeds that exact paint path from a real shell, production PTY/VT, and ABI-v7 packed frame snapshots for two 64-sample runs per mode. It retains display-independent input-write/PTY-read-start-to-Cairo percentiles, repeat/cross-mode-identical pixels, zero warm-frame renderer allocations, and separate root/tree memory. The live companion `scripts/native_grid_presentation_qualification.sh` adds mapped key-handler-to-draw/after-paint samples and Wayland presentation feedback. `scripts/native_grid_full_stack_qualification.sh` completes NCT-119 with live Wayland/X11 idle/fullscreen compositor pixels, external root/tree memory, zero fallback PTY timer ticks, and bounded wakeups. `scripts/native_grid_stability_qualification.sh` supplies the shorter visible/hidden stability tranche.

`scripts/native_grid_credentialed_ssh_smoke.sh` adds a headless real-OpenSSH disposable public-key authentication case through the same product profile/PTY path (`launch_profile=true`, `launch_library=true`, `launch_runtime=true`, `credentialed_ssh=true`). The isolated option shim and keys remain smoke-only and are trap-cleaned. `scripts/native_grid_installed_activation_smoke.sh --contract-only` separately validates the installed desktop/MIME surface and two-tab fixture in disposable state. Its full opt-in mode uses the installed `gio` route, then drives the actual Recent Workspaces button and requires the separate native child to be mapped and drawn on Wayland and X11. The retained Plasma matrix covers both backends and controlled zero exits; it requires `NOCTTY_DEDICATED_DISPLAY=1` in a disposable VM/compositor session because it mutates that session's desktop registry.

For repeatable aggregate proof, the two-tab lane waits until its native popup is mapped before it validates close behavior and then chains reopen and cleanup from the accepted state. The tab-rename lane retries until both tabs and the selected label are mapped, and its fixture PTYs stay alive behind explicit read handshakes until the driven interaction completes. This is smoke-harness synchronization, not an additional compact-UX behavior claim.

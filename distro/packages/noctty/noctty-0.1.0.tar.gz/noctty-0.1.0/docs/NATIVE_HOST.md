# Native Plasma and Noctalia Host

Last verified: 2026-10-02. The Windows boundary is tracked in the
[Linux/Windows parity matrix](WINDOWS_LINUX_PARITY.md) and its
[Simplified Chinese companion](WINDOWS_LINUX_PARITY.zh-CN.md).

## Outcome

Default `noctty` launch opens the live Zig PTY → Zig VT grid → GTK/Cairo surface. The product host is complete for the 0.1.0 scope on KDE Plasma Wayland/X11 and Noctalia-compatible Wayland:

- dropdown, borderless windowed, and zen-fullscreen presentation;
- compact notebook tabs and split panes with independent native sessions,
  optional inactive-pane dimming, and configurable transparent or colored gaps;
- keyboard, mouse, focus, adaptive resolution changes, Unicode/ANSI rendering,
  title, cursor, bounded ring-backed scrollback (including while full-screen
  alternate-screen TUIs such as Codex are active), selection, copy, safe paste,
  and default-browser hyperlink actions;
- GUI workspace, settings, theme, project, and standalone NoctEd handoff surfaces;
- status borders/tooltips, desktop notifications, and timed maintenance work;
- multi-pane selection, native tag/remove-tag actions with editable existing-tag suggestions, explicit compact selection/broadcast indicators, and a replaceable or clearable Smart Tab filter over the active live split, including button and keyboard empty-state recovery;
- Plasma GlobalAccel, compositor-owned Noctalia activation, D-Bus single-instance control, and GUI shortcut recording.

The adapter lives in `src/gui/native_grid_host.c`. It stays thin: terminal/workspace/config/theme semantics remain in Zig and cross the C boundary through narrow callbacks; stable terminal key encoding, keyboard navigation plans, shortcut labels, split visibility, divider/gap styling, balanced split positioning, and compact tab/new-tab/window-toolbar construction are also Zig-owned. The ABI v7 terminal paint path receives one borrowed packed frame snapshot for visible rows; C owns only GTK object lifetime, native effects, and reusable frame-buffer storage. Editor document state belongs to the separate Zig `nocted` process.

Recoverable GUI actions remain distinct from hard model synchronization.
Workspace save/open/recent failures stay in the current flow with a visible
retryable error instead of poisoning normal application exit. Theme imports
accept only bounded regular nonempty files (4 MiB generally and 1 MiB for the
active Noctalia `colors.json`), report success or failure in the owning dialog,
refresh open theme selectors, and redraw the applied theme immediately. Theme
selectors expose a current-tab scope; the selected name is atomically copied to
every pane profile in that tab and persists in workspace snapshots. Rendering
resolves the tab theme's background, caret, and 16 ANSI colors before falling
back to VT truecolor, so full-screen and inline TUI applications use the chosen
palette rather than a fixed terminal palette. The
Settings pages scroll vertically only; compact labels, category rail, and padding keep controls within narrow work areas.
Terminal tab close buttons retain compact geometry while their tooltip and ATK
name identify the complete target title.
The tab event target carries the full tab title as its assistive name and the current tab summary as its assistive description. Compact action buttons retain keyboard focusability even when pointer activation leaves terminal focus in place; Settings category rows retain focus on pointer activation and expose theme-aware hover, pressed, selected, and keyboard-focus states.

Settings and session-sharing dialogs use the same theme-aware surface, group,
label, action, focus, and disabled-state language. Settings labels reserve
readable control width; sharing actions expose tooltips and accessible names;
the remote preview and live status regions retain visible focus and semantic
roles.
Sharing action groups distinguish safe primary controls from destructive stop
and revoke controls through theme semantic tones without changing action
availability.
Command palette, terminal find, quick-note, keyboard-shortcuts, theme-library,
and project-workspace dialogs now share the same utility surface language:
theme-aware backgrounds, bounded search/editor areas, visible selection and
focus states, status affordances, and accessible action/search labels.

The maintained workspace smoke also exercises the live tag/filter bridge: it tags the selected pane, populates the native editable suggestion model from Zig-owned tags, verifies the active tag is named in the empty filter state, activates both the `Clear filter` button and the zero-match `Escape` recovery path, verifies a matching pane remains eligible while an untagged pane is excluded, checks the compact tab indicator and filtered focus handoff, clears the filter, and checks the resulting Zig-owned state after GTK teardown.

## Window and Workspace

The host uses zero-thickness terminal title bars and no conventional thick main title bar. Dropdown mode stays above ordinary windows and enforces a 480×240 interactive floor; legacy pixel overrides migrate to monitor-relative percentages. Windowed mode uses a centered borderless 80%×75% work-area surface with resize targets on every edge and corner, and zen mode uses native fullscreen while remaining compositor-resizable. Monitor geometry, work-area, scale, map, and screen-topology signals are coalesced: dropdown dimensions and layer-shell margins are recomputed, custom windowed geometry is clamped without discarding its size intent, fullscreen is reaffirmed on the current monitor, and every pane receives a fresh grid allocation.

A GTK notebook and recursively nested split tree host independent `TerminalSession` instances. Appearance settings preserve the existing transparent four-pixel pane gap by default, can disable gaps, set a 0–64 pixel width, or paint gaps with the selected theme's editable gap color. Inactive panes use a 70% RGB brightness multiplier by default; the effect and its 20–100% level are independently configurable, while the active pane stays bright even when the top-level window loses focus. Tabs use durable numbered defaults (`Tab 1`, `Tab 2`, `Tab 3`, …), live shell titles when available, and the working-directory basename when no shell title exists; explicit user renames remain authoritative. Compact labels truncate long titles after 18 characters with a visible ellipsis, while the tab tooltip retains the complete title and pane summary; multi-pane tabs use the exact short `×N` suffix. Compact-tab refreshes use stack or literal suffixes for pane counts, selection counts, broadcast markers, tab-color tooltip text, and ellipsis text (`tab_suffix_stack=true`). Repeated compact-tab refreshes cache the last applied markup and tooltip on the GTK tab label and skip setter calls when the strings are unchanged (`tab_setter_dedup=true`). Tab-color styling caches the applied RGB plus active-state key on the tab widget and skips CSS provider removal/rebuild when the requested style is unchanged (`tab_color_style_dedup=true`). Scoped GTK notebook CSS preserves Yakuake-style density while giving New Tab, Settings, application Close, and per-tab Close 28-logical-pixel minimum targets plus explicit hover, active, and keyboard-focus states. Initial, dynamic, and hot-restored pages are drag-reorderable but nondetachable; GTK supplies insertion feedback and edge scrolling. The handler captures the pre-drag active page, dispatches the moved tab's stable ID and destination into Zig, restores background active identity, rolls GTK back to Zig's model index on rejection, and shares the 120 ms hot-session flush coalescer across intermediate positions. Startup reconstruction suppresses reorder writeback. The PID-scoped three-tab pointer gate proves the real press/move/drop path plus snapshot/reload order (`tab_reorder_pointer_drag=true`, `tab_reorder_active_identity=true`, `tab_reorder_rollback=true`, `tab_reorder_persistence_coalesced=true`). A flat GTK `list-add-symbolic` button occupies the notebook's start action slot before the tabs. The end action slot carries flat `preferences-system-symbolic` and `window-close-symbolic` buttons in Yakuake's order, rotating with vertical tab placement; Settings opens the existing native dialog and Close performs all-session NOCTTY teardown without taking ownership of any NoctEd process. Every native action button uses the desktop's standard arrow pointer while hovered and a nonempty GTK tooltip, then restores its inherited cursor on leave so terminal, text, and resize surfaces keep their semantic pointers. Each tab retains its own explicit symbolic close button plus a right-click `Tab Color` submenu and close action. Default removes the accent; Red, Orange, Yellow, Green, Cyan, Blue, Purple, and Pink apply a contrast-aware background to that exact tab without changing terminal colors or strip geometry. New Tab and Split Left/Down allocate a session only after the Zig workspace command succeeds. Every resulting pane can split again: Split Down creates top/bottom panes, while Split Left puts the new pane to the left. Context-menu and middle-button drag movement collapse the source split and reparent the same live terminal into the destination tab; moving the last pane closes its empty source tab.

On normal startup, Zig first loads and validates `~/.local/state/noctty/autosave/default.nocttyws`. The host then queries the saved tab order and recursive layout, reuses the primary context for the saved active pane, allocates every other pane session without a fixed eight-pane ceiling, rebuilds each native page and `GtkPaned` ratio, restores the active page/pane and Smart Tab view, and only then presents the window. A missing or invalid file keeps the fresh one-tab model. Restored terminals are new shell processes started in each saved cwd; process memory is outside the persistence contract.

The pane context menu's **New Split Tab** actions materialize 2×2, 4×2, 3×3, and 4×4 grids rather than only mutating workspace metadata. The redundant 1×1 entry is absent; **New Tab** owns single-terminal creation. Growth allocates real `TerminalSession`/grid contexts, and one bounded Zig receipt returns canonical pane order. GTK reparents the drawing areas into balanced row-major `GtkPaned` trees; each new grid receives both ratio-based allocation tracking and a bounded post-map equalization pass, while three-way splits use one-third then one-half ratios instead of degrading to 50/25/25 bands.

Each visible compact tab title is a native pointer target. Double-click replaces the label with a borderless entry in the same tab, prefilled and selected from the current manual or shell title; Enter validates and dispatches the new name into Zig, while Esc or clicking any other element destroys the entry and restores the unchanged label. There is no rename popup. Right-click opens `Tab Color` and `Close Tab` for that exact page. Color preset changes reset to the base shade; `Ctrl+Alt+=` and `Ctrl+Alt+-` move the active tab through four bounded lighter or darker steps, with Blue used as the first shade base when the tab had no accent. The command palette and shortcut card expose the same two actions. Preset and shade are Zig-owned, mark recovery dirty, survive close/reopen snapshots, and persist in backward-compatible workspace snapshot version 5. Zig accepts the stable tab ID before GTK removes the page, the final tab cannot be closed, and every native context on an accepted page enters a callback-retired state before IM/GTK teardown, then stops its pane-owned terminal, presentation, note-save, hide/focus-hide, resize-overlay, and cycle-feedback sources plus PTY before the surviving tab receives focus (`teardown_sources_complete=true`, `late_callback_guard=true`). Heap-created contexts retired by accepted pane/tab close are normally removed from the root context array and freed immediately (`retired_context_free=true`); when a clipboard read is already pending, only the small C context survives until that asynchronous callback drains. The corresponding `TerminalSession` always deinitializes its VT grid and is removed from the dynamic session pool at the close boundary instead of retaining scrollback and its embedded read buffer until process exit (`session_storage_released=true`, `native_memory_leak_hardening=true`). Closing tab 1 preserves the root host controller and its one shared cursor-blink and maintenance timer used by tray, shortcut, focus-loss, and maintenance paths; stale peer links are severed, so clicking `+` afterward creates a fresh context/session from the surviving tab.

Right-clicking a terminal surface exposes `Close Terminal` for that exact pane. Before Zig mutates the model, the host compares the PTY foreground process group with its interactive shell group. A running foreground job receives a native `Keep Open` / `Close Anyway` warning; the same preflight protects tab, toolbar, tray, and window closes. After acceptance, Zig removes the pane, compacts the reachable split tree without changing surviving axes or ratios, clears zoom, and returns the stable survivor to focus. New and collapsed split trees divide space by descendant pane count; their ratios follow nested 2×2 and fullscreen allocation changes, while manual divider movement immediately becomes the new proportional ratio. The adapter then stops the clicked context's pane-owned sources and complete terminal session, promotes its GTK sibling, and retains inactive root-controller storage when pane 1 was closed. Closing the sole pane of a tab closes that tab when another exists; the application's final terminal is disabled in GTK and rejected by the workspace model. PTY close sends SIGHUP to the foreground and shell groups, tracks both for at most 500 ms even if the shell exits first, and then forces every surviving group so GTK close cannot wait indefinitely or orphan a stubborn job (`foreground_guard=true`, `pty_close_bounded=true`, `forced_group_shutdown=true`). The bounded headless Debug/`ReleaseSafe` lifecycle receipt is `terminal_session_qualification_matrix debug=true release_safe=true normal_cycles=64 forced_cycles=8 sessions_per_mode=72 total_sessions=144 allocator_leak_free=true forced_group_shutdown=true latency_percentiles=true root_memory_separate=true process_tree_memory=true scratch_clean=true`. A complementary installed Codex/Vim/btop sequence reports `terminal_real_tui_matrix debug=true release_safe=true applications=codex,vim,btop codex_login_surface=true codex_sync_output=true vim_alternate_screen=true vim_bracketed_paste=true btop_alternate_screen=true btop_mouse=true btop_truecolor=true unicode=true rich_style=true input_routed=true foreground_identity=true controlled_exit=true allocator_leak_free=true root_memory_separate=true process_tree_memory=true scratch_clean=true`; the installed nano/less/dialog sequence reports `terminal_ncurses_matrix debug=true release_safe=true applications=nano,less,dialog nano_editor=true nano_mouse=true less_pager=true dialog_widget=true editor_pager_alternate_screen=true dialog_primary_screen=true rich_style=true input_routed=true foreground_identity=true controlled_exit=true allocator_leak_free=true root_memory_separate=true process_tree_memory=true installed_tools=true scratch_clean=true`; and the installed top/watch/info/whiptail/fzf/sqlite3/glances/bash/man/sftp sequence reports `terminal_system_tui_matrix debug=true release_safe=true applications=top,watch,info,whiptail,fzf,sqlite3,glances,bash,man,sftp top_monitor=true watch_refresh=true watch_plain_surface=true info_browser=true whiptail_widget=true fzf_filter=true sqlite_repl=true glances_monitor=true bash_shell=true bash_readline=true man_pager=true pager_chain=true sftp_client=true sftp_local_server=true network_bind=false rich_style=true plain_repl=true input_routed=true foreground_identity=true controlled_exit=true allocator_leak_free=true root_memory_separate=true process_tree_memory=true installed_tools=true scratch_clean=true`. The complementary authenticated Codex and installed tmux/Zellij matrices now retain mapped production-path acceptance; multi-day stability remains separate.

The recursive split regressions render four nested and eight balanced simultaneous independent sessions, exercising repeated splits from already-created panes. Each new divider starts at the source pane midpoint. Session contexts and PTYs are allocated on demand rather than from a fixed primary/secondary pair. Panes tagged into the same selection group receive a shared high-contrast selection outline, with a stronger focused outline, so multi-pane selection is visible without relying on terminal content or focus alone.

Every mouse press claims focus for the clicked drawing area. The focus event updates both terminal focus-reporting mode and the Zig workspace's exact active pane. `Ctrl+Tab` walks only active, visible contexts on the current GTK page, wraps in stable pane order, and grabs the target drawing area so GTK focus and Zig pane identity move together; Smart Tab- and zoom-hidden panes are excluded. Alt+wheel uses that same traversal set: down advances, up reverses, and every step paints an 800 ms native blue frame plus `Pane n / total` chip over the target without changing the multi-pane tag selection. `Ctrl+Shift+Tab` advances the notebook while retaining any active Smart Tab tag, so ordinary and filtered tab views share one loop. Ctrl+Alt+wheel uses that same tab path: down selects the next tab, up selects the previous tab, both wrap, and every step paints an 800 ms native purple frame plus `Tab n / total` overlay over the focused terminal. With broadcast disabled, subsequent keyboard, IME, and clipboard input goes to the focused pane's `TerminalSession`; enabling broadcast from the pane menu, command palette, or `Ctrl+Shift+B` crosses one shared warning that names selected-versus-all-tab targeting and defaults to `Keep Off`. Disabling is immediate. Once enabled, the native adapter routes ordinary input across the active tab's live contexts, limiting delivery to tagged panes when a selection group exists and otherwise using every pane. Plain `Ctrl+C` is intentionally exempt: it writes one ETX directly to the focused session, so an interrupt cannot fan out through broadcast. Plain `Ctrl+D` is also adapter-owned and invokes exact-pane close without forwarding EOT; the final terminal remains protected. A dedicated live gate clicks the primary and secondary panes in turn, sends a distinct command to each, and requires both output/lifecycle paths. The cross-backend tab-navigation gate drives pane and tab wheel inputs, hidden-pane exclusion, both exact target overlays, wraparound, explicit previous/next tab aliases, shortcut close, shortcut reopen, and focus restoration.

The root owns one optional active-pane information strip packed after the notebook, so bottom-positioned tabs sit directly above the Yakuake-style information bar. Local formatting keeps Yakuake/Konsole's `%d : %n` title shape and appends CPU/RSS for the complete NOCTTY process tree and selected terminal shell tree. The PTY adapter calls `tcgetpgrp`, reads bounded `/proc` metadata, and walks `/proc/<pid>/task/<pid>/children` into a fixed 4096-process ceiling while summing ticks and resident pages. `PaneInfo.zig` validates text, computes one-core-normalized CPU deltas from `/proc/stat`, and writes the label/tooltip without heap allocation. Focus and page switches refresh immediately from the cached sample; the existing one-second root maintenance timer refreshes resource values and command transitions; GTK still skips identical setters. A persisted Appearance checkbox controls the strip. This is local observation only: no telemetry or history is stored, and remote username/host synthesis is not inferred from `/proc` data.

Drag selection has separate “range exists” and “Button 1 is down” state. A
click without movement clears selection, release/focus loss ends dragging, and
hover motion without Button 1 is ignored, preventing cross-pane selection
trails. Multi-row dragging follows linear terminal text rather than a
rectangle: the first and final rows honor their character endpoints while every
intervening row is selected completely, including reverse-direction drags.
Clipboard extraction uses the same range and retries bounded buffers up to 4
MiB. A pane double-click on an empty background cell zooms/restores only when
the page has multiple panes; a double-click on rendered text selects the
contiguous non-space word and consumes its trailing release without changing
pane geometry.

Cell/style reads are bounds-safe across native-grid ABI v7. A stale GTK allocation frame during rapid split reparenting or resize paints blank cells at obsolete coordinates rather than overrunning the Zig grid. The draw path reads the cursor once per frame, requests one packed frame snapshot for visible rows, coalesces equal-background cells, snaps colored cell spans outward to pixel boundaries so fractional row metrics cannot expose pane-background seams, caches guarded Cairo glyph conversions, skips blank ASCII runs, preserves rich grapheme fallback, and keeps selection/accessibility reads independent from the packed terminal frame.

Each pump uses a reusable 128 KiB buffer and remains capped at 2 MiB. Native panes share one guarded pump scratch because GLib dispatches their reads serially on the GTK thread; standalone terminal sessions retain private ownership and a reentrant pump fails closed. Writes never wait in a GTK callback: `TerminalSession` admits at most 64 MiB into an ordered queue, performs nonblocking writes, and arms a pane-local 4 ms flush source only while bytes remain. Pump and root maintenance also flush, queue capacity above 256 KiB is released after drain, and centralized I/O teardown removes the temporary source. Pane information now includes an explicit continuity badge, and workspace restore is user-selected between shell restart, persistent-session attach, and registered-agent resume. Every live pane registers its PTY descriptor directly with a GLib Unix-FD source, performs one bounded drain per readiness dispatch, and coalesces metadata/events/draw work onto a one-shot 16 ms presentation source while mapped. Hidden panes remain fully drained but coalesce presentation to 100 ms and skip unmapped redraw requests. Idle panes do not timer-poll PTY reads or own descriptor exit timers; root maintenance performs the descriptor-backed exit fallback, and a 16 ms pane-local read/exit fallback exists only if source registration fails. The centralized I/O/context stop helpers remove descriptor, presentation, fallback, note, hide, resize, and feedback sources through pane close, tab close, application close, natural exit, retirement, and final shutdown before the owning session is destroyed (`pty_pump_bounded_drain=true`, `pty_event_source=true`, `timer_read_polling=false`, `output_present_coalesced=true`, `hidden_present_throttled=true`, `mapped_redraw_only=true`, `event_source_cleanup=true`, `descriptor_fallback=root_coalesced`, `pane_exit_timers=0`, `source_cleanup=centralized`). The reproducible comparison and writer-completion boundary are recorded in [TERMINAL_BENCHMARK.md](TERMINAL_BENCHMARK.md); that metric is not claimed as final-frame latency. Its isolation receipt is `split_terminal_benchmark=true yakuake_exclusive=true process_tree_pss=true benchmark_order_isolated=true wezterm_split_ready=true`.

Pane-context close pops down the owning `GtkMenu` before foreground preflight and pane/PTY teardown. The rendered pane-close smoke drives a real foreground `sleep`, auto-accepts only in the smoke harness, and requires `pane_close_menu_popdown=true foreground_guard=true close_confirmed=true session_storage_released=true` with GLib/GDK warnings fatal. The two-tab lane separately schedules a focus callback after page/session retirement and requires `late_callback_guard=true`. Production defaults to `Keep Open`.

Window hide and final shutdown use the same ordered popup boundary: the tracked workspace menu, current menu grab, and visible process-local GTK popup windows are dismissed before the parent is unmapped or destroyed. The hot-session matrix makes GLib/GDK warnings fatal on Wayland and X11 and reports `popup_teardown=true`.

## Compact Power Controls

The host keeps the terminal dominant: one compact row carries a leading New Tab action, short tab titles, and two app-level actions at the far edge: Settings then Close. Its symbolic controls keep 28-logical-pixel width and 18-logical-pixel height targets without adding another toolbar. Optional tab accents color only the compact tab content and derive light or dark label/close contrast from the resolved RGB; the tooltip names the preset and shade. Pane state still rolls up into one independent colored dot. The compact tab event target exposes the full title and a current-state assistive description, while the native action states distinguish hover, active, disabled, and keyboard focus.

`Ctrl+Shift+P` opens a borderless fuzzy action palette. `Rename active tab` invokes the same validated inline tab-label editor as the tab surface and uses `Ctrl+Shift+R` as a direct shortcut. `Lighten active tab color` and `Darken active tab color` use `Ctrl+Alt+=` and `Ctrl+Alt+-`. `Ctrl+Shift+F` searches the active Zig grid plus scrollback and highlights/navigates matches. Smart Tab filter labels use stack formatting on refresh (`smart_filter_label_stack=true`). `Ctrl+Shift+N` opens an autosaving workspace quick note; holding Alt paints that note in a compact tooltip on every mapped pane until release, using an explicit 4 KiB bounded preview read (`note_overlay_preview_bounded=true`), reusing one cached formatted overlay label for that preview lifetime (`note_overlay_cached=true`), and reusing one root-owned Pango font description for overlay paints (`note_overlay_font_cached=true`). `Ctrl+Shift+Z` zooms/restores a live pane, `Ctrl+Tab` and Alt+wheel cycle visible panes, `Ctrl+Shift+Tab` and Ctrl+Alt+wheel cycle tabs and Smart Tab-filtered views, `Alt+Arrow` selects the nearest pane using actual GTK geometry while preserving the held-note preview, `Ctrl+wheel up/down` scales only the pointed pane's terminal font, plain `Ctrl+C` interrupts only the active pane, plain `Ctrl+D` closes it, and `Ctrl+Shift+K` shows the shortcut card. Scrollback can be atomically saved as UTF-8 from the palette or context menu. GTK IM composition routes committed text through the PTY write callback.

The note preview reads the existing Zig-owned workspace note only when Alt is pressed. It requests a bounded preview from the Zig text-action ABI and allocates 4096 bytes instead of the full 1 MiB note-editor buffer; oversized notes return a prefix for display while the Quick Note editor still uses the strict full-note read path. Each visible drawing area renders the same validated UTF-8 text with native Pango wrapping, a three-line ellipsis limit, and a 320×92-logical-pixel cap in its upper-right corner. The formatted `Note · ...` draw label is cached once per preview lifetime rather than allocated per pane paint, and the stable `Sans 9` Pango font description is cached on the root context while layouts stay draw-local to the current Cairo context. Releasing Alt, hiding the dropdown, or losing top-level focus clears the shared preview state, frees both overlay-owned strings, and redraws all mapped panes; shutdown cleanup releases the cached font description. Hidden Smart Tab and pane-zoom siblings are never targeted.

`Open NoctEd Here` is available from the same palette and every terminal context menu. It resolves the right-clicked pane's live PTY cwd, locates `nocted` beside the running NOCTTY executable or on `PATH`, and starts NoctEd through GLib with that directory as the child process cwd. NoctEd does not automatically scan the directory: create or open an explicit `.npr` project when a file tree is needed. NOCTTY retains no child handle or editor state. Missing binaries and failed launches receive a native error dialog. The handoff gate requires `editor_binary=nocted editor_handoff=true directory_resolved=true editor_process_separate=true`.

NoctEd itself provides the native folder tree, tabs, translucent minimap, UTF-8 size policy, dirty markers, clean untitled buffers, native Save As, atomic first-save, syntax discovery, document and bounded project search, capped fuzzy quick-open, reversible folding, multi-file navigation/close actions, private hot-exit snapshots, and permission-preserving atomic replacement described in [NOCTED.md](NOCTED.md). Its capped structural-index delta and 4K/25K/100K model qualification boundary is retained in [NOCTED_PROJECT_INDEX_QUALIFICATION.md](NOCTED_PROJECT_INDEX_QUALIFICATION.md). Save/Discard/Cancel belongs to individual dirty-tab closure; application exit preserves the session directly. NOCTTY no longer carries a second editor implementation or document model.

NoctEd uses atomic hot-exit snapshots for dirty saved and untitled tabs, so graceful application close does not prompt; individual dirty-tab close still requires Save, Discard, or Cancel. A completed one-second idle snapshot may survive forced termination, but SIGTERM, SIGKILL, or desktop-session teardown cannot guarantee the newest sub-second edits.

Presentation mode, drop-down width, height, reveal duration, focus-loss hiding, optional focus-follows-pointer, and active-pane information visibility are live GUI settings. Changing between Drop-down and Windowed or Zen fullscreen rebuilds the native top-level around the existing notebook and split tree, because GTK cannot remove Wayland layer-shell from a realized window; sessions and workspace state remain live while the Settings surface closes with its replaced parent. Manual drag dimensions are converted to 1–100% monitor-relative values when the drag ends; legacy pixel overrides migrate to the same percentage model at startup, with invalid or oversized values falling back to the configured percentage. Behavior also owns an atomic launch-profile form plus a fixed library of up to eight names. Native controls save/replace, select, and delete complete shell/command/SSH/Persistent-tmux/Persistent-Zellij profiles; deleting a selected name preserves its values as custom current state. Settings version 16 retains the continuity kinds and eight-entry recent-workspace chooser in Project Workspace and adds bounded pane-gap and inactive-brightness settings; versions 1–15 remain importable. That dialog uses work-area-bounded sizing, a two-axis workspace-summary scroller, and assistive names for the summary and recent-workspace selector. Open and recent activation start another native NOCTTY process, validate the absolute `.nocttyws` path, and restore its model before PTY creation, leaving current sessions unchanged. Invalid intermediate edits do not replace the prior profile/library, and running sessions are unchanged. Reveal/hide uses `GtkRevealer`; two-pixel side targets resize width and a separate two-pixel bottom dragger resizes height while preserving top anchoring and persisting through the same Zig settings events. Terminal surfaces use the text cursor, side and dragger targets use cardinal resize cursors, and diagonal corner targets are absent in dropdown and windowed modes. Settings is an explicit transient, destroy-with-parent, keep-above dialog with work-area-bounded geometry and vertically stacked launch-profile actions so natural sizing cannot force an oversized window. Its Window/Behavior/Appearance category rows expose accessible names, 48-logical-pixel targets, destination-specific tooltips, selected-state contrast, and visible keyboard focus; opening the dialog focuses Window so keyboard navigation starts in a predictable place. Settings pages use vertical-only scrolling. Compact label columns and a narrower category rail/padding mode keep controls inside a 1440×900 work area at 2× GTK scale without clipping or a horizontal scrollbar. When the Plasma Wayland dropdown is an overlay layer surface, every owned dialog receives its own overlay surface and the parent is temporarily moved to the top layer; reference-counted teardown restores the parent overlay only after the final dialog closes. X11 and ordinary Wayland toplevels use native transient/keep-above relationships. A focus-out caused by NOCTTY's own context menu is deferred while its GTK grab is active, then rechecked after dismissal; owned project and Settings transients likewise keep their parent mapped. Explicit F10/D-Bus hides still pop down active menus before animation. Windowed mode exposes only the four cardinal resize targets. New tabs and splits inherit the active pane's cwd only when the active launch profile leaves cwd blank; a configured absolute cwd becomes both the pane model cwd and PTY cwd.

Every terminal drawing area also owns a zero-layout-cost resize OSD. Initial allocation is suppressed; later accepted PTY/grid size changes paint the current `columns × rows` value in a centered rounded translucent pill and restart a 750 ms hide timer. Dense pages with four or more panes automatically reduce only the effective rendered font enough to target an 80×24 PTY grid, down to a bounded 3 pt floor; the persisted pane font remains the user's requested size and returns when space permits. If even that floor cannot fit 80×24, the pill says `Min 3pt · columns × rows` instead of implying the target was met. An automatic reduction changes the pill to `Zoom N% · columns × rows`, including after startup arming, so the adjustment is visible without permanent chrome. Split handles, layout presets, the dropdown grip, and normal window edges share the same allocation path. The layout menu includes balanced 1×1, 2×2, 4×2, 3×3, and 4×4 presets. The mapped layout matrix retains nonblank content and routed input across 16-pane Vim and mixed btop/Vim pages on both Wayland and X11.

Ctrl+wheel is intercepted before terminal scrollback or application mouse reporting only while Ctrl is held. Discrete wheel notches change one point; smooth deltas accumulate per pane into whole steps. The host clamps through the configured font range, derives matching Cairo cell width/height, resizes only the pointed Zig grid and PTY, and emits the precise size into that pane's workspace profile. Neighboring panes and the global Settings default remain unchanged. For unmodified scrolling, the visible native scrollbar rail owns its hit target before terminal mouse reporting. Wheel events over terminal content use three bounded paths: DEC mouse-wheel reports when the application requested mouse tracking; local history when the application emitted alternate-screen full-scroll rows; or xterm-compatible repeated cursor-up/down input when an alternate-screen application has neither mouse tracking nor retained rows. Application-cursor mode selects SS3 instead of CSI arrow sequences. Shift-only wheel forces local history. This covers Codex and other alternate-screen TUIs without requiring `--no-alt-screen`; an application that ignores both standard mouse reports and cursor keys cannot be made internally scrollable by a terminal emulator. Codex inline mode still emits `CSI 1;0 r`, whose explicit zero DECSTBM parameter resolves to the viewport default.

Terminal point-to-pixel conversion and bounded cell dimensions are
allocation-free Zig policy shared by rendering, damage, pointer mapping, and
PTY resize paths. GTK supplies only the pane's current font setting.
Dirty row and cell-span invalidation rectangles are also Zig-computed. GTK
clamps them to the current widget allocation and queues the redraw.

Scrollbar geometry, thumb hit testing, saturated track-page targets, and
continuous drag-to-history mapping are allocation-free Zig policy. GTK retains
only pointer-event capture, focus, drawing invalidation, and scroll dispatch.

The built-in **Paseo Black Zinc** theme uses a pure-black terminal/workspace
surface with zinc-950 through zinc-50 chrome, zinc selection/scrollbar states,
and a bright ANSI palette. It is selectable in Settings beside NOCTTY Dark and
High Contrast and is stored in the normal theme library.

Raw GTK modifier masks and Alt/Meta key identity are normalized by Zig before
keyboard and pointer routing. The C adapter retains event delivery and GTK
focus/capture effects.

Tray menu IDs are bounded by Zig policy before D-Bus layout/property handling.
Resize-handle cursor orientation is likewise selected in Zig; GTK only creates
the cursor and applies the native window edge.

Tray-menu labels and icon names are also selected by Zig for every menu ID;
GTK supplies only the live presented state for the toggle label.

Resize-handle edge ordinals are bounded by Zig before GTK begins the native
window resize drag.

Resize-handle object data uses a 1-based GTK identifier; Zig normalizes it to
the bounded zero-based handle index consumed by resize routing.

Dimmed terminal colors use the model-selected active pane identity before
falling back to GTK focus state.

Terminal status labels are selected by Zig for the five protocol states;
GTK consumes the bounded string for tooltips and attention presentation.

Accessibility word, sentence, line, and paragraph range expansion is selected
by Zig from validated UTF-8 and normalized ATK granularity IDs; C retains
UTF-8 pointer conversion, returned text allocation, and ATK callback effects.

Keyboard-scroll actions, shortcut chord redraw/reopen effects, and terminal
renderer fallback RGB values are selected by tested Zig plans; C retains GTK
key delivery plus Cairo/Pango drawing and native surface effects.

Pane status tooltip composition, including pane identity and optional tags, is
bounded Zig text policy; C retains tag acquisition, cache comparison, GTK
tooltip/ATK description effects, and widget ownership.

Compact-tab markup, tooltip, close-name, escaping, truncation, and suffix
selection are bounded Zig text policy; C retains model/title acquisition,
GTK label and tab-color effects, accessibility naming, and native styling.

Recovery notice message precedence and composition are selected by Zig from
bounded startup flags; C retains InfoBar construction, response wiring, and
startup diagnostics.

Output presentation scheduling policy selects a mapped frame tick or a bounded
100 ms timeout fallback in Zig; C retains GTK source registration, callback
dispatch, and terminal pump effects.

Smart Tab empty-state/button text, cycle feedback labels, tab-title fallback
precedence, pane-zoom feedback, and notification body formatting are bounded
Zig policy; C retains model/cwd acquisition, GTK presentation, D-Bus dispatch,
and native state effects.

Zoom enter versus unzoom selection is a Zig state plan; C retains restoring
native visibility, hiding sibling panes, notebook effects, focus, and resize.

Settings shortcut button label and transport-specific tooltip composition are
bounded Zig text policy; C retains shortcut-key acquisition and GTK widget
application.

Note-overlay labels, window-title prefixes, close confirmations, layout-preset
prompts, find-status text, keyboard-shortcuts text, and sharing peer/tab/pane
labels are bounded Zig policy; C retains GTK allocation, dialog, combo-box,
and terminal-model effects.

Sharing-preview key-event classification and terminal sequence encoding are
selected by a tested Zig policy entry from raw GTK key values, modifiers, and
cursor mode; C retains clipboard requests, input transport, and transient
feedback effects.

Layout-preset event validation and rows/columns/target-count selection are a
tested Zig state plan; C retains pane enumeration, confirmation dialogs,
session movement, and GTK layout effects.

Settings-panel and background field normalization, bounded clamping, and
layout-effect classification are tested Zig state policy; C retains
per-context state copies, widget invalidation, window redraw, and event
emission.

Launch-profile payload serialization, profile-name edge validation, save-status
messages, and Noctalia theme persistence-status composition are bounded Zig
policy; C retains GTK entry acquisition, bounded allocation, text-action
dispatch, and native status effects.

Compact-setting target mapping, font-rendering combo bounds, terminal context-menu
action/selection geometry, theme display labels, and profile-preset validity are
tested Zig policy; C retains context state writes, clipboard/terminal effects,
GTK combo construction, and menu dispatch.

Windowed-dimension percentage/floor selection and launch-profile kind,
command-field, and SSH-target sensitivity policy are tested Zig plans; C
retains monitor queries, GTK size effects, combo-box state, and widget
sensitivity.

Restore-mode text, sharing combo-box IDs, pane drag identifiers, and terminal
accessibility names use bounded Zig formatting; C retains process spawning,
GTK selection/drag effects, and ATK application.

Terminal feedback labels are selected by Zig from bounded message IDs; C retains
the timeout source, GTK redraw, and status presentation effects.

Profile preset labels, including the `Custom` fallback, are selected by Zig
before GTK constructs the radio-menu items.

The broadcast menu label is selected by Zig from the live enabled state before
GTK builds the workspace menu.

Global shortcut identity strings for normal and smoke registrations are selected
by Zig before GTK/DBus registration.

Workspace event routing (tab, split, layout, and move classification), tray-menu
item kind/action classification, and bounded native lifecycle timing values are
tested Zig policy; C retains GTK/GVariant/GLib source and effect handling.
D-Bus `RequestName` ownership-result classification and shortcut
conflict/failure event identities are also selected by tested Zig policy; C
retains D-Bus calls, callback dispatch, and native effects.

Native host geometry bounds, scrollbar/copy limits, UI color role ordinals,
status event IDs, persistence result codes, and remaining GTK scheduling
intervals are tested Zig policy. C retains native object access, GTK effects,
GLib source registration, GVariant/D-Bus handling, and callback dispatch.
D-Bus call, notification, drain, and polling intervals are selected by the
tested Zig lifecycle plan; C retains GLib scheduling and D-Bus transport.
Settings-control event IDs for appearance, scrolling, layout, and font rendering
are selected by the tested Zig settings-event map; C retains GTK signal
connection, widget state, and native effect dispatch.
Persisted compact-setting field identities, defaults, font bounds, background
opacity normalization, and panel-metric clamps are selected by the tested Zig
settings plan; C retains model callback acquisition and native state updates.
Native host protocol event identities are selected by the tested Zig host-event
map; C retains callback dispatch and native effects.

Resize-handle grid coordinates and size requests are selected by tested Zig
policy for all eight grips; GTK retains widget creation, attachment, and
overlay placement.

Pane divider snap points and the proximity threshold are selected by tested Zig
policy; GTK retains the paned position query and update.

Command-palette IDs, labels, and hints are supplied by tested Zig policy;
GTK retains list construction, search filtering, and activation.

Command-palette dispatch effects, split orientation/rendered-event selection,
tab-rename boundary trimming/validation, and restored-session dimension minimums
are now tested Zig policies. GTK retains activation effects, inline editor
objects, split/layout mutation, and native session allocation.


Workspace color-editor labels and roles are supplied by tested Zig policy; GTK
retains settings-page widget creation.

Validated OSC 8 links accept only `http`, `https`, and `mailto`. `Ctrl+click` asks GTK to open the URI through the desktop's default application; right-clicking the link opens an owned menu with **Open Link in Browser** and **Copy Link**. Invalid encodings, control bytes, unsupported schemes, and oversized addresses fail closed.

Each terminal's native context menu now includes an exact-pane `Profile` submenu with five Zig-owned radio choices: Global default, Compact, Readable, High contrast, and Mono no ligatures. The current item is resolved from the right-clicked pane, and selection carries that pane ID even if another terminal owns keyboard focus. The narrow profile query synchronizes family, size, high-contrast state, ligature preference, and current preset into only the matching native context; Settings exposes the same path as `Active pane profile`. Readable drives the target to 14 pt, High contrast updates the target theme/rendering, and the focused two-pane proof keeps the neighbor unchanged through all three driven transitions before snapshot/autosave restoration. Mono no ligatures is an honest state boundary: the preference reaches GTK and persists, but the current fixed-cell Cairo renderer paints codepoints individually and does not prove font-feature shaping or visible ligature substitution.

Alt+wheel is intercepted before those terminal-scroll branches when Alt is held without Ctrl. Discrete down/up events move next/previous; smooth vertical deltas accumulate at the root context and become bounded whole steps. Traversal never leaves the active notebook page and considers only mapped live areas, so Smart Tab and zoom visibility are respected. GTK focus performs the Zig active-pane synchronization, while a Cairo overlay confirms the exact target and visible-pane ordinal.

Ctrl+Alt+wheel is intercepted before both pane navigation and Ctrl+wheel font scaling. Discrete down/up events select next/previous notebook pages with wraparound; smooth deltas accumulate separately at the root and become bounded whole steps. The normal page-switch focus handoff preserves the active Smart Tab filter and synchronizes Zig state, while a distinct purple Cairo overlay confirms the exact tab ordinal for 800 ms.

Plain terminal control chords are intercepted before IM and ordinary broadcast translation. `Ctrl+C` calls the focused context's PTY write callback directly with one ETX byte; copy remains `Ctrl+Shift+C`. `Ctrl+D` never sends EOT: it calls the same foreground-guarded close path as the pane menu, stops the exact PTY and pane-owned sources, collapses its GTK split or tab, and focuses the model-selected survivor. If only one terminal remains, the chord is consumed and final-pane protection leaves it running.

## Plasma Global Shortcut

The default F10 action is registered as `noctty/toggle-window` through Plasma GlobalAccel. Zig validates and encodes letters, digits, navigation/editing keys, F1–F12, and Shift/Ctrl/Alt/Super modifiers.

Registration:

1. asks Plasma whether the key is available;
2. assigns the shortcut;
3. verifies Plasma returned the requested key set;
4. maps registered, conflict, and failed outcomes into Zig receipts.

Only a confirmed registration permits hidden startup. Conflict or transport failure keeps the window visible so the user is never stranded. Teardown unregisters the temporary action.

The native recorder captures the same key model. Esc cancels; successful re-registration closes and atomically persists the configuration; denial/conflict remains visible and unsaved. The live X11 release lane sends a physical F10 through Plasma to a hidden grid and requires signal receipt, visible activation, focus, and cleanup.

Wayland physical HID automation is deliberately separate from product shortcut support. Plasma GlobalAccel works normally, while synthetic RemoteDesktop/EIS input requires an interactive compositor permission session. The probe reports that consent boundary without claiming unattended injection.

## System Tray

The default native host exports `/StatusNotifierItem` on the session bus and registers it with Plasma's `org.kde.StatusNotifierWatcher`. It advertises the stable `com.noctty.NOCTTY` icon name and a real 48-pixel ARGB fallback, remains `Active` while the terminal is hidden, updates its tooltip after visibility changes, and re-registers if the watcher restarts. `ProvideXdgActivationToken` retains one validated token only until the next hidden-window presentation, applies it through GTK's startup-ID API, then clears it. Primary activation toggles the terminal and secondary activation opens Settings. The item also exports `/MenuBar` through the standard native `com.canonical.dbusmenu` contract, allowing Plasma to render dynamic `Show NOCTTY`/`Hide NOCTTY`, `Settings…`, and `Close NOCTTY` actions on right-click under Wayland or X11. Close removes all pane sources, closes each active Zig PTY, leaves the GTK loop, and unregisters both objects so no stale tray item remains. Any standalone NoctEd process remains independent and mapped.

## Noctalia Shell Activation

Noctalia is a desktop shell rather than a compositor, and its official guidance keeps global keybinds in Niri, Hyprland, Sway, Scroll, Labwc, or MangoWC. NOCTTY therefore exposes a stable native activation command instead of pretending Noctalia owns a GlobalAccel equivalent.

The running host owns `com.noctty.NOCTTY` and accepts `GetState`, `Show`, `Hide`, `Toggle`, and bounded one-use `ShowWithActivation`/`ToggleWithActivation` calls. `noctty --toggle` routes to that instance or starts a visible one when none exists. Before settings, sharing identity, PTY, or GTK state is created, the primary dropdown takes a per-user native lock; losing concurrent launchers forward Show and exit. D-Bus name conflict handling remains the fallback. Compositor autostart uses `noctty --hidden`, which waits for the control endpoint before hiding. The Settings recorder persists the same key model and `noctty --noctalia-plan <compositor>` renders the matching current keybind and autostart syntax. Installed F10 fragments and an optional Noctalia v5 compact bar button live under `share/noctty/noctalia/`; see [NOCTALIA.md](NOCTALIA.md).

## Placement

On X11/XWayland, dropdown mode requests the configured work-area percentages (96%×55% by default) at the top edge, subject to the 480×240 usable floor, then reads back position and dimensions.

On Wayland, ordinary toplevel clients cannot choose absolute placement. NOCTTY dynamically uses GTK3 layer-shell before realization and publishes `noctty-dropdown` on the overlay layer with top/left/right anchoring, monitor-relative sizing, recomputed symmetric width margins, no exclusive zone, and on-demand keyboard focus on protocol v4+ while mapped (exclusive only as an old-protocol fallback). A completed manual resize is stored as a percentage, so the dropdown retains its proportions when its monitor changes size. Hide first commits keyboard mode `NONE`, then unmaps one frame later when no reveal animation is configured, so KWin does not have to revoke focus and destroy the cold layer surface in one transition. The protocol works under Plasma and the wlroots-family compositors supported by Noctalia. Runtime loading uses only the `libgtk-layer-shell.so.0` system soname. Distribution packages provide it; bundles and the dogfood installer copy that provenance-checked system library into a launcher-owned private path. The repository no longer redistributes a prebuilt fallback.

## GUI Services

- Ctrl+Shift+V reads GTK clipboard data asynchronously, sends it through Zig
  control stripping and bracketed-paste marker policy, and delivers it to the
  active PTY. Sharing-preview control keys, editing/function-key sequences,
  arrow sequences, paste limit/chunk sizing, scroll-direction mapping,
  selection-index parsing/formatting, and normalized pane hit testing use
  Zig-owned policies; Alt-prefixed text uses the same bounded Zig policy. GTK
  retains modifier-state extraction, clipboard retrieval, chunking, and sharing
  transport. The common literal policy performs two bounded scans and one exact
  allocation from the owning session allocator
  (`literal_paste_single_pass=true`, `paste_session_allocator=true`).
- Pane state updates a thin status border and tooltip; the tooltip includes current tags when present, is stack-formatted, and skips repeated GTK setter calls when unchanged (`pane_tooltip_dedup=true`). Configured process completion sends `org.freedesktop.Notifications.Notify`.
- Settings controls dispatch typed Zig commands and atomically persist mode,
  drop-down geometry/reveal/focus behavior, global shortcut, tab position, font,
  theme, status, metrics, notifications, and the `Active pane profile`. Plasma
  captures re-register live; Noctalia captures update the generated compositor
  plan. Tab placement, drop-down sizing, and exact-pane profile changes apply
  immediately and restore during host startup; theme color-editor RGB-channel
  extraction and clamped CSS-hex formatting use Zig-owned policy before the
  typed settings action.
- Theme Library file selection routes Ghostty, Xresources, and simple Alacritty text into Zig parsing/install/select state.
- Project / NoctEd routes workspace file choosers into Zig snapshots and starts standalone NoctEd at the selected pane directory. Opening this GUI performs the bounded project refresh; terminal-only sessions do not repeatedly launch background git subprocesses. Project scans prune generated/vendor directories, check the file-entry cap before path duplication (`project_scan_pruned=true`), and check git status/graph caps before cloning overflow rows (`git_parse_cap_before_alloc=true`).
- A root-owned GLib timer executes due autosave and recovery cleanup, and records lightweight deferred project-refresh receipts until the Project / NoctEd GUI requests fresh data.
- Every accepted workspace mutation writes through to the atomic hot-session file. Divider notifications update the corresponding Zig split node and coalesce their atomic flush, while settings retain their immediate config-file save path.
- Session Sharing presents the shared Zig pairing/host/viewer state through one
  workarea-bounded native dialog. Controls are sensitive only in valid states;
  stopped/failed roles remain explicitly clearable, revocation confirms before
  removing a peer from actionable choices, and paired-device persistence errors
  expose a retry without converting them into a hard workspace-sync failure.
  Remote key/paste denial remains visible, remote paste is capped at 64 KiB,
  and closing the dialog tears down discovery, pairing, hosting, and receiving
  because no separate persistent sharing indicator exists.

## Native C ownership inventory

`scripts/check_native_c_classification.py` parses the exact top-level function
inventory in `src/gui/native_grid_host.c` and requires one classification row
for every definition in `scripts/native_grid_c_classification.tsv`. The
classes are `query`, `effect`, and `lifetime` for native GTK/ATK/Cairo/Pango
adapter work, `migrated_policy` when the function consumes a Zig policy plan,
and `orchestration` for display-backed qualification. `remaining_policy` is
the only C class counted against Zig ownership; it is intentionally empty in
the locked tree. Missing, stale, or duplicate rows fail the checker.

The ownership denominator is first-party nonblank Zig source plus explicitly
remaining C policy lines. ABI headers, native effects, generated/vendor
content, and display orchestration are reported but excluded from that
denominator. The current inventory has 630 classified C functions,
`remaining_policy_functions=0`, and the checker receipt is:

```text
zig_ownership zig_lines=91721 adapter_lines=0 percentage=100.00 target=90.00 policy_scope=first_party_zig_plus_remaining_c_policy vendor_generated_excluded=true display_orchestration_excluded=true headers_and_native_effects_excluded=true
```

## Ghostty and VTE

The installed public Ghostty package and pinned upstream commit `53bd14f` do not expose a supported Linux GUI platform surface. NOCTTY does not load another package's private `libghostty.so` and does not maintain a fork.

The source-backed [performance and algorithm research](PERFORMANCE_ALGORITHM_RESEARCH.md) keeps this renderer decision intact. NCT-119 is complete. The [display-independent renderer receipt](NATIVE_GRID_RENDERER_QUALIFICATION.md) retains 384 exact synthetic draws per mode; the [terminal pipeline receipt](TERMINAL_PIPELINE_QUALIFICATION.md) feeds that draw path through a real shell, PTY, `TerminalSession`, VT, and ABI-v7 packed frame snapshots; the [mapped presentation receipt](NATIVE_GRID_PRESENTATION_QUALIFICATION.md) retains the GTK frame-clock path and compositor feedback.

The synthetic renderer contract remains `native_grid_renderer_qualification_matrix debug=true release_safe=true frames_per_scenario=128 scenarios=3 pixel_repeat_exact=true cross_mode_artifacts_identical=true idle_draw_cpu=true fullscreen_draw_cpu=true rich_style_draw_cpu=true owned_allocation_counts=true warm_frame_owned_allocations=0 resize_growth_bounded=true resize_shrink_allocations=0 process_memory=true scratch_clean=true`.

The installed application contract remains `terminal_real_tui_matrix debug=true release_safe=true applications=codex,vim,btop codex_login_surface=true codex_sync_output=true vim_alternate_screen=true vim_bracketed_paste=true btop_alternate_screen=true btop_mouse=true btop_truecolor=true unicode=true rich_style=true input_routed=true foreground_identity=true controlled_exit=true allocator_leak_free=true root_memory_separate=true process_tree_memory=true scratch_clean=true`.

The supported renderer is NOCTTY's Zig PTY/VT grid. The `src/ghostty` adapter remains isolated for future public ABI probing, and no Ghostty-rendering claim is made. The prior GTK/VTE host is now Zig-owned and retained only in the optional `noctty-vte` binary; its preset callbacks use the correct context, owned combo text and spawn errors are released, recorder-dialog destruction clears retained pointers, and pending smoke sources are removed during teardown (`native_host_callback_cleanup=true`):

```sh
zig build vte-fallback
./zig-out/bin/noctty-vte --native-host
NOCTTY_RENDERER=vte ./zig-out/bin/noctty-vte
```

Production `noctty` does not link VTE or Tree-sitter and rejects fallback, smoke, and legacy-editor commands. VTE is not a distribution runtime dependency; its development files are needed only to compile the optional fallback or the complete check/smoke matrix. Smoke binaries are non-default and excluded from release archives.

## Release Evidence

Focused backend receipts from the maintained isolated runners:

```text
NOCTTY_ISOLATED_DISPLAY_TIMEOUT_SECONDS=300 ./scripts/native_grid_smoke.sh
native_grid_renderer_smoke abi=7 frame_batches=10 damage_rows=53 damage_cells=5222 damage_spans=10 damage_source=dirty_spans glyph_batches=60 glyph_cells=4648 glyph_cache_hits=4648 glyph_fallback_conversions=0 grapheme_cells=10 rich_style_cells=131 frame_presentations=7 timeout_presentations=0 resize_requests=2 resize_commits=1 sync_deferrals=4 sync_releases=1 sync_deadman_releases=1 passed=true
native_grid_renderer_backend backend=x11 isolated=true abi=7 passed=true
native_grid_renderer_smoke abi=7 frame_batches=9 damage_rows=53 damage_cells=5222 damage_spans=10 damage_source=dirty_spans glyph_batches=53 glyph_cells=3926 glyph_cache_hits=3926 glyph_fallback_conversions=0 grapheme_cells=8 rich_style_cells=105 frame_presentations=7 timeout_presentations=0 resize_requests=2 resize_commits=1 sync_deferrals=4 sync_releases=1 sync_deadman_releases=1 passed=true
native_grid_renderer_backend backend=wayland isolated=true abi=7 passed=true
native_grid_renderer_matrix x11=true wayland=true abi=7 dirty_spans=true frame_clock=true glyph_cache=true resize_coalesced=true synchronized_output=true deadman=true warning_fatal=true
```

The isolated Wayland Settings and compact-UX lanes also exited 0 with their
complete receipts. All graphical commands above used serialized private
display/session namespaces; no active desktop display was used.

`scripts/native_release_smoke.sh` consolidates the display-backed proof. Its expected successful receipt is:

```text
native_release_smoke renderer=true modes=true tabs=true tab_add=true tab_reorder=true tab_reorder_pointer_drag=true late_callback_guard=true popup_teardown=true window_controls=true tab_rename=true tab_color=true profile_presets=true navigation=true alt_scroll=true ctrl_alt_scroll=true tab_close=true pane_close=true terminal_chords=true layout_presets=true layout_tui=true resize_overlay=true window_resize=true tray=true splits=true recursive_splits=true eight_panes=true click_focus=true clean_selection=true pane_move=true pane_scrollbar=true live_tab_position=true compact_ux=true note_overlay=true hot_session=true clipboard=true notifications=true settings=true settings_stacking=true themes=true project=true workspace_activation=true recent_workspaces=true nocted_handoff=true nocted=true maintenance=true workspace=true shortcut=true noctalia_ipc=true hidpi=true
```

The focused profile gate reports `native_grid_profile_preset_smoke context_menu=true submenu=true menu_survived=true presets=5 exact_target=true current=true readable=true font_size=14 isolated=true high_contrast=true rendered=true mono_no_ligatures=true workspace_dirty=true snapshot=true restored=true exited=true`; its repeated backend matrix reports `native_grid_profile_preset_matrix wayland=true x11=true exact_target=true isolated=true persisted=true restored=true`.

The tab-close/add and inline-rename prerequisite lanes use state-driven orchestration under the aggregate gate. Background-tab close waits for the native popup to be mapped before focus-loss and activation, then chains close validation into fresh-tab reopen and cleanup. Rename uses bounded retries until two tabs and the selected tab label are mapped, while read-handshake PTYs remain alive until the harness explicitly finishes. These are proof-determinism safeguards; they do not add product behavior or change the receipts below.

Focused gates additionally preserve:

- exact Wayland layer-shell and X11 top-edge placement;
- live 1440×900 → 1024×640 → 1440×900 output changes with exact 96%×55%
  dropdown reflow and current-monitor fullscreen compositor frames;
- dynamic pane and tab lifecycle;
- cross-backend hot-session reconstruction of two customized tabs and five live panes, including recursive ratios, active identity, titles/colors/tags/Smart Tab/profile/settings/cwd, plus corrupt-file fallback;
- double-click and command-palette tab rename, inline entry with no popup, outside-click cancel, Enter commit, validation, visible title update, focus restoration, Zig writeback, and snapshot round trip;
- exact-tab native color preset activation, resolved RGB/contrast rendering, active-tab lighten/darken keyboard routing, reversible shade state, dirty marking, and snapshot round trip;
- exact-pane five-item `Profile` submenu routing, current-item state, Readable 14 pt geometry, High contrast rendering, Mono no ligatures preference delivery, neighboring-pane isolation, dirty marking, and snapshot/autosave restoration on Wayland/X11;
- leading `+` activation from the default one-tab row and again after closing the original host tab, including accessible/icon placement, fresh-session allocation, cleanup, and persistent one-tab availability;
- trailing Settings then Close controls in Yakuake order, including mapped placement, system-theme icons, accessibility names, native Settings activation, all-session PTY shutdown, and clean exit;
- background-tab right-click close with app-first acceptance, PTY teardown, persistent one-tab chrome, and surviving-tab focus/lifecycle;
- exact pane-context `Close Terminal` with popup survival, model-first removal, primary PTY teardown, split collapse, root-controller survival, secondary focus/lifecycle, and final-terminal protection;
- cross-backend plain `Ctrl+C` focused-pane-only ETX delivery while broadcast is enabled, plus no-EOT exact-pane `Ctrl+D` teardown, surviving focus, and final-pane protection;
- real context-menu 2×2 and 3×3 materialization with four/nine mapped live PTYs and balanced coordinate bands, absence of the redundant New 1×1 entry, and internal single-pane teardown with survivor focus;
- centered live `columns × rows` resize OSDs on both sides of a moved divider, including initial suppression and 750 ms timeout;
- eight-direction outer-window resizing plus side/bottom/corner dropdown resize targets;
- live StatusNotifier watcher registration, named and pixmap icon delivery, hide/show activation, Settings activation, standard right-click menu layout, `Close NOCTTY` PTY shutdown, and clean watcher teardown;
- Settings transient ownership, simultaneous parent/dialog visibility, above-parent compositor stacking, parent-layer restoration, and accessible/focusable category navigation on both Wayland and X11;
- recursive four-session and balanced eight-session rendering with vertical Split Down and horizontal Split Left assertions;
- click-to-focus switching plus distinct primary/secondary PTY input delivery;
- click/release/hover selection-state proof with no pointer-motion trails;
- selection-free nested lower-pane double-click zoom to full page, exact branch restoration, and preserved ordinary drag selection;
- context-menu pane reparenting, moved-pane focus, and last-pane source-tab closure;
- cross-backend visible-pane `Ctrl+Tab` and same-tab Alt+wheel cycling, including both pane-wheel directions, hidden-pane exclusion, and transient `Pane n / total` feedback; Smart Tab-preserving `Ctrl+Shift+Tab` and Ctrl+Alt+wheel tab cycling, including both tab-wheel directions, last-to-first wraparound, transient `Tab n / total` feedback, explicit PageUp/PageDown aliases, shortcut close/reopen, and reopened-tab focus restoration;
- live and startup-restored bottom tab placement;
- transient palette, scrollback find/save, quick-note persistence, zoom/restore, directional focus, bell attention, IM context, same-cwd split, and minimal resize-grip proof;
- Wayland/X11 hold-Alt note overlays with multiline UTF-8 content, every-visible-pane rendering, compact geometry, release-to-hide, and clean session exit;
- Wayland/X11 clipboard round trips;
- settings/theme persistence and fresh-App reload, including version-9 bounded launch-profile/recent-workspace state, versions 1–8 migration, rendered save/select/delete, a real post-reload command PTY with the selected cwd, environment, and history, a separate headless real-OpenSSH disposable public-key authentication case, and exact tmux/Zellij create-or-attach dispatch through the product PTY (`launch_profile=true`, `launch_library=true`, `launch_saved=true`, `launch_selected=true`, `launch_deleted=true`, `launch_runtime=true`, `credentialed_ssh=true`, `launch_continuity_matrix debug=true release_safe=true kinds=tmux,zellij direct_argv=true create_or_attach=true production_pty=true cwd=true environment=true controlled_exit=true allocator_leak_free=true tool_shims=true installed_tools=false live_reattach=false scratch_clean=true`), complemented by installed tmux 3.7b/Zellij 0.44.3 mapped detach/relaunch/reattach proof;
- bounded local `noctty:`/`file:` workspace activation, validated pre-PTY snapshot restore, the persisted eight-entry MRU, and the native Recent Workspaces control (`workspace_activation=true`, `recent_workspaces=true`); the disposable installed-desktop/MIME contract and live `gio` plus rendered child-window lane now pass on Plasma Wayland/X11;
- focus-safe `Open NoctEd Here` process handoff plus standalone project tree, translucent minimap, project/search-result activation, document/project find, reversible folding, multi-file controls, clean/dirty untitled states, duplicate-safe Save As, syntax re-detection, capped quick-open activation/capture, undo/redo, and atomic-save render proof; the legacy compatibility lane retains direct-modal deferral, dirty window-delete Cancel, save-failure survival, natural last-PTY retry, and final Save/Discard coverage;
- autosave/project-refresh/recovery-cleanup execution;
- physical X11 F10 GlobalAccel activation;
- live Wayland `noctty-dropdown` layer-shell plus D-Bus hidden/status/show/hide/toggle and single-instance activation;
- scale-2 font and high-contrast rendering.

Graphical gates must not use the developer's active display. The maintained focused lanes use `scripts/run_isolated_x11.sh` (the shared pressure-gated mount/PID/IPC/network namespace, private D-Bus/X server, and private HOME/XDG/TMP paths) or `scripts/run_isolated_wayland.sh` (private D-Bus + virtual KWin), with serialized execution, bounded timeouts, and process-tree cleanup. `scripts/verify.sh` admits graphical proof before heavy process/build qualification and retries status-75 pressure deferrals for at most one minute without lowering thresholds or retrying assertion failures. Source-tree binaries use the shared bubble; package artifacts scoped below `/dev/shm` use the reviewed private-socket fallback because the bubble intentionally masks that mount. The aggregate proves both isolation boundaries, inventories 39 self-isolating and 20 dedicated-session wrappers, and runs pane-close plus activation regression coverage there. The broader `scripts/native_release_smoke.sh` and final Noctalia-compositor acceptance require `NOCTTY_DEDICATED_DISPLAY=1` inside a disposable dedicated VM/container compositor session and refuse the active desktop by default. Physical compositor/HID acceptance remains a separate external boundary.

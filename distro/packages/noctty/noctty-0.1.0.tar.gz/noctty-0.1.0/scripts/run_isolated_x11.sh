#!/bin/sh
set -eu

if [ "$#" -eq 0 ]; then
  echo 'run_isolated_x11 error=command_required' >&2
  exit 2
fi
case "${NOCTTY_ISOLATED_DISPLAY_TIMEOUT_SECONDS:-300}" in
  ''|*[!0-9]*)
    echo 'run_isolated_x11 error=invalid_timeout' >&2
    exit 2
    ;;
esac
if [ "${NOCTTY_ISOLATED_DISPLAY_TIMEOUT_SECONDS:-300}" -lt 1 ]; then
  echo 'run_isolated_x11 error=invalid_timeout' >&2
  exit 2
fi

timeout_seconds=${NOCTTY_ISOLATED_DISPLAY_TIMEOUT_SECONDS:-300}
screen=${NOCTTY_ISOLATED_DISPLAY_SCREEN:-1440x900x24}
screen_width=${screen%%x*}
screen_tail=${screen#*x}
screen_height=${screen_tail%%x*}
screen_depth=${screen_tail#*x}
case "$screen_width:$screen_height:$screen_depth" in
  *[!0-9:]*|:*|*::*|*:|'')
    echo 'run_isolated_x11 error=invalid_screen' >&2
    exit 2
    ;;
esac
case "$screen_depth" in
  16|24|32) ;;
  *)
    echo 'run_isolated_x11 error=invalid_screen' >&2
    exit 2
    ;;
esac
if [ "$screen_width" -lt 1 ] || [ "$screen_height" -lt 1 ]; then
  echo 'run_isolated_x11 error=invalid_screen' >&2
  exit 2
fi

script_dir=$(CDPATH= cd -- "$(dirname "$0")" && pwd -P)
shared_runner=${OVERZEER_DISPLAY_RUNNER:-$script_dir/isolated_display_runner.sh}
window_manager=${NOCTTY_ISOLATED_X11_WM:-auto}
if [ "${NOCTTY_LEGACY_DISPLAY_RUNNER:-0}" != 1 ]; then
  if [ ! -x "$shared_runner" ]; then
    echo 'run_isolated_x11 error=shared_isolated_display_runner_missing' >&2
    exit 2
  fi
  exec env TMPDIR=/tmp \
    "$shared_runner" --screen "$screen" --timeout "$timeout_seconds" \
      --wm "$window_manager" -- \
    env XDG_SESSION_TYPE=x11 GDK_BACKEND=x11 NO_AT_BRIDGE=1 \
      NOCTTY_ISOLATED_DISPLAY=x11 NOCTTY_SHARED_ISOLATION=1 \
    sh -eu -c '
      root=$(mktemp -d /tmp/noctty-isolated-home.XXXXXX)
      mkdir -p "$root/home" "$root/config" "$root/state" \
        "$root/cache" "$root/data" "$root/tmp"
      export HOME="$root/home"
      export XDG_CONFIG_HOME="$root/config"
      export XDG_STATE_HOME="$root/state"
      export XDG_CACHE_HOME="$root/cache"
      export XDG_DATA_HOME="$root/data"
      export TMPDIR="$root/tmp"
      exec "$@"
    ' sh "$@"
fi

for command in dbus-run-session flock timeout xvfb-run; do
  if ! command -v "$command" >/dev/null 2>&1; then
    echo "run_isolated_x11 error=missing_tool tool=$command" >&2
    exit 2
  fi
done

lock_root="/tmp/noctty-isolated-display-$(id -u)"
if ! mkdir -m 0700 "$lock_root" 2>/dev/null; then
  if [ ! -d "$lock_root" ] || [ -L "$lock_root" ] ||
    [ "$(stat -c %u "$lock_root")" != "$(id -u)" ] ||
    [ "$(stat -c %a "$lock_root")" != 700 ]; then
    echo "run_isolated_x11: unsafe shared lock directory: $lock_root" >&2
    exit 1
  fi
fi
lock="$lock_root/runner.lock"
scratch=$(mktemp -d "${TMPDIR:-/tmp}/noctty-isolated-x11.XXXXXX")
cleanup() {
  if ! rm -rf "$scratch" 2>/dev/null; then
    sleep 0.1
    rm -rf "$scratch"
  fi
}
trap cleanup EXIT
trap 'exit 129' HUP
trap 'exit 130' INT
trap 'exit 143' TERM
chmod 0700 "$scratch"
mkdir -p "$scratch/home" "$scratch/config" "$scratch/state" \
  "$scratch/cache" "$scratch/data" "$scratch/runtime" "$scratch/tmp"
chmod 0700 "$scratch/runtime"

unset DISPLAY WAYLAND_DISPLAY
export NOCTTY_ISOLATED_DISPLAY_TIMEOUT_SECONDS="$timeout_seconds"
export NOCTTY_ISOLATED_X11_ROOT="$scratch"
flock -x -w "$timeout_seconds" "$lock" \
  timeout --kill-after=10 "$timeout_seconds" \
  env HOME="$scratch/home" XDG_CONFIG_HOME="$scratch/config" \
    XDG_STATE_HOME="$scratch/state" XDG_CACHE_HOME="$scratch/cache" \
    XDG_DATA_HOME="$scratch/data" XDG_RUNTIME_DIR="$scratch/runtime" \
    TMPDIR="$scratch/tmp" \
  dbus-run-session -- xvfb-run -a -s "-screen 0 $screen -nolisten tcp" \
  sh -eu -c '
    scratch=$NOCTTY_ISOLATED_X11_ROOT
    export HOME="$scratch/home"
    export XDG_CONFIG_HOME="$scratch/config"
    export XDG_STATE_HOME="$scratch/state"
    export XDG_CACHE_HOME="$scratch/cache"
    export XDG_DATA_HOME="$scratch/data"
    export XDG_RUNTIME_DIR="$scratch/runtime"
    export TMPDIR="$scratch/tmp"
    export XDG_SESSION_TYPE=x11
    export GDK_BACKEND=x11
    export NO_AT_BRIDGE=1
    export NOCTTY_ISOLATED_DISPLAY=x11
    unset WAYLAND_DISPLAY
    "$@"
  ' sh "$@"

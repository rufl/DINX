#define UNICODE 1
#define _UNICODE 1
#define WIN32_LEAN_AND_MEAN 1
#define NOMINMAX 1
#define _FORTIFY_SOURCE 0

#include <windows.h>
#include <bcrypt.h>
#include <commctrl.h>
#include <commdlg.h>
#include <dbghelp.h>
#include <dpapi.h>
#include <richedit.h>
